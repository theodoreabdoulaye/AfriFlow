import type { CityDef } from "./cities";

/**
 * Géocodage réel via Nominatim (OpenStreetMap, sans clé API).
 * Politique d'usage respectée : User-Agent identifié, requêtes
 * sérialisées (au plus ~1/s), caches mémoire (30 min par requête).
 * Les requêtes sont restreintes à la ville active (viewbox + bounded).
 */

export interface GeoPlace {
  name: string;
  displayName: string;
  lat: number;
  lon: number;
  kind: string; // université, marché, gare…
}

const searchCache = new Map<string, { at: number; value: GeoPlace[] }>();
const CACHE_MS = 30 * 60_000;

let queue: Promise<void> = Promise.resolve();
function throttle(): Promise<void> {
  const run = queue.then(() => new Promise<void>((r) => setTimeout(r, 210)));
  queue = run;
  return run;
}

const KIND_LABELS: Record<string, string> = {
  university: "université",
  school: "école",
  hospital: "hôpital",
  marketplace: "marché",
  bus_station: "gare routière",
  fuel: "station-service",
  place_of_worship: "lieu de culte",
  stadium: "stade",
  hotel: "hôtel",
  restaurant: "restaurant",
  bank: "banque",
  pharmacy: "pharmacie",
  police: "commissariat",
  townhall: "mairie",
  airport: "aéroport",
  harbour: "port",
  ferry_terminal: "embarcadère",
  neighbourhood: "quartier",
  suburb: "quartier",
  quarter: "quartier",
};

function kindLabel(type: string | undefined, category: string | undefined): string {
  if (type && KIND_LABELS[type]) return KIND_LABELS[type];
  if (category === "amenity") return "point d'intérêt";
  if (category === "place") return "quartier";
  return "lieu";
}

/** Recherche d'adresses/POI dans le périmètre de la ville (bbox ±0,35°). */
export async function searchPlaces(city: CityDef, query: string, limit = 6): Promise<GeoPlace[]> {
  const q = query.trim().slice(0, 80);
  if (q.length < 2) return [];
  const cacheKey = `${city.id}:${q.toLowerCase()}`;
  const hit = searchCache.get(cacheKey);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.value;

  const delta = 0.35;
  const viewbox = `${city.lon - delta},${city.lat + delta},${city.lon + delta},${city.lat - delta}`;
  const url =
    `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=${limit}` +
    `&q=${encodeURIComponent(`${q}, ${city.name}, ${city.country}`)}` +
    `&viewbox=${viewbox}&bounded=1&addressdetails=0`;

  await throttle();
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": "AfriFlow/2.5 (plateforme trafic Afrique de l'Ouest; contact: dev@afriflow.app)" },
      signal: AbortSignal.timeout(8000),
      cache: "no-store",
    });
    if (!res.ok) return [];
    const json = (await res.json()) as {
      display_name?: string;
      name?: string;
      lat?: string;
      lon?: string;
      type?: string;
      category?: string;
    }[];
    const places: GeoPlace[] = (Array.isArray(json) ? json : [])
      .map((p) => {
        const lat = Number(p.lat);
        const lon = Number(p.lon);
        if (!Number.isFinite(lat) || !Number.isFinite(lon)) return null;
        const short = (p.name || p.display_name || q).split(",").slice(0, 2).join(", ");
        return {
          name: short.slice(0, 90),
          displayName: (p.display_name ?? short).slice(0, 180),
          lat,
          lon,
          kind: kindLabel(p.type, p.category),
        };
      })
      .filter((p): p is GeoPlace => p !== null);
    searchCache.set(cacheKey, { at: Date.now(), value: places });
    return places;
  } catch {
    return [];
  }
}

/** Adresse approximative d'un point GPS (reverse), best-effort et cachée. */
export async function reversePlace(city: CityDef, lat: number, lon: number): Promise<string | null> {
  const cacheKey = `rev:${lat.toFixed(3)},${lon.toFixed(3)}`;
  const hit = searchCache.get(cacheKey);
  if (hit?.value[0]?.name) return hit.value[0].name;
  try {
    await throttle();
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${lat}&lon=${lon}&zoom=16`,
      {
        headers: { "User-Agent": "AfriFlow/2.5 (plateforme trafic Afrique de l'Ouest; contact: dev@afriflow.app)" },
        signal: AbortSignal.timeout(7000),
        cache: "no-store",
      },
    );
    if (!res.ok) return null;
    const json = (await res.json()) as { display_name?: string; name?: string };
    const name = (json.name || json.display_name || "").split(",").slice(0, 2).join(", ").slice(0, 90);
    return name || null;
  } catch {
    return null;
  }
}
