"use client";

import { useCallback, useEffect, useState } from "react";
import {
  BrainCircuit,
  Bus,
  Camera,
  CheckCircle2,
  CloudSun,
  Database,
  Loader2,
  Map as MapIcon,
  MessageCircle,
  Navigation,
  Radar,
  Radio,
  RefreshCw,
  Satellite,
  Signal,
  Truck,
  Waves,
  Wind,
  XCircle,
} from "lucide-react";
import { CITY_COUNT, CITY_MAP } from "@/lib/cities";
import type { SourcesPayload } from "@/lib/api-types";
import { useApp } from "./AppClient";

const SOURCE_ICONS: Record<string, typeof CloudSun> = {
  "open-meteo": CloudSun,
  overpass: MapIcon,
  glofas: Waves,
  air: Wind,
  telemetry: Satellite,
  fleets: Truck,
  here: Radar,
  transit: Bus,
  waze: Navigation,
  whatsapp: MessageCircle,
  vision: Camera,
};

const FOUR_SOURCES = [
  {
    num: "01",
    icon: Signal,
    title: "Crowdsourcing léger",
    badge: "En direct",
    live: true,
    text: "Ping GPS anonymisé toutes les 30-60 s, uniquement en mouvement. ≈2 Mo/mois, batterie préservée, même sur Android d'entrée de gamme.",
  },
  {
    num: "02",
    icon: Radio,
    title: "Données télécoms agrégées",
    badge: "Partenariats opérateurs",
    live: false,
    text: "Densité de mobiles par cellule (Orange, MTN, Moov, Airtel), anonymisée. La densité de téléphones = un excellent proxy de congestion. Flux en cours d'intégration avec les opérateurs — pas encore dans le moteur.",
  },
  {
    num: "03",
    icon: Truck,
    title: "Flottes partenaires",
    badge: "En direct",
    live: true,
    text: "GPS des transporteurs et livreurs (Gozem, Yango, logisticiens locaux), échangés contre un accès Premium gratuit à la plateforme.",
  },
  {
    num: "04",
    icon: MapIcon,
    title: "OpenStreetMap + terrain",
    badge: "En direct",
    live: true,
    text: "OSM, souvent plus à jour que Google sur les routes secondaires. Chaque nid-de-poule validé par la communauté enrichit la carte.",
  },
];

const PIPELINE = [
  {
    title: "Ingestion multi-canal",
    text: "GPS géolocalisés (app + partenaires via API), signalements communautaires, chantiers OpenStreetMap — stockés en PostgreSQL, rattachés à l'axe le plus proche (< 400 m).",
  },
  {
    title: "Moteur temps réel",
    text: "Vitesse moyenne par segment par lissage exponentiel (α=0,3) — porté du prototype Rust/axum.",
  },
  {
    title: "Prédiction IA 15-60 min",
    text: "Profils horaires (jour × heure) fusionnés à la météo Open-Meteo, aux débits GloFAS et aux incidents validés — validés en continu sur les GPS réels (voir ci-dessus).",
  },
  {
    title: "Ventilation + quotas",
    text: "Décision de délestage dosée : 8-30 % du trafic, quotas MFD, zones protégées verrouillées à 80 %.",
  },
  {
    title: "Routage repondéré",
    text: "Plus court chemin (Dijkstra) sur le graphe d'axes AfriFlow de la ville, re-noté en direct : vitesses mesurées ou estimées, risques, météo et risque de crue.",
  },
  {
    title: "Restitution inclusive",
    text: "App, push, SMS et radio partenaire — les alertes sont diffusées aux conducteurs.",
  },
];

interface ModelMetrics {
  gpsValidation: {
    samples: number;
    maeKmh: number;
    within5KmhPct: number;
    maeLearnedKmh: number | null;
    within5LearnedPct: number | null;
    improvementPct: number | null;
    periodDays: number;
  } | null;
  holdout: {
    trainedAt: string;
    samplesTest: number;
    axesTrained: number;
    maeGenericKmh: number | null;
    maeLearnedKmh: number | null;
    improvementPct: number | null;
  } | null;
  coherence: Record<string, { mae: number; within10: number; samples: number }>;
}

interface TrainResult {
  samplesTotal: number;
  axesTrained: number;
  maeGenericKmh: number | null;
  maeLearnedKmh: number | null;
  improvementPct: number | null;
  evaluation: string;
}

export default function DataSection() {
  const { cityId, heat } = useApp();
  const city = CITY_MAP[cityId];
  const [sources, setSources] = useState<SourcesPayload | null>(null);
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState<ModelMetrics | null>(null);
  const [training, setTraining] = useState(false);
  const [trainResult, setTrainResult] = useState<TrainResult | { error: string } | null>(null);

  const trainModel = async () => {
    setTraining(true);
    setTrainResult(null);
    try {
      const res = await fetch("/api/model/train", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: cityId }),
      });
      const json = (await res.json()) as TrainResult & { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Entraînement impossible");
      setTrainResult(json);
      // Recharge les métriques pour refléter le modèle entraîné.
      const m = await fetch(`/api/model/metrics?city=${cityId}`, { cache: "no-store" });
      if (m.ok) setMetrics((await m.json()) as ModelMetrics);
    } catch (e) {
      setTrainResult({ error: e instanceof Error ? e.message : "Entraînement impossible" });
    } finally {
      setTraining(false);
    }
  };

  // Candidature Waze for Cities
  const [wazeForm, setWazeForm] = useState({ organisation: "", contactName: "", email: "" });
  const [wazeBusy, setWazeBusy] = useState(false);
  const [wazeResult, setWazeResult] = useState<{ steps: string[] } | { error: string } | null>(null);

  const submitWaze = async () => {
    setWazeBusy(true);
    setWazeResult(null);
    try {
      const res = await fetch("/api/waze/apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...wazeForm, city: cityId }),
      });
      const json = (await res.json()) as { nextSteps?: string[]; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Candidature impossible");
      setWazeResult({ steps: json.nextSteps ?? [] });
      void loadSources();
    } catch (e) {
      setWazeResult({ error: e instanceof Error ? e.message : "Candidature impossible" });
    } finally {
      setWazeBusy(false);
    }
  };

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      try {
        const res = await fetch(`/api/model/metrics?city=${cityId}`, { cache: "no-store" });
        if (res.ok && !cancelled) setMetrics((await res.json()) as ModelMetrics);
      } catch {
        /* métriques optionnelles */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [cityId]);

  // Détails techniques (latences, erreurs brutes) uniquement avec ?debug=true.
  const [debug] = useState(
    () =>
      typeof window !== "undefined" &&
      new URLSearchParams(window.location.search).get("debug") === "true",
  );

  const loadSources = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/sources?city=${cityId}${debug ? "&debug=1" : ""}`, { cache: "no-store" });
      if (res.ok) setSources((await res.json()) as SourcesPayload);
    } catch {
      /* état précédent conservé */
    } finally {
      setLoading(false);
    }
  }, [cityId, debug]);

  useEffect(() => {
    void loadSources();
    const t = setInterval(() => void loadSources(), 60_000);
    return () => clearInterval(t);
  }, [loadSources]);

  return (
    <section id="donnees" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-14 sm:px-6">
      <div data-reveal>
        <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
          <span className="inline-block h-px w-8 bg-brand-500" /> 06 · Données &amp; IA
        </p>
        <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Zéro capteur officiel ? <span className="text-brand-500">Quatre sources ingénieuses.</span>
        </h2>
        <p className="mt-2 max-w-3xl text-[14px] leading-relaxed text-sage">
          Le plus grand obstacle en Afrique n&apos;est pas l&apos;algorithme — c&apos;est la donnée. AfriFlow croise
          quatre sources complémentaires, toutes anonymisées, pour reconstruire le trafic en continu.
        </p>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {FOUR_SOURCES.map(({ num, icon: Icon, title, text, badge, live }) => (
          <article key={num} data-reveal className="rounded-3xl border border-night-600 bg-night-900 p-5">
            <div className="flex items-center justify-between">
              <span className="font-display text-2xl font-bold text-night-500">{num}</span>
              <span className="grid h-10 w-10 place-items-center rounded-2xl bg-brand-500/12 text-brand-500">
                <Icon className="h-5 w-5" />
              </span>
            </div>
            <h3 className="mt-4 font-display text-[16px] font-bold">{title}</h3>
            <p className="mt-1.5 text-[13px] leading-relaxed text-sage">{text}</p>
            <span
              className={`mt-3 inline-block rounded-full px-2.5 py-1 text-[10px] font-bold ${
                live ? "bg-brand-500/15 text-mint-300" : "bg-amber-warn/15 text-amber-warn"
              }`}
            >
              {live ? "● " : "○ "}
              {badge.toUpperCase()}
            </span>
          </article>
        ))}
      </div>

      <div data-reveal className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 font-display text-lg font-bold">
              <Database className="h-5 w-5 text-brand-500" />
              Sources authentiques — état en direct ({city.name})
            </h3>
            <p className="mt-1 max-w-2xl text-[13px] leading-relaxed text-sage">
              Uniquement des flux réels vérifiables : Open-Meteo, OpenStreetMap/Overpass (chantiers relevés via le
              pool d&apos;instances OSM), débits GloFAS, qualité de l&apos;air CAMS, GPS des conducteurs et
              partenaires. Tableau de bord calculé en{" "}
              <b className="text-paper">{sources ? sources.computedInMs : (heat?.summary.computedInMs ?? "—")} ms</b>.
            </p>
          </div>
          <button
            onClick={() => void loadSources()}
            className="flex items-center gap-2 rounded-xl bg-night-800 px-3 py-2 text-[12px] font-semibold transition hover:bg-night-700"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} /> Revérifier
          </button>
        </div>

        {loading && !sources ? (
          <p className="mt-5 flex items-center gap-2 text-[13px] text-sage">
            <Loader2 className="h-4 w-4 animate-spin text-brand-500" /> État des sources en cours de chargement…
          </p>
        ) : (
          <div className="mt-5 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {sources?.sources.map((s) => {
              const Icon = SOURCE_ICONS[s.id] ?? Database;
              const ok = s.level === "ok";
              const warn = !ok && !(debug && s.level === "off");
              return (
                <div key={s.id} className="rounded-2xl border border-night-600 bg-night-800/50 p-4">
                  <p className="flex items-center justify-between gap-2">
                    <span className="flex items-center gap-2 text-[13.5px] font-bold">
                      <Icon className="h-4 w-4 text-mint-400" />
                      {s.name}
                    </span>
                    {ok ? (
                      <CheckCircle2 className="h-4 w-4 shrink-0 text-brand-500" />
                    ) : warn ? (
                      <RefreshCw className="h-4 w-4 shrink-0 animate-spin text-amber-warn" />
                    ) : (
                      <XCircle className="h-4 w-4 shrink-0 text-coral" />
                    )}
                  </p>
                  <p className="mt-1.5 min-h-10 text-[12px] leading-relaxed text-sage">{s.detail}</p>
                  <p className="mt-2 flex flex-wrap gap-x-3 gap-y-1 border-t border-night-600/60 pt-2 text-[11px] font-medium">
                    <span className={ok ? "text-mint-300" : warn ? "text-amber-warn" : "text-coral"}>{s.status}</span>
                    {s.latencyMs !== null && <span className="text-sage">{s.latencyMs} ms</span>}
                    <span className="text-sage">{s.metric}</span>
                  </p>
                </div>
              );
            })}
            <div className="rounded-2xl border border-brand-500/40 bg-brand-500/8 p-4">
              <p className="flex items-center gap-2 text-[13.5px] font-bold">
                <BrainCircuit className="h-4 w-4 text-brand-500" /> Moteur de prédiction IA
              </p>
              <p className="mt-1.5 text-[12px] leading-relaxed text-sage">
                Profils jour × heure appris sur la télémétrie réelle de {city.name}, fusionnés à la météo Open-Meteo et
                aux débits GloFAS. Backtest continu sur les 7 derniers jours.
              </p>
              <p className="mt-2 border-t border-night-600/60 pt-2 text-[11px] font-medium text-mint-300">
                {heat ? `Indice ${city.name} : ${heat.summary.index}/100 · +30 min : ${heat.summary.indexIn30}/100` : "Chargement du modèle…"}
              </p>
              {metrics && (
                <div className="mt-3 border-t border-night-600/60 pt-3">
                  <p className="text-[11px] font-bold tracking-wide text-sage uppercase">
                    Validation du modèle — {city.name}
                  </p>
                  {metrics.gpsValidation && metrics.gpsValidation.samples >= 10 ? (
                    <p className="mt-2 rounded-xl bg-brand-500/10 px-3 py-2 text-[12px] leading-relaxed text-mint-300">
                      <b>Vérité terrain (GPS réels, {metrics.gpsValidation.periodDays} j)</b> : sur{" "}
                      {metrics.gpsValidation.samples} points mesurés par les conducteurs, le profil historique générique
                      prédit la vitesse à <b>±{metrics.gpsValidation.maeKmh} km/h</b> en moyenne (
                      {metrics.gpsValidation.within5KmhPct} % à ±5 km/h).
                      {metrics.gpsValidation.maeLearnedKmh !== null ? (
                        <>
                          {" "}
                          Après entraînement sur ces mêmes mesures : <b>±{metrics.gpsValidation.maeLearnedKmh} km/h</b>{" "}
                          ({metrics.gpsValidation.within5LearnedPct} % à ±5 km/h), soit{" "}
                          <b>{metrics.gpsValidation.improvementPct} % d&apos;erreur en moins</b>.
                        </>
                      ) : (
                        <> Le modèle n&apos;est pas encore entraîné sur cette ville — lancez l&apos;entraînement ci-dessous.</>
                      )}
                    </p>
                  ) : (
                    <p className="mt-2 rounded-xl bg-night-950/70 px-3 py-2 text-[11.5px] leading-relaxed text-sage">
                      Vérité terrain : {metrics.gpsValidation?.samples ?? 0} point(s) GPS réel(s) sur 7 jours à{" "}
                      {city.name} — échantillon encore insuffisant pour valider le modèle. Contribuez depuis le
                      simulateur GPS du haut de page ou via POST /api/telemetry.
                    </p>
                  )}
                  {metrics.holdout && metrics.holdout.maeLearnedKmh !== null && (
                    <p className="mt-2 rounded-xl border border-violet-500/40 bg-violet-500/10 px-3 py-2 text-[12px] leading-relaxed text-violet-200">
                      🧪 <b>Preuve holdout du dernier entraînement</b> (découpage temporel 80/20, points jamais vus) :{" "}
                      {metrics.holdout.maeGenericKmh} km/h → <b>{metrics.holdout.maeLearnedKmh} km/h</b> (
                      {metrics.holdout.improvementPct} % d&apos;erreur en moins) sur {metrics.holdout.samplesTest}{" "}
                      points de test · {metrics.holdout.axesTrained} axes · le{" "}
                      {new Date(metrics.holdout.trainedAt).toLocaleString("fr-FR", {
                        day: "2-digit",
                        month: "2-digit",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                      .
                    </p>
                  )}
                  <div className="mt-2 grid grid-cols-3 gap-2 text-center">
                    {Object.entries(metrics.coherence).map(([h, m]) => (
                      <div key={h} className="rounded-xl bg-night-950/70 px-2 py-2">
                        <p className="font-display text-[15px] font-bold">±{m.mae} pts</p>
                        <p className="text-[10px] leading-snug text-sage">
                          auto-test {h} min · {m.within10} % à ±10 pts
                        </p>
                      </div>
                    ))}
                  </div>
                  <p className="mt-2 text-[10.5px] leading-relaxed text-sage">
                    Auto-test de cohérence interne (le modèle comparé à lui-même sur 24 h) : il mesure la stabilité des
                    profils, pas une exactitude terrain — seule la validation GPS ci-dessus fait foi.
                  </p>
                  <div className="mt-3 border-t border-night-600/60 pt-3">
                    <p className="text-[11px] font-bold tracking-wide text-sage uppercase">
                      Entraîner l&apos;IA sur les données de {city.name}
                    </p>
                    <p className="mt-1 text-[11.5px] leading-relaxed text-sage">
                      Apprend, par axe et par heure, les vitesses réellement mesurées (médianes semaine / week-end) et
                      les fusionne aux prédictions. Évaluation intégrée en holdout 80/20 : l&apos;amélioration est
                      mesurée sur des points jamais vus à l&apos;entraînement.
                    </p>
                    <button
                      onClick={() => void trainModel()}
                      disabled={training}
                      className="mt-2.5 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-500 py-2.5 text-[12.5px] font-bold text-night-950 transition hover:bg-mint-400 disabled:opacity-60"
                    >
                      {training ? <Loader2 className="h-4 w-4 animate-spin" /> : <BrainCircuit className="h-4 w-4" />}
                      {training ? "Entraînement en cours…" : "Entraîner sur les GPS collectés (7 j)"}
                    </button>
                    {trainResult && "error" in trainResult && (
                      <p className="mt-2 rounded-xl bg-coral/10 px-3 py-2 text-[12px] font-medium text-coral">
                        {trainResult.error}
                      </p>
                    )}
                    {trainResult && !("error" in trainResult) && (
                      <p className="mt-2 rounded-xl bg-brand-500/10 px-3 py-2 text-[12px] leading-relaxed text-mint-300">
                        ✓ <b>{trainResult.axesTrained} axe(s) entraîné(s)</b> sur {trainResult.samplesTotal} points GPS.{" "}
                        {trainResult.evaluation}
                      </p>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* Partenariats données : Waze for Cities, HERE, WhereIsMyTransport */}
      <div data-reveal className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
        <h3 className="flex items-center gap-2 font-display text-lg font-bold">
          <Navigation className="h-5 w-5 text-brand-500" /> Partenariats données — l&apos;action la plus rentable
        </h3>
        <p className="mt-1 max-w-3xl text-[13px] leading-relaxed text-sage">
          Le programme <b className="text-paper">Waze for Cities</b> (Connected Citizens) échange gratuitement les
          alertes des conducteurs Waze contre les incidents validés des villes. AfriFlow est prêt des deux côtés :
          flux sortant au format Waze Traffic View et réception des alertes Waze dans le consensus. L&apos;adhésion se
          signe sur le portail officiel Waze — générez ici le dossier avec les URLs à déclarer.
        </p>
        <div className="mt-4 grid gap-4 lg:grid-cols-[1fr_1.1fr]">
          <div className="space-y-2 font-mono text-[11.5px] leading-relaxed">
            <p className="rounded-2xl bg-night-950 p-3.5 text-mint-300">
              <span className="text-sage">{"// flux sortant (à déclarer à Waze)"}</span>
              <br />
              GET /api/waze/feed?city={cityId}
            </p>
            <p className="rounded-2xl bg-night-950 p-3.5 text-mint-300">
              <span className="text-sage">{"// réception des alertes Waze"}</span>
              <br />
              POST /api/waze/webhook · POST /api/v1/report
            </p>
            <p className="rounded-2xl bg-night-950 p-3.5 text-sage">
              HERE Traffic v7 et WhereIsMyTransport s&apos;activent avec leurs clés/jetons partenaires
              (variables d&apos;environnement) — voir le panneau des sources ci-dessus pour leur état réel.
            </p>
          </div>
          <div className="rounded-2xl border border-night-600 bg-night-800/50 p-4">
            <p className="text-[13px] font-bold">Générer le dossier de candidature — {city.name}</p>
            <div className="mt-3 grid gap-2 sm:grid-cols-3">
              <input
                value={wazeForm.organisation}
                onChange={(e) => setWazeForm({ ...wazeForm, organisation: e.target.value })}
                placeholder="Organisation (mairie, opérateur…)"
                className="rounded-xl border border-night-600 bg-night-900 px-3 py-2 text-[12.5px] outline-none placeholder:text-sage/50 focus:border-brand-500"
              />
              <input
                value={wazeForm.contactName}
                onChange={(e) => setWazeForm({ ...wazeForm, contactName: e.target.value })}
                placeholder="Personne de contact"
                className="rounded-xl border border-night-600 bg-night-900 px-3 py-2 text-[12.5px] outline-none placeholder:text-sage/50 focus:border-brand-500"
              />
              <input
                value={wazeForm.email}
                onChange={(e) => setWazeForm({ ...wazeForm, email: e.target.value })}
                placeholder="E-mail professionnel"
                type="email"
                className="rounded-xl border border-night-600 bg-night-900 px-3 py-2 text-[12.5px] outline-none placeholder:text-sage/50 focus:border-brand-500"
              />
            </div>
            <button
              onClick={() => void submitWaze()}
              disabled={wazeBusy}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-500 py-2.5 text-[13px] font-bold text-night-950 transition hover:bg-mint-400 disabled:opacity-60"
            >
              {wazeBusy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Navigation className="h-4 w-4" />}
              Générer le dossier Waze for Cities
            </button>
            {wazeResult && "error" in wazeResult && (
              <p className="mt-3 rounded-xl bg-coral/10 px-3 py-2 text-[12.5px] font-medium text-coral">{wazeResult.error}</p>
            )}
            {wazeResult && "steps" in wazeResult && (
              <div className="mt-3 rounded-xl bg-brand-500/10 px-3 py-2.5">
                <p className="text-[12.5px] font-bold text-mint-300">✓ Dossier généré — prochaines étapes :</p>
                <ol className="mt-1.5 list-decimal space-y-1 pl-5 text-[12px] leading-relaxed text-paper/85">
                  {wazeResult.steps.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>
              </div>
            )}
          </div>
        </div>
      </div>

      <div data-reveal className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
        <h3 className="flex items-center gap-2 font-display text-lg font-bold">
          <span className="text-brand-500">⇢</span> De la route au conducteur — le pipeline
        </h3>
        <ol className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {PIPELINE.map((step, i) => (
            <li key={step.title} className="flex gap-3.5">
              <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-500 font-display text-[13px] font-bold text-night-950">
                {i + 1}
              </span>
              <span>
                <b className="block text-[14px]">{step.title}</b>
                <span className="mt-0.5 block text-[12.5px] leading-relaxed text-sage">{step.text}</span>
              </span>
            </li>
          ))}
        </ol>
        <p className="mt-5 flex flex-wrap items-center gap-2 text-[12px]">
          <span className="font-semibold text-sage">Open data & intégrations :</span>
          <a
            href={`/api/incidents/export?city=${cityId}`}
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-night-800 px-3 py-1.5 font-semibold text-mint-300 transition hover:bg-night-700"
          >
            Incidents GeoJSON ({city.name})
          </a>
          <a
            href="/api/cities"
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-night-800 px-3 py-1.5 font-semibold text-mint-300 transition hover:bg-night-700"
          >
            Indices des {CITY_COUNT} villes (JSON)
          </a>
          <a
            href="/api/stats"
            target="_blank"
            rel="noreferrer"
            className="rounded-full bg-night-800 px-3 py-1.5 font-semibold text-mint-300 transition hover:bg-night-700"
          >
            Statistiques plateforme (JSON)
          </a>
          <span className="text-sage">— utilisables dans QGIS, uMap et les portails open data des villes.</span>
        </p>
        <div className="mt-6 grid gap-3 md:grid-cols-3">
          <p className="rounded-2xl bg-night-950 p-4 font-mono text-[11.5px] leading-relaxed text-mint-300">
            <span className="text-sage">{"// moteur (Rust → TS)"}</span>
            <br />
            POST /api/telemetry (points GPS)
            <br />
            POST /api/report (bot WhatsApp)
            <br />
            POST /api/simulate/traces (démo)
            <br />
            GET /api/heatmap · /api/routing · /api/stream (deltas SSE)
            <br />
            <span className="text-paper">fluidité × 1/(1+densité)</span>
          </p>
          <p className="rounded-2xl bg-night-950 p-4 font-mono text-[11.5px] leading-relaxed text-mint-300">
            <span className="text-sage">{"// prédiction (profils appris)"}</span>
            <br />
            profils jour×heure appris sur
            <br />
            télémétrie réelle + météo
            <br />
            Open-Meteo + GloFAS + air CAMS
          </p>
          <p className="rounded-2xl bg-night-950 p-4 font-mono text-[11.5px] leading-relaxed text-mint-300">
            <span className="text-sage">{"// garde-fous métier"}</span>
            <br />
            consensus évènement ≥ 3<br />
            zone ≥ 80% ⇒ bloquée
            <br />
            quota plein ⇒ axe fermé
          </p>
        </div>
      </div>
    </section>
  );
}
