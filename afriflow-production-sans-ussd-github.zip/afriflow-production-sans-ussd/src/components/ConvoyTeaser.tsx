"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ArrowRight, Fuel, OctagonAlert, Timer, Truck } from "lucide-react";
import { CITY_COUNT, CITY_MAP } from "@/lib/cities";
import type { FleetPayload } from "@/lib/api-types";
import { useApp } from "./AppClient";

/**
 * Encart d'accueil du Mode « Convoi Industriel » : la gestion complète de
 * flotte vit désormais sur sa page dédiée (/convoi). Ici : aperçu en
 * direct de la ville active + accès direct à la page.
 */
export default function ConvoyTeaser() {
  const { cityId } = useApp();
  const city = CITY_MAP[cityId];
  const [fleet, setFleet] = useState<FleetPayload | null>(null);

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch(`/api/fleet?city=${cityId}`, { cache: "no-store" });
        if (res.ok && !cancelled) setFleet((await res.json()) as FleetPayload);
      } catch {
        /* aperçu optionnel */
      }
    };
    void load();
    const t = setInterval(() => void load(), 30_000);
    return () => {
      cancelled = true;
      clearInterval(t);
    };
  }, [cityId]);

  const vehicles = fleet?.vehicles ?? [];
  const blocked = vehicles.filter((v) => v.status === "Bloqué").length;
  const slowed = vehicles.filter((v) => v.status === "Ralentissement").length;
  const moving = vehicles.filter((v) => v.status === "En mouvement").length;

  return (
    <section id="convoi" className="scroll-mt-24 border-y border-night-600/60 bg-night-900/50">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div data-reveal className="overflow-hidden rounded-3xl border border-night-600 bg-gradient-to-br from-night-800 via-night-900 to-night-950">
          <div className="grid gap-6 p-6 sm:p-8 lg:grid-cols-[1.3fr_0.7fr] lg:items-center">
            <div>
              <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
                <span className="inline-block h-px w-8 bg-brand-500" /> 05 · Convoi industriel
              </p>
              <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
                Mode « Convoi Industriel »
              </h2>
              <p className="mt-2 max-w-2xl text-[14px] leading-relaxed text-sage">
                Tous vos camions en direct à {city.name}. En cas de blocage majeur,{" "}
                <b className="text-paper">reroutez le convoi entier en un clic</b> — réparti sur plusieurs délestages
                pour ne pas créer un nouveau bouchon. Les ordres partent par SMS + WhatsApp aux chauffeurs.
              </p>
              <p className="mt-4 flex flex-wrap gap-x-5 gap-y-1.5 text-[12.5px] font-medium text-sage">
                <span className="flex items-center gap-1.5">
                  <Truck className="h-4 w-4 text-brand-500" /> {vehicles.length} camions suivis à {city.name}
                </span>
                <span className="flex items-center gap-1.5 text-mint-300">{moving} en mouvement</span>
                <span className="flex items-center gap-1.5 text-amber-warn">
                  <Timer className="h-3.5 w-3.5" /> {slowed} ralenti(s)
                </span>
                <span className="flex items-center gap-1.5 text-coral">
                  <OctagonAlert className="h-3.5 w-3.5" /> {blocked} bloqué(s)
                </span>
                <span className="flex items-center gap-1.5">
                  <Fuel className="h-3.5 w-3.5" /> ETA moyenne {fleet?.stats.avgEta ?? 0} min
                </span>
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <Link
                href={`/convoi?ville=${cityId}`}
                className="flex items-center justify-center gap-2 rounded-2xl bg-brand-500 px-5 py-4 text-sm font-bold text-night-950 shadow-lg shadow-brand-500/20 transition hover:bg-mint-400"
              >
                Ouvrir le centre Convoi Industriel <ArrowRight className="h-4 w-4" />
              </Link>
              <p className="text-center text-[12px] leading-relaxed text-sage">
                Page dédiée : déclaration de flotte, reroutage collectif, axes critiques de la ville, export CSV —
                pour les {CITY_COUNT} villes du réseau.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
