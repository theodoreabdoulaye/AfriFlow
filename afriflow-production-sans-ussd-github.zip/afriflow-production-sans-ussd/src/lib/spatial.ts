import type { AxisDef, CityDef } from "./cities";
import { distanceToSegmentM } from "./cities";

/**
 * Index spatial par grille (cellules ≈ 1,1 km) pour le map matching :
 * trouver l'axe le plus proche d'un point GPS sans scanner tous les
 * segments. Les cellules voisines sont explorées en anneaux croissants
 * jusqu'au rayon maximal — complexité proche de O(log N) en pratique,
 * même avec des dizaines de milliers de segments (équivalent applicatif
 * d'un R-Tree/PostGIS pour notre graphe).
 */

interface SegmentRef {
  axis: AxisDef;
  a: [number, number];
  b: [number, number];
}

const CELL = 0.01; // degrés (~1,1 km)
const indexCache = new Map<string, Map<string, SegmentRef[]>>();

function cellKey(lat: number, lon: number): string {
  return `${Math.floor(lat / CELL)},${Math.floor(lon / CELL)}`;
}

function buildIndex(city: CityDef): Map<string, SegmentRef[]> {
  const cacheKey = `${city.id}:${city.axes.length}`;
  const cached = indexCache.get(cacheKey);
  if (cached) return cached;
  const grid = new Map<string, SegmentRef[]>();
  for (const axis of city.axes) {
    for (let i = 0; i < axis.gps.length - 1; i++) {
      const seg: SegmentRef = { axis, a: axis.gps[i], b: axis.gps[i + 1] };
      // Enregistre le segment dans toutes les cellules traversées (bbox élargie).
      const minLat = Math.min(seg.a[0], seg.b[0]) - CELL / 2;
      const maxLat = Math.max(seg.a[0], seg.b[0]) + CELL / 2;
      const minLon = Math.min(seg.a[1], seg.b[1]) - CELL / 2;
      const maxLon = Math.max(seg.a[1], seg.b[1]) + CELL / 2;
      for (let la = minLat; la <= maxLat; la += CELL) {
        for (let lo = minLon; lo <= maxLon; lo += CELL) {
          const key = cellKey(la, lo);
          const list = grid.get(key) ?? [];
          list.push(seg);
          grid.set(key, list);
        }
      }
    }
  }
  indexCache.set(cacheKey, grid);
  return grid;
}

/** Axe le plus proche d'un point GPS via l'index grille (rayon max en mètres). */
export function nearestAxisFast(
  city: CityDef,
  lat: number,
  lon: number,
  maxM = 400,
): { axis: AxisDef; distanceM: number } | null {
  const grid = buildIndex(city);
  const cx = Math.floor(lat / CELL);
  const cy = Math.floor(lon / CELL);
  let best: AxisDef | null = null;
  let bestDist = maxM;

  // Anneaux de cellules croissants : 0, 1, puis 2 cellules (~3,3 km max).
  const maxRing = Math.min(3, Math.ceil(maxM / 1000) + 1);
  for (let ring = 0; ring <= maxRing; ring++) {
    for (let dx = -ring; dx <= ring; dx++) {
      for (let dy = -ring; dy <= ring; dy++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== ring) continue;
        const list = grid.get(`${cx + dx},${cy + dy}`);
        if (!list) continue;
        for (const seg of list) {
          const d = distanceToSegmentM([lat, lon], seg.a, seg.b);
          if (d < bestDist) {
            bestDist = d;
            best = seg.axis;
          }
        }
      }
    }
    // Un candidat dans l'anneau courant plus proche que le rayon de l'anneau suffit.
    if (best && bestDist < ring * 900) break;
  }
  return best ? { axis: best, distanceM: Math.round(bestDist) } : null;
}
