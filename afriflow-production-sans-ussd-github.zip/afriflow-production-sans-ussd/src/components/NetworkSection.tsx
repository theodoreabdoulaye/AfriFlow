"use client";

import { useEffect, useMemo, useState } from "react";
import { Globe2, Loader2, MapPin, Search, TrendingDown, TrendingUp } from "lucide-react";
import { CITY_COUNT, COUNTRIES, COUNTRY_COUNT } from "@/lib/cities";
import { useApp } from "./AppClient";

interface CityRow {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  axesCount: number;
  zonesCount: number;
  index: number;
  indexIn30: number;
  saturatedAxes: number;
  vehiclesTracked: number;
}

interface CitiesPayload {
  generatedAt: string;
  total: number;
  cities: CityRow[];
  insights: { mostCongested: CityRow[]; mostFluid: CityRow[] };
}

function indexColor(index: number): string {
  return index >= 70 ? "#22b573" : index >= 48 ? "#a3e635" : index >= 30 ? "#ffb020" : "#ff5d47";
}

export default function NetworkSection() {
  const { setCityId, cityId } = useApp();
  const [data, setData] = useState<CitiesPayload | null>(null);
  const [error, setError] = useState(false);
  const [query, setQuery] = useState("");
  const [countryFilter, setCountryFilter] = useState<string>("tous");

  const load = async () => {
    try {
      const res = await fetch("/api/cities", { cache: "no-store" });
      if (!res.ok) throw new Error();
      setData((await res.json()) as CitiesPayload);
      setError(false);
    } catch {
      setError(true);
    }
  };

  useEffect(() => {
    const t0 = window.setTimeout(() => void load(), 0);
    const t = setInterval(() => void load(), 60_000);
    return () => {
      clearTimeout(t0);
      clearInterval(t);
    };
  }, []);

  const filtered = useMemo(() => {
    if (!data) return [];
    const q = query.trim().toLowerCase();
    return data.cities.filter(
      (c) =>
        (countryFilter === "tous" || c.countryCode === countryFilter) &&
        (q === "" || c.name.toLowerCase().includes(q) || c.country.toLowerCase().includes(q)),
    );
  }, [data, query, countryFilter]);

  const goToCity = (id: string) => {
    setCityId(id);
    requestAnimationFrame(() => {
      document.querySelector("#dashboard")?.scrollIntoView({ behavior: "smooth" });
    });
  };

  return (
    <section id="reseau" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-14 sm:px-6">
      <div data-reveal>
        <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
          <span className="inline-block h-px w-8 bg-brand-500" /> 07 · Réseau déployé
        </p>
        <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Le réseau déployé : <span className="text-brand-500">{CITY_COUNT} villes, {COUNTRY_COUNT} pays — tout le continent</span>
        </h2>
        <p className="mt-2 max-w-3xl text-[14px] leading-relaxed text-sage">
          Chaque ville ci-dessous est surveillée par le même moteur : profils appris, prédiction IA et ventilation.
          Cliquez une ville pour basculer son centre de contrôle, sa carte thermique et son réseau d&apos;axes.
          <span className="mt-1 block text-[12px]">
            Indices ci-dessous : prévisionnels, calculés sur les profils horaires appris à l&apos;heure locale de
            chaque ville (le détail météo/GPS temps réel se trouve dans la carte de la ville).
          </span>
        </p>
      </div>

      {data && (
        <div className="mt-6 grid gap-4 md:grid-cols-2">
          <div data-reveal className="rounded-3xl border border-coral/40 bg-night-900 p-5">
            <h3 className="flex items-center gap-2 font-display text-[15px] font-bold">
              <TrendingDown className="h-4 w-4 text-coral" /> Villes les plus tendues actuellement
            </h3>
            <ul className="mt-3 space-y-2">
              {data.insights.mostCongested.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => goToCity(c.id)}
                    className="flex w-full items-center gap-3 rounded-xl bg-night-800/70 px-3 py-2 text-left transition hover:bg-night-700"
                  >
                    <span className="font-display text-lg font-bold" style={{ color: indexColor(c.index) }}>
                      {c.index}
                    </span>
                    <span className="flex-1 text-[13px] font-semibold">
                      {c.name} <span className="font-normal text-sage">· {c.country}</span>
                    </span>
                    <span className="text-[11px] text-sage">{c.saturatedAxes} axe(s) saturé(s)</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
          <div data-reveal className="rounded-3xl border border-brand-500/40 bg-night-900 p-5">
            <h3 className="flex items-center gap-2 font-display text-[15px] font-bold">
              <TrendingUp className="h-4 w-4 text-brand-500" /> Villes les plus fluides
            </h3>
            <ul className="mt-3 space-y-2">
              {data.insights.mostFluid.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => goToCity(c.id)}
                    className="flex w-full items-center gap-3 rounded-xl bg-night-800/70 px-3 py-2 text-left transition hover:bg-night-700"
                  >
                    <span className="font-display text-lg font-bold" style={{ color: indexColor(c.index) }}>
                      {c.index}
                    </span>
                    <span className="flex-1 text-[13px] font-semibold">
                      {c.name} <span className="font-normal text-sage">· {c.country}</span>
                    </span>
                    <span className="text-[11px] text-sage">{c.vehiclesTracked.toLocaleString("fr-FR")} véh. suivis</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>
      )}

      <div className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
        <div className="flex flex-wrap items-center gap-3">
          <label className="relative min-w-55 flex-1">
            <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-sage" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Rechercher une ville ou un pays (ex. Lagos, Mali, Praia…)"
              className="w-full rounded-xl border border-night-600 bg-night-800 py-2.5 pr-3 pl-9 text-sm outline-none placeholder:text-sage/60 focus:border-brand-500"
            />
          </label>
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setCountryFilter("tous")}
              className={`rounded-full px-3 py-1.5 text-[12px] font-semibold transition ${
                countryFilter === "tous" ? "bg-brand-500 text-night-950" : "bg-night-800 text-sage hover:text-paper"
              }`}
            >
              Tous ({data?.total ?? "…"})
            </button>
            {COUNTRIES.map((c) => (
              <button
                key={c.code}
                onClick={() => setCountryFilter(c.code)}
                className={`rounded-full px-3 py-1.5 text-[12px] font-semibold transition ${
                  countryFilter === c.code ? "bg-brand-500 text-night-950" : "bg-night-800 text-sage hover:text-paper"
                }`}
              >
                {c.name} ({c.cityCount})
              </button>
            ))}
          </div>
        </div>

        {!data && !error && (
          <p className="mt-8 flex items-center gap-2 text-sm text-sage">
            <Loader2 className="h-4 w-4 animate-spin text-brand-500" /> Chargement des indices des {CITY_COUNT} villes…
          </p>
        )}
        {error && (
          <p className="mt-8 text-sm text-coral">
            Impossible de charger la vue réseau.{" "}
            <button onClick={() => void load()} className="font-semibold underline">
              Réessayer
            </button>
          </p>
        )}

        {data && (
          <div className="mt-5 space-y-6">
            {COUNTRIES.filter((c) => countryFilter === "tous" || c.code === countryFilter).map((country) => {
              const cities = filtered.filter((c) => c.countryCode === country.code);
              if (cities.length === 0) return null;
              const avg = Math.round(cities.reduce((a, c) => a + c.index, 0) / cities.length);
              return (
                <div key={country.code}>
                  <h3 className="flex items-center gap-2 text-[13px] font-bold tracking-wide text-sage uppercase">
                    <Globe2 className="h-4 w-4 text-brand-500" />
                    {country.name}
                    <span className="font-medium normal-case">
                      — {cities.length} ville(s) · indice moyen{" "}
                      <b style={{ color: indexColor(avg) }}>{avg}/100</b>
                    </span>
                  </h3>
                  <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6">
                    {cities.map((c) => (
                      <button
                        key={c.id}
                        onClick={() => goToCity(c.id)}
                        className={`rounded-2xl border px-3 py-2.5 text-left transition hover:border-mint-400/50 hover:bg-night-700 ${
                          c.id === cityId ? "border-brand-500 bg-brand-500/12" : "border-night-600 bg-night-800/60"
                        }`}
                      >
                        <span className="flex items-center justify-between gap-2">
                          <span className="flex items-center gap-1 truncate text-[13px] font-bold">
                            <MapPin className="h-3.5 w-3.5 shrink-0 text-sage" />
                            <span className="truncate">{c.name}</span>
                          </span>
                          <span className="font-display text-[15px] font-bold" style={{ color: indexColor(c.index) }}>
                            {c.index}
                          </span>
                        </span>
                        <span className="mt-0.5 block text-[10.5px] text-sage">
                          {c.axesCount} axes · +30 min : {c.indexIn30}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
            {filtered.length === 0 && (
              <p className="py-6 text-center text-sm text-sage">
                Aucune ville ne correspond à « {query} ». Essayez un autre nom ou réinitialisez les filtres.
              </p>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
