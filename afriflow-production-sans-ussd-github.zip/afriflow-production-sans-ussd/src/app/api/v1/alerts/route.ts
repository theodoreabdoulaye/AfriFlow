import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { toValidatedAlert } from "@/lib/alert-hub";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/alerts?city=dakar — alertes actives : incidents validés par
 * le consensus (diffusés) dans leur fenêtre d'impact de 3 h, au format
 * ValidatedAlert du hub temps réel.
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const cityParam = req.nextUrl.searchParams.get("city");
  if (cityParam && !CITY_MAP[cityParam]) {
    return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  }
  const since = new Date(Date.now() - 3 * 3600_000);
  try {
    const rows = await db
      .select()
      .from(incidents)
      .where(
        cityParam
          ? and(
              eq(incidents.city, cityParam),
              eq(incidents.status, "broadcast"),
              gte(incidents.createdAt, since),
            )
          : and(eq(incidents.status, "broadcast"), gte(incidents.createdAt, since)),
      )
      .orderBy(desc(incidents.createdAt))
      .limit(100);
    const alerts = rows
      .map((i) => {
        const city = CITY_MAP[i.city];
        return city ? toValidatedAlert(city, i) : null;
      })
      .filter((a) => a !== null);
    return NextResponse.json({ count: alerts.length, alerts }, { headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return NextResponse.json({ count: 0, alerts: [] }, { headers: { "Cache-Control": "private, no-store" } });
  }
}
