import { after, NextRequest, NextResponse } from "next/server";
import { and, count, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { incidents, mlObservations, telemetryPoints } from "@/db/schema";
import { CITY_MAP, getAxis, type AxisDef } from "@/lib/cities";
import { maybeRetrain, retrainAxisWeights } from "@/lib/learning";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/telemetry — ingestion d'une observation terrain au format
 * du MLEngine (porté du prototype Rust) :
 *   { city?, edge_id, observed_speed_kmh, baseline_speed_kmh?,
 *     rain_mm?, active_reports?, reporter? }
 * L'observation est rattachée à l'axe (point médian), stockée comme un
 * point GPS d'entraînement (source « v1-telemetry ») et déclenche le
 * réentraînement automatique (profils + poids ML) en arrière-plan.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`v1telemetry:${clientIp(req)}`, 300, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;

  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  let axis: AxisDef | null = null;
  if (typeof body.edge_id === "string") axis = getAxis(city, body.edge_id) ?? null;
  else if (typeof body.edge_id === "number") axis = city.axes[body.edge_id] ?? null;
  if (!axis) {
    return NextResponse.json({ error: "edge_id inconnu pour cette ville" }, { status: 422 });
  }

  const observed = Number(body.observed_speed_kmh);
  if (!Number.isFinite(observed) || observed < 0 || observed > 160) {
    return NextResponse.json({ error: "observed_speed_kmh invalide (0-160)" }, { status: 422 });
  }
  const rainMm = Number.isFinite(Number(body.rain_mm)) ? Math.max(0, Number(body.rain_mm)) : null;

  const mid = axis.gps[Math.floor(axis.gps.length / 2)];
  try {
    await db.insert(telemetryPoints).values({
      city: city.id,
      axisId: axis.id,
      lat: mid[0],
      lon: mid[1],
      speedKmh: observed,
      source: "v1-telemetry",
      deviceHash: typeof body.reporter === "string" ? body.reporter.slice(0, 48) : "v1-observation",
      rainMm,
    });

    // Observation MLEngine : signalements actifs = ceux fournis par
    // l'émetteur, sinon comptés depuis le consensus en cours sur l'axe.
    let activeReports = Number.isFinite(Number(body.active_reports))
      ? Math.max(0, Math.round(Number(body.active_reports)))
      : 0;
    if (!Number.isFinite(Number(body.active_reports))) {
      const twoHoursAgo = new Date(Date.now() - 2 * 3600_000);
      const [rep] = await db
        .select({ n: count() })
        .from(incidents)
        .where(
          and(
            eq(incidents.city, city.id),
            eq(incidents.axisId, axis.id),
            eq(incidents.status, "broadcast"),
            gte(incidents.createdAt, twoHoursAgo),
          ),
        );
      activeReports = rep?.n ?? 0;
    }
    await db.insert(mlObservations).values({
      city: city.id,
      axisId: axis.id,
      observedSpeedKmh: observed,
      baselineSpeedKmh: Number.isFinite(Number(body.baseline_speed_kmh))
        ? Number(body.baseline_speed_kmh)
        : axis.freeFlowKmh,
      rainMm: rainMm ?? 0,
      activeReports,
      source: "v1-telemetry",
    });
  } catch {
    return NextResponse.json({ error: "Ingestion indisponible" }, { status: 503 });
  }

  // Réentraînement de CET axe en arrière-plan (équivalent tokio::spawn),
  // plus le réentraînement global périodique si les profils ont > 6 h.
  const axisId = axis.id;
  after(async () => {
    await Promise.all([retrainAxisWeights(city, axisId), maybeRetrain(city)]);
  });

  return NextResponse.json(
    {
      accepted: true,
      city: city.id,
      edge_id: axis.id,
      retraining: "axe réentraîné en arrière-plan (50 dernières observations)",
    },
    { status: 202 },
  );
}
