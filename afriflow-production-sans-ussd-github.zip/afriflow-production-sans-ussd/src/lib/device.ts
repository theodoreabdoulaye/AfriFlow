/**
 * Identifiant d'appareil anonyme et stable (localStorage).
 * Il permet au consensus communautaire de distinguer de vrais conducteurs
 * différents — y compris deux abonnés du même opérateur (Orange, MTN…) —
 * sans collecter aucune donnée personnelle.
 */
export function getDeviceHash(): string {
  if (typeof window === "undefined") return "server";
  try {
    let id = window.localStorage.getItem("afri_device_id");
    if (!id) {
      id = `dev-${Math.random().toString(16).slice(2, 10)}${Date.now().toString(16)}`;
      window.localStorage.setItem("afri_device_id", id);
    }
    return id;
  } catch {
    return "dev-ephemeral";
  }
}
