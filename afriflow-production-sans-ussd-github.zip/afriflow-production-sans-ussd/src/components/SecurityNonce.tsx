"use client";
import { createContext, type ReactNode } from "react";

export const NonceContext = createContext<string | undefined>(undefined);
export function SecurityNonce({ nonce, children }: { nonce?: string; children: ReactNode }) {
  return <NonceContext.Provider value={nonce}>{children}</NonceContext.Provider>;
}
