export function GET() {
  return new Response([
    "Contact: https://wa.me/221772015751",
    "Expires: 2027-10-01T00:00:00Z",
    "Preferred-Languages: fr, en",
    "# TérangaStudio - disclosure contact. Do not send passwords or personal data.",
    "",
  ].join("\n"), { headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "public, max-age=3600", "Content-Security-Policy": "default-src 'none'; frame-ancestors 'none'" } });
}
