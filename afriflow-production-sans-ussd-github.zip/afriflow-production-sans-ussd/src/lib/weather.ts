import type { CityDef } from "./cities";
import { CLEAR_WEATHER, clamp, type WeatherInfo } from "./engine";

/**
 * Sources environnementales RÉELLES, sans clé API :
 * — Open-Meteo : météo observée + probabilité de pluie horaire ;
 * — Copernicus GloFAS (API Flood d'Open-Meteo) : débit du cours d'eau de
 *   référence et risque de crue à 3 jours, injectés dans le moteur ;
 * — CAMS (API Air Quality d'Open-Meteo) : indice européen de qualité
 *   de l'air et poussières (harmattan).
 *
 * Résilience (circuit breaker) : après 2 échecs consécutifs, le disjoncteur
 * s'ouvre 1 h — on sert alors la DERNIÈRE météo connue de la ville (ou le
 * repli saisonnier) sans bloquer ni exposer d'erreur à l'utilisateur.
 */

const cache = new Map<string, { at: number; value: WeatherInfo }>();
const CACHE_MS = 10 * 60_000;
const AUX_CACHE_MS = 60 * 60_000; // crue + air : rafraîchis à l'heure

const floodCache = new Map<string, { at: number; discharge: number | null; risk: 0 | 1 | 2 | null }>();
const airCache = new Map<string, { at: number; aqi: number | null }>();

/* ------------------------- Circuit breaker ------------------------- */
interface BreakerState {
  failures: number;
  openUntil: number;
  lastGood: WeatherInfo | null;
}
const breakers = new Map<string, BreakerState>();
const BREAKER_OPEN_MS = 3600_000;

function breakerFor(cityId: string): BreakerState {
  let b = breakers.get(cityId);
  if (!b) {
    b = { failures: 0, openUntil: 0, lastGood: null };
    breakers.set(cityId, b);
  }
  return b;
}

/** Dernière météo connue (ou repli saisonnier étiqueté « fallback »). */
function fallbackWeather(city: CityDef, breaker: BreakerState): WeatherInfo {
  if (breaker.lastGood) return { ...breaker.lastGood, source: "fallback" };
  return { ...CLEAR_WEATHER };
}

function labelFor(code: number, precip: number): { label: string; level: 0 | 1 | 2 } {
  if (code >= 95) return { label: "Orage", level: 2 };
  if (code >= 65 || precip >= 7) return { label: "Pluie forte", level: 2 };
  if (code >= 51 || precip > 0.2) return { label: "Pluie", level: 1 };
  if (code >= 45) return { label: "Brumeux", level: 0 };
  if (code >= 2) return { label: "Nuageux", level: 0 };
  return { label: "Ensoleillé", level: 0 };
}

/** Pluie prévue sur les 3 prochaines heures (somme horaire, mm). */
function rainNext3h(json: unknown, currentTime: string | undefined): number | null {
  try {
    const hourly = (json as { hourly?: { time?: string[]; precipitation?: (number | null)[] } })?.hourly;
    const times = hourly?.time;
    const precs = hourly?.precipitation;
    if (!Array.isArray(times) || !Array.isArray(precs) || !currentTime) return null;
    const hourPrefix = currentTime.slice(0, 13);
    const idx = times.findIndex((t) => typeof t === "string" && t.startsWith(hourPrefix));
    if (idx < 0) return null;
    const values = [precs[idx], precs[idx + 1], precs[idx + 2]].filter(
      (v): v is number => typeof v === "number",
    );
    if (values.length === 0) return null;
    return Math.round(values.reduce((a, b) => a + b, 0) * 10) / 10;
  } catch {
    return null;
  }
}

/** Probabilité de pluie de l'heure en cours / suivante (prévision horaire). */
function precipProbNextHour(json: unknown, currentTime: string | undefined): number | null {
  try {
    const hourly = (json as { hourly?: { time?: string[]; precipitation_probability?: (number | null)[] } })?.hourly;
    const times = hourly?.time;
    const probs = hourly?.precipitation_probability;
    if (!Array.isArray(times) || !Array.isArray(probs) || !currentTime) return null;
    const hourPrefix = currentTime.slice(0, 13);
    const idx = times.findIndex((t) => typeof t === "string" && t.startsWith(hourPrefix));
    if (idx < 0) return null;
    const values = [probs[idx], probs[idx + 1]].filter((v): v is number => typeof v === "number");
    if (values.length === 0) return null;
    return Math.round(Math.max(...values));
  } catch {
    return null;
  }
}

/** Débit du jour + risque de crue (max 3 jours vs médiane de la série GloFAS). */
async function fetchFlood(city: CityDef): Promise<{ discharge: number | null; risk: 0 | 1 | 2 | null }> {
  const hit = floodCache.get(city.id);
  if (hit && Date.now() - hit.at < AUX_CACHE_MS) return hit;
  let result: { discharge: number | null; risk: 0 | 1 | 2 | null } = { discharge: null, risk: null };
  try {
    const url = `https://flood-api.open-meteo.com/v1/flood?latitude=${city.lat}&longitude=${city.lon}&daily=river_discharge&forecast_days=7`;
    const res = await fetch(url, { signal: AbortSignal.timeout(6000), cache: "no-store" });
    if (res.ok) {
      const json = (await res.json()) as { daily?: { river_discharge?: (number | null)[] } };
      const series = (json?.daily?.river_discharge ?? []).filter(
        (v): v is number => typeof v === "number" && v > 0,
      );
      if (series.length >= 4) {
        const today = series[0];
        // Seuil de significativité : sous 50 m³/s, le pixel GloFAS est un
        // cours d'eau mineur — un doublement n'y signifie pas une crue.
        if (today >= 50) {
          const sorted = [...series].sort((a, b) => a - b);
          const median = sorted[Math.floor(sorted.length / 2)] || 1;
          const maxNext3 = Math.max(...series.slice(0, 3));
          const ratio = maxNext3 / Math.max(0.001, median);
          const risk: 0 | 1 | 2 = ratio >= 1.6 ? 2 : ratio >= 1.25 ? 1 : 0;
          result = { discharge: Math.round(today * 10) / 10, risk };
        } else {
          result = { discharge: Math.round(today * 10) / 10, risk: null };
        }
      }
    }
  } catch {
    /* pas de cours d'eau modélisé à proximité : risque inconnu (null) */
  }
  floodCache.set(city.id, { at: Date.now(), ...result });
  return result;
}

/** Indice européen de qualité de l'air (CAMS). */
async function fetchAir(city: CityDef): Promise<number | null> {
  const hit = airCache.get(city.id);
  if (hit && Date.now() - hit.at < AUX_CACHE_MS) return hit.aqi;
  let aqi: number | null = null;
  try {
    const url = `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${city.lat}&longitude=${city.lon}&current=european_aqi`;
    const res = await fetch(url, { signal: AbortSignal.timeout(6000), cache: "no-store" });
    if (res.ok) {
      const json = (await res.json()) as { current?: { european_aqi?: number } };
      if (typeof json?.current?.european_aqi === "number") {
        aqi = Math.round(clamp(json.current.european_aqi, 0, 500));
      }
    }
  } catch {
    aqi = null;
  }
  airCache.set(city.id, { at: Date.now(), aqi });
  return aqi;
}

export async function fetchWeather(city: CityDef): Promise<WeatherInfo> {
  const cached = cache.get(city.id);
  if (cached && Date.now() - cached.at < CACHE_MS) return cached.value;

  const breaker = breakerFor(city.id);
  // Disjoncteur ouvert : on sert la dernière météo connue, sans appel réseau.
  if (breaker.openUntil > Date.now()) {
    return fallbackWeather(city, breaker);
  }

  const [flood, aqi] = await Promise.all([fetchFlood(city), fetchAir(city)]);

  try {
    const url =
      `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}` +
      `&current=temperature_2m,weather_code,wind_speed_10m,precipitation` +
      `&hourly=precipitation_probability,precipitation&forecast_days=2&timezone=auto`;
    const res = await fetch(url, { signal: AbortSignal.timeout(6000), cache: "no-store" });
    if (!res.ok) throw new Error(`Open-Meteo ${res.status}`);
    const json = await res.json();
    const cur = json?.current ?? {};
    const code = typeof cur.weather_code === "number" ? cur.weather_code : 0;
    const precip = typeof cur.precipitation === "number" ? cur.precipitation : 0;
    const { label, level } = labelFor(code, precip);
    const value: WeatherInfo = {
      label,
      level,
      tempC: typeof cur.temperature_2m === "number" ? Math.round(cur.temperature_2m) : null,
      windKmh: typeof cur.wind_speed_10m === "number" ? Math.round(cur.wind_speed_10m) : null,
      precipMm: precip,
      code,
      source: "open-meteo",
      precipProb1h: precipProbNextHour(json, typeof cur.time === "string" ? cur.time : undefined),
      nextRainMm3h: rainNext3h(json, typeof cur.time === "string" ? cur.time : undefined),
      riverDischargeM3s: flood.discharge,
      floodRiskLevel: flood.risk,
      aqiEu: aqi,
    };
    // Succès : disjoncteur refermé, dernière bonne valeur mémorisée.
    breaker.failures = 0;
    breaker.openUntil = 0;
    breaker.lastGood = value;
    cache.set(city.id, { at: Date.now(), value });
    return value;
  } catch {
    // Échec : compteur + ouverture du disjoncteur après 2 échecs (1 h).
    breaker.failures += 1;
    if (breaker.failures >= 2) {
      breaker.openUntil = Date.now() + BREAKER_OPEN_MS;
      breaker.failures = 0;
    }
    const fallback = fallbackWeather(city, breaker);
    return { ...fallback, riverDischargeM3s: flood.discharge, floodRiskLevel: flood.risk, aqiEu: aqi };
  }
}
