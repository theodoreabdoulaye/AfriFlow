import { boolean, check, index, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { sql } from "drizzle-orm";
import { users } from "./auth-schema";

export const paymentOrders = pgTable("payment_orders", {
  id: uuid("id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  plan: text("plan").notNull(),
  productId: text("product_id").notNull(),
  saleId: text("sale_id").unique(),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, t => [
  index("payment_orders_user_idx").on(t.userId),
  check("payment_orders_plan_check", sql`${t.plan} in ('day', 'week', 'month')`),
  check("payment_orders_status_check", sql`${t.status} in ('pending', 'completed')`),
]);

export const paymentGrants = pgTable("payment_grants", {
  saleId: text("sale_id").primaryKey(),
  userId: text("user_id").notNull().references(() => users.id),
  startsAt: timestamp("starts_at", { withTimezone: true }).notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  revoked: boolean("revoked").notNull().default(false),
}, t => [
  index("payment_grants_user_expiry_idx").on(t.userId, t.expiresAt),
  check("payment_grants_duration_check", sql`${t.expiresAt} > ${t.startsAt}`),
]);

export const paymentDeliveries = pgTable("payment_deliveries", {
  id: text("id").primaryKey(),
  saleId: text("sale_id").notNull().references(() => paymentGrants.saleId),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
