import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { extractIncidentEntities } from "@/lib/extract";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/**
 * POST /api/nlp/extract { text, city } — extraction d'entités d'un
 * signalement en langage naturel (français approximatif, wolof, pulaar).
 *
 *   "Y'a un gros trou devant la pharmacie à Yoff"
 *     → { "edge_id": "route-yoff", "type": "nid_de_poule", "severite": 3 }
 *
 * Extraction GPT-4o-mini si OPENAI_API_KEY est configurée, sinon parseur
 * local multilingue ; le lieu est résolu dans le graphe (noms locaux)
 * puis par Nominatim, et rattaché à l'axe par map matching.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`nlp:${clientIp(req)}`, 60, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;
  const text = String(body.text ?? "").trim().slice(0, 500);
  if (text.length < 3) {
    return NextResponse.json({ error: "Texte trop court (3 caractères minimum)." }, { status: 422 });
  }
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  const entities = await extractIncidentEntities(text, city);
  return NextResponse.json({ city: city.id, text, ...entities });
}
