import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { ingestCrowdReport } from "@/lib/crowd";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { ensureCitySeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * POST /api/waze/webhook — réception d'alertes au format Waze
 * (programme Waze for Cities). Chaque alerte est convertie en
 * signalement crowdsourcé (source "waze_webhook", score = reliability)
 * puis traitée par le même consensus pondéré que /api/v1/report :
 * map matching sur l'axe le plus proche, validation à 3 signalements
 * distincts en 10 min ou score cumulé ≥ 20.
 *
 * Corps accepté : { alerts: [{ type, subtype?, location: {x, y},
 *   reliability?, reportDescription?, uuid? }], city? }
 * ou une alerte unique au même format.
 */

const WAZE_TYPE_MAP: Record<string, string> = {
  ACCIDENT: "accident",
  POLICE: "police",
  JAM: "bouchon",
  CONSTRUCTION: "travaux",
  ROAD_WORKS: "travaux",
  WEATHERHAZARD: "inondation",
  HAZARD: "danger",
};

interface WazeAlert {
  type?: string;
  subtype?: string;
  location?: { x?: number; y?: number };
  reliability?: number;
  confidence?: number;
  reportDescription?: string;
  uuid?: string;
  city?: string;
}

export async function POST(req: NextRequest) {
  const rl = rateLimit(`wazewebhook:${clientIp(req)}`, 60, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object") {
    return NextResponse.json({ error: "Corps JSON invalide" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;
  const alertsRaw = Array.isArray(body.alerts) ? body.alerts : [body];
  const alerts = alertsRaw.filter(
    (a): a is WazeAlert => !!a && typeof a === "object",
  );
  if (alerts.length === 0) {
    return NextResponse.json({ error: "Aucune alerte Waze dans le corps" }, { status: 422 });
  }

  const results: Record<string, unknown>[] = [];
  for (const alert of alerts.slice(0, 50)) {
    const lon = Number(alert.location?.x);
    const lat = Number(alert.location?.y);
    if (!Number.isFinite(lat) || !Number.isFinite(lon)) {
      results.push({ uuid: alert.uuid ?? null, accepted: false, reason: "location manquante" });
      continue;
    }
    // Ville : champ explicite, ou la plus proche de l'alerte.
    let city = CITY_MAP[String(body.city ?? alert.city ?? "")];
    if (!city) {
      let bestDist = Infinity;
      for (const c of Object.values(CITY_MAP)) {
        const d = Math.hypot(c.lat - lat, c.lon - lon);
        if (d < bestDist) {
          bestDist = d;
          city = c;
        }
      }
      if (!city || bestDist > 1.5) {
        results.push({ uuid: alert.uuid ?? null, accepted: false, reason: "ville inconnue" });
        continue;
      }
    }
    await ensureCitySeed(city);
    const incidentType =
      WAZE_TYPE_MAP[String(alert.type ?? "").toUpperCase()] ??
      (String(alert.subtype ?? "").includes("POT_HOLE") ? "nid_de_poule" : "danger");
    const score = Math.max(
      1,
      Math.min(10, Number(alert.reliability ?? alert.confidence ?? 7) || 7),
    );
    try {
      const result = await ingestCrowdReport(city, {
        source: "waze_webhook",
        lat,
        lon,
        incidentType,
        confidenceScore: score,
        reporterKey: alert.uuid ?? `waze-${lat},${lon}`,
        description: alert.reportDescription ?? undefined,
      });
      results.push({
        uuid: alert.uuid ?? null,
        accepted: !!result,
        city: city.id,
        edge_id: result?.axisId ?? null,
        validated: result?.validated ?? false,
        status: result?.incident.status ?? null,
      });
    } catch {
      results.push({ uuid: alert.uuid ?? null, accepted: false, reason: "ingestion échouée" });
    }
  }

  return NextResponse.json({ received: alerts.length, results }, { status: 202 });
}
