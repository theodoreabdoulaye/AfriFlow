import { createHash } from "node:crypto";
import { gzipSync } from "node:zlib";
import { NextRequest, NextResponse } from "next/server";

/**
 * Réponse JSON cacheable : ETag fort (SHA-1 du corps) + Cache-Control
 * public avec stale-while-revalidate. Si le client renvoie le même
 * If-None-Match, on répond 304 sans corps — économie de bande passante
 * sur les écrans des conducteurs (2G/3G, forfaits data comptés).
 */
export function jsonCached(
  req: NextRequest,
  payload: unknown,
  maxAgeSec: number,
  swrSec = 60,
): NextResponse {
  const body = JSON.stringify(payload);
  const etag = `"${createHash("sha1").update(body).digest("base64url").slice(0, 24)}"`;
  const headers: Record<string, string> = {
    "Cache-Control": `public, max-age=${maxAgeSec}, stale-while-revalidate=${swrSec}`,
    ETag: etag,
    "Content-Type": "application/json; charset=utf-8",
    Vary: "Accept-Encoding",
  };
  if (req.headers.get("if-none-match") === etag) {
    return new NextResponse(null, { status: 304, headers });
  }
  // Compression gzip explicite pour les grosses réponses : les parcours
  // clients cibles sont en 2G/3G avec data comptée (gain typique ×5-8).
  const acceptsGzip = (req.headers.get("accept-encoding") ?? "").includes("gzip");
  if (acceptsGzip && body.length > 1500) {
    const compressed = gzipSync(Buffer.from(body, "utf-8"), { level: 6 });
    return new NextResponse(compressed, {
      status: 200,
      headers: { ...headers, "Content-Encoding": "gzip", "Content-Length": String(compressed.length) },
    });
  }
  return new NextResponse(body, { status: 200, headers });
}
