import { test } from "node:test";
import assert from "node:assert/strict";
import { validateProductionEnv } from "../scripts/production-env";

const required = {
  DATABASE_URL: "postgresql://user:private-password@db.example.test/app",
  NEXT_PUBLIC_SITE_URL: "https://app.example.test",
  NEXT_PUBLIC_RECAPTCHA_SITE_KEY: "site-key",
  RECAPTCHA_SECRET_KEY: "private-secret",
};

test("required configuration and complete optional integrations pass", () => {
  assert.deepEqual(validateProductionEnv(required), []);
  assert.deepEqual(validateProductionEnv({ ...required,
    NEXT_PUBLIC_GOOGLE_CLIENT_ID: "123-client.apps.googleusercontent.com",
    WHATSAPP_VERIFY_TOKEN: "verify", WHATSAPP_APP_SECRET: "secret",
    WHATSAPP_TOKEN: "token", WHATSAPP_PHONE_NUMBER_ID: "12345",
    CHARIOW_API_KEY: "private", CHARIOW_WEBHOOK_SECRET: "whsec_private",
  }), []);
});

test("missing required values, malformed URLs and unsafe origins fail", () => {
  assert.equal(validateProductionEnv({}).length, 4);
  for (const site of ["http://app.example.test", "https://user:secret@app.example.test", "https://app.example.test/path", "https://app.example.test?x=1", "https://app.example.test#x", "https://localhost", "not-a-url"]) {
    assert.ok(validateProductionEnv({ ...required, NEXT_PUBLIC_SITE_URL: site }).length);
  }
  for (const db of ["https://db.example.test/app", "postgresql://db.example.test", "not-a-url"]) {
    assert.ok(validateProductionEnv({ ...required, DATABASE_URL: db }).length);
  }
  assert.ok(validateProductionEnv({ ...required, RECAPTCHA_SECRET_KEY: " " }).length);
});

test("partial integrations, bad identifiers and public secrets fail without exposing values", () => {
  for (const extra of [
    { WHATSAPP_TOKEN: "sensitive-token" }, { CHARIOW_API_KEY: "sensitive-key" },
    { CHARIOW_WEBHOOK_SECRET: "sensitive-secret" }, { WHATSAPP_PHONE_NUMBER_ID: "bad-id" },
    { NEXT_PUBLIC_GOOGLE_CLIENT_ID: "bad-id" }, { NEXT_PUBLIC_DATABASE_URL: "sensitive-url" },
  ]) {
    const errors = validateProductionEnv({ ...required, ...extra });
    assert.ok(errors.length);
    for (const secret of Object.values(extra)) assert.ok(!errors.join("\n").includes(secret));
  }
});
