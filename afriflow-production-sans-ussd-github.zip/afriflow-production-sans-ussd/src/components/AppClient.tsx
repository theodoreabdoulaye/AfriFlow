"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import Link from "next/link";
import { AlertTriangle, ChevronDown, Compass, Radio } from "lucide-react";
import { CITIES, CITY_MAP, COUNTRIES, CITY_COUNT, COUNTRY_COUNT } from "@/lib/cities";
import { formatCityClock } from "@/lib/format";
import type { HeatmapPayload } from "@/lib/api-types";
import dynamic from "next/dynamic";
import RevealManager from "./Reveal";
import SectionBoundary from "./SectionBoundary";
import SwRegister from "./SwRegister";
import Hero from "./Hero";
import HeatmapSection from "./HeatmapSection";
import RoutingSection from "./RoutingSection";
import Footer from "./Footer";

/**
 * Sections sous la ligne de flottaison : chargées en chunks séparés pour
 * alléger le JavaScript initial (crucial sur mobile d'entrée de gamme).
 */
function SectionSkeleton() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6" aria-hidden>
      <div className="h-48 animate-pulse rounded-3xl border border-night-600 bg-night-900" />
    </div>
  );
}

const CommunitySection = dynamic(() => import("./CommunitySection"), { loading: SectionSkeleton });
const MultimodalSection = dynamic(() => import("./MultimodalSection"), { loading: SectionSkeleton });
const ConvoyTeaser = dynamic(() => import("./ConvoyTeaser"), { loading: SectionSkeleton });
const DataSection = dynamic(() => import("./DataSection"), { loading: SectionSkeleton });
const NetworkSection = dynamic(() => import("./NetworkSection"), { loading: SectionSkeleton });
const PricingSection = dynamic(() => import("./PricingSection"), { loading: SectionSkeleton });

export interface AppContextValue {
  cityId: string;
  setCityId: (id: string) => void;
  heat: HeatmapPayload | null;
  heatLoading: boolean;
  refreshHeat: () => Promise<void>;
  /** null = heure réelle */
  projectedHour: number | null;
  setProjectedHour: (h: number | null) => void;
  selectedAxisId: string | null;
  setSelectedAxisId: (id: string | null) => void;
  clock: Date;
  /** Flux temps réel SSE connecté (sinon, actualisation par polling). */
  live: boolean;
  /** Horodatage de la dernière mise à jour de la carte. */
  lastUpdateAt: number | null;
  /** Mode Économie de données (PWA) : flux réduit, images allégées. */
  dataSaver: boolean;
  setDataSaver: (v: boolean) => void;
}

const AppCtx = createContext<AppContextValue | null>(null);

export function useApp(): AppContextValue {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp hors du fournisseur AppClient");
  return ctx;
}

function AlertTicker() {
  const { heat, cityId } = useApp();
  const city = CITY_MAP[cityId];
  const worst = useMemo(() => {
    if (!heat) return [];
    return [...heat.axes].sort((a, b) => a.fluidity - b.fluidity).slice(0, 3);
  }, [heat]);

  // Le libellé « ALERTES EN COURS — ville » vit UNIQUEMENT dans le cartouche
  // fixe à gauche (sinon il se concatène visuellement au texte défilant).
  const items: string[] = [
    ...worst.map(
      (a) =>
        `${a.name} : ${a.level === "sature" ? "saturé" : a.level === "congestion" ? "congestionné" : "dense"} (${Math.round(a.speedKmh)} km/h, fluidité ${a.fluidity}/100)`,
    ),
    "Circulation surveillée en temps réel — signalez un incident dans l'application web",
    "💬 Bot WhatsApp · 📱 App AfriFlow",
  ];
  const doubled = [...items, ...items];

  return (
    <div className="relative z-40 flex items-stretch overflow-hidden bg-amber-warn text-night-950">
      <div className="flex shrink-0 items-center gap-2 bg-coral px-3 py-1.5 text-[11px] font-bold tracking-wide text-white sm:px-4">
        <AlertTriangle className="h-3.5 w-3.5" />
        <span className="hidden sm:inline">ALERTES EN COURS — {city.name.toUpperCase()}</span>
        <span className="sm:hidden">ALERTES</span>
      </div>
      <div className="relative flex-1 overflow-hidden">
        <div className="ticker-track flex w-max items-center gap-10 py-1.5 pl-6 text-[12px] font-semibold whitespace-nowrap">
          {doubled.map((item, i) => (
            <span key={i} className="flex items-center gap-2" aria-hidden={i >= items.length}>
              <Radio className="h-3 w-3 opacity-60" />
              {item}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

function Header() {
  const { cityId, setCityId, heat, dataSaver, setDataSaver } = useApp();
  const nav = [
    { href: "#dashboard", label: "Carte en direct" },
    { href: "#routage", label: "Itinéraires" },
    { href: "#multimodal", label: "Multimodal" },
    { href: "#communaute", label: "Communauté" },
    { href: "#convoi", label: "Convoi" },
    { href: "#donnees", label: "Données & IA" },
    { href: "#tarifs", label: "Tarifs" },
  ];
  return (
    <header className="sticky top-0 z-30 border-b border-night-600/70 bg-night-950/85 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <Link href="#top" className="flex items-center gap-2.5">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-500 text-night-950">
            <Compass className="h-5 w-5" strokeWidth={2.4} />
          </span>
          <span className="leading-none">
            <span className="block font-display text-lg font-bold tracking-tight">
              Afri<span className="text-brand-500">Flow</span>
            </span>
            <span className="mt-0.5 flex items-center gap-1.5 text-[10px] font-medium tracking-wide text-sage uppercase">
              <span className={`live-dot h-1.5 w-1.5 rounded-full ${heat ? "bg-brand-500" : "bg-amber-warn"}`} />
              Trafic en temps réel
            </span>
          </span>
        </Link>

        <nav className="ml-6 hidden items-center gap-1 lg:flex">
          {nav.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="rounded-lg px-3 py-2 text-[13px] font-medium text-sage transition hover:bg-night-700 hover:text-paper"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <Link href="/compte" className="rounded-xl border border-night-600 bg-night-800 px-3 py-2 text-[12px] font-semibold text-paper">Mon compte</Link>
          {heat && (
            <span
              className="hidden items-center gap-1.5 rounded-xl border border-night-600 bg-night-800 px-3 py-2 text-[12px] font-semibold whitespace-nowrap md:flex"
              title="Heure locale de la ville sélectionnée"
            >
              🕐 <span className="text-mint-300">{formatCityClock(heat.cityTime, new Date())}</span>
              <span className="text-sage">à {heat.cityName}</span>
              {heat.weather.aqiEu !== null && heat.weather.aqiEu !== undefined && (
                <span className="text-sage">· air {heat.weather.aqiEu}</span>
              )}
            </span>
          )}
          <label className="relative flex items-center">
            <span className="sr-only">Ville surveillée</span>
            <select
              value={cityId}
              onChange={(e) => setCityId(e.target.value)}
              className="cursor-pointer appearance-none rounded-xl border border-night-600 bg-night-800 py-2 pr-8 pl-3 text-[13px] font-semibold text-paper outline-none transition hover:border-brand-600 focus:border-brand-500"
            >
              {COUNTRIES.map((country) => (
                <optgroup key={country.code} label={`${country.name} (${country.cityCount})`}>
                  {CITIES.filter((c) => c.countryCode === country.code).map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </optgroup>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-2.5 h-4 w-4 text-sage" />
          </label>
          <button
            onClick={() => setDataSaver(!dataSaver)}
            title="Mode Économie de données : flux temps réel allégé (deltas), images réduites, actualisation espacée"
            className={`rounded-xl border px-3 py-2 text-[11px] font-bold whitespace-nowrap transition ${
              dataSaver
                ? "border-brand-500 bg-brand-500/15 text-mint-300"
                : "border-night-600 bg-night-800 text-sage hover:text-paper"
            }`}
          >
            📉 Éco données {dataSaver ? "ON" : "OFF"}
          </button>
          <span className="hidden rounded-xl border border-night-600 bg-night-800 px-3 py-2 text-[11px] font-semibold text-sage xl:block">
            {CITY_COUNT} villes · {COUNTRY_COUNT} pays
          </span>
        </div>
      </div>
      <nav className="flex gap-1 overflow-x-auto px-4 pb-2 lg:hidden">
        {nav.map((n) => (
          <a
            key={n.href}
            href={n.href}
            className="shrink-0 rounded-lg bg-night-800 px-3 py-1.5 text-[12px] font-medium text-sage"
          >
            {n.label}
          </a>
        ))}
      </nav>
    </header>
  );
}

export default function AppClient({ initialHeat }: { initialHeat: HeatmapPayload | null }) {
  const [cityId, setCityIdState] = useState(initialHeat?.city ?? "dakar");
  const [heat, setHeat] = useState<HeatmapPayload | null>(null);
  const [active, setActive] = useState(false);
  const [accessMessage, setAccessMessage] = useState("Vérification de votre accès en cours.");
  const accessRef = useRef(false);
  const expiryRef = useRef<number | null>(null);
  const generationRef = useRef(0);
  const heatRequestRef = useRef<AbortController | null>(null);
  const [heatLoading, setHeatLoading] = useState(false);
  const [projectedHour, setProjectedHour] = useState<number | null>(null);
  const [selectedAxisId, setSelectedAxisId] = useState<string | null>(null);
  const [clock, setClock] = useState(() => new Date());
  const [live, setLive] = useState(false);
  const [lastUpdateAt, setLastUpdateAt] = useState<number | null>(null);
  const [dataSaver, setDataSaverState] = useState(false);
  const [toasts, setToasts] = useState<{ id: number; message: string; expired: boolean }[]>([]);
  const lockAccess = useCallback((message: string) => {
    accessRef.current = false;
    expiryRef.current = null;
    generationRef.current += 1;
    heatRequestRef.current?.abort();
    setActive(false);
    setHeat(null);
    setLive(false);
    setLastUpdateAt(null);
    setHeatLoading(false);
    setToasts([]);
    setAccessMessage(message);
  }, []);

  useEffect(() => {
    let disposed = false;
    let request = 0;
    const check = async () => {
      const current = ++request;
      const generation = generationRef.current;
      try {
        const res = await fetch("/api/access", { cache: "no-store" });
        if (!res.ok) throw new Error();
        const data = await res.json() as { active: boolean; expiresAt: string | null };
        if (disposed || current !== request || generation !== generationRef.current) return;
        const expires = data.expiresAt ? Date.parse(data.expiresAt) : NaN;
        if (data.active === true && Number.isFinite(expires) && expires > Date.now()) {
          accessRef.current = true;
          expiryRef.current = expires;
          setActive(true);
        } else {
          lockAccess("Connectez-vous ou renouvelez votre accès pour consulter ces services.");
        }
      } catch {
        if (!disposed && current === request && generation === generationRef.current) {
          lockAccess("Accès non vérifié : services verrouillés. Réessayez depuis votre compte.");
        }
      }
    };
    const accountChanged = () => {
      lockAccess("Vérification de votre compte en cours.");
      void check();
    };
    void check();
    const poll = window.setInterval(() => void check(), 30_000);
    const expiry = window.setInterval(() => {
      if (expiryRef.current !== null && Date.now() >= expiryRef.current) {
        lockAccess("Votre accès a expiré. Renouvelez-le depuis votre compte.");
        void check();
      }
    }, 1000);
    window.addEventListener("focus", check);
    window.addEventListener("afri:account", accountChanged);
    return () => {
      disposed = true;
      generationRef.current += 1;
      heatRequestRef.current?.abort();
      clearInterval(poll);
      clearInterval(expiry);
      window.removeEventListener("focus", check);
      window.removeEventListener("afri:account", accountChanged);
    };
  }, [lockAccess]);


  // Restaure le Mode Économie de données choisi précédemment.
  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        if (window.localStorage.getItem("afri_data_saver") === "1") setDataSaverState(true);
      } catch {
        /* stockage indisponible */
      }
    }, 0);
    return () => clearTimeout(t);
  }, []);

  const setDataSaver = useCallback((v: boolean) => {
    setDataSaverState(v);
    try {
      window.localStorage.setItem("afri_data_saver", v ? "1" : "0");
    } catch {
      /* stockage indisponible */
    }
  }, []);

  const refreshHeat = useCallback(async () => {
    if (!accessRef.current || (expiryRef.current ?? 0) <= Date.now()) return;
    heatRequestRef.current?.abort();
    const controller = new AbortController();
    heatRequestRef.current = controller;
    const generation = generationRef.current;
    setHeatLoading(true);
    try {
      const q = new URLSearchParams({ city: cityId });
      if (projectedHour !== null) q.set("hour", String(projectedHour));
      const res = await fetch(`/api/heatmap?${q.toString()}`, { cache: "no-store", signal: controller.signal });
      if (controller.signal.aborted || generation !== generationRef.current || !accessRef.current) return;
      if (res.status === 401 || res.status === 402) {
        lockAccess("Votre accès n’est plus actif. Connectez-vous ou renouvelez-le depuis votre compte.");
        return;
      }
      if (res.ok) {
        const payload = await res.json() as HeatmapPayload;
        if (controller.signal.aborted || generation !== generationRef.current || !accessRef.current || (expiryRef.current ?? 0) <= Date.now()) return;
        setHeat(payload);
        setLastUpdateAt(Date.now());
      }
    } catch {
      /* on conserve le dernier état connu */
    } finally {
      if (heatRequestRef.current === controller) setHeatLoading(false);
    }
  }, [cityId, projectedHour, lockAccess]);

  // Flux d'alertes validées par le consensus (SSE Hub) : toast + carte à jour.
  useEffect(() => {
    if (!active || typeof EventSource === "undefined") return;
    let closed = false;
    const generation = generationRef.current;
    const source = new EventSource(`/api/v1/stream?city=${cityId}`);
    source.addEventListener("alert", (event) => {
      if (closed || generation !== generationRef.current || !accessRef.current || (expiryRef.current ?? 0) <= Date.now()) return;
      try {
        const data = JSON.parse((event as MessageEvent<string>).data) as {
          event_type: string;
          message: string;
        };
        const id = Date.now() + Math.random();
        setToasts((prev) => [
          ...prev.slice(-3),
          { id, message: data.message, expired: data.event_type === "alert_expired" },
        ]);
        window.setTimeout(() => {
          setToasts((prev) => prev.filter((t) => t.id !== id));
        }, 8000);
        void refreshHeat();
        window.dispatchEvent(new CustomEvent("afri:alert"));
      } catch {
        /* événement illisible ignoré */
      }
    });
    source.onerror = () => { void refreshHeat(); };
    return () => { closed = true; source.close(); };
  }, [cityId, refreshHeat, active]);


  // Flux temps réel (SSE) : la carte se met à jour dès qu'un évènement
  // arrive ; en mode projection horaire, on reste sur le polling classique.
  useEffect(() => {
    if (!active || projectedHour !== null || typeof EventSource === "undefined") {
      return;
    }
    let closed = false;
    const generation = generationRef.current;
    const source = new EventSource(`/api/stream?city=${cityId}`);
    source.addEventListener("heatmap", (event) => {
      if (closed || generation !== generationRef.current || !accessRef.current || (expiryRef.current ?? 0) <= Date.now()) return;
      try {
        setHeat(JSON.parse((event as MessageEvent<string>).data) as HeatmapPayload);
        setLastUpdateAt(Date.now());
        setLive(true);
      } catch {
        /* évènement illisible ignoré */
      }
    });
    // Deltas légers : seuls les axes modifiés sont fusionnés dans l'état.
    source.addEventListener("delta", (event) => {
      if (closed || generation !== generationRef.current || !accessRef.current || (expiryRef.current ?? 0) <= Date.now()) return;
      try {
        const delta = JSON.parse((event as MessageEvent<string>).data) as {
          at: string;
          cityTime: string;
          changed: {
            axisId: string;
            speedKmh: number;
            fluidity: number;
            level: string;
            vehiclesTracked: number;
            measured: boolean;
            dataSource: string;
            simulated: boolean;
          }[];
          summary?: HeatmapPayload["summary"];
          dataCoverage?: HeatmapPayload["dataCoverage"];
        };
        setHeat((prev) => {
          if (!prev) return prev;
          const byId = new Map(delta.changed.map((c) => [c.axisId, c]));
          // Seuls les axes modifiés sont fusionnés ; tendances et
          // prédictions seront rafraîchies au prochain cycle complet.
          return {
            ...prev,
            axes: prev.axes.map((a) => {
              const c = byId.get(a.axisId);
              return c
                ? {
                    ...a,
                    speedKmh: c.speedKmh,
                    fluidity: c.fluidity,
                    level: c.level as typeof a.level,
                    vehiclesTracked: c.vehiclesTracked,
                    measured: c.measured,
                    dataSource: c.dataSource as typeof a.dataSource,
                    simulated: c.simulated,
                  }
                : a;
            }),
            at: delta.at,
            cityTime: delta.cityTime,
            summary: delta.summary ?? prev.summary,
            dataCoverage: delta.dataCoverage ?? prev.dataCoverage,
          };
        });
        setLastUpdateAt(Date.now());
        setLive(true);
      } catch {
        /* delta illisible ignoré */
      }
    });
    source.onerror = () => { setLive(false); void refreshHeat(); };
    return () => {
      closed = true;
      source.close();
      setLive(false);
    };
  }, [cityId, projectedHour, active, refreshHeat]);

  const setCityId = useCallback((id: string) => {
    setCityIdState(id);
    setSelectedAxisId(null);
    // Lien partageable par ville : /?ville=lagos
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("ville", id);
      window.history.replaceState(null, "", url.toString());
    } catch {
      /* historique indisponible */
    }
  }, []);

  // Deep-link entrant : /?ville=<id> sélectionne directement la ville.
  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        const ville = new URLSearchParams(window.location.search).get("ville");
        if (ville && CITY_MAP[ville] && ville !== cityId) {
          setCityId(ville);
        }
      } catch {
        /* URL illisible ignorée */
      }
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!active) return;
    const initialRefresh = window.setTimeout(() => void refreshHeat(), 0);
    return () => {
      clearTimeout(initialRefresh);
      heatRequestRef.current?.abort();
    };
  }, [refreshHeat, active]);

  useEffect(() => {
    // Mode Économie de données : actualisation deux fois moins fréquente.
    const t = active ? setInterval(() => void refreshHeat(), dataSaver ? 60_000 : 30_000) : undefined;
    const c = setInterval(() => setClock(new Date()), 20_000);
    return () => {
      clearInterval(t);
      clearInterval(c);
    };
  }, [refreshHeat, dataSaver, active]);

  const value = useMemo<AppContextValue>(
    () => ({
      cityId,
      setCityId,
      heat: active ? heat : null,
      heatLoading: active && heatLoading,
      refreshHeat,
      projectedHour,
      setProjectedHour,
      selectedAxisId,
      setSelectedAxisId,
      clock,
      live: active && live,
      lastUpdateAt: active ? lastUpdateAt : null,
      dataSaver,
      setDataSaver,
    }),
    [cityId, setCityId, heat, heatLoading, refreshHeat, projectedHour, selectedAxisId, clock, live, lastUpdateAt, dataSaver, setDataSaver, active],
  );

  const city = CITY_MAP[cityId];

  return (
    <AppCtx.Provider value={value}>
      <RevealManager />
      <SwRegister />
      <a
        href="#dashboard"
        className="sr-only focus:not-sr-only focus:absolute focus:z-50 focus:bg-brand-500 focus:px-4 focus:py-2 focus:font-bold focus:text-night-950"
      >
        Aller directement à la carte thermique
      </a>
      <AlertTicker />
      <Header />
      <main key={city.id}>
        <Hero />
        {active ? <>
        <SectionBoundary name="Carte thermique">
          <HeatmapSection />
        </SectionBoundary>
        <SectionBoundary name="Itinéraires ventilés">
          <RoutingSection />
        </SectionBoundary>
        <SectionBoundary name="Multimodal, parkings & covoiturage">
          <MultimodalSection />
        </SectionBoundary>
        <SectionBoundary name="Communauté">
          <CommunitySection />
        </SectionBoundary>
        <SectionBoundary name="Convoi Industriel">
          <ConvoyTeaser />
        </SectionBoundary>
        <SectionBoundary name="Données & IA">
          <DataSection />
        </SectionBoundary>
        </> : [
          ["dashboard", "Carte en direct"], ["routage", "Itinéraires"],
          ["multimodal", "Multimodal"], ["communaute", "Communauté"],
          ["convoi", "Convoi Industriel"], ["donnees", "Données & IA"],
        ].map(([id, title]) => (
          <section key={id} id={id} className="mx-auto max-w-7xl scroll-mt-24 px-4 py-10 sm:px-6">
            <div className="rounded-3xl border border-night-600 bg-night-900 p-6">
              <h2 className="font-display text-2xl font-bold">{title}</h2>
              <p className="mt-2 text-sm text-sage">{accessMessage}</p>
              <Link href="/compte" className="mt-4 inline-block rounded-xl bg-brand-500 px-5 py-3 text-sm font-bold text-night-950">Mon compte et mon accès</Link>
            </div>
          </section>
        ))}
        <SectionBoundary name="Réseau déployé">
          <NetworkSection />
        </SectionBoundary>
        <SectionBoundary name="Tarifs">
          <PricingSection />
        </SectionBoundary>
      </main>
      <Footer />
      <BackToTop />
      <div className="pointer-events-none fixed bottom-5 left-5 z-50 flex w-80 max-w-[calc(100vw-2.5rem)] flex-col gap-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            role="alert"
            className={`pointer-events-auto rounded-2xl border px-4 py-3 text-[13px] leading-snug font-semibold shadow-2xl backdrop-blur ${
              t.expired
                ? "border-night-500 bg-night-800/95 text-sage"
                : "border-amber-warn/60 bg-[#2a1f05]/95 text-amber-100"
            }`}
          >
            {t.message}
          </div>
        ))}
      </div>
    </AppCtx.Provider>
  );
}

function BackToTop() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 900);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);
  if (!visible) return null;
  return (
    <button
      onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
      aria-label="Retour en haut de page"
      className="fixed right-5 bottom-5 z-40 grid h-11 w-11 place-items-center rounded-full bg-brand-500 text-night-950 shadow-xl shadow-black/40 transition hover:bg-mint-400"
    >
      ↑
    </button>
  );
}
