import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { db } from "@/db";
import { fleetVehicles } from "@/db/schema";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { buildFleet, buildHeatmap } from "@/lib/server-data";
import { ensureCitySeed, ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

/** GET /api/fleet?city=dakar — convoi industriel, positions fusionnées à la carte thermique. */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  await ensureSeed();
  await ensureCitySeed(city);
  const heat = await buildHeatmap(city);
  const vehicles = await buildFleet(city, heat);
  const moving = vehicles.filter((v) => v.status === "En mouvement").length;
  const blocked = vehicles.filter((v) => v.status === "Bloqué").length;
  const avgEta = vehicles.length
    ? Math.round(vehicles.reduce((a, v) => a + v.etaMin, 0) / vehicles.length)
    : 0;
  const fuelEmbarked = Math.round(vehicles.reduce((a, v) => a + v.fuelL, 0));
  return NextResponse.json({
    city: city.id,
    vehicles,
    stats: { total: vehicles.length, moving, blocked, avgEta, fuelEmbarked },
  }, { headers: { "Cache-Control": "private, no-store" } });
}

/** POST /api/fleet — déclarer un véhicule réel de sa flotte. */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`fleet:${clientIp(req)}`, 60, 600_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  const body = raw as Record<string, unknown>;
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  const plate = String(body.plate ?? "").trim().slice(0, 20);
  const driver = String(body.driver ?? "").trim().slice(0, 60);
  const cargo = String(body.cargo ?? "").trim().slice(0, 80);
  const origin = String(body.origin ?? "").trim().slice(0, 60);
  const destination = String(body.destination ?? "").trim().slice(0, 60);
  const axisId = String(body.axisId ?? "");
  if (!plate || !driver || !cargo || !origin || !destination || !getAxis(city, axisId)) {
    return NextResponse.json({ error: "Tous les champs et un axe valide sont requis." }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }
  const phoneRaw = typeof body.phone === "string" ? body.phone.trim() : "";
  if (phoneRaw && phoneRaw.replace(/[^\d]/g, "").length < 8) {
    return NextResponse.json(
      { error: "Téléphone du chauffeur invalide (8 chiffres minimum pour les alertes SMS)." },
      { status: 422, headers: { "Cache-Control": "private, no-store" } },
    );
  }

  await ensureSeed();
  try {
    const [created] = await db
      .insert(fleetVehicles)
      .values({
        city: city.id,
        plate,
        driver,
        phone: typeof body.phone === "string" ? body.phone.slice(0, 24) : null,
        cargo,
        origin,
        destination,
        axisId,
        speedKmh: Math.max(0, Math.min(120, Number(body.speedKmh ?? 35) || 35)),
        etaMin: Math.max(1, Math.min(600, Number(body.etaMin ?? 45) || 45)),
        fuelL: Math.max(0, Math.min(900, Number(body.fuelL ?? 150) || 150)),
        status: "En mouvement",
      })
      .returning();
    return NextResponse.json({ vehicle: created }, { status: 201, headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return NextResponse.json({ error: "Enregistrement indisponible" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
  }
}
