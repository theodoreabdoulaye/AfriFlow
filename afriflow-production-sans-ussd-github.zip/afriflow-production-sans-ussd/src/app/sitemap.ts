import type { MetadataRoute } from "next";
import { CITIES } from "@/lib/cities";

const BASE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? "https://afriflow.app";

export default function sitemap(): MetadataRoute.Sitemap {
  const now = new Date();
  return [
    { url: `${BASE_URL}/`, lastModified: now, changeFrequency: "always", priority: 1 },
    { url: `${BASE_URL}/convoi`, lastModified: now, changeFrequency: "always", priority: 0.9 },
    ...CITIES.map((city) => ({
      url: `${BASE_URL}/?ville=${city.id}`,
      lastModified: now,
      changeFrequency: "hourly" as const,
      priority: 0.7,
    })),
  ];
}
