import type { CityDef } from "./cities";
import { haversineKm } from "./engine";

/**
 * Réseau de transport collectif : gares TER réelles (Dakar ↔ Diamniadio
 * ↔ AIBD), stations BRT de Dakar et hubs de transport informel
 * (Car Rapide / gbaka). Pour les autres villes, des hubs Car Rapide
 * sont dérivés des quartiers de la ville.
 */

export type TransportMode = "car" | "ter" | "brt" | "carrapide" | "walking" | "bike";

export interface TransitStop {
  id: string;
  name: string;
  mode: "ter" | "brt" | "carrapide";
  lat: number;
  lon: number;
  parkingSpots: number;
  frequencyMinutes: number;
  operatingHours: [number, number]; // (début, fin)
  line: string;
}

/** Ligne TER Dakar — AIBD : gares réelles et temps de parcours par tronçon. */
export const TER_LINE = {
  name: "TER Dakar — AIBD",
  fareFcfa: 1500,
  segmentMinutes: [3, 4, 2, 2, 3, 3, 5, 5, 8], // total Dakar → AIBD : 35 min
};

const DAKAR_STOPS: TransitStop[] = [
  { id: "ter-dakar", name: "Gare de Dakar (Plateau)", mode: "ter", lat: 14.6723, lon: -17.4387, parkingSpots: 200, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-colobane", name: "Colobane", mode: "ter", lat: 14.695, lon: -17.437, parkingSpots: 40, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-hann", name: "Hann", mode: "ter", lat: 14.708, lon: -17.46, parkingSpots: 60, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-dalifort", name: "Dalifort", mode: "ter", lat: 14.728, lon: -17.428, parkingSpots: 30, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-baux", name: "Baux Maraichers", mode: "ter", lat: 14.738, lon: -17.41, parkingSpots: 30, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-pikine", name: "Pikine", mode: "ter", lat: 14.753, lon: -17.388, parkingSpots: 80, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-thiaroye", name: "Thiaroye", mode: "ter", lat: 14.742, lon: -17.33, parkingSpots: 50, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-bargny", name: "Bargny", mode: "ter", lat: 14.715, lon: -17.235, parkingSpots: 40, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-diamniadio", name: "Diamniadio", mode: "ter", lat: 14.723, lon: -17.183, parkingSpots: 500, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  { id: "ter-aibd", name: "AIBD (Aéroport)", mode: "ter", lat: 14.6728, lon: -17.0725, parkingSpots: 1000, frequencyMinutes: 15, operatingHours: [5, 23], line: TER_LINE.name },
  // BRT Dakar (Guédiawaye ↔ Petersen)
  { id: "brt-guediawaye", name: "Guédiawaye (BRT)", mode: "brt", lat: 14.777, lon: -17.385, parkingSpots: 60, frequencyMinutes: 8, operatingHours: [5, 23], line: "BRT Dakar" },
  { id: "brt-pikine", name: "Pikine (BRT)", mode: "brt", lat: 14.755, lon: -17.39, parkingSpots: 40, frequencyMinutes: 8, operatingHours: [5, 23], line: "BRT Dakar" },
  { id: "brt-grand-dakar", name: "Grand Dakar (BRT)", mode: "brt", lat: 14.715, lon: -17.455, parkingSpots: 20, frequencyMinutes: 8, operatingHours: [5, 23], line: "BRT Dakar" },
  { id: "brt-petersen", name: "Petersen — Plateau (BRT)", mode: "brt", lat: 14.67, lon: -17.435, parkingSpots: 30, frequencyMinutes: 8, operatingHours: [5, 23], line: "BRT Dakar" },
  // Hubs Car Rapide (transport informel)
  { id: "cr-petersen", name: "Gare routière Petersen", mode: "carrapide", lat: 14.6695, lon: -17.4345, parkingSpots: 0, frequencyMinutes: 5, operatingHours: [5, 23], line: "Car Rapide" },
  { id: "cr-latdior", name: "Gare Lat Dior", mode: "carrapide", lat: 14.686, lon: -17.439, parkingSpots: 0, frequencyMinutes: 5, operatingHours: [5, 23], line: "Car Rapide" },
  { id: "cr-pikine", name: "Gare routière de Pikine", mode: "carrapide", lat: 14.749, lon: -17.382, parkingSpots: 0, frequencyMinutes: 5, operatingHours: [5, 23], line: "Car Rapide" },
  { id: "cr-colobane", name: "Terminus Colobane", mode: "carrapide", lat: 14.696, lon: -17.435, parkingSpots: 0, frequencyMinutes: 5, operatingHours: [5, 23], line: "Car Rapide" },
];

/** Coordonnées GPS approximatives d'une zone (extrémités des axes). */
export function zoneLatLon(city: CityDef, zoneId: string): [number, number] | null {
  for (const axis of city.axes) {
    if (axis.from === zoneId) return axis.gps[0];
    if (axis.to === zoneId) return axis.gps[axis.gps.length - 1];
  }
  return null;
}

/** Arrêts de transport d'une ville (réseau réel à Dakar, hubs dérivés ailleurs). */
export function transitStopsFor(city: CityDef): TransitStop[] {
  if (city.id === "dakar") return DAKAR_STOPS;
  // Autres villes : hubs de transport informel dérivés des quartiers
  // (centre + deux quartiers majeurs), fréquences élevées type gbaka.
  const stops: TransitStop[] = [];
  const picks = [city.zones[0], city.zones[Math.floor(city.zones.length / 2)], city.zones[city.zones.length - 1]];
  picks.forEach((zone, i) => {
    if (!zone) return;
    const coords = zoneLatLon(city, zone.id);
    if (!coords) return;
    stops.push({
      id: `cr-${city.id}-${i}`,
      name: i === 0 ? `Gare routière — ${zone.name}` : `Arrêt Car Rapide — ${zone.name}`,
      mode: "carrapide",
      lat: coords[0],
      lon: coords[1],
      parkingSpots: 0,
      frequencyMinutes: 6,
      operatingHours: [5, 23],
      line: "Car Rapide / Gbaka",
    });
  });
  return stops;
}

/** Temps de trajet TER entre deux gares (minutes, cumuls de la ligne). */
export function terDurationMinutes(fromId: string, toId: string): number | null {
  const stops = DAKAR_STOPS.filter((s) => s.mode === "ter");
  const i = stops.findIndex((s) => s.id === fromId);
  const j = stops.findIndex((s) => s.id === toId);
  if (i < 0 || j < 0 || i === j) return null;
  const [a, b] = i < j ? [i, j] : [j, i];
  return TER_LINE.segmentMinutes.slice(a, b).reduce((acc, m) => acc + m, 0);
}

/** Prochain départ d'un arrêt à fréquence fixe (heure locale ville). */
export function nextDeparture(
  stop: TransitStop,
  atLocal: Date,
): { time: string; waitMinutes: number; inService: boolean } {
  const minutes = atLocal.getUTCHours() * 60 + atLocal.getUTCMinutes();
  const [startH, endH] = stop.operatingHours;
  const start = startH * 60;
  const end = endH * 60;
  if (minutes < start) {
    return {
      time: `${String(startH).padStart(2, "0")}:00`,
      waitMinutes: start - minutes,
      inService: false,
    };
  }
  if (minutes >= end) {
    return { time: `${String(startH).padStart(2, "0")}:00 (+1 j)`, waitMinutes: 24 * 60 - minutes + start, inService: false };
  }
  const next = start + Math.ceil((minutes - start) / stop.frequencyMinutes) * stop.frequencyMinutes;
  const hh = Math.floor(next / 60);
  const mm = next % 60;
  return {
    time: `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`,
    waitMinutes: Math.max(0, next - minutes),
    inService: true,
  };
}

export function nearestStop(
  stops: TransitStop[],
  lat: number,
  lon: number,
  mode?: TransitStop["mode"],
): { stop: TransitStop; distanceKm: number } | null {
  let best: { stop: TransitStop; distanceKm: number } | null = null;
  for (const stop of stops) {
    if (mode && stop.mode !== mode) continue;
    const d = haversineKm([lat, lon], [stop.lat, stop.lon]);
    if (!best || d < best.distanceKm) best = { stop, distanceKm: d };
  }
  return best;
}
