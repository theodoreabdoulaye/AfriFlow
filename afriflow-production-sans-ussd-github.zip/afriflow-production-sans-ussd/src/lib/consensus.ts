/** Règles du consensus communautaire AfriFlow (signalements). */

export const INCIDENT_TYPES = [
  "accident",
  "bouchon",
  "travaux",
  "police",
  "inondation",
  "panne",
  "danger",
] as const;

/** Confiance selon le nombre de confirmations : 38 % → 71 % → 98 %. */
export function confidenceFor(confirmations: number): number {
  if (confirmations <= 1) return 38;
  if (confirmations === 2) return 71;
  return 98;
}

/** À 3 confirmations de conducteurs distincts : diffusion à toute la ville. */
export function statusFor(confirmations: number): string {
  if (confirmations >= 3) return "broadcast";
  if (confirmations === 2) return "confirmed";
  return "pending";
}

export interface ConfirmationIdentity {
  network: string;
  deviceHash: string | null;
}

/**
 * Ce conducteur a-t-il déjà compté pour cet incident ?
 * L'identité est l'appareil anonyme quand il est fourni (deux abonnés
 * Orange distincts comptent donc séparément) ; à défaut, on retombe sur
 * le réseau seul (clients API historiques sans identifiant d'appareil).
 */
export function alreadyCounted(
  existing: ConfirmationIdentity[],
  network: string,
  deviceHash: string | null,
): boolean {
  return existing.some((c) => {
    if (deviceHash) {
      return c.deviceHash === deviceHash || (c.deviceHash === null && c.network === network);
    }
    return c.network === network;
  });
}
