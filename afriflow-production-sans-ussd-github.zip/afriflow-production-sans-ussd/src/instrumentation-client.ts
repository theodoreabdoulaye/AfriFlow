import * as Sentry from "@sentry/nextjs";

/**
 * Surveillance d'erreurs Sentry (navigateur) : activée uniquement si
 * NEXT_PUBLIC_SENTRY_DSN est définie. Capture les erreurs React/JS non
 * gérées (ex. flux temps réel interrompu) sans affecter l'expérience.
 */
if (process.env.NEXT_PUBLIC_SENTRY_DSN) {
  Sentry.init({
    dsn: process.env.NEXT_PUBLIC_SENTRY_DSN,
    tracesSampleRate: 0.1,
  });
}
