import type { AxisLiveState, CitySummary, WeatherInfo } from "./engine";

export interface HeatmapPayload {
  city: string;
  cityName: string;
  /** Instant réel (UTC). */
  at: string;
  /** Heure locale de la ville, encodée en composantes UTC (à formater en getUTC*). */
  cityTime: string;
  /** Heure locale de la ville (0-23). */
  hour: number;
  weather: WeatherInfo;
  axes: AxisLiveState[];
  summary: CitySummary;
  telemetryPoints24h: number;
  /** Points GPS réels sur 24 h (hors simulateur de démonstration). */
  realPoints24h: number;
  /** Cold start : < 5 points GPS réels — les scores IA sont masqués. */
  coldStart: boolean;
  /** Délestages réellement accordés sur 24 h (grants de quota en base). */
  quotaGrants24h: number;
  /** Axes alimentés par des mesures GPS réelles fraîches (≤ 10 min). */
  measuredAxes: number;
  /** Couverture des axes par provenance de la donnée (voir dataSource). */
  dataCoverage: { reel: number; estime: number; aucune: number; simulatedAxes: number };
}

export interface IncidentRow {
  id: number;
  city: string;
  axisId: string;
  type: string;
  severity: number;
  channel: string;
  network: string;
  description: string | null;
  confirmations: number;
  confidence: number;
  status: string; // pending | confirmed | broadcast
  createdAt: string;
  updatedAt: string;
}

export interface FleetVehicleRow {
  id: number;
  plate: string;
  driver: string;
  phone: string;
  cargo: string;
  origin: string;
  destination: string;
  axisId: string;
  speedKmh: number;
  etaMin: number;
  fuelL: number;
  status: string;
  convoy: boolean;
  city: string;
}

export interface FleetPayload {
  city: string;
  vehicles: FleetVehicleRow[];
  stats: { total: number; moving: number; blocked: number; avgEta: number; fuelEmbarked: number };
}

export interface SourceStatus {
  id: string;
  name: string;
  detail: string;
  status: string;
  /** Niveau technique : ok | degraded | info | off (couleurs d'UI). */
  level: string;
  latencyMs: number | null;
  metric: string;
}

export interface SourcesPayload {
  city: string;
  computedInMs: number;
  sources: SourceStatus[];
}
