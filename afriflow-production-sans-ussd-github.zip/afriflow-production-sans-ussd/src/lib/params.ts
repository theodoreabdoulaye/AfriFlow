/** Heure de projection valide : entier entre 0 et 23, sinon temps réel (null). */
export function parseHourParam(value: string | null): number | null {
  if (value === null || value === "") return null;
  const n = Number(value);
  return Number.isInteger(n) && n >= 0 && n <= 23 ? n : null;
}
