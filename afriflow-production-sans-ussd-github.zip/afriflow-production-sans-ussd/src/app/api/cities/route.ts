import { NextRequest } from "next/server";
import { jsonCached } from "@/lib/http-cache";
import { buildCitySummaries } from "@/lib/server-data";

export const dynamic = "force-dynamic";

let payloadCache: { at: number; payload: Record<string, unknown> } | null = null;
const CACHE_MS = 30_000;

/**
 * GET /api/cities — vue réseau : indice de fluidité prévisionnel de
 * chacune des 112 villes activées (profils horaires appris), regroupable
 * par pays. Sert la section « Réseau déployé » et les intégrations.
 * Réponse cacheable (ETag) : l'horodatage est figé dans la fenêtre de cache.
 */
export async function GET(req: NextRequest) {
  if (!payloadCache || Date.now() - payloadCache.at >= CACHE_MS) {
    const cities = buildCitySummaries();
    const worst = [...cities].sort((a, b) => a.index - b.index).slice(0, 5);
    const best = [...cities].sort((a, b) => b.index - a.index).slice(0, 5);
    payloadCache = {
      at: Date.now(),
      payload: {
        generatedAt: new Date().toISOString(),
        total: cities.length,
        cities,
        insights: { mostCongested: worst, mostFluid: best },
      },
    };
  }
  return jsonCached(req, payloadCache.payload, 30, 120);
}
