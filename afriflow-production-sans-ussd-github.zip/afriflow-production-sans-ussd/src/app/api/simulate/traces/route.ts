import { NextRequest, NextResponse } from "next/server";
import { and, count, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { telemetryPoints } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { simulateTraces } from "@/lib/simulator";

export const dynamic = "force-dynamic";

/**
 * GET /api/simulate/traces?city=dakar — provenance des points GPS reçus
 * sur 24 h, par source (conducteurs réels vs simulateur de démonstration).
 */
export async function GET(req: NextRequest) {
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  let bySource: Record<string, number> = {};
  try {
    const since = new Date(Date.now() - 24 * 3600_000);
    const rows = await db
      .select({ source: telemetryPoints.source, n: count() })
      .from(telemetryPoints)
      .where(and(eq(telemetryPoints.city, city.id), gte(telemetryPoints.createdAt, since)))
      .groupBy(telemetryPoints.source);
    bySource = Object.fromEntries(rows.map((r) => [r.source, r.n]));
  } catch {
    bySource = {};
  }
  const simulated = bySource.simulateur ?? 0;
  const total = Object.values(bySource).reduce((a, b) => a + b, 0);
  return NextResponse.json({
    city: city.id,
    windowHours: 24,
    bySource,
    total,
    real: total - simulated,
    simulated,
  });
}

/**
 * POST /api/simulate/traces { city, vehicles? } — génère des traces GPS
 * de démonstration qui circulent sur les axes de la ville et alimentent
 * le moteur comme de vrais GPS (source « simulateur », toujours tracée).
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`simulate:${clientIp(req)}`, 12, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown = null;
  try {
    raw = await req.json();
  } catch {
    /* corps optionnel */
  }
  const body = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  const vehicles = Math.max(4, Math.min(60, Number(body.vehicles ?? 18) || 18));

  try {
    const result = await simulateTraces(city, vehicles);
    return NextResponse.json({
      city: city.id,
      source: "simulateur",
      ...result,
      note: "Traces de démonstration injectées dans le pipeline GPS réel (map matching + lissage α=0,3). Elles sont toujours distinguées des GPS des conducteurs (source « simulateur »).",
    });
  } catch {
    return NextResponse.json({ error: "Simulation indisponible" }, { status: 503 });
  }
}
