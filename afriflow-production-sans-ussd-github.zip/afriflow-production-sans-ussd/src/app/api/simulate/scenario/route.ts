import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { runDemoScenario } from "@/lib/simulator";

export const dynamic = "force-dynamic";

/**
 * POST /api/simulate/scenario { city } — active le scénario « Démo Live »
 * d'une ville : traces GPS de démonstration sur les axes + un incident
 * emblématique (travaux) validé par le consensus, le tout étiqueté DÉMO.
 * Sert à démontrer la valeur du produit dès la première visite, sans
 * jamais maquiller ces données en mesures réelles.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`scenario:${clientIp(req)}`, 6, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown = null;
  try {
    raw = await req.json();
  } catch {
    /* corps optionnel */
  }
  const body = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  try {
    const result = await runDemoScenario(city);
    return NextResponse.json({
      city: city.id,
      demoLive: true,
      ...result,
      note: "Scénario de démonstration : traces « simulateur » et incident [DÉMO LIVE], toujours distingués des données réelles des conducteurs.",
    });
  } catch {
    return NextResponse.json({ error: "Scénario indisponible" }, { status: 503 });
  }
}
