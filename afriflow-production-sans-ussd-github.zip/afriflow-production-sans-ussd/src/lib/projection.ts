/**
 * Projection GPS (lon/lat) → coordonnées SVG de la carte thermique
 * (régression affine sur les paires connues axes GPS ↔ tracés SVG).
 * Module client-safe : aucune dépendance serveur.
 */
import type { CityDef } from "./cities";

function solve3(a: number[][], b: number[]): number[] | null {
  const m = a.map((row, i) => [...row, b[i]]);
  for (let col = 0; col < 3; col++) {
    let pivot = col;
    for (let r = col + 1; r < 3; r++) {
      if (Math.abs(m[r][col]) > Math.abs(m[pivot][col])) pivot = r;
    }
    if (Math.abs(m[pivot][col]) < 1e-12) return null;
    [m[col], m[pivot]] = [m[pivot], m[col]];
    for (let r = 0; r < 3; r++) {
      if (r === col) continue;
      const factor = m[r][col] / m[col][col];
      for (let c = col; c < 4; c++) m[r][c] -= factor * m[col][c];
    }
  }
  return [m[0][3] / m[0][0], m[1][3] / m[1][1], m[2][3] / m[2][2]];
}

const projectionCache = new Map<string, ((lat: number, lon: number) => [number, number]) | null>();

/** Projette un point GPS sur le plan SVG de la carte de la ville. */
export function gpsToSvg(city: CityDef): ((lat: number, lon: number) => [number, number]) | null {
  const cached = projectionCache.get(city.id);
  if (cached !== undefined) return cached;

  const pairs: { lon: number; lat: number; x: number; y: number }[] = [];
  for (const axis of city.axes) {
    const n = Math.min(axis.gps.length, axis.path.length);
    for (let i = 0; i < n; i++) {
      pairs.push({ lat: axis.gps[i][0], lon: axis.gps[i][1], x: axis.path[i][0], y: axis.path[i][1] });
    }
  }
  let project: ((lat: number, lon: number) => [number, number]) | null = null;
  if (pairs.length >= 6) {
    const ata = [
      [0, 0, 0],
      [0, 0, 0],
      [0, 0, 0],
    ];
    const atx = [0, 0, 0];
    const aty = [0, 0, 0];
    for (const p of pairs) {
      const v = [p.lon, p.lat, 1];
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 3; c++) ata[r][c] += v[r] * v[c];
        atx[r] += v[r] * p.x;
        aty[r] += v[r] * p.y;
      }
    }
    const cx = solve3(ata, atx);
    const cy = solve3(ata, aty);
    if (cx && cy) {
      project = (lat: number, lon: number): [number, number] => [
        Math.round((cx[0] * lon + cx[1] * lat + cx[2]) * 10) / 10,
        Math.round((cy[0] * lon + cy[1] * lat + cy[2]) * 10) / 10,
      ];
    }
  }
  projectionCache.set(city.id, project);
  return project;
}
