import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { buildHeatmap } from "@/lib/server-data";
import { ensureCitySeed, ensureSeed } from "@/lib/seed";
import { requirePaidAccess } from "@/lib/access";
import { parseHourParam } from "@/lib/params";

export const dynamic = "force-dynamic";

/**
 * GET /api/heatmap?city=dakar&hour=18
 * Carte thermique : état temps réel de chaque axe (vitesse, fluidité,
 * densité, prédiction IA +15/+30/+60 min) + synthèse de la ville.
 * Le paramètre hour n'accepte que des entiers 0-23 (sinon temps réel).
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const cityId = req.nextUrl.searchParams.get("city") ?? "dakar";
  const city = CITY_MAP[cityId];
  if (!city) {
    return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  }
  const hour = parseHourParam(req.nextUrl.searchParams.get("hour"));

  await ensureSeed();
  await ensureCitySeed(city);
  const payload = await buildHeatmap(city, { hourOverride: hour });
  return NextResponse.json(payload, { headers: { "Cache-Control": "private, no-store" } });
}
