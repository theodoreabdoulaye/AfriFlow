# Comptes et acces Chariow

## Parcours implemente

1. Ouvrir /compte et creer un compte avec nom, e-mail et mot de passe de 12 a 128 caracteres.
2. Se connecter : une session opaque de 30 jours est stockee dans un cookie HttpOnly, SameSite=Lax et Secure en production. La base ne conserve que le hash du jeton de session. Les mots de passe sont haches par scrypt avec sel aleatoire.
3. Choisir 24h, 7 jours ou 1 mois, puis renseigner le telephone et son pays.
4. Le serveur cree une commande liee au compte connecte et transmet sa reference a Chariow. L'e-mail vient du compte, pas du corps de la demande de paiement.
5. Chariow affiche le prix et les moyens de paiement. Le retour sur le site ne debloque rien a lui seul.
6. Un Pulse successful.sale signe confirme la vente. La transaction en base active l'acces et enregistre la vente et la livraison pour prevenir les doubles activations.
7. Le compte et la page principale relisent regulierement l'acces. Les sections payantes se verrouillent a expiration ou apres deconnexion.

La creation gratuite d'un compte et l'ancien formulaire /api/subscriptions ne donnent aucun droit premium.

## Produits

| Duree | Produit Chariow | Calcul |
| --- | --- | --- |
| 24 heures | prd_3axt0ryr | 24 heures exactes |
| 1 semaine | prd_049ep2ma | 7 jours exacts |
| 1 mois | prd_bcc94ior | Mois calendaire UTC, dernier jour ajuste si necessaire |

Le debut est l'heure de traitement de la confirmation en base. En cas de renouvellement, la duree est ajoutee a la fin du temps deja paye.
Exemple : 31 janvier + 1 mois se termine le 28 fevrier, ou le 29 en annee bissextile.

Les trois acces couvrent la carte thermique, les itineraires ventiles et le multimodal/parkings/covoiturage. Les donnees de trafic derivees de la flotte, du convoi et du flux Waze sont egalement protegees pour ne pas contourner ces controles.

## Pourquoi le checkout serveur remplace les widgets

Les widgets fournis n'associent pas une commande a la session AfriFlow. Un achat effectue directement depuis ces widgets ou la boutique, sans reference de commande serveur, n'active pas automatiquement le compte.
Le parcours implemente utilise la Public API Chariow, tout en conservant les trois identifiants produits et la boutique nicbtvnz.mychariow.store.

IMPORTANT : les produits doivent etre publies et compatibles avec l'API. Chariow ne permet pas de checkout API pour les types Service/Coaching ou les prix libres. Pour renouveler plusieurs fois, le type License est adapte ; les produits telechargeables, cours et bundles peuvent renvoyer already_purchased. Verifier ou adapter les trois produits dans le tableau de bord avant ouverture des paiements. Leur type reel n'a pas pu etre verifie sans vos identifiants.
Le prix n'est jamais invente dans l'application : il est affiche par Chariow.

## Base de donnees

Les fichiers SQL sont additifs et ne remplacent pas les tables existantes :

- migrations/001-auth.sql : users et user_sessions.
- migrations/002-payments.sql : payment_orders, payment_grants et payment_deliveries.

Sur une base existante, sauvegarder puis appliquer les fichiers dans cet ordre avec votre client PostgreSQL. Exemple avec psql :

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f migrations/001-auth.sql -f migrations/002-payments.sql
```

Ces scripts supposent qu'aucune table portant ces noms avec un schema incompatible n'existe deja. IF NOT EXISTS ne met pas a niveau un schema incompatible.
Sur une base vide, npm run db:push peut initialiser le schema complet apres examen des modifications proposees. drizzle.config.ts inclut maintenant les trois fichiers de schema. Les commandes Drizzle migrate utilisent le dossier drizzle ; elles n'executent pas les deux scripts SQL ci-dessus. Ne pas melanger les historiques de migration sans verification.
Aucune migration n'est executee automatiquement pendant le build Vercel.

## Variables Vercel

- DATABASE_URL : PostgreSQL, endpoint pooler recommande.
- NEXT_PUBLIC_SITE_URL : origine HTTPS exacte de votre application, sans chemin ; utilisee pour les retours de paiement et la protection same-origin.
- CHARIOW_API_KEY : cle privee API avec droit de creation checkout. Jamais NEXT_PUBLIC.
- CHARIOW_WEBHOOK_SECRET : secret whsec_ du Pulse, distinct de la cle API. Jamais NEXT_PUBLIC.

Les previews Vercel doivent avoir leur propre NEXT_PUBLIC_SITE_URL correspondant a l'origine depuis laquelle on se connecte. La protection same-origin refuse les autres origines et les POST sans Origin. Les cookies Secure de production exigent HTTPS.

## Configurer le Pulse

Dans Chariow : Automations > Pulses, creer un Pulse HTTPS vers :

```text
https://votre-domaine/api/v1/payment/webhook
```

Selectionner successful.sale et les trois produits. Renseigner son secret dans CHARIOW_WEBHOOK_SECRET puis redeployer.
Le contrat verifie est celui de la documentation actuelle, pas l'exemple Rust initial :

- En-tete x-chariow-signature : sha256= suivi du HMAC-SHA256 hex sur les octets bruts du corps.
- En-tete x-pulse-delivery-id : identifiant de livraison.
- Corps event, sale.id, sale.status, sale.custom_metadata.order_id, product.id, customer.email, store.url.
- store.url doit correspondre a l'origine https://nicbtvnz.mychariow.store. Verifier la valeur reelle dans une livraison si Chariow emploie une adresse canonique differente ; ne pas supprimer le controle sans remplacer cette origine par celle de votre boutique.

Un test signe du tableau de bord est accepte mais ignore : il ne doit pas creer d'acces reel. Un echec de base renvoie 503 pour permettre une nouvelle tentative ; le serveur ne confirme pas la reception avant le COMMIT. Une vente deja traitee ne prolonge pas une seconde fois l'acces, meme si une nouvelle livraison est creee par un replay.

## Verification effectuee

- Compilation de production et verification TypeScript : succes.
- Tests unitaires de hachage, signatures, validation, calcul des durees et tailles des corps : succes.
- ESLint cible sur les nouvelles interfaces et nouveaux modules serveur : succes.
- Serveur de production local : /, /compte, /convoi, /api/auth/me et /api/access repondent 200 sans session.
- API premium testees sans session : 401 avec private, no-store. Paiement et multimodal sans session : 401.
- Inscription d'une autre origine : 403.
- Signature webhook invalide : 401 ; evenement de test correctement signe : 200 sans activation.

## Limites avant mise en production

- Les fichiers SQL n'ont pas ete appliques ici : aucune base PostgreSQL ni cle Chariow reelle n'etait fournie. L'inscription/connexion persistante, le checkout reel, le renouvellement concurrent et le parcours navigateur complet doivent etre testes sur un environnement de validation.
- La confirmation d'e-mail et la recuperation/changement de mot de passe ne sont pas encore disponibles. Ne pas presenter les e-mails comme verifies.
- Les limites de debit sont locales aux instances. Ajouter une protection distribuee/Vercel Firewall pour limiter les abus en production.
- Les sessions expirees et les commandes en attente doivent etre purgee(s) par un traitement planifie selon votre politique de retention.
- Les remboursements et revocations ne sont pas automatiquement synchronises. payment_grants.revoked permet une revocation en base par l'operateur ; mettre en place un processus de support et de remboursement avant lancement.
- Un compte payant n'est pas une autorisation de propriete sur une flotte ou une reservation de covoiturage. L'application existante n'a pas encore les controles d'appartenance par flotte/reservation ; cela reste indispensable pour utiliser des donnees reelles.
- Les fonctions communautaires et les indicateurs agreges publics restent gratuits. Les integrations partenaires WhatsApp/Waze existantes peuvent alimenter les donnees sans passer par le compte navigateur ; leurs autorisations propres restent a auditer.
- Le cache hors ligne ne conserve plus les pages privees ni leur contenu HTML. Une connexion est requise pour verifier l'acces ; seul le cache des assets statiques est conserve.
- Le lint global comporte encore les erreurs React preexistantes indiquees dans le guide Vercel. Aucune regle n'a ete desactivee pour les masquer.

References : https://chariow.dev/en/guides/checkout, https://chariow.dev/en/guides/pulses, https://chariow.dev/en/guides/pulse-security.
