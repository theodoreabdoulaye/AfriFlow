# Google et reCAPTCHA

## Configuration avant deploiement

1. Creer des cles reCAPTCHA **v3** et autoriser les domaines du site (et localhost pour le developpement).
2. Renseigner `NEXT_PUBLIC_RECAPTCHA_SITE_KEY` et `RECAPTCHA_SECRET_KEY` dans Vercel.
3. Creer un client OAuth Google **Application Web**, configurer l'ecran de consentement et les utilisateurs de test si necessaire.
4. Ajouter l'origine HTTPS exacte du site aux origines JavaScript autorisees du client Google. Cette integration Google Identity Services ne demande pas d'URL de callback OAuth.
5. Renseigner `NEXT_PUBLIC_GOOGLE_CLIENT_ID` et `NEXT_PUBLIC_SITE_URL`, puis reconstruire et redeployer. Les variables NEXT_PUBLIC sont integrees lors de la compilation.

Sans secret reCAPTCHA, la connexion et l'inscription sont bloquees volontairement. Le serveur verifie la signature Google, l'audience, l'expiration et l'e-mail verifie; reCAPTCHA verifie l'action, le domaine et un score minimum de 0,5.

Les comptes Google utilisent les sessions existantes, sans migration. Une adresse deja inscrite avec un mot de passe n'est pas associee automatiquement a Google : utilisez le mot de passe existant. La connexion Google ne donne pas d'acces payant et les paiements restent lies a la session.

## Modifications de la page

Les quatre anciennes offres et leur formulaire ont ete retires. Les acces 24h, 7 jours et 1 mois restent disponibles. La grande liste du reseau n'est plus masquee en attendant un seuil d'apparition difficile a atteindre sur mobile.

## Verification

Executer `npm run typecheck`, `npm test` et `npm run build`. Tester ensuite les vrais parcours Google et reCAPTCHA avec les cles configurees et PostgreSQL disponible. Le lint global contient deja des erreurs dans les anciens composants. L'installation signale aussi des vulnerabilites de dependances a examiner avant production.
