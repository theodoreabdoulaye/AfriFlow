/**
 * Expéditeur WhatsApp Business (Meta Graph API) — porté du design Rust
 * WhatsAppSender : confirmations personnalisées par type d'incident aux
 * conducteurs qui ont signalé, dès que le consensus valide l'alerte.
 * Sans jeton configuré, l'envoi est journalisé comme non effectué
 * (retour false) — jamais d'échec silencieux maquillé en succès.
 */

const GRAPH = "https://graph.facebook.com/v17.0";

export function waConfigured(): boolean {
  return !!(process.env.WHATSAPP_TOKEN && process.env.WHATSAPP_PHONE_NUMBER_ID);
}

/** Envoie un message texte via l'API Meta (si configurée). */
export async function sendWhatsAppText(to: string, body: string): Promise<boolean> {
  const token = process.env.WHATSAPP_TOKEN;
  const phoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (!token || !phoneId) return false;
  try {
    const res = await fetch(`${GRAPH}/${phoneId}/messages`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to,
        type: "text",
        text: { body: body.slice(0, 900) },
      }),
      signal: AbortSignal.timeout(10000),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/** Message de confirmation envoyé aux rapporteurs quand l'alerte est validée. */
export function buildConfirmationMessage(
  incidentType: string,
  axisName: string,
  confidenceScore: number,
): string {
  switch (incidentType) {
    case "accident":
      return (
        `✅ Votre signalement d'accident a été confirmé par 3 conducteurs (confiance ${confidenceScore}%).\n` +
        `🚨 Alerte diffusée à toute la ville sur ${axisName}.\nMerci pour votre contribution ! 🙏`
      );
    case "police":
      return (
        `✅ Contrôle de police confirmé (confiance ${confidenceScore}%).\n` +
        `Les conducteurs ont été alertés sur ${axisName}.\nMerci ! 🙏`
      );
    case "inondation":
      return (
        `✅ Inondation confirmée (confiance ${confidenceScore}%).\n` +
        `Les conducteurs évitent ${axisName}.\nMerci ! 🙏`
      );
    default:
      return (
        `✅ Votre signalement a été confirmé par la communauté (confiance ${confidenceScore}%).\n` +
        `Alerte diffusée sur ${axisName}. Merci pour votre contribution ! 🙏`
      );
  }
}

/** Message d'attente envoyé juste après un signalement non encore validé. */
export function buildPendingMessage(): string {
  return "⏳ Votre signalement a été reçu. Il sera diffusé après confirmation par 2 autres conducteurs.";
}
