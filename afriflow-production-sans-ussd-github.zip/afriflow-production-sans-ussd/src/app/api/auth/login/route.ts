import { handleAuth } from "@/lib/auth";

export const runtime = "nodejs";
export async function POST(req: Request) { return handleAuth(req, "login"); }
