import { NextRequest } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { CITY_MAP } from "@/lib/cities";
import { and, desc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { toValidatedAlert, type AlertEvent, type ValidatedAlert } from "@/lib/alert-hub";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

/**
 * GET /api/v1/stream?city=dakar — flux SSE des ALERTES validées par le
 * consensus (porté du SseHub Rust) :
 *   event: connected — message de bienvenue à la connexion ;
 *   event: alert     — { event_type: "alert_validated" | "alert_expired",
 *                        alert: ValidatedAlert, timestamp, message } ;
 *   keep-alive       — commentaire toutes les 15 s.
 * Sans paramètre city : toutes les villes du réseau.
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const cityParam = req.nextUrl.searchParams.get("city");
  if (cityParam && !CITY_MAP[cityParam]) {
    return new Response(JSON.stringify({ error: "Ville inconnue" }), {
      status: 404,
      headers: { "Content-Type": "application/json", "Cache-Control": "private, no-store" },
    });
  }
  const cityKey = cityParam ?? "*";
  const encoder = new TextEncoder();
  let closed = false;
  let beat: ReturnType<typeof setInterval> | null = null;
  let tick: ReturnType<typeof setInterval> | null = null;
  let timeout: ReturnType<typeof setTimeout> | null = null;
  let polling = false;
  let close: (() => void) | null = null;
  const active = new Map<number, ValidatedAlert>();

  const cleanup = () => {
    closed = true;
    if (beat) clearInterval(beat);
    if (tick) clearInterval(tick);
    if (timeout) clearTimeout(timeout);
    req.signal.removeEventListener("abort", onAbort);
  };
  const onAbort = () => close?.();

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      close = () => {
        if (closed) return;
        cleanup();
        try {
          controller.close();
        } catch {
          /* déjà fermé */
        }
      };
      req.signal.addEventListener("abort", onAbort, { once: true });
      if (req.signal.aborted) {
        close();
        return;
      }
      timeout = setTimeout(close, 50_000);
      const send = (eventName: string, data: unknown) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`event: ${eventName}\ndata: ${JSON.stringify(data)}\n\n`));
        } catch {
          close?.();
        }
      };

      // Événement de connexion initial (format du design).
      send("connected", {
        event_type: "connected",
        alert: {
          id: 0,
          city: cityKey,
          edge_id: "",
          axis_name: "",
          incident_type: "",
          severity: 0,
          confirmation_count: 0,
          confidence_score: 0,
          speed_penalty_kmh: 0,
          expires_at: new Date().toISOString(),
        },
        timestamp: Math.floor(Date.now() / 1000),
        message: "🔗 Connecté au flux temps réel AfriFlow",
      });

      const poll = async () => {
        if (closed || polling) return;
        polling = true;
        try {
          if (await requirePaidAccess()) {
            close?.();
            return;
          }
          if (closed) return;
          const rows = await db.select().from(incidents).where(and(
            eq(incidents.status, "broadcast"),
            gt(incidents.createdAt, new Date(Date.now() - 3 * 3600_000)),
            cityParam ? eq(incidents.city, cityParam) : undefined,
          )).orderBy(desc(incidents.createdAt), desc(incidents.id)).limit(1000);
          if (await requirePaidAccess()) {
            close?.();
            return;
          }
          if (closed) return;
          const now = Date.now();
          for (const incident of rows) {
            const city = CITY_MAP[incident.city];
            if (!city) continue;
            const alert = toValidatedAlert(city, incident);
            if (new Date(alert.expires_at).getTime() <= now) continue;
            if (JSON.stringify(active.get(alert.id)) !== JSON.stringify(alert)) {
              const event: AlertEvent = {
                event_type: "alert_validated",
                alert,
                timestamp: Math.floor(now / 1000),
                message: `🚨 ${alert.incident_type} confirmé sur ${alert.axis_name} (confiance ${alert.confidence_score}%)`,
              };
              send("alert", event);
              if (closed) return;
              active.set(alert.id, alert);
            }
          }
          // A limited result set is not proof that a missing alert expired.
          for (const [id, alert] of active) {
            if (new Date(alert.expires_at).getTime() > now) continue;
            const event: AlertEvent = {
              event_type: "alert_expired",
              alert,
              timestamp: Math.floor(now / 1000),
              message: `⌛ Alerte expirée : ${alert.incident_type} sur ${alert.axis_name} (fenêtre d'impact de 3 h écoulée)`,
            };
            send("alert", event);
            if (closed) return;
            active.delete(id);
          }
        } catch {
          /* Preserve active alerts on query failure; retry next cycle. */
        } finally {
          polling = false;
        }
      };
      void poll();
      tick = setInterval(() => void poll(), 10_000);

      beat = setInterval(() => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`: keep-alive ${Date.now()}\n\n`));
        } catch {
          close?.();
        }
      }, 15_000);

    },
    cancel() {
      cleanup();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "private, no-store, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
