import type { AxisDef, CityDef } from "./cities";
import { hashNoise, modelSpeed } from "./engine";
import { ingestCrowdReport } from "./crowd";
import { ingestGpsPoint } from "./ingest";
import { fetchWeather } from "./weather";

/**
 * Simulateur de traces GPS (démonstration) : génère des véhicules qui se
 * déplacent le long des axes de la ville, à des vitesses cohérentes avec
 * l'état du trafic calculé par le moteur, et les injecte dans le MÊME
 * pipeline d'ingestion que les vrais GPS (map matching + lissage α=0,3).
 * Les points sont tracés avec source="simulateur" — jamais confondus,
 * dans les compteurs, avec les GPS réels des conducteurs.
 */

function interpolate(axis: AxisDef, t: number): [number, number] {
  const pts = axis.gps;
  if (pts.length < 2) return pts[0];
  const pos = t * (pts.length - 1);
  const i = Math.min(pts.length - 2, Math.floor(pos));
  const frac = pos - i;
  return [
    pts[i][0] + (pts[i + 1][0] - pts[i][0]) * frac,
    pts[i][1] + (pts[i + 1][1] - pts[i][1]) * frac,
  ];
}

export interface SimulationResult {
  points: number;
  vehicles: number;
  axesCovered: number;
}

export async function simulateTraces(
  city: CityDef,
  vehicles = 18,
  pointsPerVehicle = 2,
): Promise<SimulationResult> {
  const weather = await fetchWeather(city);
  const localNow = new Date(Date.now() + (city.tzOffsetMin ?? 0) * 60_000);
  const runId = Math.floor(Date.now() / 1000);

  // Choix des axes pondéré par leur capacité (les gros axes portent le trafic).
  const totalCapacity = city.axes.reduce((a, x) => a + x.capacityVehH, 0);
  const pickAxis = (seed: string): AxisDef => {
    let r = hashNoise(seed) * totalCapacity;
    for (const axis of city.axes) {
      r -= axis.capacityVehH;
      if (r <= 0) return axis;
    }
    return city.axes[city.axes.length - 1];
  };

  const covered = new Set<string>();
  let points = 0;

  for (let v = 0; v < vehicles; v++) {
    const seed = `sim:${city.id}:${runId}:${v}`;
    const axis = pickAxis(seed);
    covered.add(axis.id);
    const baseSpeed = modelSpeed(axis, localNow, weather, []);
    // Effet local persistant par axe et par jour (marché, école, travaux
    // lents…) : c'est ce signal réel-iste que l'apprentissage des profils
    // doit capturer pour battre le profil historique générique.
    const dayKey = localNow.toISOString().slice(0, 10);
    const localFactor = 0.78 + hashNoise(`local:${city.id}:${axis.id}:${dayKey}`) * 0.34;
    const startT = hashNoise(seed + ":t") * 0.7;
    for (let p = 0; p < pointsPerVehicle; p++) {
      const t = Math.min(0.98, startT + p * 0.18 + hashNoise(seed + `:p${p}`) * 0.05);
      const [lat, lon] = interpolate(axis, t);
      // Vitesse du véhicule : vitesse de l'axe × effet local ± dispersion.
      const speed = Math.max(
        3,
        Math.min(
          axis.freeFlowKmh * 1.05,
          baseSpeed * localFactor * (0.85 + hashNoise(seed + `:s${p}`) * 0.3),
        ),
      );
      await ingestGpsPoint(city, {
        lat,
        lon,
        speedKmh: Math.round(speed * 10) / 10,
        source: "simulateur",
        deviceHash: `sim-${city.id}-${v}`,
        rainMm: weather.precipMm ?? 0,
      });
      points++;
    }
  }

  return { points, vehicles, axesCovered: covered.size };
}

/**
 * Scénario « Démo Live » d'une ville : traces GPS de démonstration + un
 * incident emblématique (travaux sur l'axe d'un lieu connu — plage, port,
 * marché, gare…) validé par le vrai consensus pondéré (3 émetteurs démo).
 * Tout est étiqueté « DÉMO » : descriptions et source « simulateur ».
 */
export async function runDemoScenario(city: CityDef): Promise<{
  traces: SimulationResult;
  axisName: string;
  incidentStatus: string;
}> {
  const traces = await simulateTraces(city, 24, 2);

  // Lieu emblématique d'abord (plage, marché, gare…), centre-ville ensuite.
  const notableZone =
    city.zones.find((z) => /saly|portudal|plage|marche|gare|universit|aeroport/i.test(z.name)) ??
    city.zones.find((z) => /port|centre/i.test(z.name));
  const axis =
    (notableZone && city.axes.find((a) => a.from === notableZone.id || a.to === notableZone.id)) ||
    [...city.axes].sort((a, b) => b.capacityVehH - a.capacityVehH)[0];
  const mid = axis.gps[Math.floor(axis.gps.length / 2)];

  let status = "pending";
  for (const reporter of ["demo-live-1", "demo-live-2", "demo-live-3"]) {
    const result = await ingestCrowdReport(city, {
      source: "whatsapp",
      lat: mid[0],
      lon: mid[1],
      incidentType: "travaux",
      confidenceScore: 6,
      reporterKey: reporter,
      severity: 3,
      description: `[DÉMO LIVE] Travaux simulés sur ${axis.name} — scénario de démonstration, données fictives affichées à titre d'exemple.`,
    });
    if (result) status = result.incident.status;
  }

  return { traces, axisName: axis.name, incidentStatus: status };
}
