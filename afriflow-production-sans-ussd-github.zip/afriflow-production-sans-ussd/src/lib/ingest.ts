import { and, count, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { axisState, incidents, mlObservations, telemetryPoints } from "@/db/schema";
import type { AxisDef, CityDef } from "./cities";
import { nearestAxisFast } from "./spatial";

export interface IngestInput {
  lat: number;
  lon: number;
  speedKmh: number;
  heading?: number | null;
  source: string; // app | partner | whatsapp | simulateur…
  deviceHash?: string | null;
  /** Pluie horaire au moment du point (mm) — variable d'entraînement ML. */
  rainMm?: number | null;
}

/**
 * Ingestion d'un point GPS (partagée par /api/telemetry et le simulateur
 * de traces) : rattachement à l'axe le plus proche via l'index spatial,
 * puis mise à jour de la vitesse lissée exponentiellement (α = 0,3) en
 * upsert atomique sur l'index unique (ville, axe).
 */
export async function ingestGpsPoint(
  city: CityDef,
  input: IngestInput,
): Promise<{ axis: AxisDef | null; distanceM: number | null }> {
  const found = nearestAxisFast(city, input.lat, input.lon, 400);

  await db.insert(telemetryPoints).values({
    city: city.id,
    axisId: found?.axis.id ?? null,
    lat: input.lat,
    lon: input.lon,
    speedKmh: input.speedKmh,
    heading: input.heading ?? null,
    source: input.source,
    deviceHash: input.deviceHash ?? null,
    rainMm: input.rainMm ?? null,
  });

  if (found) {
    await db
      .insert(axisState)
      .values({ city: city.id, axisId: found.axis.id, smoothedSpeedKmh: input.speedKmh, samples: 1 })
      .onConflictDoUpdate({
        target: [axisState.city, axisState.axisId],
        set: {
          smoothedSpeedKmh: sql`0.3 * ${input.speedKmh} + 0.7 * ${axisState.smoothedSpeedKmh}`,
          samples: sql`${axisState.samples} + 1`,
          updatedAt: new Date(),
        },
      });

    // Observation MLEngine (best-effort) : la mesure devient une donnée
    // d'entraînement avec pluie et signalements actifs au même moment.
    try {
      const twoHoursAgo = new Date(Date.now() - 2 * 3600_000);
      const [rep] = await db
        .select({ n: count() })
        .from(incidents)
        .where(
          and(
            eq(incidents.city, city.id),
            eq(incidents.axisId, found.axis.id),
            eq(incidents.status, "broadcast"),
            gte(incidents.createdAt, twoHoursAgo),
          ),
        );
      await db.insert(mlObservations).values({
        city: city.id,
        axisId: found.axis.id,
        observedSpeedKmh: input.speedKmh,
        baselineSpeedKmh: found.axis.freeFlowKmh,
        rainMm: input.rainMm ?? 0,
        activeReports: rep?.n ?? 0,
        source: input.source,
      });
    } catch {
      /* l'observation ML ne doit jamais bloquer l'ingestion GPS */
    }
  }

  return { axis: found?.axis ?? null, distanceM: found?.distanceM ?? null };
}
