/* AfriFlow — service worker : coquille d'app + assets en cache.
   Les API (/api/*) ne sont JAMAIS mises en cache : le trafic est temps réel. */
const VERSION = "afriflow-v5.3.0-security";
const STATIC_CACHE = `${VERSION}-static`;
const PRECACHE = ["/manifest.webmanifest", "/icons/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(STATIC_CACHE)
      .then((cache) => cache.addAll(PRECACHE))
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(keys.filter((k) => !k.startsWith(VERSION)).map((k) => caches.delete(k))),
      )
      .then(() => self.clients.claim()),
  );
});

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;
  const url = new URL(request.url);

  // Temps réel et données : toujours le réseau, jamais le cache.
  if (url.origin !== self.location.origin || url.pathname.startsWith("/api/")) return;

  // Account and paid page responses must never survive logout in an offline cache.
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request).catch(() => new Response(
        '<!doctype html><html lang="fr"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AfriFlow hors ligne</title><h1>Connexion requise</h1><p>Reconnectez-vous pour verifier votre compte et votre acces.</p></html>',
        { status: 503, headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } },
      )),
    );
    return;
  }

  // Assets immuables (JS/CSS hachés, icônes, manifeste) : cache d'abord.
  const isStatic =
    url.pathname.startsWith("/_next/static/") ||
    url.pathname.startsWith("/icons/") ||
    url.pathname === "/manifest.webmanifest" ||
    url.pathname.startsWith("/_next/image");
  if (isStatic) {
    event.respondWith(
      caches.match(request).then(
        (hit) =>
          hit ??
          fetch(request).then((response) => {
            if (response.ok) {
              const copy = response.clone();
              event.waitUntil(caches.open(STATIC_CACHE).then((cache) => cache.put(request, copy)));
            }
            return response;
          }),
      ),
    );
  }
});

/* ---- Notifications push : alertes validées par le consensus ---- */
self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    data = { title: "Alerte AfriFlow", body: event.data ? event.data.text() : "" };
  }
  const title = data.title || "🚨 Alerte AfriFlow";
  const options = {
    body: data.body || "Un incident vient d'être confirmé par la communauté.",
    icon: "/icons/icon-512.png",
    badge: "/icons/icon-512.png",
    tag: `afriflow-${data.edge_id || "alert"}`,
    data: { url: data.url || "/" },
    vibrate: [120, 60, 120],
  };
  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
   let url = self.location.origin + "/";
   try {
     const target = new URL((event.notification.data && event.notification.data.url) || "/", self.location.origin);
     if (target.origin === self.location.origin) url = target.href;
   } catch { /* Keep the same-origin fallback. */ }
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clients) => {
      for (const client of clients) {
        if ("focus" in client) {
          client.navigate(url);
          return client.focus();
        }
      }
      return self.clients.openWindow(url);
    }),
  );
});
