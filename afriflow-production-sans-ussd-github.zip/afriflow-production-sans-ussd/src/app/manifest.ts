import type { MetadataRoute } from "next";
import { CITY_COUNT, COUNTRY_COUNT } from "@/lib/cities";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "AfriFlow — Trafic en temps réel",
    short_name: "AfriFlow",
    description:
      `Bouchons prévus 30 à 60 minutes à l'avance dans ${CITY_COUNT} villes et ${COUNTRY_COUNT} pays d'Afrique. Signalements communautaires dans l'application web.`,
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#060f0a",
    theme_color: "#22b573",
    lang: "fr",
    icons: [
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
    ],
  };
}
