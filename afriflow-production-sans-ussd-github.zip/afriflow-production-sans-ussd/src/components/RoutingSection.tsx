"use client";

import { useEffect, useMemo, useState } from "react";
import {
  ArrowUpDown,
  Clock3,
  MapPin,
  Search,
  CloudRain,
  Fuel,
  Loader2,
  Navigation,
  Route as RouteIcon,
  ShieldAlert,
  ShieldCheck,
  Timer,
  TriangleAlert,
  Wallet,
  Wrench,
} from "lucide-react";
import { CITY_MAP } from "@/lib/cities";
import type { RouteOption } from "@/lib/engine";
import { getDeviceHash } from "@/lib/device";
import { useApp } from "./AppClient";
import { LEVEL_COLORS } from "./HeatmapSection";

interface RoutingResponse {
  routes: RouteOption[];
  weather: { label: string; level: number };
  engine: string;
}

const PRIORITIES = [
  { key: "time", label: "temps de parcours", icon: Timer },
  { key: "fuel", label: "litres & FCFA économisés", icon: Wallet },
  { key: "safety", label: "zones accidentogènes / insécurité", icon: ShieldCheck },
  { key: "practicability", label: "nids-de-poule & inondations", icon: Wrench },
] as const;

const PROFILES = [
  {
    id: "standard",
    label: "🚗 Voiture standard",
    desc: "Équilibre temps, carburant et sécurité.",
  },
  {
    id: "gbaka",
    label: "🚌 Gbaka / transport en commun",
    desc: "Axes structurants privilégiés, densité modérée tolérée, voies étroites évitées.",
  },
  {
    id: "urgence",
    label: "🚨 Voiture / urgence",
    desc: "Évitement maximal des axes saturés, même si le trajet est plus long.",
  },
] as const;

type ProfileId = (typeof PROFILES)[number]["id"];

type PriorityKey = (typeof PRIORITIES)[number]["key"];

interface GeoResult {
  name: string;
  displayName: string;
  kind: string;
  axisName: string | null;
  zoneId: string | null;
  zoneName: string | null;
  walkDistanceM: number | null;
}

/** Recherche d'adresse réelle (Nominatim/OSM) rattachée à une zone AfriFlow. */
function AddressSearch({
  cityId,
  label,
  onZone,
}: {
  cityId: string;
  label: string;
  onZone: (zoneId: string) => void;
}) {
  const [q, setQ] = useState("");
  const [results, setResults] = useState<GeoResult[]>([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const search = async () => {
    if (q.trim().length < 2) {
      setMsg("Tapez au moins 2 caractères (marché, université, gare, quartier…).");
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch(`/api/geo?q=${encodeURIComponent(q)}&city=${cityId}`, { cache: "no-store" });
      const json = (await res.json()) as { results?: GeoResult[]; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Recherche impossible");
      const list = json.results ?? [];
      setResults(list);
      if (list.length === 0) setMsg("Aucun lieu trouvé dans cette ville pour cette recherche (données OpenStreetMap).");
    } catch (e) {
      setMsg(e instanceof Error ? e.message : "Recherche impossible");
      setResults([]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div>
      <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">{label}</span>
      <div className="flex gap-2">
        <label className="relative flex-1">
          <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-sage" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && void search()}
            placeholder="Marché, université, gare, hôpital…"
            className="w-full rounded-xl border border-night-600 bg-night-800 py-2 pr-3 pl-9 text-[13px] outline-none placeholder:text-sage/50 focus:border-brand-500"
          />
        </label>
        <button
          onClick={() => void search()}
          disabled={busy}
          className="rounded-xl bg-night-700 px-3 text-[12.5px] font-semibold transition hover:bg-night-600 disabled:opacity-60"
        >
          {busy ? "…" : "Chercher"}
        </button>
      </div>
      {msg && <p className="mt-1.5 text-[11.5px] text-amber-warn">{msg}</p>}
      {results.length > 0 && (
        <ul className="mt-2 space-y-1">
          {results.map((r, i) => (
            <li key={i}>
              <button
                onClick={() => {
                  if (r.zoneId) {
                    onZone(r.zoneId);
                    setMsg(`Rattaché à la zone « ${r.zoneName} »${r.axisName ? ` via ${r.axisName}` : ""}.`);
                    setResults([]);
                  }
                }}
                className="flex w-full items-start gap-2 rounded-xl bg-night-800/80 px-3 py-2 text-left transition hover:bg-night-700"
              >
                <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-500" />
                <span className="min-w-0">
                  <span className="block truncate text-[12.5px] font-semibold">
                    {r.name} <span className="font-normal text-sage">· {r.kind}</span>
                  </span>
                  <span className="block truncate text-[11px] text-sage">
                    {r.zoneName ? `Zone : ${r.zoneName}` : "Hors zones surveillées"}
                    {r.walkDistanceM !== null ? ` · à ${r.walkDistanceM} m de la zone` : ""}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function fluidColor(f: number): string {
  return f >= 70 ? LEVEL_COLORS.fluide : f >= 48 ? LEVEL_COLORS.dense : f >= 30 ? LEVEL_COLORS.congestion : LEVEL_COLORS.sature;
}

function RouteCard({
  route,
  isBest,
  onAccept,
  accepting,
  accepted,
  shareText,
}: {
  route: RouteOption;
  isBest: boolean;
  onAccept: (r: RouteOption) => void;
  accepting: boolean;
  accepted: boolean;
  shareText?: string;
}) {
  const blocked = route.status === "zone-protegee";
  const quotaFull = route.status === "quota-plein";
  const unavailable = blocked || quotaFull;

  return (
    <article
      className={`relative rounded-3xl border p-5 ${
        isBest && !unavailable
          ? "border-brand-500/60 bg-gradient-to-b from-brand-500/12 to-night-900"
          : "border-night-600 bg-night-900"
      } ${unavailable ? "opacity-75" : ""}`}
    >
      <div className="flex items-center gap-3">
        <span
          className={`grid h-10 w-10 place-items-center rounded-2xl font-display text-lg font-bold ${
            route.id === "A" ? "bg-night-600 text-paper" : route.id === "B" ? "bg-brand-500 text-night-950" : "bg-night-600 text-mint-300"
          }`}
        >
          {route.id}
        </span>
        <div className="flex-1">
          <h4 className="font-display text-[15px] font-bold">{route.label}</h4>
          <p className="text-[11px] tracking-wide text-sage uppercase">
            {route.kind === "principal" ? "axe principal" : route.kind === "delestage" ? "ventilation dosée" : "solution de repli"}
          </p>
        </div>
        {isBest && !unavailable && (
          <span className="rounded-full bg-brand-500 px-2.5 py-1 text-[10px] font-bold text-night-950">RECOMMANDÉ</span>
        )}
        {blocked && (
          <span className="flex items-center gap-1 rounded-full bg-coral/15 px-2.5 py-1 text-[10px] font-bold text-coral">
            <ShieldAlert className="h-3 w-3" /> ZONE PROTÉGÉE
          </span>
        )}
        {quotaFull && (
          <span className="rounded-full bg-amber-warn/15 px-2.5 py-1 text-[10px] font-bold text-amber-warn">QUOTA PLEIN</span>
        )}
      </div>

      <div className="mt-4 flex items-end gap-2">
        <p className="font-display text-4xl font-bold">
          {route.minutes}
          <span className="text-base font-medium text-sage"> min</span>
        </p>
        <p className="pb-1.5 text-[12px] text-sage">
          · {route.distanceKm} km · fluidité moy.{" "}
          <b style={{ color: fluidColor(route.fluidityAvg) }}>{route.fluidityAvg}/100</b>
        </p>
      </div>

      {route.maxLoadPct >= 80 && (
        <p className="mt-2 w-fit rounded-full bg-coral/15 px-2.5 py-1 text-[10.5px] font-bold text-coral">
          ⚠️ Axe à {route.maxLoadPct} % de saturation sur ce trajet
        </p>
      )}
      {route.explanation && (
        <p className="mt-2 border-l-2 border-brand-500/60 pl-2.5 text-[12px] leading-relaxed text-sage italic">
          {route.explanation}
        </p>
      )}

      <ul className="mt-3 space-y-1.5">
        {route.legs.map((leg, i) => (
          <li key={i} className="flex items-center gap-2 text-[12.5px]">
            <span className="h-1.5 w-1.5 shrink-0 rounded-full" style={{ background: fluidColor(leg.fluidity) }} />
            <span className="flex-1 truncate">{leg.name}</span>
            {leg.protectedBlocked && <TriangleAlert className="h-3.5 w-3.5 shrink-0 text-coral" />}
            {leg.loadPct >= 60 && (
              <span
                className={`shrink-0 rounded-full px-1.5 py-0.5 text-[9.5px] font-bold ${leg.loadPct >= 80 ? "bg-coral/15 text-coral" : "bg-amber-warn/15 text-amber-warn"}`}
                title="Charge de l'axe (% de sa capacité) — le multiplicateur de quota s'applique dès 60 %"
              >
                {leg.loadPct} %
              </span>
            )}
            <span className="font-mono text-[11px] text-sage">{leg.minutes} min</span>
          </li>
        ))}
      </ul>

      <div className="mt-4 grid grid-cols-2 gap-2 text-center">
        <div className="rounded-xl bg-night-800 px-2 py-2.5">
          <p className="font-display text-[15px] font-bold">{route.fuelLiters} L</p>
          <p className="text-[10px] text-sage">carburant estimé</p>
        </div>
        <div className="rounded-xl bg-night-800 px-2 py-2.5">
          <p className="font-display text-[15px] font-bold">{route.fuelFcfa.toLocaleString("fr-FR")} F</p>
          <p className="text-[10px] text-sage">
            {route.fuelSavedFcfa && route.fuelSavedFcfa > 0
              ? `−${route.fuelSavedFcfa.toLocaleString("fr-FR")} F vs A`
              : route.fuelSavedFcfa && route.fuelSavedFcfa < 0
                ? `+${Math.abs(route.fuelSavedFcfa).toLocaleString("fr-FR")} F vs A`
                : "coût carburant"}
          </p>
        </div>
      </div>

      {route.quota && (
        <div className="mt-3">
          <div className="flex justify-between text-[11px] font-medium text-sage">
            <span title="Nombre de conducteurs encore admis sur ce délestage avant sa fermeture temporaire">
              Quota d&apos;accès (MFD) ⓘ
            </span>
            <span>
              {route.quota.remaining} / {route.quota.total} places
            </span>
          </div>
          <div className="mt-1 h-2 overflow-hidden rounded-full bg-night-950">
            <div
              className={`h-full rounded-full transition-all duration-700 ${route.quota.remaining <= 0 ? "bg-coral" : route.quota.remaining < route.quota.total * 0.25 ? "bg-amber-warn" : "bg-brand-500"}`}
              style={{ width: `${(route.quota.remaining / Math.max(1, route.quota.total)) * 100}%` }}
            />
          </div>
          {route.quota.remaining <= route.quota.total * 0.25 && route.quota.remaining > 0 && (
            <p className="mt-1.5 animate-pulse text-[11px] font-semibold text-amber-warn">
              ⚠️ Quota presque plein : dès 80 % de capacité, le coût de cet axe explose dans le moteur et il est
              masqué des délestages — pour ne pas créer un nouveau bouchon sur la route de secours.
            </p>
          )}
          {route.quota.remaining <= 0 && (
            <p className="mt-1.5 text-[11px] font-semibold text-coral">
              🔒 Axe temporairement masqué : quota atteint (règle des 80 %) — le trafic reste sur l&apos;axe principal.
            </p>
          )}
        </div>
      )}

      <p className="mt-3 min-h-8 text-[12px] leading-relaxed text-sage">{route.note}</p>

      {shareText && (
        <a
          href={`https://wa.me/?text=${encodeURIComponent(shareText)}`}
          target="_blank"
          rel="noreferrer"
          className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-brand-500/50 py-2 text-[12px] font-bold text-mint-300 transition hover:bg-brand-500/10"
        >
          💬 Partager cet itinéraire sur WhatsApp
        </a>
      )}
      {route.kind !== "principal" &&
        (accepted ? (
          <p className="mt-2 rounded-xl bg-brand-500/15 px-3 py-2.5 text-center text-[13px] font-bold text-mint-300">
            ✓ Délestage confirmé — bonne route, vous faites partie des conducteurs ventilés.
          </p>
        ) : (
          <button
            disabled={unavailable || accepting}
            onClick={() => onAccept(route)}
            className="mt-2 w-full rounded-xl bg-brand-500 py-2.5 text-[13px] font-bold text-night-950 transition enabled:hover:bg-mint-400 disabled:cursor-not-allowed disabled:bg-night-600 disabled:text-sage"
          >
            {accepting ? "Réservation du quota…" : blocked ? "Délestage interdit (zone protégée)" : quotaFull ? "Quota épuisé — rester sur l'axe principal" : "Suivre ce délestage"}
          </button>
        ))}
    </article>
  );
}

export default function RoutingSection() {
  const { cityId, heat, projectedHour } = useApp();
  const city = CITY_MAP[cityId];

  const defaultFrom = city.zones[0].id;
  const defaultTo = city.id === "dakar" ? "pikine" : city.zones[city.zones.length - 1].id;
  const [from, setFrom] = useState(defaultFrom);
  const [to, setTo] = useState(defaultTo);
  const [prio, setPrio] = useState<Record<PriorityKey, boolean>>({
    time: true,
    fuel: true,
    safety: false,
    practicability: true,
  });
  const [profile, setProfile] = useState<ProfileId>("standard");
  const [favorites, setFavorites] = useState<{ from: string; to: string }[]>([]);

  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        const raw = window.localStorage.getItem(`afri_fav_routes_${cityId}`);
        if (raw) setFavorites(JSON.parse(raw) as { from: string; to: string }[]);
      } catch {
        /* pas de favoris */
      }
    }, 0);
    return () => clearTimeout(t);
  }, [cityId]);

  const isFavorite = favorites.some((f) => f.from === from && f.to === to);
  const toggleFavorite = () => {
    const next = isFavorite
      ? favorites.filter((f) => !(f.from === from && f.to === to))
      : [...favorites, { from, to }].slice(-6);
    setFavorites(next);
    try {
      window.localStorage.setItem(`afri_fav_routes_${cityId}`, JSON.stringify(next));
    } catch {
      /* stockage indisponible */
    }
  };
  const [result, setResult] = useState<RoutingResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [acceptingId, setAcceptingId] = useState<string | null>(null);
  const [acceptedIds, setAcceptedIds] = useState<Set<string>>(new Set());

  // Changement de ville : jamais de zones/routes de l'ancienne ville.
  useEffect(() => {
    const t = window.setTimeout(() => {
      setResult(null);
      setError(null);
      setAcceptedIds(new Set());
      let savedFrom: string | null = null;
      let savedTo: string | null = null;
      try {
        const raw = window.localStorage.getItem(`afri_route_${cityId}`);
        if (raw) {
          const saved = JSON.parse(raw) as { from?: string; to?: string; prio?: Record<PriorityKey, boolean> };
          if (saved.from && city.zones.some((z) => z.id === saved.from)) savedFrom = saved.from;
          if (saved.to && city.zones.some((z) => z.id === saved.to)) savedTo = saved.to;
          if (saved.prio) setPrio((p) => ({ ...p, ...saved.prio }));
        }
      } catch {
        /* pas d'historique */
      }
      setFrom(savedFrom ?? city.zones[0].id);
      setTo(savedTo ?? (city.id === "dakar" ? "pikine" : city.zones[city.zones.length - 1].id));
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cityId]);

  const swapZones = () => {
    setFrom(to);
    setTo(from);
  };

  const floodZones = useMemo(() => city.axes.filter((a) => a.floodProne).map((a) => a.short), [city]);
  const protectedAxes = useMemo(() => {
    if (!heat) return [];
    return heat.axes.filter((a) => a.protectedZone);
  }, [heat]);

  const compute = async () => {
    if (from === to) {
      setError(
        "Le départ et la destination sont identiques : choisissez deux zones différentes pour calculer un itinéraire ventilé.",
      );
      setResult(null);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const q = new URLSearchParams({ city: cityId, from, to });
      q.set("profile", profile);
      q.set("time", prio.time ? "1" : "0");
      q.set("fuel", prio.fuel ? "1" : "0");
      q.set("safety", prio.safety ? "1" : "0");
      q.set("practicability", prio.practicability ? "1" : "0");
      if (projectedHour !== null) q.set("hour", String(projectedHour));
      const res = await fetch(`/api/routing?${q.toString()}`, { cache: "no-store" });
      const json = (await res.json()) as RoutingResponse & { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Calcul impossible");
      setResult(json);
      setAcceptedIds(new Set());
      try {
        window.localStorage.setItem(`afri_route_${cityId}`, JSON.stringify({ from, to, prio }));
      } catch {
        /* stockage indisponible */
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : "Calcul impossible");
      setResult(null);
    } finally {
      setLoading(false);
    }
  };

  const accept = async (route: RouteOption) => {
    const firstLeg = route.legs[0];
    if (!firstLeg) return;
    setAcceptingId(route.id);
    try {
      const res = await fetch("/api/routing/accept", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: cityId, axisId: firstLeg.axisId, deviceHash: getDeviceHash() }),
      });
      if (res.ok) {
        setAcceptedIds((prev) => new Set(prev).add(route.id));
        // Met à jour le quota affiché localement.
        setResult((prev) => {
          if (!prev) return prev;
          return {
            ...prev,
            routes: prev.routes.map((r) =>
              r.id === route.id && r.quota
                ? { ...r, quota: { ...r.quota, granted: r.quota.granted + 1, remaining: Math.max(0, r.quota.remaining - 1) } }
                : r,
            ),
          };
        });
      } else if (res.status === 409) {
        setError("Quota atteint entre-temps : cet axe de délestage vient d'être fermé.");
      }
    } catch {
      setError("Impossible de réserver le quota, réessayez.");
    } finally {
      setAcceptingId(null);
    }
  };

  const bestRoute = useMemo(() => {
    if (!result) return null;
    const usable = result.routes.filter((r) => r.status === "recommande");
    if (usable.length === 0) return result.routes[0];
    return [...usable].sort((a, b) => a.minutes - b.minutes)[0];
  }, [result]);

  return (
    <section id="routage" className="scroll-mt-24 border-y border-night-600/60 bg-night-900/50">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
              <span className="inline-block h-px w-8 bg-brand-500" /> 02 · Itinéraires ventilés
            </p>
            <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
              L&apos;itinéraire <span className="text-brand-500">ventilé</span>, pas juste le plus court
            </h2>
            <p className="mt-2 max-w-3xl text-[14px] leading-relaxed text-sage">
              Le plus <b className="text-paper">économique</b> en carburant, le plus <b className="text-paper">sûr</b>{" "}
              (accidents &amp; insécurité), le plus <b className="text-paper">praticable</b> (nids-de-poule, zones
              inondables) — tout en aérant l&apos;axe principal sans saturer le délestage, grâce aux{" "}
              <b className="text-paper">quotas par axe</b> et aux <b className="text-paper">zones protégées bloquées à 80&nbsp;%</b>.
            </p>
          </div>
          <p className="rounded-xl bg-night-950 px-3 py-2 font-mono text-[11px] leading-relaxed text-mint-300">
            coût = (Distance/Vitesse) × M_profil × (1 + P_qualité + P_sécurité) × M_quota
            <br />
            <span className="text-sage">{"// A* + mur de quota ×50 à 80 % — porté du prototype Rust"}</span>
          </p>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[0.9fr_1.6fr]">
          <div data-reveal className="h-fit rounded-3xl border border-night-600 bg-night-900 p-5">
            <div className="flex items-center gap-3">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-brand-500 font-display text-[13px] font-bold text-night-950">1</span>
              <h3 className="font-display text-base font-semibold">Votre trajet</h3>
            </div>
            <div className="mt-4 space-y-3">
              <AddressSearch cityId={cityId} label="Ou recherchez un lieu de départ" onZone={(z) => setFrom(z)} />
              <label className="block">
                <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">Départ (zone)</span>
                <select
                  value={from}
                  onChange={(e) => setFrom(e.target.value)}
                  className="w-full cursor-pointer rounded-xl border border-night-600 bg-night-800 px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                >
                  {city.zones.map((z) => (
                    <option key={z.id} value={z.id}>
                      {z.name}
                    </option>
                  ))}
                </select>
              </label>
              <button
                onClick={swapZones}
                className="mx-auto flex items-center gap-2 rounded-full border border-night-600 bg-night-800 px-3 py-1.5 text-[11.5px] font-semibold text-mint-300 transition hover:bg-night-700"
                title="Inverser départ et destination"
              >
                <ArrowUpDown className="h-3.5 w-3.5" /> Inverser le trajet
              </button>
              <AddressSearch cityId={cityId} label="Ou recherchez un lieu d'arrivée" onZone={(z) => setTo(z)} />
              <label className="block">
                <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">Destination (zone)</span>
                <select
                  value={to}
                  onChange={(e) => setTo(e.target.value)}
                  className="w-full cursor-pointer rounded-xl border border-night-600 bg-night-800 px-3 py-2.5 text-sm outline-none focus:border-brand-500"
                >
                  {city.zones.map((z) => (
                    <option key={z.id} value={z.id}>
                      {z.name}
                    </option>
                  ))}
                </select>
              </label>
            </div>

            <div className="mt-6">
              <span className="mb-2 block text-[11px] font-semibold tracking-wide text-sage uppercase">
                Profil de conduite
              </span>
              <div className="space-y-2">
                {PROFILES.map((p) => (
                  <button
                    key={p.id}
                    onClick={() => setProfile(p.id)}
                    className={`w-full rounded-xl border px-3 py-2.5 text-left transition ${
                      profile === p.id
                        ? "border-brand-500 bg-brand-500/12"
                        : "border-night-600 bg-night-800/60 hover:border-night-500"
                    }`}
                  >
                    <span className="block text-[13px] font-bold">{p.label}</span>
                    <span className="mt-0.5 block text-[11.5px] leading-snug text-sage">{p.desc}</span>
                  </button>
                ))}
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-sage">
                Dans tous les profils, un axe à ≥ 80 % de capacité voit son coût augmenter exponentiellement : le
                moteur n&apos;y déverse jamais un flux massif.
              </p>
            </div>

            <div className="mt-6 flex items-center gap-3">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-brand-500 font-display text-[13px] font-bold text-night-950">2</span>
              <h3 className="font-display text-base font-semibold">Vos priorités</h3>
            </div>
            <div className="mt-4 space-y-2">
              {PRIORITIES.map(({ key, label, icon: Icon }) => (
                <label
                  key={key}
                  className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-2.5 text-[13px] font-medium transition ${
                    prio[key] ? "border-brand-500/50 bg-brand-500/10 text-paper" : "border-night-600 bg-night-800/60 text-sage hover:text-paper"
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={prio[key]}
                    onChange={(e) => setPrio((p) => ({ ...p, [key]: e.target.checked }))}
                    className="h-4 w-4 accent-[#22b573]"
                  />
                  <Icon className="h-4 w-4 text-mint-400" />
                  {label}
                </label>
              ))}
            </div>

            <p className="mt-4 flex items-start gap-2 rounded-xl bg-night-800/70 p-3 text-[12px] leading-relaxed text-sage">
              <CloudRain className="mt-0.5 h-4 w-4 shrink-0 text-sky-300" />
              <span>
                Météo actuelle prise en compte : <b className="text-paper">{heat?.weather.label.toLowerCase() ?? "…"}</b>.
                En pluie forte, {floodZones.slice(0, 3).join(", ")} (inondables) sont fortement pénalisés.
              </span>
            </p>

            {favorites.length > 0 && (
              <div className="mt-4 flex flex-wrap gap-1.5">
                {favorites.map((f) => (
                  <button
                    key={`${f.from}-${f.to}`}
                    onClick={() => {
                      setFrom(f.from);
                      setTo(f.to);
                    }}
                    className="rounded-full bg-night-800 px-2.5 py-1.5 text-[11px] font-semibold text-mint-300 transition hover:bg-night-700"
                    title="Charger ce trajet favori"
                  >
                    ★ {city.zones.find((z) => z.id === f.from)?.name} → {city.zones.find((z) => z.id === f.to)?.name}
                  </button>
                ))}
              </div>
            )}
            <button
              onClick={toggleFavorite}
              className={`mt-3 w-full rounded-xl border py-2 text-[12px] font-bold transition ${
                isFavorite
                  ? "border-amber-warn/60 bg-amber-warn/10 text-amber-warn"
                  : "border-night-600 text-sage hover:text-paper"
              }`}
            >
              {isFavorite ? "★ Trajet dans vos favoris" : "☆ Enregistrer ce trajet en favori"}
            </button>
            <button
              onClick={() => void compute()}
              disabled={loading}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-500 py-3 text-sm font-bold text-night-950 transition hover:bg-mint-400 disabled:opacity-60"
            >
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RouteIcon className="h-4 w-4" />}
              Calculer l&apos;itinéraire ventilé
            </button>
            {error && <p className="mt-3 rounded-xl bg-coral/10 px-3 py-2 text-[12.5px] font-medium text-coral">{error}</p>}
          </div>

          <div data-reveal id="route-result">
            {!result ? (
              <>
                <div className="grid place-items-center rounded-3xl border border-dashed border-night-500 bg-night-900/60 px-6 py-14 text-center">
                  <span className="text-4xl">🧭</span>
                  <p className="mt-3 font-display text-lg font-semibold">Lancez un calcul pour voir la ventilation en action</p>
                  <p className="mt-1 max-w-md text-[13px] leading-relaxed text-sage">
                    Le moteur compare tous les axes de {city.name}, applique vos priorités, vérifie les quotas et les
                    zones protégées — puis ne recommande le délestage qu&apos;aux conducteurs qu&apos;il peut encore
                    accueillir.
                  </p>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  {[
                    {
                      icon: Navigation,
                      title: "Quota d'accès (MFD)",
                      text: "Seuls les N premiers conducteurs prennent le délestage B. Les suivants restent sur A ou passent par C : on n'engorge jamais la route de secours.",
                    },
                    {
                      icon: ShieldAlert,
                      title: "Zones protégées",
                      text: "École, hôpital ou quartier résidentiel à ≥80 % de capacité ? Le délestage y est interdit, même s'il est plus rapide.",
                    },
                    {
                      icon: Fuel,
                      title: "Ventilation dosée",
                      text: "En saturation, 18 à 30 % du trafic est dévié — jamais 100 %. L'axe principal respire, le secondaire reste fluide.",
                    },
                  ].map(({ icon: Icon, title, text }) => (
                    <div key={title} className="rounded-3xl border border-night-600 bg-night-900 p-4">
                      <Icon className="h-5 w-5 text-brand-500" />
                      <p className="mt-2 font-display text-[14px] font-bold">{title}</p>
                      <p className="mt-1 text-[12px] leading-relaxed text-sage">{text}</p>
                    </div>
                  ))}
                </div>
              </>
            ) : (
              <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                {result.routes.map((route) => (
                  <RouteCard
                    key={route.id}
                    route={route}
                    isBest={bestRoute?.id === route.id}
                    onAccept={(r) => void accept(r)}
                    accepting={acceptingId === route.id}
                    accepted={acceptedIds.has(route.id)}
                    shareText={`${route.label} (${city.zones.find((z) => z.id === from)?.name} → ${city.zones.find((z) => z.id === to)?.name}, ${city.name}) : ${route.minutes} min, ${route.distanceKm} km via ${route.legs.map((l) => l.name).join(", ")}. ${route.explanation} — calculé par AfriFlow 🚦`}
                  />
                ))}
              </div>
            )}
          </div>
        </div>

        <div data-reveal className="mt-10">
          <h3 className="font-display text-xl font-bold">Zones protégées de {city.name}</h3>
          <p className="mt-1 text-[13px] text-sage">
            On ne déleste jamais le trafic devant une école ou un hôpital déjà saturé — règle des 80 %.
          </p>
          <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {protectedAxes.map((axis) => (
              <div
                key={axis.axisId}
                className={`rounded-2xl border p-4 ${
                  axis.protectedBlocked ? "border-coral/50 bg-coral/8" : "border-night-600 bg-night-900"
                }`}
              >
                <p className="flex items-center justify-between text-[13px] font-bold">
                  <span>{axis.protectedZone?.name}</span>
                  {axis.protectedBlocked ? (
                    <ShieldAlert className="h-4 w-4 text-coral" />
                  ) : (
                    <ShieldCheck className="h-4 w-4 text-brand-500" />
                  )}
                </p>
                <p className="mt-0.5 text-[11px] text-sage">
                  {axis.protectedZone?.kind} · via {axis.short}
                </p>
                <div className="mt-3 h-2 overflow-hidden rounded-full bg-night-950">
                  <div
                    className={`h-full rounded-full ${axis.protectedBlocked ? "bg-coral" : "bg-brand-500"}`}
                    style={{ width: `${axis.protectedSaturation}%` }}
                  />
                </div>
                <p className="mt-1.5 flex justify-between text-[11px] font-medium">
                  <span className="text-sage">saturation {axis.protectedSaturation} %</span>
                  <span className={axis.protectedBlocked ? "font-bold text-coral" : "text-mint-300"}>
                    {axis.protectedBlocked ? "DÉLESTAGE BLOQUÉ" : "délestage autorisé"}
                  </span>
                </p>
              </div>
            ))}
            {protectedAxes.length === 0 && (
              <p className="text-[13px] text-sage">Chargement des zones protégées…</p>
            )}
          </div>
          <p className="mt-4 flex items-center gap-2 text-[12px] text-sage">
            <Clock3 className="h-4 w-4" /> Les saturations sont recalculées à chaque actualisation de la carte
            thermique (toutes les 30 s).
          </p>
        </div>
      </div>
    </section>
  );
}
