import { NextRequest } from "next/server";
import { jsonCached } from "@/lib/http-cache";
import { buildPlatformStats } from "@/lib/server-data";

export const dynamic = "force-dynamic";

let payloadCache: { at: number; payload: Record<string, unknown> } | null = null;
const CACHE_MS = 20_000;

/**
 * GET /api/stats — compteurs plateforme réels : villes et axes surveillés,
 * pings GPS 24 h, incidents du jour et diffusés, flotte suivie, abonnés API.
 * Réponse cacheable (ETag) dans la fenêtre de cache des statistiques.
 */
export async function GET(req: NextRequest) {
  if (!payloadCache || Date.now() - payloadCache.at >= CACHE_MS) {
    const stats = await buildPlatformStats();
    payloadCache = {
      at: Date.now(),
      payload: { generatedAt: new Date().toISOString(), ...stats },
    };
  }
  return jsonCached(req, payloadCache.payload, 20, 60);
}
