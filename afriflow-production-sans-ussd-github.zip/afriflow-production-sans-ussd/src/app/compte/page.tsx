import AccountAccess from "@/components/AccountAccess";

export default function AccountPage() {
  return <AccountAccess />;
}
