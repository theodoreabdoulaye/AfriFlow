// Pure validation: no database imports, network calls or values in diagnostics.
export function validateProductionEnv(env: Record<string, string | undefined>): string[] {
  const errors: string[] = [];
  const value = (key: string) => env[key]?.trim() ?? "";
  for (const key of ["DATABASE_URL", "NEXT_PUBLIC_SITE_URL", "NEXT_PUBLIC_RECAPTCHA_SITE_KEY", "RECAPTCHA_SECRET_KEY"]) {
    if (!value(key)) errors.push(`${key}: required in production`);
  }
  if (value("DATABASE_URL")) {
    try {
      const url = new URL(value("DATABASE_URL"));
      if (!["postgres:", "postgresql:"].includes(url.protocol) || !url.hostname || url.pathname.length < 2) {
        errors.push("DATABASE_URL: expected a PostgreSQL URL with host and database");
      }
    } catch { errors.push("DATABASE_URL: invalid URL"); }
  }
  if (value("NEXT_PUBLIC_SITE_URL")) {
    try {
      const url = new URL(value("NEXT_PUBLIC_SITE_URL"));
      if (url.protocol !== "https:" || !url.hostname || url.username || url.password || url.pathname !== "/" || url.search || url.hash) {
        errors.push("NEXT_PUBLIC_SITE_URL: expected an HTTPS origin without credentials, path, query or fragment");
      }
      if (["localhost", "127.0.0.1", "[::1]"].includes(url.hostname) || url.hostname.endsWith(".localhost")) {
        errors.push("NEXT_PUBLIC_SITE_URL: must not be a loopback origin");
      }
    } catch { errors.push("NEXT_PUBLIC_SITE_URL: invalid URL"); }
  }
  if (value("NEXT_PUBLIC_GOOGLE_CLIENT_ID") && !/^[A-Za-z0-9_-]+\.apps\.googleusercontent\.com$/.test(value("NEXT_PUBLIC_GOOGLE_CLIENT_ID"))) {
    errors.push("NEXT_PUBLIC_GOOGLE_CLIENT_ID: expected a Google Web OAuth client ID");
  }
  for (const keys of [
    ["WHATSAPP_VERIFY_TOKEN", "WHATSAPP_APP_SECRET", "WHATSAPP_TOKEN", "WHATSAPP_PHONE_NUMBER_ID"],
    ["CHARIOW_API_KEY", "CHARIOW_WEBHOOK_SECRET"],
  ]) {
    if (keys.some(key => value(key))) {
      for (const key of keys) if (!value(key)) errors.push(`${key}: required when this integration is enabled`);
    }
  }
  if (value("WHATSAPP_PHONE_NUMBER_ID") && !/^\d+$/.test(value("WHATSAPP_PHONE_NUMBER_ID"))) {
    errors.push("WHATSAPP_PHONE_NUMBER_ID: expected a numeric Meta identifier");
  }
  if (value("CHARIOW_WEBHOOK_SECRET") && !/^whsec_\S+$/.test(value("CHARIOW_WEBHOOK_SECRET"))) {
    errors.push("CHARIOW_WEBHOOK_SECRET: expected a Pulse secret starting with whsec_");
  }
  for (const key of ["DATABASE_URL", "RECAPTCHA_SECRET_KEY", "CHARIOW_API_KEY", "CHARIOW_WEBHOOK_SECRET", "WHATSAPP_VERIFY_TOKEN", "WHATSAPP_APP_SECRET", "WHATSAPP_TOKEN"]) {
    if (value(`NEXT_PUBLIC_${key}`)) errors.push(`NEXT_PUBLIC_${key}: server secrets must not be public`);
  }
  return errors;
}
