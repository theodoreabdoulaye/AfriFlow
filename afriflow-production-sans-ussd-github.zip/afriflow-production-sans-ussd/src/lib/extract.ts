import type { CityDef } from "./cities";
import { searchPlaces } from "./geocode";
import { extractIncidentLocal, severityFromText } from "./nlp";

/**
 * Extraction d'entités des signalements en langage naturel (français
 * approximatif, wolof, pulaar) — le contrat demandé :
 *
 *   "Y'a un gros trou devant la pharmacie à Yoff"
 *     → { "edge_id": "route-yoff", "type": "nid_de_poule", "severite": 3 }
 *
 * Chaîne : extraction LLM (GPT-4o-mini si OPENAI_API_KEY) ou parseur
 * local multilingue → résolution du lieu dans NOTRE graphe (noms locaux)
 * puis Nominatim en repli → map matching sur l'axe.
 */

export interface ExtractedEntities {
  edge_id: string | null;
  axis_name: string | null;
  /** accident | police | inondation | bouchon | travaux | panne | nid_de_poule | danger */
  type: string;
  severite: number; // 1..5
  location_name: string | null;
  confidence: number; // 0..1
  provider: "openai" | "local";
  /** Coordonnées du lieu résolu (si rattaché au graphe). */
  lat: number | null;
  lon: number | null;
}

function normalize(s: string): string {
  return s
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/**
 * Résolution d'un lieu cité dans NOTRE graphe : les noms locaux
 * ("VDN", "Corniche", "Patte d'Oie") y sont plus fiables que Nominatim.
 */
export function resolveInGraph(
  city: CityDef,
  locationName: string,
): { lat: number; lon: number; label: string; axisId: string } | null {
  const tokens = normalize(locationName)
    .split(/[^a-z0-9]+/)
    .filter((t) => t.length >= 2);
  if (tokens.length === 0) return null;

  let best: { axis: CityDef["axes"][number]; score: number } | null = null;
  for (const axis of city.axes) {
    const hay = normalize(`${axis.name} ${axis.short}`);
    let score = 0;
    for (const t of tokens) {
      if (hay.split(/[^a-z0-9]+/).includes(t)) score += 2;
      else if (hay.includes(t)) score += 1;
    }
    if (score > 0 && (!best || score > best.score)) best = { axis, score };
  }
  if (best) {
    const mid = best.axis.gps[Math.floor(best.axis.gps.length / 2)];
    return { lat: mid[0], lon: mid[1], label: best.axis.name, axisId: best.axis.id };
  }

  for (const zone of city.zones) {
    const zn = normalize(zone.name);
    if (tokens.some((t) => zn.includes(t) || t.includes(zn))) {
      const axis = city.axes.find((a) => a.from === zone.id || a.to === zone.id);
      if (axis) {
        const pt = axis.from === zone.id ? axis.gps[0] : axis.gps[axis.gps.length - 1];
        return { lat: pt[0], lon: pt[1], label: zone.name, axisId: axis.id };
      }
    }
  }
  return null;
}

async function extractWithLlm(
  text: string,
): Promise<{ incidentType: string; locationName: string | null; confidence: number } | null> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return null;
  try {
    const prompt =
      "Tu es un assistant de trafic en Afrique de l'Ouest. Analyse ce message (français approximatif, wolof ou pulaar possible). " +
      "Extrais le type d'incident (accident, police, inondation, bouchon, travaux, panne, nid_de_poule, danger), le lieu mentionné et la gravité de 1 (faible) à 5 (bloquant). " +
      'Réponds UNIQUEMENT en JSON valide : {"incident_type": "...", "location_name": "...", "severite": 3, "confidence": 0.9}. ' +
      `Message: "${text.replace(/"/g, "'")}"`;
    const res = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-4o-mini",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.1,
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const parsed = JSON.parse(json.choices?.[0]?.message?.content ?? "{}") as {
      incident_type?: string;
      location_name?: string;
      severite?: number;
      confidence?: number;
    };
    if (!parsed.incident_type) return null;
    return {
      incidentType: parsed.incident_type,
      locationName: parsed.location_name ?? null,
      confidence: typeof parsed.confidence === "number" ? parsed.confidence : 0.75,
      ...(typeof parsed.severite === "number" ? { severite: parsed.severite } : {}),
    } as { incidentType: string; locationName: string | null; confidence: number };
  } catch {
    return null;
  }
}

/** Extraction complète : texte libre → entités structurées rattachées au graphe. */
export async function extractIncidentEntities(
  text: string,
  city: CityDef,
): Promise<ExtractedEntities> {
  const llm = await extractWithLlm(text);
  const local = extractIncidentLocal(text);

  const type = llm?.incidentType ?? local.incidentType;
  const locationName = llm?.locationName ?? local.locationName;
  const confidence = llm?.confidence ?? local.confidence;
  const provider: "openai" | "local" = llm ? "openai" : "local";
  const severite = Math.max(1, Math.min(5, severityFromText(text)));

  let edgeId: string | null = null;
  let axisName: string | null = null;
  let lat: number | null = null;
  let lon: number | null = null;

  // Repli : lieu non extrait proprement → recherche dans tout le message
  // (ex. wolof « Aksidaan am na ci corniche ouest »).
  if (!locationName) {
    const inText = resolveInGraph(city, text);
    if (inText) {
      return {
        edge_id: inText.axisId,
        axis_name: inText.label,
        type,
        severite,
        location_name: inText.label,
        confidence,
        provider,
        lat: inText.lat,
        lon: inText.lon,
      };
    }
  }

  if (locationName) {
    const inGraph = resolveInGraph(city, locationName);
    if (inGraph) {
      edgeId = inGraph.axisId;
      axisName = inGraph.label;
      lat = inGraph.lat;
      lon = inGraph.lon;
    } else {
      const places = await searchPlaces(city, locationName, 1);
      if (places.length > 0) {
        lat = places[0].lat;
        lon = places[0].lon;
        const { nearestAxisFast } = await import("./spatial");
        const found = nearestAxisFast(city, places[0].lat, places[0].lon, 2500);
        if (found) {
          edgeId = found.axis.id;
          axisName = found.axis.name;
        }
      }
    }
  }

  return {
    edge_id: edgeId,
    axis_name: axisName,
    type,
    severite,
    location_name: locationName,
    confidence,
    provider,
    lat,
    lon,
  };
}
