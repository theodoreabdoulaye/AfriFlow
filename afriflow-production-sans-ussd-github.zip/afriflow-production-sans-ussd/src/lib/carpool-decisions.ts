import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { carpoolBookings, carpoolOffers, carpoolRatings } from "@/db/schema";
import { sendWhatsAppText } from "./wa-sender";

/**
 * Décisions et notation du covoiturage :
 * - le conducteur accepte/refuse une demande en répondant OUI ou NON
 *   sur WhatsApp (le passager est notifié automatiquement) ;
 * - après le trajet, conducteur et passager se notent (1 à 5 étoiles),
 *   par l'API ou simplement en envoyant la note sur WhatsApp.
 */

/** Compare deux numéros sur leurs 9 derniers chiffres (formats locaux/intl). */
export function samePhone(a: string, b: string): boolean {
  const da = a.replace(/\D/g, "");
  const dbDigits = b.replace(/\D/g, "");
  if (da.length < 7 || dbDigits.length < 7) return false;
  return da.slice(-9) === dbDigits.slice(-9);
}

export interface PendingDecision {
  bookingId: number;
  passengerName: string;
  passengerPhone: string;
  seats: number;
  offer: typeof carpoolOffers.$inferSelect;
}

/** Dernière demande en attente de décision pour ce conducteur. */
export async function findPendingDecision(driverPhone: string): Promise<PendingDecision | null> {
  try {
    const rows = await db
      .select({ booking: carpoolBookings, offer: carpoolOffers })
      .from(carpoolBookings)
      .innerJoin(carpoolOffers, eq(carpoolBookings.offerId, carpoolOffers.id))
      .where(eq(carpoolBookings.status, "pending"))
      .orderBy(desc(carpoolBookings.id))
      .limit(30);
    const match = rows.find((r) => samePhone(r.offer.driverPhone, driverPhone));
    if (!match) return null;
    return {
      bookingId: match.booking.id,
      passengerName: match.booking.passengerName,
      passengerPhone: match.booking.passengerPhone,
      seats: match.booking.seats,
      offer: match.offer,
    };
  } catch {
    return null;
  }
}

export interface DecisionOutcome {
  handled: boolean;
  reply: string;
}

/** Applique la réponse OUI/NON du conducteur à sa demande en attente. */
export async function handleDriverDecision(
  driverPhone: string,
  decision: "oui" | "non",
): Promise<DecisionOutcome> {
  const pending = await findPendingDecision(driverPhone);
  if (!pending) return { handled: false, reply: "" };
  const { offer, bookingId } = pending;

  const expired =
    Date.now() - new Date(offer.departureTime).getTime() > 30 * 60_000 ||
    Date.now() - new Date(offer.createdAt).getTime() > 24 * 3600_000;
  if (expired) {
    await db
      .update(carpoolBookings)
      .set({ status: "expired" })
      .where(eq(carpoolBookings.id, bookingId));
    return {
      handled: true,
      reply: "⌛ Cette demande de covoiturage a expiré (départ dépassé). Merci quand même !",
    };
  }

  if (decision === "non") {
    await db
      .update(carpoolBookings)
      .set({ status: "declined" })
      .where(eq(carpoolBookings.id, bookingId));
    await sendWhatsAppText(
      pending.passengerPhone,
      `❌ ${offer.driverName} n'a pas pu accepter votre demande de covoiturage (${offer.fromLabel} → ${offer.toLabel}). Cherchez une autre offre dans l'app AfriFlow — de nouveaux conducteurs publient chaque jour.`,
    );
    return {
      handled: true,
      reply: `❌ Demande de ${pending.passengerName} refusée. Le passager a été prévenu. Merci de votre réponse !`,
    };
  }

  // OUI : prise de place atomique (échoue proprement si l'offre est pleine).
  const updated = await db
    .update(carpoolOffers)
    .set({
      seatsTaken: sql`${carpoolOffers.seatsTaken} + ${pending.seats}`,
      status: sql`CASE WHEN ${carpoolOffers.seatsTaken} + ${pending.seats} >= ${carpoolOffers.seatsTotal} THEN 'full' ELSE 'active' END`,
    })
    .where(
      and(
        eq(carpoolOffers.id, offer.id),
        sql`${carpoolOffers.seatsTaken} + ${pending.seats} <= ${carpoolOffers.seatsTotal}`,
      ),
    )
    .returning();
  if (updated.length === 0) {
    await db
      .update(carpoolBookings)
      .set({ status: "declined" })
      .where(eq(carpoolBookings.id, bookingId));
    await sendWhatsAppText(
      pending.passengerPhone,
      `❌ Désolé, le trajet ${offer.fromLabel} → ${offer.toLabel} vient de se remplir. Cherchez une autre offre dans l'app AfriFlow.`,
    );
    return {
      handled: true,
      reply: "⚠️ Votre offre vient de se remplir entre-temps : la demande a été refusée et le passager prévenu.",
    };
  }

  await db
    .update(carpoolBookings)
    .set({ status: "confirmed" })
    .where(eq(carpoolBookings.id, bookingId));
  const when = new Date(offer.departureTime).toLocaleString("fr-FR", {
    day: "2-digit",
    month: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
  await sendWhatsAppText(
    pending.passengerPhone,
    `✅ ${offer.driverName} a accepté votre demande ! Trajet ${offer.fromLabel} → ${offer.toLabel}, départ ${when}, ${pending.seats} place(s) réservée(s). Le conducteur vous contactera pour le point de rendez-vous. Après le trajet, répondez avec une note de 1 à 5 pour noter votre conducteur. Bon voyage !`,
  );
  return {
    handled: true,
    reply: `✅ Réservation confirmée pour ${pending.passengerName} (${offer.fromLabel} → ${offer.toLabel}, départ ${when}). Le passager a été prévenu. Après le trajet, il pourra vous noter de 1 à 5 étoiles.`,
  };
}

/* ------------------------------ Notation ------------------------------ */

export interface RatableTrip {
  bookingId: number;
  role: "passenger" | "driver";
  rateePhone: string;
  rateeLabel: string;
  offer: typeof carpoolOffers.$inferSelect;
}

/** Trajet terminé (ou en cours) que ce numéro peut encore noter. */
export async function findRatableTrip(phone: string): Promise<RatableTrip | null> {
  try {
    const rows = await db
      .select({ booking: carpoolBookings, offer: carpoolOffers })
      .from(carpoolBookings)
      .innerJoin(carpoolOffers, eq(carpoolBookings.offerId, carpoolOffers.id))
      .where(eq(carpoolBookings.status, "confirmed"))
      .orderBy(desc(carpoolBookings.id))
      .limit(40);
    for (const row of rows) {
      const departurePassed = new Date(row.offer.departureTime).getTime() < Date.now();
      if (!departurePassed) continue;
      const isPassenger = samePhone(row.booking.passengerPhone, phone);
      const isDriver = samePhone(row.offer.driverPhone, phone);
      if (!isPassenger && !isDriver) continue;
      const role = isPassenger ? "passenger" : "driver";
      const rated = await db
        .select({ id: carpoolRatings.id })
        .from(carpoolRatings)
        .where(and(eq(carpoolRatings.bookingId, row.booking.id), eq(carpoolRatings.raterRole, role)))
        .limit(1);
      if (rated.length > 0) continue;
      return {
        bookingId: row.booking.id,
        role,
        rateePhone: isPassenger ? row.offer.driverPhone : row.booking.passengerPhone,
        rateeLabel: isPassenger ? row.offer.driverName : row.booking.passengerName,
        offer: row.offer,
      };
    }
    return null;
  } catch {
    return null;
  }
}

export interface RatingOutcome {
  ok: boolean;
  message: string;
  average?: number;
  count?: number;
}

/** Enregistre une note (1-5) : éligibilité vérifiée (partie prenante, trajet passé, pas déjà noté). */
export async function recordRating(input: {
  bookingId: number;
  raterPhone: string;
  stars: number;
  comment?: string | null;
}): Promise<RatingOutcome> {
  const stars = Math.round(input.stars);
  if (!(stars >= 1 && stars <= 5)) {
    return { ok: false, message: "La note doit être entre 1 et 5 étoiles." };
  }
  try {
    const rows = await db
      .select({ booking: carpoolBookings, offer: carpoolOffers })
      .from(carpoolBookings)
      .innerJoin(carpoolOffers, eq(carpoolBookings.offerId, carpoolOffers.id))
      .where(eq(carpoolBookings.id, input.bookingId))
      .limit(1);
    if (rows.length === 0) return { ok: false, message: "Réservation introuvable." };
    const { booking, offer } = rows[0];
    if (booking.status !== "confirmed") {
      return { ok: false, message: "Seuls les trajets confirmés peuvent être notés." };
    }
    if (new Date(offer.departureTime).getTime() > Date.now()) {
      return { ok: false, message: "Le trajet n'a pas encore eu lieu — notez-le après l'arrivée." };
    }
    const isPassenger = samePhone(booking.passengerPhone, input.raterPhone);
    const isDriver = samePhone(offer.driverPhone, input.raterPhone);
    if (!isPassenger && !isDriver) {
      return { ok: false, message: "Seuls le conducteur et le passager de ce trajet peuvent le noter." };
    }
    const existing = await db
      .select({ id: carpoolRatings.id })
      .from(carpoolRatings)
      .where(
        and(
          eq(carpoolRatings.bookingId, input.bookingId),
          eq(carpoolRatings.raterRole, isPassenger ? "passenger" : "driver"),
        ),
      )
      .limit(1);
    if (existing.length > 0) {
      return { ok: false, message: "Vous avez déjà noté ce trajet. Merci !" };
    }
    const rateePhone = isPassenger ? offer.driverPhone : booking.passengerPhone;
    await db.insert(carpoolRatings).values({
      bookingId: input.bookingId,
      raterPhone: input.raterPhone,
      raterRole: isPassenger ? "passenger" : "driver",
      rateePhone,
      stars,
      comment: input.comment ?? null,
    });
    const agg = await ratingAggregate(rateePhone);
    return {
      ok: true,
      message: `Merci ! Note de ${stars} étoile(s) enregistrée.`,
      average: agg.average ?? undefined,
      count: agg.count,
    };
  } catch {
    return { ok: false, message: "Notation indisponible pour le moment." };
  }
}

/** Moyenne et nombre d'avis reçus par un numéro (conducteur ou passager). */
export async function ratingAggregate(phone: string): Promise<{ average: number | null; count: number }> {
  try {
    const rows = await db
      .select({ stars: carpoolRatings.stars })
      .from(carpoolRatings)
      .where(eq(carpoolRatings.rateePhone, phone));
    if (rows.length === 0) return { average: null, count: 0 };
    const avg = rows.reduce((a, r) => a + r.stars, 0) / rows.length;
    return { average: Math.round(avg * 10) / 10, count: rows.length };
  } catch {
    return { average: null, count: 0 };
  }
}

/** Agrégats pour un lot de numéros (affichage dans les offres). */
export async function ratingAggregates(
  phones: string[],
): Promise<Map<string, { average: number | null; count: number }>> {
  const map = new Map<string, { average: number | null; count: number }>();
  if (phones.length === 0) return map;
  try {
    const rows = await db
      .select({ rateePhone: carpoolRatings.rateePhone, stars: carpoolRatings.stars })
      .from(carpoolRatings)
      .where(inArray(carpoolRatings.rateePhone, phones));
    const grouped = new Map<string, number[]>();
    for (const r of rows) {
      const list = grouped.get(r.rateePhone) ?? [];
      list.push(r.stars);
      grouped.set(r.rateePhone, list);
    }
    for (const [phone, stars] of grouped) {
      map.set(phone, {
        average: Math.round((stars.reduce((a, b) => a + b, 0) / stars.length) * 10) / 10,
        count: stars.length,
      });
    }
  } catch {
    /* agrégats optionnels */
  }
  return map;
}
