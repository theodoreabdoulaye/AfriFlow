/**
 * Extraction NLP locale (sans clé API) des signalements WhatsApp :
 * type d'incident + lieu, sur des messages en français, wolof ou pulaar
 * (les emprunts au français y sont la norme pour le vocabulaire trafic).
 * Si OPENAI_API_KEY est configurée, un LLM affine l'extraction (whatsapp.ts) ;
 * ce parseur reste le repli garanti, y compris hors-ligne.
 */

export interface NlpExtraction {
  incidentType: string; // accident | police | inondation | bouchon | travaux | panne | danger
  locationName: string | null;
  confidence: number; // 0..1
  /** Un mot-clé de type a été reconnu dans le message. */
  typeFound: boolean;
}

const TYPE_KEYWORDS: { type: string; words: string[] }[] = [
  {
    type: "accident",
    words: [
      "accident", "aksidaan", "aksidan", "collision", "carambolage", "percut",
      "renvers", "heurt", "accidente",
    ],
  },
  {
    type: "inondation",
    words: ["inond", "crue", "eau sur la route", "eau partout", "alagamento", "enchente", "sous l'eau"],
  },
  {
    type: "police",
    words: ["police", "controle", "contrôle", "gendarme", "radar", "checkpoint", "barrage"],
  },
  {
    type: "travaux",
    words: ["travaux", "chantier", "obras", "roadwork", "en travaux"],
  },
  {
    type: "panne",
    words: ["panne", "en panne", "tombe en panne", "tombé en panne", "avaria", "vehicule arrete", "véhicule arrêté"],
  },
  {
    type: "nid_de_poule",
    words: ["nid-de-poule", "nid de poule", "pothole", "buraco", "gros trou", "grand trou", "trou sur la route"],
  },
  {
    type: "danger",
    words: ["danger", "dangereux", "risque"],
  },
  {
    type: "bouchon",
    words: [
      "bouchon", "embouteillage", "bloque", "bloqué", "bloquee", "circulation arretee",
      "circulation arrêtée", "engarrafamento", "traffic jam", "ça ne bouge pas", "ca ne bouge pas",
    ],
  },
];

const LOCATION_MARKERS = [
  "au niveau de",
  "au niveau d",
  "a cote de",
  "à côté de",
  "pres de",
  "près de",
  "devant",
  "derriere",
  "derrière",
  "sur la",
  "sur le",
  "vers",
  "avant",
  "apres",
  "après",
  "ci", // wolof : « à / sur » (ex. « am na ci corniche »)
  "au",
  "a",
  "à",
];

function normalizeText(text: string): string {
  return text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function extractLocation(normalized: string, original: string): string | null {
  for (const marker of LOCATION_MARKERS) {
    const m = ` ${marker} `;
    const idx = normalized.indexOf(m);
    if (idx >= 0) {
      const rest = original.slice(idx + m.length).trim();
      const cleaned = rest
        .split(/[.,;!?\n]/)[0]
        .replace(/\s+/g, " ")
        .trim()
        .slice(0, 60);
      // Un lieu utile fait au moins 3 caractères et contient une lettre.
      if (cleaned.length >= 3 && /[a-zàâäéèêëîïôöùûüç]/i.test(cleaned)) return cleaned;
    }
  }
  return null;
}

export function extractIncidentLocal(text: string): NlpExtraction {
  const normalized = normalizeText(text);
  let incidentType = "bouchon";
  let typeFound = false;
  for (const { type, words } of TYPE_KEYWORDS) {
    if (words.some((w) => normalized.includes(normalizeText(w)))) {
      incidentType = type;
      typeFound = true;
      break;
    }
  }
  const locationName = extractLocation(normalized, text);
  let confidence = typeFound ? 0.8 : 0.35;
  if (locationName) confidence += 0.12;
  if (/bloqu|grave|urgent|fort/.test(normalized)) confidence += 0.03;
  return {
    incidentType,
    locationName,
    confidence: Math.min(0.95, Math.round(confidence * 100) / 100),
    typeFound,
  };
}

/** Gravité 1-5 déduite du vocabulaire d'urgence du message. */
export function severityFromText(text: string): number {
  const t = normalizeText(text);
  if (/bloquant|totalement|grave|urgent|mortel|bless/.test(t)) return 5;
  if (/fort|important|gros|énorme|enorme/.test(t)) return 4;
  if (/petit|leger|léger|faible/.test(t)) return 2;
  return 3;
}
