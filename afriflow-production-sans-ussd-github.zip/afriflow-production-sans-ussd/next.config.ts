import type { NextConfig } from "next";
import { securityHeaders } from "./src/lib/security-headers";


const nextConfig: NextConfig = {
  poweredByHeader: false,
  // Racine explicite : évite que Next remonte au dossier parent quand
  // plusieurs package-lock.json coexistent (build local et Vercel).
  turbopack: { root: process.cwd() },
  // Optimisation d'images intégrée (AVIF/WebP, redimensionnement à la demande).
  images: {
    minimumCacheTTL: 86400,
    remotePatterns: [{ protocol: "https", hostname: "images.pexels.com" }],
    formats: ["image/avif", "image/webp"],
  },
  async headers() {
    return [
      { source: "/:path*", headers: securityHeaders },
      { source: "/compte", headers: [{ key: "Cross-Origin-Embedder-Policy", value: "unsafe-none" }] },
      { source: "/api/:path*", headers: [
        { key: "Cache-Control", value: "no-store" },
        { key: "Content-Security-Policy", value: "default-src 'none'; frame-ancestors 'none'; base-uri 'none'" },
      ] },
      {
        source: "/sw.js",
        headers: [{ key: "Cache-Control", value: "no-cache, no-store, must-revalidate" }],
      },
      {
        // Icônes et manifeste : rarement modifiés, cache long navigateur.
        source: "/icons/:path*",
        headers: [{ key: "Cache-Control", value: "public, max-age=86400, stale-while-revalidate=604800" }],
      },
      {
        source: "/manifest.webmanifest",
        headers: [{ key: "Cache-Control", value: "public, max-age=86400, stale-while-revalidate=604800" }],
      },
    ];
  },
};

export default nextConfig;
