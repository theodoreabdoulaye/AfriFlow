"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  CloudSun,
  Fuel,
  LocateFixed,
  LocateOff,
  Map as MapIcon,
  Route as RouteIcon,
  Satellite,
  TrendingUp,
  TriangleAlert,
} from "lucide-react";
import { CITY_COUNT, CITY_MAP, COUNTRY_COUNT } from "@/lib/cities";
import { cityDisplayDate, formatCityClock } from "@/lib/format";
import { useApp } from "./AppClient";

function Gauge({ value }: { value: number }) {
  const arc = 251.3;
  const offset = arc * (1 - Math.max(0, Math.min(100, value)) / 100);
  const color = value >= 70 ? "#22b573" : value >= 48 ? "#7fe8bb" : value >= 30 ? "#ffb020" : "#ff5d47";
  return (
    <div className="relative mx-auto w-full max-w-55">
      <svg viewBox="0 0 200 112" className="w-full">
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="#26382b" strokeWidth="15" strokeLinecap="round" />
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke={color}
          strokeWidth="15"
          strokeLinecap="round"
          strokeDasharray="251.3"
          strokeDashoffset={offset}
          className="gauge-arc"
        />
      </svg>
      <div className="absolute inset-x-0 bottom-0 text-center">
        <p className="font-display text-4xl font-bold tracking-tight">
          {value}
          <span className="text-base font-medium text-sage">/100</span>
        </p>
      </div>
    </div>
  );
}

type GeoStatus = "off" | "requesting" | "on" | "denied" | "unsupported";

function ContextSimulator() {
  const { cityId, heat, projectedHour, setProjectedHour, clock, refreshHeat } = useApp();
  const city = CITY_MAP[cityId];
  const [geoStatus, setGeoStatus] = useState<GeoStatus>("off");
  const [sentPoints, setSentPoints] = useState(0);
  const watchId = useRef<number | null>(null);
  const lastSent = useRef(0);
  const lastPos = useRef<{ lat: number; lon: number; t: number } | null>(null);

  // Heure locale de la VILLE affichée (pas celle de l'appareil du visiteur).
  const displayDate = cityDisplayDate(heat?.cityTime, projectedHour, clock);
  const cityNowLabel = formatCityClock(heat?.cityTime, clock);

  const stopGeo = () => {
    if (watchId.current !== null && "geolocation" in navigator) {
      navigator.geolocation.clearWatch(watchId.current);
    }
    watchId.current = null;
    setGeoStatus("off");
  };

  const startGeo = () => {
    if (!("geolocation" in navigator)) {
      setGeoStatus("unsupported");
      return;
    }
    setGeoStatus("requesting");
    watchId.current = navigator.geolocation.watchPosition(
      (pos) => {
        setGeoStatus("on");
        const now = Date.now();
        const { latitude, longitude, speed } = pos.coords;
        let kmh = speed !== null && speed >= 0 ? speed * 3.6 : 0;
        if ((speed === null || speed < 0) && lastPos.current) {
          const dt = (now - lastPos.current.t) / 1000;
          if (dt > 0) {
            const dLat = (latitude - lastPos.current.lat) * 111_320;
            const dLon = (longitude - lastPos.current.lon) * 111_320 * Math.cos((latitude * Math.PI) / 180);
            kmh = (Math.hypot(dLat, dLon) / dt) * 3.6;
          }
        }
        lastPos.current = { lat: latitude, lon: longitude, t: now };
        // Transmission toutes les ~25 s, comme l'app conducteur.
        if (now - lastSent.current >= 25_000) {
          lastSent.current = now;
          void fetch("/api/telemetry", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              city: cityId,
              lat: latitude,
              lon: longitude,
              speedKmh: Math.min(140, Math.round(kmh * 10) / 10),
              source: "app",
              deviceHash: "web-contributeur",
            }),
          })
            .then((r) => {
              if (r.ok) {
                setSentPoints((n) => n + 1);
                void refreshHeat();
              }
            })
            .catch(() => undefined);
        }
      },
      () => setGeoStatus("denied"),
      { enableHighAccuracy: true, maximumAge: 10_000, timeout: 15_000 },
    );
  };

  useEffect(() => stopGeo, []);

  return (
    <div data-reveal className="rounded-3xl border border-night-600 bg-night-900/90 p-5 shadow-2xl backdrop-blur sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-base font-semibold">Simulateur de contexte</h3>
          <p className="mt-1 max-w-md text-[13px] leading-relaxed text-sage">
            Météo observée en direct (Open-Meteo), heure de projection pour les prédictions, et contribution GPS
            réelle depuis votre appareil.
          </p>
        </div>
        <span className="flex items-center gap-2 rounded-full border border-night-600 bg-night-800 px-3 py-1.5 text-[12px] font-semibold">
          <CloudSun className="h-4 w-4 text-amber-warn" />
          {heat?.weather.label ?? "—"}
          {heat?.weather.tempC !== null && heat?.weather.tempC !== undefined ? ` · ${heat.weather.tempC}°C` : ""}
          <span className="font-normal text-sage">{heat?.weather.source === "open-meteo" ? "(Open-Meteo)" : "(repli)"}</span>
        </span>
      </div>

      <div className="mt-5 rounded-2xl border border-night-600 bg-night-800/70 p-4">
        <div className="flex items-baseline justify-between">
          <label htmlFor="ctx-hour" className="text-[12px] font-semibold tracking-wide text-sage uppercase">
            Heure de projection
          </label>
          <p className="font-display text-xl font-bold text-mint-300">{formatCityClock(displayDate.toISOString(), clock)}</p>
        </div>
        <input
          id="ctx-hour"
          type="range"
          min={5}
          max={22}
          step={1}
          value={projectedHour ?? heat?.hour ?? clock.getHours()}
          onChange={(e) => setProjectedHour(Number(e.target.value))}
          className="ctx-range mt-3 w-full"
        />
        <div className="mt-2 flex justify-between text-[10px] font-medium text-sage">
          <span>5h</span>
          <span>pic 7-9h</span>
          <span>pic 17-20h</span>
          <span>22h</span>
        </div>
        {projectedHour !== null && (
          <button
            onClick={() => setProjectedHour(null)}
            className="mt-3 rounded-lg bg-night-700 px-3 py-1.5 text-[12px] font-semibold text-mint-300 transition hover:bg-night-600"
          >
            Revenir au temps réel ({cityNowLabel} à {city.name})
          </button>
        )}
      </div>

      <div className="mt-4 rounded-2xl border border-night-600 bg-night-800/70 p-4">
        <div className="flex flex-wrap items-center gap-3">
          <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl ${geoStatus === "on" ? "bg-brand-500 text-night-950" : "bg-night-700 text-sage"}`}>
            {geoStatus === "on" ? <LocateFixed className="h-5 w-5" /> : <LocateOff className="h-5 w-5" />}
          </span>
          <div className="min-w-55 flex-1">
            <p className="text-[13px] leading-relaxed">
              {geoStatus === "on" ? (
                <>
                  <span className="font-semibold text-mint-300">Contribution GPS active.</span>{" "}
                  <span className="text-sage">
                    Position + vitesse réelles transmises toutes les ~25 s ({sentPoints} point(s) envoyé(s)) : elles
                    alimentent la carte de densité GPS et l&apos;entraînement du modèle.
                  </span>
                </>
              ) : geoStatus === "denied" ? (
                <span className="text-coral">
                  Géolocalisation refusée. Autorisez la position pour contribuer vos pings GPS réels au moteur.
                </span>
              ) : geoStatus === "unsupported" ? (
                <span className="text-coral">Géolocalisation non disponible sur cet appareil.</span>
              ) : (
                <span className="text-sage">
                  Partagez votre position réelle : vos pings GPS anonymisés alimentent la carte en direct, comme
                  l&apos;app conducteur.
                </span>
              )}
            </p>
          </div>
          {geoStatus === "on" || geoStatus === "requesting" ? (
            <button
              onClick={stopGeo}
              className="rounded-xl border border-night-500 px-4 py-2 text-[13px] font-semibold text-paper transition hover:bg-night-700"
            >
              Arrêter
            </button>
          ) : (
            <button
              onClick={startGeo}
              className="rounded-xl bg-brand-500 px-4 py-2 text-[13px] font-bold text-night-950 transition hover:bg-mint-400"
            >
              Contribuer en GPS réel
            </button>
          )}
        </div>
        <p className="mt-3 border-t border-night-600/70 pt-3 text-[12px] leading-relaxed text-sage">
          Partenaires (flottes, opérateurs) : ingestion serveur via{" "}
          <code className="rounded bg-night-950 px-1.5 py-0.5 font-mono text-[11px] text-mint-300">POST /api/telemetry</code>{" "}
          avec clé API — voir section Données &amp; IA.
        </p>
      </div>
    </div>
  );
}

export default function Hero() {
  const { cityId, heat, clock, projectedHour, dataSaver } = useApp();
  const city = CITY_MAP[cityId];
  const summary = heat?.summary;
  const displayDate = cityDisplayDate(heat?.cityTime, projectedHour, clock);

  return (
    <section id="top" className="relative overflow-hidden">
      {dataSaver ? (
        <div className="absolute inset-0 bg-gradient-to-br from-night-700 via-night-900 to-night-950" aria-hidden />
      ) : (
        <Image
          src="https://images.pexels.com/photos/16206733/pexels-photo-16206733.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=1600"
          alt="Vue aérienne d'une congestion urbaine en Afrique de l'Ouest"
          fill
          priority
          sizes="100vw"
          className="object-cover"
        />
      )}
      <div className="absolute inset-0 bg-gradient-to-b from-night-950/80 via-night-950/72 to-night-950" />
      <div className="absolute inset-0 bg-gradient-to-r from-night-950/70 via-transparent to-night-950/40" />

      <div className="relative mx-auto max-w-7xl px-4 pt-14 pb-10 sm:px-6 lg:pt-20">
        <div className="grid items-start gap-8 lg:grid-cols-[1.15fr_0.85fr]">
          <div data-reveal>
            <p className="inline-flex flex-wrap items-center gap-2 rounded-full border border-mint-400/30 bg-night-900/80 py-1.5 pr-4 pl-1.5 text-[12px] font-semibold backdrop-blur">
              <span className="rounded-full bg-brand-500 px-2.5 py-0.5 text-[11px] font-bold text-night-950">
                EN DIRECT
              </span>
              <span className="h-1.5 w-1.5 rounded-full bg-brand-500 live-dot" />
              {CITY_COUNT} villes activées · {COUNTRY_COUNT} pays · Afrique de l&apos;Ouest &amp; centrale
            </p>
            <h1 className="mt-6 font-display text-[clamp(2.6rem,6vw,4.6rem)] leading-[0.98] font-bold tracking-tight">
              Les bouchons
              <br />
              se prévoient.
              <br />
              <span className="text-brand-500">La ville respire.</span>
            </h1>
            <p className="mt-6 max-w-xl text-[15px] leading-relaxed text-paper/85 sm:text-base">
              Sans capteurs coûteux : pings GPS légers, densité télécom anonymisée, flottes partenaires et
              signalements <b className="text-paper">communautaires</b>. Notre IA anticipe les
              embouteillages <b className="text-paper">30 à 60 minutes à l&apos;avance</b> — marchés, matchs, pluies,
              manifestations — puis ventile le trafic avant la saturation.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href="#dashboard"
                className="inline-flex items-center gap-2 rounded-2xl bg-brand-500 px-5 py-3 text-sm font-bold text-night-950 shadow-lg shadow-brand-500/25 transition hover:bg-mint-400"
              >
                <MapIcon className="h-4 w-4" /> Voir la carte en direct
              </a>
              <a
                href="#routage"
                className="inline-flex items-center gap-2 rounded-2xl border border-paper/25 bg-night-900/70 px-5 py-3 text-sm font-semibold backdrop-blur transition hover:border-mint-400/60 hover:text-mint-300"
              >
                <RouteIcon className="h-4 w-4" /> Calculer un itinéraire ventilé
              </a>
              <a
                href="#communaute"
                className="inline-flex items-center gap-2 rounded-2xl border border-amber-warn/50 bg-amber-warn/10 px-5 py-3 text-sm font-semibold text-amber-warn backdrop-blur transition hover:bg-amber-warn/20"
              >
                Signaler un incident
              </a>
            </div>
            <dl className="mt-10 grid max-w-lg grid-cols-3 gap-4">
              <div className="rounded-2xl border border-paper/12 bg-night-900/70 p-4 backdrop-blur">
                <dd className="font-display text-3xl font-bold">{CITY_COUNT}</dd>
                <dt className="mt-1 text-[11px] leading-snug text-sage">villes activées ({COUNTRY_COUNT} pays)</dt>
              </div>
              <div className="rounded-2xl border border-paper/12 bg-night-900/70 p-4 backdrop-blur">
                <dd className="font-display text-3xl font-bold">{heat ? heat.axes.length : "—"}</dd>
                <dt className="mt-1 text-[11px] leading-snug text-sage">axes surveillés à {city.name}</dt>
              </div>
              <div className="rounded-2xl border border-paper/12 bg-night-900/70 p-4 backdrop-blur">
                <dd className="font-display text-3xl font-bold">0 capteur</dd>
                <dt className="mt-1 text-[11px] leading-snug text-sage">infrastructure routière requise</dt>
              </div>
            </dl>
          </div>

          <div data-reveal className="rounded-3xl border border-night-600 bg-night-900/90 p-5 shadow-2xl backdrop-blur sm:p-6">
            <p className="flex items-center justify-between text-[11px] font-bold tracking-[0.14em] text-sage uppercase">
              <span className="flex items-center gap-2">
                <span className="live-dot h-2 w-2 rounded-full bg-brand-500" />
                Centre de contrôle — {city.name}
              </span>
              <Satellite className="h-4 w-4" />
            </p>
            <div className="mt-4">
              <Gauge value={summary?.index ?? 0} />
            </div>
            <div className="mt-3 grid grid-cols-3 gap-3 text-center">
              <div className="rounded-2xl bg-night-800 px-2 py-3">
                <p className="flex items-center justify-center gap-1 font-display text-lg font-bold">
                  <TrendingUp className="h-4 w-4 text-mint-400" />
                  {summary ? `${summary.indexIn30}/100` : "—/100"}
                </p>
                <p className="mt-0.5 text-[10px] tracking-wide text-sage uppercase">IA +30 min</p>
              </div>
              <div className="rounded-2xl bg-night-800 px-2 py-3">
                <p className="font-display text-lg font-bold">{summary ? summary.vehiclesTracked.toLocaleString("fr-FR") : "0"}</p>
                <p className="mt-0.5 text-[10px] tracking-wide text-sage uppercase">véhicules estimés en circulation</p>
              </div>
              <div className="rounded-2xl bg-night-800 px-2 py-3">
                <p className="font-display text-lg font-bold">{heat ? heat.quotaGrants24h : "—"}</p>
                <p className="mt-0.5 text-[10px] tracking-wide text-sage uppercase">délestages accordés (24 h, réel)</p>
              </div>
            </div>
            <p className="mt-3 text-[10.5px] leading-relaxed text-sage/80">
              Indice = fluidité pondérée par capacité. Modèle AfriFlow nourri par les GPS réels des conducteurs, la
              météo Open-Meteo, les débits GloFAS et le consensus communautaire ; les valeurs non mesurées sont des
              estimations affichées comme telles.
            </p>
            <p className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-1 border-t border-night-600/70 pt-3 text-[12px] text-sage">
              <span>🕐 {formatCityClock(displayDate.toISOString(), clock)} (heure de {city.name})</span>
              <span>☀️ {heat?.weather.label ?? "…"}</span>
              {heat?.weather.precipProb1h !== null && heat?.weather.precipProb1h !== undefined && (
                <span>🌧️ pluie (1 h) : {heat.weather.precipProb1h} %</span>
              )}
              {heat?.weather.aqiEu !== null && heat?.weather.aqiEu !== undefined && (
                <span>🌫️ air CAMS : IQA {heat.weather.aqiEu}/500</span>
              )}
              {heat?.weather.riverDischargeM3s !== null && heat?.weather.riverDischargeM3s !== undefined && (
                <span>🌊 fleuve (GloFAS) : {heat.weather.riverDischargeM3s} m³/s</span>
              )}
              <span className="flex items-center gap-1">
                <Fuel className="h-3.5 w-3.5 text-amber-warn" />
                {summary ? summary.fuelLostLitersPerHour.toLocaleString("fr-FR") : 0} L/h perdus (est.)
              </span>
              {summary && summary.saturatedAxes > 0 && (
                <span className="flex items-center gap-1 text-coral">
                  <TriangleAlert className="h-3.5 w-3.5" />
                  {summary.saturatedAxes} axe(s) saturé(s)
                </span>
              )}
            </p>
          </div>
        </div>

        <div className="mt-8">
          <ContextSimulator />
        </div>

        <a href="#dashboard" className="mt-8 inline-flex items-center gap-2 text-[13px] font-semibold text-mint-300 hover:text-mint-400">
          Descendre vers la carte thermique <ArrowRight className="h-4 w-4 rotate-90" />
        </a>
      </div>
    </section>
  );
}
