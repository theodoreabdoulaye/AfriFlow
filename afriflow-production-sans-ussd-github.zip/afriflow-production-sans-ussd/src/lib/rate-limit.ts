import { NextResponse } from "next/server";

/**
 * Limiteur de débit en mémoire (fenêtre glissante par clé, typiquement
 * par IP). Protège les endpoints d'écriture contre le spam de
 * signalements, l'épuisement des quotas et l'ingestion abusive.
 * Instance unique : suffisant pour un déploiement mono-processus.
 */

const buckets = new Map<string, number[]>();

export function clientIp(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) return forwarded.split(",")[0].trim();
  return req.headers.get("x-real-ip") ?? "local";
}

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number,
): { ok: boolean; retryAfterSec: number } {
  const now = Date.now();
  const hits = (buckets.get(key) ?? []).filter((t) => now - t < windowMs);
  if (hits.length >= limit) {
    buckets.set(key, hits);
    return {
      ok: false,
      retryAfterSec: Math.max(1, Math.ceil((hits[0] + windowMs - now) / 1000)),
    };
  }
  hits.push(now);
  buckets.set(key, hits);
  // Purge opportuniste pour borner la mémoire.
  if (buckets.size > 5000) {
    for (const [k, v] of buckets) {
      if (v.every((t) => now - t >= windowMs)) buckets.delete(k);
    }
  }
  return { ok: true, retryAfterSec: 0 };
}

export function tooManyRequests(retryAfterSec: number): NextResponse {
  return NextResponse.json(
    { error: "Trop de requêtes — réessayez dans quelques instants." },
    { status: 429, headers: { "Retry-After": String(retryAfterSec) } },
  );
}
