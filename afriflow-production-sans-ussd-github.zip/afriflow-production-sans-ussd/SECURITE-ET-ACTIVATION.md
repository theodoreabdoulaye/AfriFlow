# AfriFlow : securite et activation

Ce renforcement n'est ni une certification de conformite a toutes les normes ni un audit d'intrusion. Aucun DNS, compte Meta ou pare-feu distant n'a ete modifie.

## Protections integrees

- CSP sur les pages : nonce aleatoire par requete, scripts inline non autorises sans nonce, restrictions Google/reCAPTCHA, interdiction des objets, des bases HTML et de l'integration en iframe.
- Pages dynamiques et non mises en cache pour ne pas reutiliser les nonces. Styles inline conserves pour React et Google ; il ne s'agit pas d'une politique sans aucune exception.
- CSP restrictive sur les API, nosniff, Referrer-Policy, Permissions-Policy, X-Frame-Options DENY.
- HSTS un an, sans includeSubDomains/preload : ne pas imposer HTTPS a des sous-domaines inconnus. Deployer exclusivement en HTTPS.
- COOP same-origin-allow-popups, pour la connexion Google. CORP same-origin. COEP credentialless, sauf /compte (unsafe-none) pour les frames Google et reCAPTCHA. Cette configuration ne garantit pas crossOriginIsolated et doit etre testee avec les vraies cles.
- Contact RFC 9116 a /.well-known/security.txt, via WhatsApp TerangaStudio. Renouveler Expires avant le 1er octobre 2027. Aucun e-mail ou domaine de contact invente.
- Webhook WhatsApp : signature HMAC sur les octets bruts, limite 1 MiB en streaming, validation de structure et des donnees, pas de donnees personnelles dans l'accuse de reception.
- Notifications : navigation restreinte a l'origine du site.
- Next.js et dependances associees mises a jour. Examiner encore npm audit, notamment les dependances transitives Sentry et les outils de developpement.

## WhatsApp

Le lien https://wa.me/221772015751 est utilisable. Il ouvre une conversation avec le numero fourni ; cela ne signifie pas que ce numero est inscrit a la Cloud API ni que le bot est actif.

Pour le bot existant, configurer dans Meta WhatsApp Business :

1. Numero Business enregistre, application Meta et jeton d'acces de production avec les permissions WhatsApp adequates.
2. WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_APP_SECRET et WHATSAPP_VERIFY_TOKEN dans Vercel. Garder tous ces secrets cote serveur.
3. Callback HTTPS https://VOTRE-DOMAINE/api/webhooks/whatsapp et abonnement au champ messages. Le token de verification doit correspondre a WHATSAPP_VERIFY_TOKEN.
4. Verifier une reception signee et une reponse reelle. Respecter l'accord utilisateur, la fenetre de conversation et les templates approuves Meta hors de cette fenetre.

## SPF et DMARC : a publier chez le fournisseur DNS

Le domaine et le fournisseur de messagerie doivent etre confirmes avant publication. Ne pas remplacer un SPF existant ; il ne doit y avoir qu'un seul enregistrement SPF par nom.

Si le domaine **n'envoie aucun e-mail**, le modele est :

```text
Nom : @
Type : TXT
Valeur : v=spf1 -all

Nom : _dmarc
Type : TXT
Valeur : v=DMARC1; p=reject; sp=reject; adkim=s; aspf=s
```

Si le domaine envoie des e-mails : obtenir les include/IP exacts du prestataire, configurer DKIM, verifier l'alignement, commencer DMARC avec p=none et une adresse de rapports reellement exploitee, puis passer a quarantine/reject apres analyse. Publier -all sans inventorier les expediteurs peut bloquer les messages legitimes.

## DNSSEC : a activer dans le DNS et chez le registrar

1. Activer la signature DNSSEC chez l'operateur de la zone.
2. L'operateur genere et publie les DNSKEY et signatures RRSIG, avec leur rotation. Ne pas fabriquer de cles statiques dans le code du site.
3. Recuperer le DS fourni, verifier nom, algorithme, key tag et digest, puis le publier chez le registrar pour la delegation dans la zone parente.
4. Verifier la chaine avec un resolveur validant. Un mauvais DS rend le domaine inaccessible aux resolveurs DNSSEC. Lors d'une migration, suivre l'ordre de retrait/rotation du fournisseur.

TC (Truncated) indique une reponse DNS tronquee, demandant generalement un repli TCP. AD (Authenticated Data) indique une validation effectuee par un resolveur de confiance. CD signifie **Checking Disabled**, demande de desactivation de la validation, et non verification des personnes handicapees. Ce sont des bits de messages DNS, pas des enregistrements ni des options HTTP a activer. Ne pas forcer AD et ne pas desactiver la validation avec CD.

## Pare-feu et exploitation

Activer Vercel Firewall / regles gerees WAF selon le plan, ou Cloudflare WAF avec le domaine proxifie et TLS Full (strict). Ce code n'est pas un WAF.

- Appliquer limites distribuees aux routes login, register, google, report et ingestion ; le limiteur actuel en memoire n'est pas partage entre instances.
- Ne pas imposer un challenge navigateur aux webhooks Meta/Chariow : verifier leur signature. Ne pas contourner l'authentification des endpoints sous pretexte d'exemption WAF.
- Tester les seuils avec le trafic legitime, limiter les corps de requete a l'edge, surveiller refus/abus et centraliser les journaux sans secrets ni donnees personnelles.
- Proteger l'acces a l'origine pour eviter un contournement du proxy Cloudflare ; TLS seul ne suffit pas.
- MFA pour Vercel, Meta, DNS et registrar ; roles minimaux, rotation des secrets, PostgreSQL prive/TLS, sauvegardes avec restauration testee, procedure d'incident et mises a jour regulieres.
- Les endpoints metier et l'anti-rejeu des webhooks necessitent une revue complete et une strategie de deduplication persistante avant de promettre une couverture de securite exhaustive.

## Verification apres deploiement

```sh
npm ci
npm run typecheck
npm test
npm run build
npm audit --omit=dev
curl -I https://VOTRE-DOMAINE/compte
curl https://VOTRE-DOMAINE/.well-known/security.txt
dig TXT VOTRE-DOMAINE
dig TXT _dmarc.VOTRE-DOMAINE
dig +dnssec DNSKEY VOTRE-DOMAINE
dig +dnssec DS VOTRE-DOMAINE
dig +dnssec A VOTRE-DOMAINE
```

Tester aussi desktop/mobile, la console CSP, Google, reCAPTCHA, paiement, notifications et WhatsApp. Les commandes DNS et HTTP ci-dessus sont des instructions, pas la preuve d'une activation distante. Pour terminer l'activation, fournir le domaine public exact, le prestataire de messagerie et les acces via les interfaces securisees des prestataires, jamais des secrets dans le chat.
