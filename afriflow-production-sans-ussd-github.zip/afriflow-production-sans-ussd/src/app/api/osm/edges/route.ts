import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { isPostgisAvailable, loadRoadEdges, postgisStatus, syncRoadEdgesNow } from "@/lib/road-edges";

export const dynamic = "force-dynamic";

/**
 * GET /api/osm/edges?city=dakar — la couche spatiale road_edges persistée :
 * arêtes enrichies (géométrie GeoJSON, capacité, risque d'inondation,
 * nids-de-poule, zone protégée) telles que chargées en mémoire par le
 * moteur. POST /api/osm/edges { city } force une resynchronisation.
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const edges = await loadRoadEdges(city);
  return NextResponse.json({
    city: city.id,
    cityName: city.name,
    spatialEngine: isPostgisAvailable()
      ? "PostGIS (GEOMETRY LineString 4326 + index GiST, KNN <->)"
      : "Index spatial par grille applicatif (PostGIS indisponible dans cet environnement)",
    postgis: postgisStatus(),
    count: edges.length,
    edges,
  }, { headers: { "Cache-Control": "private, no-store" } });
}

export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`osmsync:${clientIp(req)}`, 10, 600_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }
  let raw: unknown = null;
  try {
    raw = await req.json();
  } catch {
    /* corps optionnel */
  }
  const body = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const total = await syncRoadEdgesNow(city);
  const edges = await loadRoadEdges(city);
  return NextResponse.json({
    city: city.id,
    synced: edges.length,
    totalRowsAllCities: total,
    postgis: postgisStatus(),
  }, { headers: { "Cache-Control": "private, no-store" } });
}
