import * as Sentry from "@sentry/nextjs";

/**
 * Surveillance d'erreurs Sentry (serveur) : activée uniquement si
 * SENTRY_DSN est définie — sinon le SDK reste inerte et l'application
 * fonctionne normalement. Alertes immédiates si le flux SSE tombe ou
 * si une API externe échoue de façon répétée.
 */
export async function register(): Promise<void> {
  const dsn = process.env.SENTRY_DSN;
  if (!dsn) return;
  if (process.env.NEXT_RUNTIME === "nodejs") {
    Sentry.init({ dsn, tracesSampleRate: 0.1 });
  }
  if (process.env.NEXT_RUNTIME === "edge") {
    Sentry.init({ dsn, tracesSampleRate: 0.1 });
  }
}

export const onRequestError = Sentry.captureRequestError;
