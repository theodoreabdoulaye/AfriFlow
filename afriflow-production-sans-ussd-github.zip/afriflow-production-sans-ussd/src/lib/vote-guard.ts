/**
 * Garde anti-Sybil du consensus communautaire : au-delà de l'appareil
 * anonyme, une même connexion (IP) ne peut voter qu'une fois par incident
 * (création ou confirmation). Un attaquant qui ferait tourner des
 * identifiants d'appareil depuis une seule machine ne peut donc pas, à
 * lui seul, faire diffuser un faux incident. Fenêtre : 50 minutes,
 * alignée sur la fenêtre de fusion des signalements.
 */

const votes = new Map<string, number>();
const TTL_MS = 50 * 60_000;

function key(ip: string, incidentId: number): string {
  return `${ip}|${incidentId}`;
}

export function hasVoted(ip: string, incidentId: number): boolean {
  const t = votes.get(key(ip, incidentId));
  return t !== undefined && Date.now() - t < TTL_MS;
}

export function markVoted(ip: string, incidentId: number): void {
  votes.set(key(ip, incidentId), Date.now());
  if (votes.size > 10_000) {
    const now = Date.now();
    for (const [k, t] of votes) {
      if (now - t >= TTL_MS) votes.delete(k);
    }
  }
}
