import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { parkingLots } from "@/db/schema";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/**
 * POST /api/parking/occupancy { lotId, occupancy } — mise à jour de
 * l'occupation réelle d'un parking (capteur, barrière, opérateur).
 * Elle prime sur le modèle pendant 2 heures.
 */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`parkingocc:${clientIp(req)}`, 120, 60_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  const body = raw as Record<string, unknown>;
  const lotId = Number(body.lotId);
  const occupancy = Number(body.occupancy);
  if (!Number.isFinite(lotId) || !Number.isFinite(occupancy) || occupancy < 0) {
    return NextResponse.json({ error: "lotId et occupancy (≥ 0) requis" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }
  try {
    const [lot] = await db
      .update(parkingLots)
      .set({ currentOccupancy: Math.round(occupancy), occupancyUpdatedAt: new Date() })
      .where(eq(parkingLots.id, lotId))
      .returning();
    if (!lot) return NextResponse.json({ error: "Parking introuvable" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
    return NextResponse.json({
      lot: {
        id: lot.id,
        name: lot.name,
        currentOccupancy: lot.currentOccupancy,
        totalSpots: lot.totalSpots,
        availableSpots: Math.max(0, lot.totalSpots - (lot.currentOccupancy ?? 0)),
        source: "réelle (capteur/opérateur)",
      },
    }, { headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return NextResponse.json({ error: "Mise à jour indisponible" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
  }
}
