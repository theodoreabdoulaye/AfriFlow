import { NextRequest, NextResponse } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { incidentConfirmations, incidents } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { alreadyCounted } from "@/lib/consensus";
import { emitValidatedAlert } from "@/lib/alert-hub";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { hasVoted, markVoted } from "@/lib/vote-guard";

export const dynamic = "force-dynamic";

/**
 * POST /api/incidents/:id/confirm — un conducteur distinct corrobore
 * l'incident. À 3 confirmations (conducteurs distincts, identifiés par
 * appareil anonyme ou à défaut par réseau) : diffusion (push, SMS gratuit,
 * radio partenaire, repondération des itinéraires).
 * L'incrément est atomique : aucune confirmation ne se perd en concurrence.
 */
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const ip = clientIp(req);
  const rl = rateLimit(`confirm:${ip}`, 180, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  const { id } = await params;
  const incidentId = Number(id);
  if (!Number.isFinite(incidentId)) {
    return NextResponse.json({ error: "Identifiant invalide" }, { status: 422 });
  }

  let network = "web";
  let channel = "web";
  let deviceHash: string | null = null;
  try {
    const body = (await req.json()) as Record<string, unknown>;
    if (typeof body?.network === "string") network = body.network.slice(0, 16);
    if (typeof body?.channel === "string") channel = body.channel.slice(0, 16);
    if (typeof body?.deviceHash === "string") deviceHash = body.deviceHash.slice(0, 64);
  } catch {
    /* confirmation anonyme web */
  }

  try {
    const rows = await db.select().from(incidents).where(eq(incidents.id, incidentId)).limit(1);
    if (rows.length === 0) return NextResponse.json({ error: "Incident introuvable" }, { status: 404 });
    const target = rows[0];

    // Anti-Sybil : une seule voix par connexion et par incident.
    if (hasVoted(ip, incidentId)) {
      return NextResponse.json({ alreadyConfirmed: true, incident: target });
    }

    const existing = await db
      .select()
      .from(incidentConfirmations)
      .where(eq(incidentConfirmations.incidentId, incidentId));
    if (alreadyCounted(existing, network, deviceHash)) {
      return NextResponse.json({ alreadyConfirmed: true, incident: target });
    }

    await db.insert(incidentConfirmations).values({ incidentId, network, channel, deviceHash });
    markVoted(ip, incidentId);
    const [updated] = await db
      .update(incidents)
      .set({
        confirmations: sql`${incidents.confirmations} + 1`,
        confidence: sql`CASE WHEN ${incidents.confirmations} + 1 >= 3 THEN 98 WHEN ${incidents.confirmations} + 1 = 2 THEN 71 ELSE 38 END`,
        status: sql`CASE WHEN ${incidents.confirmations} + 1 >= 3 THEN 'broadcast' WHEN ${incidents.confirmations} + 1 = 2 THEN 'confirmed' ELSE 'pending' END`,
        updatedAt: new Date(),
      })
      .where(eq(incidents.id, incidentId))
      .returning();
    if (updated.status === "broadcast" && target.status !== "broadcast") {
      const cityDef = CITY_MAP[updated.city];
      if (cityDef) emitValidatedAlert(cityDef, updated);
    }
    return NextResponse.json({ incident: updated, broadcast: updated.status === "broadcast" });
  } catch {
    return NextResponse.json({ error: "Confirmation indisponible" }, { status: 503 });
  }
}
