import { createHash } from "node:crypto";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { incidentConfirmations, incidents } from "@/db/schema";
import type { CityDef } from "./cities";
import { emitValidatedAlert } from "./alert-hub";
import { nearestAxisFast } from "./spatial";

/**
 * Ingestion de signalements crowdsourcés multi-sources — contrat de
 * l'endpoint historique POST /api/v1/report (porté du prototype Rust) :
 *
 *   { source: "ussd" | "whatsapp" | "waze_webhook" | "scraper_facebook",
 *     lat, lon, incident_type: "accident" | "police" | "inondation" |
 *     "nid_de_poule" | …, confidence_score: 1..10 }
 *
 * 1) Map matching sur l'axe le plus proche (index spatial grille).
 * 2) Consensus PONDÉRÉ : validation à 3 signalements distincts en 10 min
 *    OU score cumulé ≥ 20 (un flux partenaire fiable type Waze, score 8-10,
 *    fait donc valider plus vite qu'un canal anonyme).
 * 3) L'incident validé ralentit l'axe dans le moteur (consensus → diffusion).
 */

export const CROWD_SOURCES = ["ussd", "whatsapp", "waze_webhook", "scraper_facebook"] as const;
export type CrowdSource = (typeof CROWD_SOURCES)[number];

const TYPE_MAP: Record<string, { type: string; label: string }> = {
  accident: { type: "accident", label: "Accident" },
  police: { type: "police", label: "Police / contrôle" },
  inondation: { type: "inondation", label: "Inondation" },
  nid_de_poule: { type: "danger", label: "Nid-de-poule" },
  nid_de_poule_osm: { type: "danger", label: "Nid-de-poule" },
  bouchon: { type: "bouchon", label: "Bouchon" },
  travaux: { type: "travaux", label: "Travaux" },
  panne: { type: "panne", label: "Panne / obstacle" },
  danger: { type: "danger", label: "Danger" },
};

const CHANNEL_BY_SOURCE: Record<CrowdSource, string> = {
  ussd: "ussd",
  whatsapp: "whatsapp",
  waze_webhook: "waze",
  scraper_facebook: "web",
};

export interface CrowdReportInput {
  source: CrowdSource;
  lat: number;
  lon: number;
  incidentType: string;
  confidenceScore: number; // 1..10
  reporterKey?: string | null; // téléphone / uuid émetteur (haché, jamais stocké en clair)
  /** Numéro WhatsApp du rapporteur (canal WhatsApp) pour la confirmation. */
  reporterContact?: string | null;
  severity?: number;
  description?: string | null;
}

export interface CrowdIngestResult {
  incident: typeof incidents.$inferSelect;
  axisId: string;
  axisName: string;
  merged: boolean;
  validated: boolean;
  scoreTotal: number;
}

export async function ingestCrowdReport(
  city: CityDef,
  input: CrowdReportInput,
): Promise<CrowdIngestResult | null> {
  const found = nearestAxisFast(city, input.lat, input.lon, 2500);
  if (!found) return null;
  const axis = found.axis;

  const mapped = TYPE_MAP[input.incidentType] ?? { type: "danger", label: "Danger" };
  const score = Math.max(1, Math.min(10, Math.round(input.confidenceScore) || 1));
  const channel = CHANNEL_BY_SOURCE[input.source];
  const reporterHash = input.reporterKey
    ? `${input.source}-${createHash("sha1").update(input.reporterKey).digest("hex").slice(0, 14)}`
    : `${input.source}-anonyme`;

  // Fenêtre de consensus resserrée pour les flux crowdsourcés : 10 minutes.
  const windowStart = new Date(Date.now() - 10 * 60_000);
  const similar = await db
    .select()
    .from(incidents)
    .where(
      and(
        eq(incidents.city, city.id),
        eq(incidents.axisId, axis.id),
        eq(incidents.type, mapped.type),
        gte(incidents.createdAt, windowStart),
      ),
    )
    .orderBy(desc(incidents.createdAt))
    .limit(1);

  const recomputeStatus = async (incidentId: number) => {
    const rows = await db
      .select({ score: incidentConfirmations.score })
      .from(incidentConfirmations)
      .where(eq(incidentConfirmations.incidentId, incidentId));
    const count = rows.length;
    const total = rows.reduce((a, r) => a + r.score, 0);
    const status = count >= 3 || total >= 20 ? "broadcast" : count >= 2 || total >= 12 ? "confirmed" : "pending";
    const confidence = status === "broadcast" ? 98 : status === "confirmed" ? 71 : Math.min(68, 30 + total * 4);
    const [updated] = await db
      .update(incidents)
      .set({ confirmations: count, confidence, status, updatedAt: new Date() })
      .where(eq(incidents.id, incidentId))
      .returning();
    return { incident: updated, scoreTotal: total, validated: status === "broadcast" };
  };

  if (similar.length > 0) {
    const target = similar[0];
    const prior = await db
      .select()
      .from(incidentConfirmations)
      .where(eq(incidentConfirmations.incidentId, target.id));
    // Un même émetteur ne compte qu'une fois par incident.
    if (prior.some((c) => c.deviceHash === reporterHash)) {
      const total = prior.reduce((a, r) => a + r.score, 0);
      return {
        incident: target,
        axisId: axis.id,
        axisName: axis.name,
        merged: true,
        validated: target.status === "broadcast",
        scoreTotal: total,
      };
    }
    await db.insert(incidentConfirmations).values({
      incidentId: target.id,
      network: input.source,
      channel,
      deviceHash: reporterHash,
      reporterContact: input.reporterContact ?? null,
      score,
    });
    const { incident, scoreTotal, validated } = await recomputeStatus(target.id);
    // Transition vers la diffusion : hub temps réel + confirmations WhatsApp.
    if (incident.status === "broadcast" && target.status !== "broadcast") {
      emitValidatedAlert(city, incident);
    }
    return { incident, axisId: axis.id, axisName: axis.name, merged: true, validated, scoreTotal };
  }

  const [created] = await db
    .insert(incidents)
    .values({
      city: city.id,
      axisId: axis.id,
      type: mapped.type,
      severity: input.severity ?? (score >= 8 ? 4 : 3),
      channel,
      network: input.source,
      description:
        input.description ??
        `${mapped.label} signalé via ${input.source} (score de confiance ${score}/10) — ${axis.name}.`,
      confirmations: 1,
      confidence: Math.min(68, 30 + score * 4),
      status: "pending",
    })
    .returning();
  await db.insert(incidentConfirmations).values({
    incidentId: created.id,
    network: input.source,
    channel,
    deviceHash: reporterHash,
    reporterContact: input.reporterContact ?? null,
    score,
  });
  const { incident, scoreTotal, validated } = await recomputeStatus(created.id);
  return { incident, axisId: axis.id, axisName: axis.name, merged: false, validated, scoreTotal };
}
