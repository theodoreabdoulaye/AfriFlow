import { NextRequest, NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { processWhatsAppMessage, type WaMessage } from "@/lib/whatsapp";

export const dynamic = "force-dynamic";

/**
 * Webhook WhatsApp Business (Meta Graph API) — porté du design Rust.
 *
 * GET  /api/webhooks/whatsapp : vérification Meta (hub.mode=subscribe +
 *      hub.verify_token == WHATSAPP_VERIFY_TOKEN → hub.challenge).
 * POST /api/webhooks/whatsapp : réception des messages (texte, vocal,
 *      localisation partagée). Traitement par le pipeline
 *      (transcription Whisper si clés, extraction NLP FR/Wolof/Pulaar,
 *      géocodage Nominatim, map matching, consensus) puis réponse 200
 *      immédiate pour éviter les réessais Meta.
 */
export async function GET(req: NextRequest) {
  const params = req.nextUrl.searchParams;
  const mode = params.get("hub.mode");
  const token = params.get("hub.verify_token");
  const challenge = params.get("hub.challenge");
  const expected = process.env.WHATSAPP_VERIFY_TOKEN;

  if (!expected) {
    return NextResponse.json(
      { error: "WHATSAPP_VERIFY_TOKEN non configuré côté serveur" },
      { status: 503 },
    );
  }
  if (mode === "subscribe" && token === expected && challenge) {
    return new NextResponse(challenge, {
      status: 200,
      headers: { "Content-Type": "text/plain" },
    });
  }
  return NextResponse.json({ error: "Vérification échouée" }, { status: 403 });
}

interface MetaWebhookPayload {
  object?: string;
  entry?: {
    changes?: {
      value?: {
        messages?: WaMessage[];
      };
    }[];
  }[];
}

const MAX_BODY_BYTES = 1024 * 1024;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function isPayload(value: unknown): value is MetaWebhookPayload {
  if (!isRecord(value) || value.object !== "whatsapp_business_account" || !Array.isArray(value.entry)) return false;
  return value.entry.every((entry: unknown) => {
    if (!isRecord(entry) || !Array.isArray(entry.changes)) return false;
    return entry.changes.every((change: unknown) => {
      if (!isRecord(change) || !isRecord(change.value)) return false;
      const messages = change.value.messages;
      // Delivery/status notifications do not contain messages.
      if (messages === undefined) return true;
      if (!Array.isArray(messages)) return false;
      return messages.every((msg: unknown) => {
        if (!isRecord(msg) || typeof msg.from !== "string" || !/^\d{1,15}$/.test(msg.from) ||
            typeof msg.type !== "string" || !/^[a-z_]{1,64}$/.test(msg.type)) return false;
        if (msg.type === "text") {
          return isRecord(msg.text) && typeof msg.text.body === "string" &&
            msg.text.body.trim().length > 0 && msg.text.body.length <= 4096;
        }
        if (msg.type === "location") {
          return isRecord(msg.location) && typeof msg.location.latitude === "number" &&
            Number.isFinite(msg.location.latitude) && Math.abs(msg.location.latitude) <= 90 &&
            typeof msg.location.longitude === "number" && Number.isFinite(msg.location.longitude) &&
            Math.abs(msg.location.longitude) <= 180;
        }
        if (msg.type === "audio" || msg.type === "image") {
          const media = msg[msg.type];
          return isRecord(media) && typeof media.id === "string" && /^\d{1,64}$/.test(media.id) &&
            (msg.type !== "image" || media.caption === undefined ||
              (typeof media.caption === "string" && media.caption.length <= 4096));
        }
        return true;
      });
    });
  });
}

export async function POST(req: NextRequest) {
  const rl = rateLimit(`wahoo:${clientIp(req)}`, 600, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  const secret = process.env.WHATSAPP_APP_SECRET;
  if (!secret) return NextResponse.json({ error: "Webhook non configure" }, { status: 503 });
  const signature = req.headers.get("x-hub-signature-256") ?? "";
  if (!/^sha256=[a-fA-F0-9]{64}$/.test(signature)) {
    return NextResponse.json({ error: "Signature invalide" }, { status: 403 });
  }
  const reader = req.body?.getReader();
  if (!reader) return NextResponse.json({ error: "Payload invalide" }, { status: 400 });
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > MAX_BODY_BYTES) {
        await reader.cancel().catch(() => {});
        return NextResponse.json({ error: "Payload trop volumineux" }, { status: 413 });
      }
      chunks.push(value);
    }
  } catch {
    return NextResponse.json({ error: "Payload illisible" }, { status: 400 });
  } finally {
    reader.releaseLock();
  }
  const raw = Buffer.concat(chunks, size);
  const expected = createHmac("sha256", secret).update(raw).digest();
  if (!timingSafeEqual(Buffer.from(signature.slice(7), "hex"), expected)) {
    return NextResponse.json({ error: "Signature invalide" }, { status: 403 });
  }
  let payload: unknown;
  try {
    payload = JSON.parse(new TextDecoder("utf-8", { fatal: true }).decode(raw));
  } catch {
    return NextResponse.json({ error: "Payload invalide" }, { status: 400 });
  }
  if (!isPayload(payload)) return NextResponse.json({ error: "Payload invalide" }, { status: 400 });

  for (const entry of payload.entry ?? []) {
    for (const change of entry.changes ?? []) {
      for (const msg of change.value?.messages ?? []) {
        try {
          await processWhatsAppMessage(msg);
        } catch {
          // Keep the acknowledgement independent of personal data and pipeline errors.
        }
      }
    }
  }

  // Réponse immédiate à Meta (le traitement métier est déjà terminé ou journalisé).
  return NextResponse.json({ received: true });
}
