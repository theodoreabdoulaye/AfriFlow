import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { parkingLots } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { haversineKm } from "@/lib/engine";
import { parkingAvailability } from "@/lib/multimodal";
import { ensureCitySeed } from "@/lib/seed";
import { transitStopsFor } from "@/lib/transit";

export const dynamic = "force-dynamic";

/**
 * GET /api/parking?city=dakar&lat=..&lon=..&maxDistanceM=3000 — parkings
 * disponibles près d'un point : places libres, disponibilité actuelle
 * et prédite dans 30 min, prix, distance et arrêt de transport proche.
 * L'occupation est réelle si un capteur/opérateur l'a mise à jour
 * (< 2 h), sinon modélisée par profil horaire (affiché comme tel).
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  await ensureCitySeed(city);

  const lat = Number(req.nextUrl.searchParams.get("lat") ?? city.lat);
  const lon = Number(req.nextUrl.searchParams.get("lon") ?? city.lon);
  const maxDistanceM = Math.max(300, Math.min(20000, Number(req.nextUrl.searchParams.get("maxDistanceM") ?? 6000) || 6000));
  const atLocal = new Date(Date.now() + (city.tzOffsetMin ?? 0) * 60_000);
  const stops = transitStopsFor(city);

  try {
    const rows = await db.select().from(parkingLots).where(eq(parkingLots.city, city.id));
    const lots = rows
      .map((lot) => {
        const distanceKm = haversineKm([lat, lon], [lot.lat, lot.lon]);
        const avail = parkingAvailability(
          {
            id: lot.id,
            totalSpots: lot.totalSpots,
            currentOccupancy: lot.currentOccupancy,
            occupancyUpdatedAt: lot.occupancyUpdatedAt,
            parkingType: lot.parkingType,
          },
          atLocal,
        );
        const nearStop = lot.nearestTransitStop
          ? stops.find((s) => s.id === lot.nearestTransitStop)
          : null;
        return {
          id: lot.id,
          name: lot.name,
          lat: lot.lat,
          lon: lot.lon,
          distanceM: Math.round(distanceKm * 1000),
          totalSpots: lot.totalSpots,
          availableSpots: avail.availableSpots,
          availabilityPct: avail.availabilityPct,
          predictedAvailabilityPct: avail.predictedAvailabilityPct,
          occupancySource: avail.source,
          pricePerHourFcfa: lot.pricePerHourFcfa,
          parkingType: lot.parkingType,
          nearestTransitStop: nearStop
            ? {
                name: nearStop.name,
                mode: nearStop.mode,
                walkingDistanceM: Math.round(
                  haversineKm([lot.lat, lot.lon], [nearStop.lat, nearStop.lon]) * 1000,
                ),
              }
            : null,
        };
      })
      .filter((l) => l.distanceM <= maxDistanceM)
      .sort((a, b) => a.distanceM - b.distanceM)
      .slice(0, 10);
    return NextResponse.json({ city: city.id, count: lots.length, lots }, { headers: { "Cache-Control": "private, no-store" } });
  } catch {
    return NextResponse.json({ city: city.id, count: 0, lots: [] }, { headers: { "Cache-Control": "private, no-store" } });
  }
}
