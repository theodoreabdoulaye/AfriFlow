import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { CITY_MAP, getAxis, getZone } from "@/lib/cities";
import { requirePaidAccess } from "@/lib/access";
import { buildHeatmap } from "@/lib/server-data";

export const dynamic = "force-dynamic";

/**
 * GET /api/waze/feed?city=dakar — flux d'incidents au format « Waze
 * Traffic View » (programme Waze for Cities / Connected Citizens) :
 * - alerts : incidents validés par le consensus communautaire ;
 * - jams   : axes congestionnés ou saturés (niveau, vitesse, ligne GPS).
 * C'est le flux à déclarer dans le dossier d'adhésion Waze for Cities
 * pour que Waze ingère les alertes AfriFlow — et le format miroir de ce
 * que le webhook /api/waze/webhook sait recevoir.
 */

const TYPE_TO_WAZE: Record<string, { type: string; subtype: string }> = {
  accident: { type: "ACCIDENT", subtype: "ACCIDENT_MAJOR" },
  bouchon: { type: "JAM", subtype: "JAM_HEAVY_TRAFFIC" },
  travaux: { type: "CONSTRUCTION", subtype: "CONSTRUCTION" },
  police: { type: "POLICE", subtype: "POLICE_VISIBLE" },
  inondation: { type: "WEATHERHAZARD", subtype: "HAZARD_WEATHER_FLOOD" },
  panne: { type: "HAZARD", subtype: "HAZARD_ON_ROAD" },
  danger: { type: "HAZARD", subtype: "HAZARD_ON_ROAD_POT_HOLE" },
};

export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  const since = new Date(Date.now() - 3 * 3600_000);
  let rows: (typeof incidents.$inferSelect)[] = [];
  try {
    rows = await db
      .select()
      .from(incidents)
      .where(and(eq(incidents.city, city.id), eq(incidents.status, "broadcast"), gte(incidents.createdAt, since)))
      .orderBy(desc(incidents.createdAt))
      .limit(100);
  } catch {
    rows = [];
  }

  const alerts = rows.map((i) => {
    const axis = getAxis(city, i.axisId);
    const mid = axis?.gps[Math.floor(axis.gps.length / 2)] ?? [city.lat, city.lon];
    const waze = TYPE_TO_WAZE[i.type] ?? TYPE_TO_WAZE.danger;
    return {
      uuid: `afriflow-${city.id}-${i.id}`,
      type: waze.type,
      subtype: waze.subtype,
      location: { x: mid[1], y: mid[0] },
      street: axis?.name ?? i.axisId,
      city: city.name,
      country: city.countryCode,
      reportRating: i.confirmations,
      confidence: Math.round(i.confidence / 10),
      reliability: Math.max(1, Math.round(i.confidence / 12)),
      pubDate: new Date(i.createdAt).getTime(),
      roadType: 3,
      description: i.description,
      source: `AfriFlow consensus x${i.confirmations} (canal ${i.channel})`,
    };
  });

  const heat = await buildHeatmap(city);
  const jams = heat.axes
    .filter((a) => a.level === "congestion" || a.level === "sature" || a.level === "dense")
    .map((a, idx) => {
      const axisDef = city.axes.find((x) => x.id === a.axisId)!;
      const freeMinutes = (axisDef.lengthKm / Math.max(5, axisDef.freeFlowKmh)) * 60;
      const currentMinutes = (axisDef.lengthKm / Math.max(4, a.speedKmh)) * 60;
      return {
        id: 1000 + idx,
        level: a.level === "sature" ? 5 : a.level === "congestion" ? 4 : 3,
        speedKMH: Math.round(a.speedKmh),
        length: Math.round(axisDef.lengthKm * 1000),
        delay: Math.max(0, Math.round((currentMinutes - freeMinutes) * 60)),
        street: a.name,
        city: city.name,
        line: axisDef.gps.map(([lat, lon]) => ({ x: lon, y: lat })),
        startNode: getZone(city, a.from)?.name ?? a.from,
        endNode: getZone(city, a.to)?.name ?? a.to,
        pubDate: Date.now(),
      };
    });

  return NextResponse.json(
    {
      alerts,
      jams,
      startTime: new Date(Date.now() - 15 * 60_000).toISOString(),
      endTime: new Date().toISOString(),
      format: "Waze Traffic View (Waze for Cities / Connected Citizens Program)",
      generator: "AfriFlow — consensus communautaire x3 + moteur temps réel",
    },
    { headers: { "Cache-Control": "private, no-store" } },
  );
}
