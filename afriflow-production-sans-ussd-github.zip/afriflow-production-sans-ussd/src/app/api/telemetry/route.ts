import { after, NextRequest, NextResponse } from "next/server";
import { eq, lt } from "drizzle-orm";
import { db } from "@/db";
import { subscriptions, telemetryPoints } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { ingestGpsPoint } from "@/lib/ingest";
import { maybeRetrain } from "@/lib/learning";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { fetchWeather } from "@/lib/weather";

export const dynamic = "force-dynamic";

/**
 * POST /api/telemetry — ingestion de points GPS (app conducteurs + flottes
 * partenaires). Corps : { city, lat, lon, speedKmh, heading?, source?, apiKey? }
 * Le point est rattaché à l'axe le plus proche (< 400 m) et alimente le
 * lissage exponentiel de vitesse (α = 0,3) utilisé par la carte thermique.
 * Les partenaires doivent présenter une clé API valide (offre API Traffic).
 */
export async function POST(req: NextRequest) {
  // Seuil large : des milliers d'appareils partagent les IP des NAT opérateurs.
  const rl = rateLimit(`telemetry:${clientIp(req)}`, 1200, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;

  const cityId = String(body.city ?? "dakar");
  const city = CITY_MAP[cityId];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  const lat = Number(body.lat);
  const lon = Number(body.lon);
  const speedKmh = Number(body.speedKmh);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || !Number.isFinite(speedKmh)) {
    return NextResponse.json({ error: "lat, lon et speedKmh sont requis" }, { status: 422 });
  }
  if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return NextResponse.json({ error: "Coordonnées hors limites (lat ±90, lon ±180)" }, { status: 422 });
  }
  if (speedKmh < 0 || speedKmh > 180) {
    return NextResponse.json({ error: "speedKmh hors limites" }, { status: 422 });
  }
  const heading =
    typeof body.heading === "number" && body.heading >= 0 && body.heading <= 360 ? body.heading : null;

  const source = typeof body.source === "string" ? body.source.slice(0, 24) : "app";
  if (source === "partner") {
    const apiKey = typeof body.apiKey === "string" ? body.apiKey : null;
    if (!apiKey) {
      return NextResponse.json(
        { error: "Clé API requise pour l'ingestion partenaire (offre API Traffic)." },
        { status: 401 },
      );
    }
    try {
      const keyRows = await db
        .select({ id: subscriptions.id })
        .from(subscriptions)
        .where(eq(subscriptions.apiKey, apiKey))
        .limit(1);
      if (keyRows.length === 0) {
        return NextResponse.json({ error: "Clé API partenaire invalide ou expirée." }, { status: 403 });
      }
    } catch {
      return NextResponse.json({ error: "Vérification de la clé API indisponible" }, { status: 503 });
    }
  }

  try {
    // Pipeline partagé avec le simulateur : map matching (index spatial)
    // + lissage exponentiel α = 0,3 en upsert atomique. La pluie horaire
    // (cache Open-Meteo) est jointe au point pour l'entraînement ML.
    const weather = await fetchWeather(city);
    var ingested = await ingestGpsPoint(city, {
      lat,
      lon,
      speedKmh,
      heading,
      source,
      deviceHash: typeof body.deviceHash === "string" ? body.deviceHash.slice(0, 64) : null,
      rainMm: weather.precipMm ?? null,
    });

    // Réentraînement automatique des profils IA (arrière-plan, ≤ 1×/6 h).
    after(async () => { await maybeRetrain(city); });

    // Rétention : purge opportuniste des pings de plus de 7 jours.
    if (Math.random() < 0.05) {
      const cutoff = new Date(Date.now() - 7 * 24 * 3600_000);
      after(async () => { await db.delete(telemetryPoints).where(lt(telemetryPoints.createdAt, cutoff)); });
    }
  } catch {
    return NextResponse.json({ error: "Ingestion indisponible" }, { status: 503 });
  }

  return NextResponse.json({
    accepted: true,
    axisId: ingested.axis?.id ?? null,
    axisName: ingested.axis?.name ?? null,
    distanceM: ingested.distanceM,
    smoothing: "exponentiel α=0,3",
  });
}
