"use client";

import Image from "next/image";
import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  ArrowLeft,
  CheckCircle2,
  ChevronDown,
  Compass,
  Download,
  Fuel,
  Loader2,
  OctagonAlert,
  PlusCircle,
  Route as RouteIcon,
  Search,
  ShieldAlert,
  Timer,
  Truck,
} from "lucide-react";
import { CITIES, CITY_MAP, COUNTRIES, getAxis } from "@/lib/cities";
import type { FleetPayload, FleetVehicleRow, HeatmapPayload } from "@/lib/api-types";

const STATUS_STYLES: Record<string, string> = {
  "En mouvement": "bg-brand-500/15 text-mint-300",
  Ralentissement: "bg-amber-warn/15 text-amber-warn",
  Bloqué: "bg-coral/15 text-coral",
  Livré: "bg-night-600 text-sage",
};

function fluidColor(f: number): string {
  return f >= 70 ? "#22b573" : f >= 48 ? "#a3e635" : f >= 30 ? "#ffb020" : "#ff5d47";
}

interface ReroutedOrder {
  vehicleId: number;
  plate: string;
  fromAxis: string;
  toAxis: string;
  toAxisName: string;
  channel: string;
}

export default function ConvoyPage() {
  const [cityId, setCityIdState] = useState("dakar");
  const city = CITY_MAP[cityId];

  const [fleet, setFleet] = useState<FleetPayload | null>(null);
  const [heat, setHeat] = useState<HeatmapPayload | null>(null);
  const [rerouting, setRerouting] = useState(false);
  const [reroutingId, setReroutingId] = useState<number | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [orders, setOrders] = useState<ReroutedOrder[]>([]);
  const [statusFilter, setStatusFilter] = useState<string>("tous");
  const [query, setQuery] = useState("");

  const [form, setForm] = useState({
    plate: "",
    driver: "",
    phone: "",
    cargo: "",
    origin: "",
    destination: "",
    axisId: CITY_MAP.dakar.axes[0].id,
    fuelL: 150,
    etaMin: 45,
  });
  const [adding, setAdding] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Ville initiale depuis le lien (?ville=...), comme la page d'accueil.
  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        const ville = new URLSearchParams(window.location.search).get("ville");
        if (ville && CITY_MAP[ville]) {
          setCityIdState(ville);
          setForm((f) => ({ ...f, axisId: CITY_MAP[ville].axes[0].id }));
        }
      } catch {
        /* URL illisible ignorée */
      }
    }, 0);
    return () => clearTimeout(t);
  }, []);

  const setCityId = (id: string) => {
    setCityIdState(id);
    setForm((f) => ({ ...f, axisId: CITY_MAP[id].axes[0].id }));
    setNotice(null);
    setOrders([]);
    try {
      const url = new URL(window.location.href);
      url.searchParams.set("ville", id);
      window.history.replaceState(null, "", url.toString());
    } catch {
      /* historique indisponible */
    }
  };

  const loadFleet = useCallback(async () => {
    try {
      const res = await fetch(`/api/fleet?city=${cityId}`, { cache: "no-store" });
      if (res.ok) setFleet((await res.json()) as FleetPayload);
    } catch {
      /* dernier état conservé */
    }
  }, [cityId]);

  const loadHeat = useCallback(async () => {
    try {
      const res = await fetch(`/api/heatmap?city=${cityId}`, { cache: "no-store" });
      if (res.ok) setHeat((await res.json()) as HeatmapPayload);
    } catch {
      /* axes critiques optionnels */
    }
  }, [cityId]);

  useEffect(() => {
    const t0 = window.setTimeout(() => {
      void loadFleet();
      void loadHeat();
    }, 0);
    const t1 = setInterval(() => void loadFleet(), 20_000);
    const t2 = setInterval(() => void loadHeat(), 30_000);
    return () => {
      clearTimeout(t0);
      clearInterval(t1);
      clearInterval(t2);
    };
  }, [loadFleet, loadHeat]);

  const addVehicle = async () => {
    setAdding(true);
    setFormError(null);
    try {
      const res = await fetch("/api/fleet", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: cityId, ...form }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Ajout impossible");
      setForm((f) => ({ ...f, plate: "", driver: "", phone: "", cargo: "", origin: "", destination: "" }));
      setNotice("Véhicule ajouté à votre flotte — suivi actif.");
      void loadFleet();
    } catch (e) {
      setFormError(e instanceof Error ? e.message : "Ajout impossible");
    } finally {
      setAdding(false);
    }
  };

  const reroute = async (vehicleIds?: number[]) => {
    if (vehicleIds) setReroutingId(vehicleIds[0]);
    else setRerouting(true);
    setNotice(null);
    try {
      const res = await fetch("/api/fleet/reroute", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: cityId, vehicleIds }),
      });
      const json = (await res.json()) as {
        message?: string;
        error?: string;
        rerouted?: ReroutedOrder[];
      };
      if (!res.ok) throw new Error(json.error ?? "Reroutage impossible");
      setNotice(json.message ?? "Reroutage effectué.");
      if (json.rerouted && json.rerouted.length > 0) setOrders(json.rerouted);
      void loadFleet();
    } catch (e) {
      setNotice(e instanceof Error ? e.message : "Reroutage impossible");
    } finally {
      setRerouting(false);
      setReroutingId(null);
    }
  };

  const vehicles = useMemo<FleetVehicleRow[]>(() => fleet?.vehicles ?? [], [fleet]);
  const blockedCount = vehicles.filter((v) => v.status === "Bloqué").length;
  const slowedCount = vehicles.filter((v) => v.status === "Ralentissement").length;
  const movingCount = vehicles.filter((v) => v.status === "En mouvement").length;

  const visibleVehicles = useMemo(() => {
    const q = query.trim().toLowerCase();
    return vehicles.filter(
      (v) =>
        (statusFilter === "tous" || v.status === statusFilter) &&
        (q === "" ||
          v.plate.toLowerCase().includes(q) ||
          v.driver.toLowerCase().includes(q) ||
          v.cargo.toLowerCase().includes(q)),
    );
  }, [vehicles, statusFilter, query]);

  const criticalAxes = useMemo(() => {
    if (!heat) return [];
    return [...heat.axes].sort((a, b) => a.fluidity - b.fluidity).slice(0, 4);
  }, [heat]);

  const exportCsv = () => {
    const header = "immatriculation;chauffeur;telephone;cargaison;depart;destination;axe;vitesse_kmh;eta_min;carburant_l;statut";
    const lines = vehicles.map((v) =>
      [
        v.plate,
        v.driver,
        v.phone,
        v.cargo,
        v.origin,
        v.destination,
        getAxis(city, v.axisId)?.name ?? v.axisId,
        Math.round(v.speedKmh),
        v.etaMin,
        Math.round(v.fuelL),
        v.status,
      ]
        .map((cell) => {
          let s = String(cell).replace(/"/g, '""');
          if (/^\s*[=+\-@]/.test(s)) s = `'${s}`;
          return `"${s}"`;
        })
        .join(";"),
    );
    const blob = new Blob([[header, ...lines].join("\n")], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `afriflow-flotte-${cityId}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const inputCls =
    "w-full rounded-xl border border-night-600 bg-night-800 px-3 py-2 text-[13px] outline-none placeholder:text-sage/50 focus:border-brand-500";

  const kpis = [
    { label: "Camions suivis", value: String(vehicles.length), sub: `à ${city.name}`, color: "text-paper" },
    { label: "En mouvement", value: String(movingCount), sub: "circulation fluide", color: "text-mint-300" },
    { label: "Ralentissements", value: String(slowedCount), sub: "sous surveillance", color: "text-amber-warn" },
    { label: "Bloqués", value: String(blockedCount), sub: "à rerouter en priorité", color: "text-coral" },
    { label: "ETA moyenne", value: `${fleet?.stats.avgEta ?? 0} min`, sub: "toutes livraisons", color: "text-paper" },
    { label: "Carburant embarqué", value: `${(fleet?.stats.fuelEmbarked ?? 0).toLocaleString("fr-FR")} L`, sub: "flotte active", color: "text-paper" },
  ];

  return (
    <div className="min-h-screen">
      {/* Barre supérieure de la page */}
      <header className="sticky top-0 z-30 border-b border-night-600/70 bg-night-950/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center gap-3 px-4 py-3 sm:px-6">
          <Link href="/" className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-500 text-night-950">
              <Compass className="h-5 w-5" strokeWidth={2.4} />
            </span>
            <span className="font-display text-lg font-bold tracking-tight">
              Afri<span className="text-brand-500">Flow</span>
            </span>
          </Link>
          <span className="hidden rounded-full bg-night-800 px-3 py-1.5 text-[11px] font-bold tracking-wide text-mint-300 uppercase sm:block">
            Page flottes &amp; industrie
          </span>
          <div className="ml-auto flex items-center gap-2">
            <Link
              href={`/?ville=${cityId}#convoi`}
              className="flex items-center gap-1.5 rounded-xl border border-night-600 bg-night-800 px-3 py-2 text-[12.5px] font-semibold transition hover:bg-night-700"
            >
              <ArrowLeft className="h-4 w-4" /> Retour à l&apos;accueil
            </Link>
            <label className="relative flex items-center">
              <span className="sr-only">Ville du convoi</span>
              <select
                value={cityId}
                onChange={(e) => setCityId(e.target.value)}
                className="cursor-pointer appearance-none rounded-xl border border-night-600 bg-night-800 py-2 pr-8 pl-3 text-[13px] font-semibold text-paper outline-none transition hover:border-brand-600 focus:border-brand-500"
              >
                {COUNTRIES.map((country) => (
                  <optgroup key={country.code} label={`${country.name} (${country.cityCount})`}>
                    {CITIES.filter((c) => c.countryCode === country.code).map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name}
                      </option>
                    ))}
                  </optgroup>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-2.5 h-4 w-4 text-sage" />
            </label>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 pb-16 sm:px-6">
        {/* Bandeau */}
        <div className="grid items-stretch gap-6 pt-10 lg:grid-cols-[1.15fr_0.85fr]">
          <div data-reveal className="is-visible">
            <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
              <span className="inline-block h-px w-8 bg-brand-500" /> Centre de contrôle — flottes &amp; industrie
            </p>
            <h1 className="font-display text-4xl font-bold tracking-tight sm:text-5xl">
              Mode « Convoi <span className="text-brand-500">Industriel</span> » — {city.name}
            </h1>
            <p className="mt-3 max-w-xl text-[14.5px] leading-relaxed text-sage">
              Tous vos camions suivis en direct à {city.name} ({city.country}). En cas de blocage majeur,{" "}
              <b className="text-paper">reroutez le convoi entier en un clic</b> — réparti sur plusieurs délestages pour
              ne pas créer un nouveau bouchon. Les ordres partent par SMS + WhatsApp aux chauffeurs.
            </p>
            <div className="mt-5 flex flex-wrap gap-2 text-[12px] font-semibold">
              <span className="rounded-full bg-night-800 px-3 py-1.5">🚛 Reroutage collectif en 1 clic</span>
              <span className="rounded-full bg-night-800 px-3 py-1.5">💬 Ordres SMS + WhatsApp</span>
              <span className="rounded-full bg-night-800 px-3 py-1.5">🛡️ Zones protégées respectées (règle des 80 %)</span>
              <span className="rounded-full bg-night-800 px-3 py-1.5">⛽ Suivi carburant par camion</span>
            </div>
          </div>
          <figure className="relative min-h-56 overflow-hidden rounded-3xl border border-night-600">
            <Image
              src="https://images.pexels.com/photos/27732803/pexels-photo-27732803.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Camion et conteneurs dans un port industriel"
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 42vw"
              className="object-cover"
            />
            <figcaption className="absolute inset-x-0 bottom-0 flex flex-wrap gap-x-8 gap-y-2 bg-gradient-to-t from-night-950/95 via-night-950/70 to-transparent px-5 pt-12 pb-4">
              <span>
                <b className="font-display text-xl">{vehicles.length} camions</b>
                <span className="block text-[11px] text-sage">suivis à {city.name}</span>
              </span>
              <span>
                <b className="font-display text-xl text-coral">{blockedCount} bloqué(s)</b>
                <span className="block text-[11px] text-sage">à rerouter en priorité</span>
              </span>
              <span>
                <b className="font-display text-xl">{fleet?.stats.avgEta ?? 0} min</b>
                <span className="block text-[11px] text-sage">ETA moyenne</span>
              </span>
            </figcaption>
          </figure>
        </div>

        {/* Indicateurs */}
        <div className="mt-8 grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-6">
          {kpis.map((kpi) => (
            <div key={kpi.label} className="rounded-3xl border border-night-600 bg-night-900 p-4">
              <p className="text-[10.5px] font-bold tracking-wider text-sage uppercase">{kpi.label}</p>
              <p className={`mt-1.5 font-display text-[26px] leading-none font-bold ${kpi.color}`}>{kpi.value}</p>
              <p className="mt-1 text-[11px] text-sage">{kpi.sub}</p>
            </div>
          ))}
        </div>

        {/* Action + déclaration */}
        <div className="mt-6 grid gap-6 lg:grid-cols-[1.05fr_1fr]">
          <div className="h-fit rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
            <h2 className="flex items-center gap-2 font-display text-base font-bold">
              <PlusCircle className="h-5 w-5 text-brand-500" /> Déclarer un véhicule de votre flotte
            </h2>
            <div className="mt-4 grid grid-cols-2 gap-2.5">
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Immatriculation</span>
                <input value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value })} placeholder="DK-1234-AB" className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Chauffeur</span>
                <input value={form.driver} onChange={(e) => setForm({ ...form, driver: e.target.value })} placeholder="Nom du chauffeur" className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Téléphone (SMS)</span>
                <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="+221 77 000 00 00" className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Cargaison</span>
                <input value={form.cargo} onChange={(e) => setForm({ ...form, cargo: e.target.value })} placeholder="Conteneur 40' — riz" className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Départ</span>
                <input value={form.origin} onChange={(e) => setForm({ ...form, origin: e.target.value })} placeholder="Port de Dakar" className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Destination</span>
                <input value={form.destination} onChange={(e) => setForm({ ...form, destination: e.target.value })} placeholder="Diamniadio" className={inputCls} />
              </label>
              <label className="col-span-2 block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Axe actuel</span>
                <select value={form.axisId} onChange={(e) => setForm({ ...form, axisId: e.target.value })} className={`${inputCls} cursor-pointer`}>
                  {city.axes.map((a) => (
                    <option key={a.id} value={a.id}>
                      {a.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">Carburant (L)</span>
                <input type="number" min={0} max={900} value={form.fuelL} onChange={(e) => setForm({ ...form, fuelL: Number(e.target.value) })} className={inputCls} />
              </label>
              <label className="block">
                <span className="mb-1 block text-[10.5px] font-semibold tracking-wide text-sage uppercase">ETA (min)</span>
                <input type="number" min={1} max={600} value={form.etaMin} onChange={(e) => setForm({ ...form, etaMin: Number(e.target.value) })} className={inputCls} />
              </label>
            </div>
            {formError && <p className="mt-3 rounded-xl bg-coral/10 px-3 py-2 text-[12.5px] font-medium text-coral">{formError}</p>}
            <button
              onClick={() => void addVehicle()}
              disabled={adding}
              className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-night-700 py-2.5 text-[13px] font-bold transition hover:bg-night-600 disabled:opacity-60"
            >
              {adding ? <Loader2 className="h-4 w-4 animate-spin" /> : <Truck className="h-4 w-4" />}
              Ajouter à la flotte suivie
            </button>
          </div>

          <div className="space-y-6">
            <div className="rounded-3xl border border-amber-warn/40 bg-night-900 p-5 sm:p-6">
              <h2 className="flex items-center gap-2 font-display text-base font-bold">
                <RouteIcon className="h-5 w-5 text-amber-warn" /> Centre d&apos;action du convoi
              </h2>
              <p className="mt-2 text-[13px] leading-relaxed text-sage">
                <span className="mr-3 inline-flex items-center gap-1.5">
                  <span className="live-dot h-2 w-2 rounded-full bg-brand-500" /> {movingCount} en mouvement
                </span>
                <span className="mr-3 inline-flex items-center gap-1.5 text-amber-warn">
                  <Timer className="h-3.5 w-3.5" /> {slowedCount} ralenti(s)
                </span>
                <span className="mr-3 inline-flex items-center gap-1.5 text-coral">
                  <OctagonAlert className="h-3.5 w-3.5" /> {blockedCount} bloqué(s)
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Fuel className="h-3.5 w-3.5 text-sage" /> {(fleet?.stats.fuelEmbarked ?? 0).toLocaleString("fr-FR")} L embarqués
                </span>
              </p>
              <button
                onClick={() => void reroute()}
                disabled={rerouting || (blockedCount === 0 && slowedCount === 0)}
                className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-amber-warn py-3 text-sm font-bold text-night-950 transition hover:brightness-105 disabled:cursor-not-allowed disabled:bg-night-600 disabled:text-sage"
              >
                {rerouting ? <Loader2 className="h-4 w-4 animate-spin" /> : <RouteIcon className="h-4 w-4" />}
                Rerouter le convoi entier ({blockedCount + slowedCount} camion(s) concerné(s))
              </button>
              <p className="mt-2 text-[12px] leading-relaxed text-sage">
                Répartition automatique sur les délestages les plus fluides, hors zones protégées saturées. Chaque
                chauffeur reçoit son nouvel itinéraire par SMS + WhatsApp.
              </p>
              {notice && (
                <p className="mt-3 rounded-xl bg-brand-500/12 px-3 py-2.5 text-[12.5px] font-medium text-mint-300">{notice}</p>
              )}
              {orders.length > 0 && (
                <div className="mt-4 rounded-2xl border border-night-600 bg-night-800/60 p-4">
                  <p className="flex items-center gap-2 text-[12px] font-bold tracking-wide text-sage uppercase">
                    <CheckCircle2 className="h-4 w-4 text-brand-500" /> Ordres émis — derniers itinéraires envoyés
                  </p>
                  <ul className="mt-2.5 space-y-1.5">
                    {orders.map((o) => (
                      <li key={o.vehicleId} className="flex flex-wrap items-center gap-x-2 text-[12.5px]">
                        <span className="font-mono font-semibold">{o.plate}</span>
                        <span className="text-sage">→</span>
                        <span className="font-semibold text-mint-300">{o.toAxisName}</span>
                        <span className="ml-auto rounded-full bg-night-950 px-2 py-0.5 text-[10px] font-bold text-sage">
                          {o.channel}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            <div className="rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
              <div className="flex items-center justify-between gap-3">
                <h2 className="font-display text-base font-bold">Axes critiques — {city.name}</h2>
                <Link href={`/?ville=${cityId}#dashboard`} className="text-[12px] font-semibold text-mint-300 hover:text-mint-400">
                  Voir la carte thermique →
                </Link>
              </div>
              <p className="mt-1 text-[12px] text-sage">Les axes à éviter pour vos tournées en ce moment (fluidité la plus faible).</p>
              <ul className="mt-3 space-y-3">
                {criticalAxes.map((a) => (
                  <li key={a.axisId}>
                    <div className="flex items-baseline justify-between gap-2 text-[12.5px]">
                      <span className="truncate font-semibold">{a.name}</span>
                      <span className="shrink-0 font-display font-bold" style={{ color: fluidColor(a.fluidity) }}>
                        {a.fluidity}/100
                      </span>
                    </div>
                    <div className="mt-1 h-2 overflow-hidden rounded-full bg-night-950">
                      <div className="h-full rounded-full transition-all duration-700" style={{ width: `${a.fluidity}%`, background: fluidColor(a.fluidity) }} />
                    </div>
                    {a.protectedBlocked && (
                      <p className="mt-1 flex items-center gap-1 text-[11px] font-medium text-coral">
                        <ShieldAlert className="h-3 w-3" /> Zone protégée saturée : délestage interdit sur cet axe.
                      </p>
                    )}
                  </li>
                ))}
                {criticalAxes.length === 0 && <li className="text-[12.5px] text-sage">Chargement de l&apos;état des axes…</li>}
              </ul>
            </div>
          </div>
        </div>

        {/* Tableau de flotte */}
        <div className="mt-6 overflow-hidden rounded-3xl border border-night-600 bg-night-900">
          <div className="flex flex-wrap items-center gap-3 border-b border-night-600/60 px-4 py-3">
            <p className="text-[13px] font-bold">
              Flotte suivie — {visibleVehicles.length}/{vehicles.length} véhicule(s) à {city.name}
            </p>
            <div className="ml-auto flex flex-wrap items-center gap-2">
              <label className="relative">
                <Search className="absolute top-1/2 left-2.5 h-3.5 w-3.5 -translate-y-1/2 text-sage" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Plaque, chauffeur, cargaison…"
                  className="w-52 rounded-xl border border-night-600 bg-night-800 py-1.5 pr-2 pl-8 text-[12px] outline-none placeholder:text-sage/50 focus:border-brand-500"
                />
              </label>
              {["tous", "En mouvement", "Ralentissement", "Bloqué", "Livré"].map((s) => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`rounded-full px-2.5 py-1.5 text-[11px] font-semibold transition ${
                    statusFilter === s ? "bg-brand-500 text-night-950" : "bg-night-800 text-sage hover:text-paper"
                  }`}
                >
                  {s === "tous" ? "Tous" : s}
                </button>
              ))}
              <button
                onClick={exportCsv}
                disabled={vehicles.length === 0}
                className="flex items-center gap-2 rounded-xl bg-night-700 px-3 py-2 text-[12px] font-semibold transition hover:bg-night-600 disabled:opacity-50"
              >
                <Download className="h-3.5 w-3.5" /> Exporter CSV
              </button>
            </div>
          </div>
          <div className="thin-scroll overflow-x-auto">
            <table className="w-full min-w-225 text-left text-[12.5px]">
              <thead>
                <tr className="border-b border-night-600 bg-night-800/70 text-[10.5px] tracking-wider text-sage uppercase">
                  <th className="px-4 py-3 font-semibold">Camion</th>
                  <th className="px-3 py-3 font-semibold">Chauffeur</th>
                  <th className="px-3 py-3 font-semibold">Cargaison</th>
                  <th className="px-3 py-3 font-semibold">Trajet</th>
                  <th className="px-3 py-3 font-semibold">Axe actuel</th>
                  <th className="px-3 py-3 font-semibold">Vitesse</th>
                  <th className="px-3 py-3 font-semibold">ETA</th>
                  <th className="px-3 py-3 font-semibold">Réservoir</th>
                  <th className="px-3 py-3 font-semibold">Statut</th>
                  <th className="px-3 py-3" />
                </tr>
              </thead>
              <tbody>
                {visibleVehicles.length === 0 && (
                  <tr>
                    <td colSpan={10} className="px-4 py-10 text-center text-sage">
                      {vehicles.length === 0
                        ? `Aucun véhicule enregistré à ${city.name} pour le moment — déclarez votre flotte réelle avec le formulaire ci-dessus.`
                        : "Aucun véhicule ne correspond à ces filtres."}
                    </td>
                  </tr>
                )}
                {visibleVehicles.map((v) => (
                  <tr
                    key={v.id}
                    className={`border-b border-night-600/50 transition ${
                      v.convoy ? "bg-amber-warn/10" : "hover:bg-night-800/50"
                    }`}
                  >
                    <td className="px-4 py-3 font-mono text-[12px] font-semibold whitespace-nowrap">{v.plate}</td>
                    <td className="px-3 py-3 whitespace-nowrap">{v.driver}</td>
                    <td className="max-w-45 truncate px-3 py-3 text-sage">{v.cargo}</td>
                    <td className="px-3 py-3 whitespace-nowrap text-sage">
                      {v.origin} → {v.destination}
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">{getAxis(city, v.axisId)?.short ?? v.axisId}</td>
                    <td className="px-3 py-3 font-mono whitespace-nowrap">{Math.round(v.speedKmh)} km/h</td>
                    <td className="px-3 py-3 font-mono whitespace-nowrap">{v.etaMin} min</td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <span className="flex items-center gap-2">
                        <span className="h-1.5 w-12 overflow-hidden rounded-full bg-night-950">
                          <span
                            className={`block h-full rounded-full ${v.fuelL < 60 ? "bg-coral" : v.fuelL < 110 ? "bg-amber-warn" : "bg-brand-500"}`}
                            style={{ width: `${Math.min(100, (v.fuelL / 300) * 100)}%` }}
                          />
                        </span>
                        {Math.round(v.fuelL)} L
                      </span>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      <span className={`rounded-full px-2 py-1 text-[10.5px] font-bold ${STATUS_STYLES[v.status] ?? STATUS_STYLES.Livré}`}>
                        {v.status.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-3 py-3 whitespace-nowrap">
                      {(v.status === "Bloqué" || v.status === "Ralentissement") && (
                        <button
                          onClick={() => void reroute([v.id])}
                          disabled={reroutingId === v.id}
                          className="rounded-lg bg-amber-warn px-2.5 py-1.5 text-[11px] font-bold text-night-950 transition hover:brightness-105 disabled:opacity-60"
                        >
                          {reroutingId === v.id ? "…" : "Rerouter"}
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="border-t border-night-600/60 px-4 py-3 text-[12px] text-sage">
            💡 Les lignes sur fond ambré appartiennent au convoi ciblé par les boutons d&apos;action ci-dessus.
            <span className="mt-1 block">
              Véracité des données : vitesses, ETA et statuts sont <b>déduits en direct de l&apos;état des axes</b>{" "}
              (carte thermique). Pour un suivi GPS par véhicule, vos boîtiers ou l&apos;app chauffeur peuvent émettre
              via POST /api/telemetry — les mesures réelles priment alors sur le modèle.
            </span>
          </p>
        </div>

        <p className="mt-6 text-center text-[12px] text-sage">
          AfriFlow — offre SaaS Flottes &amp; Industrie : 14 900 FCFA / véhicule / mois.{" "}
          <Link href="/#tarifs" className="font-semibold text-mint-300 hover:text-mint-400">
            Voir les offres
          </Link>
        </p>
      </main>
    </div>
  );
}
