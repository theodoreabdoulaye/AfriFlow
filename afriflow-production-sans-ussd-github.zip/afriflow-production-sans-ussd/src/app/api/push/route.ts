import { NextRequest, NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { pushSubscriptions } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { getVapidPublicKey } from "@/lib/push";

export const dynamic = "force-dynamic";

/** GET /api/push — clé publique VAPID pour s'abonner aux alertes. */
export async function GET() {
  const publicKey = await getVapidPublicKey();
  if (!publicKey) {
    return NextResponse.json({ error: "Notifications push indisponibles" }, { status: 503 });
  }
  return NextResponse.json({ publicKey });
}

/**
 * POST /api/push { subscription: {endpoint, keys:{p256dh, auth}}, city? }
 * Enregistre (ou met à jour) l'abonnement aux alertes validées.
 * DELETE /api/push { endpoint } — désabonnement.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`push:${clientIp(req)}`, 30, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;
  const sub = body.subscription as
    | { endpoint?: string; keys?: { p256dh?: string; auth?: string } }
    | undefined;
  if (!sub?.endpoint || !sub.keys?.p256dh || !sub.keys?.auth) {
    return NextResponse.json({ error: "Abonnement push incomplet" }, { status: 422 });
  }
  const cityRaw = typeof body.city === "string" ? body.city : null;
  const city = cityRaw && CITY_MAP[cityRaw] ? cityRaw : null;

  try {
    await db
      .insert(pushSubscriptions)
      .values({ endpoint: sub.endpoint, p256dh: sub.keys.p256dh, auth: sub.keys.auth, city })
      .onConflictDoUpdate({
        target: pushSubscriptions.endpoint,
        set: { p256dh: sub.keys.p256dh, auth: sub.keys.auth, city },
      });
    return NextResponse.json({ subscribed: true, city });
  } catch {
    return NextResponse.json({ error: "Abonnement indisponible" }, { status: 503 });
  }
}

export async function DELETE(req: NextRequest) {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  const endpoint = (raw as Record<string, unknown>)?.endpoint;
  if (typeof endpoint !== "string") {
    return NextResponse.json({ error: "endpoint requis" }, { status: 422 });
  }
  try {
    await db.delete(pushSubscriptions).where(eq(pushSubscriptions.endpoint, endpoint));
  } catch {
    /* désabonnement best-effort */
  }
  return NextResponse.json({ unsubscribed: true });
}
