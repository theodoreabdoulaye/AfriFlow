/**
 * AfriFlow — moteur de trafic (porté du prototype Rust/axum).
 *
 * score d'itinéraire = fluidité × 1/(1+densité) × critères
 * Vitesse par segment : profil horaire appris (jour × heure) + météo
 * + incidents validés + télémétrie réelle lissée (α = 0,3).
 */
import type { AxisDef, CityDef } from "./cities";
import { getZone } from "./cities";
import type { OsmAxisMeta } from "./osm-enrich";

export interface WeatherInfo {
  label: string; // Ensoleillé | Nuageux | Pluie | Pluie forte | Orage
  level: 0 | 1 | 2; // 0 sec, 1 pluie, 2 pluie forte / orage
  tempC: number | null;
  windKmh: number | null;
  precipMm: number | null;
  code: number | null;
  source: "open-meteo" | "fallback";
  /** Probabilité de précipitation dans l'heure (Open-Meteo), 0-100. */
  precipProb1h?: number | null;
  /** Débit du cours d'eau de référence du jour (Copernicus GloFAS, m³/s). */
  riverDischargeM3s?: number | null;
  /** Risque de crue déduit des débits GloFAS à 3 jours : 0 faible, 1 modéré, 2 élevé. */
  floodRiskLevel?: 0 | 1 | 2 | null;
  /** Indice européen de qualité de l'air (CAMS via Open-Meteo). */
  aqiEu?: number | null;
  /** Pluie prévue sur les 3 prochaines heures (mm, Open-Meteo horaire). */
  nextRainMm3h?: number | null;
}

export const CLEAR_WEATHER: WeatherInfo = {
  label: "Ensoleillé",
  level: 0,
  tempC: 31,
  windKmh: 12,
  precipMm: 0,
  code: 0,
  source: "fallback",
  riverDischargeM3s: null,
  floodRiskLevel: null,
  aqiEu: null,
};

export interface IncidentImpact {
  axisId: string;
  severity: number;
  /** Âge de l'incident en minutes : l'impact décroît avec le temps. */
  ageMinutes?: number;
}

export interface MeasureBlend {
  speedKmh: number;
  samples: number;
  freshMinutes: number;
  /** Dernières mesures issues du simulateur de démonstration (tracé). */
  simulated?: boolean;
}

export interface AxisLiveState {
  axisId: string;
  name: string;
  short: string;
  speedKmh: number;
  freeFlowKmh: number;
  fluidity: number; // 0..100
  density: number; // 0..1 (part de capacité)
  level: "fluide" | "dense" | "congestion" | "sature";
  vehiclesTracked: number;
  trend: number[]; // fluidité des 12 dernières tranches de 5 min
  prediction: {
    in15: number;
    in30: number;
    in60: number;
    /** Score de confiance HONNÊTE (0-100) : erreur holdout + volume de données. */
    confidence30: number;
    confidenceLabel: string; // "Réel (Données terrain)" | "Estimation fiable (Modèle appris)" | …
    confidenceReason: string;
  };
  measured: boolean; // alimenté par télémétrie réelle récente
  /**
   * Provenance des données de l'axe :
   * - "reel"   : mesures GPS fraîches (< 5 min) — vert sur la carte ;
   * - "estime" : estimation IA (profil historique) — orange ;
   * - "aucune" : aucune couverture GPS de la ville pour le moment — gris.
   */
  dataSource: "reel" | "estime" | "aucune";
  /** Les mesures fraîches proviennent (au moins en partie) du simulateur démo. */
  simulated: boolean;
  /** Cause probable de l'état actuel (affichée au clic sur l'axe). */
  cause: { code: string; label: string };
  /** Fluidité estimée par le profil, heure par heure (0-23). */
  dayHistory: number[];
  floodProne: boolean;
  potholes: number; // 0..1 — dégradation de la chaussée
  riskScore: number; // 0..1 — risque accidentogène / insécurité
  /** Attributs réels de la voie OpenStreetMap correspondante (Overpass). */
  osm: OsmAxisMeta | null;
  /** Échantillons GPS ayant servi à apprendre le profil de cet axe (0 = générique). */
  learnedSamples: number;
  protectedZone: AxisDef["protectedZone"] | null;
  protectedSaturation: number; // 0..100 — ≥ 80 ⇒ délestage interdit
  protectedBlocked: boolean;
  from: string;
  to: string;
  path: [number, number][];
}

/** Bruit pseudo-aléatoire déterministe (stable entre deux appels proches). */
export function hashNoise(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 1000) / 1000; // 0..1
}

/**
 * Facteur de vitesse du profil horaire (pics 7-9 h et 17-20 h),
 * appris des mesures jour × heure. 1 = fluide, ~0.35 = saturation.
 */
export function profileFactor(axis: AxisDef, at: Date): number {
  // `at` est un instant décalé de l'offset de la ville : les getters UTC
  // donnent donc l'heure locale de la ville, quel que soit le fuseau du serveur.
  const h = at.getUTCHours() + at.getUTCMinutes() / 60;
  const dow = at.getUTCDay(); // 0 dimanche
  const weekend = dow === 0 || dow === 6 ? 0.55 : 1;

  const morningDip = axis.morningPeak * weekend;
  const eveningDip = axis.eveningPeak * weekend;

  let factor = 1;
  // Pic du matin 6h30 → 9h30 (creux à 8h)
  factor -= 0.62 * morningDip * gauss(h, 8, 1.15);
  // Pic du soir 16h30 → 20h30 (creux à 18h15)
  factor -= 0.66 * eveningDip * gauss(h, 18.25, 1.5);
  // Creux de mi-journée (marchés, sorties de bureau)
  factor -= 0.18 * weekend * gauss(h, 13, 1.6);
  // Nuit profonde très fluide
  if (h < 5 || h >= 23) factor = Math.min(1, factor + 0.06);
  return clamp(factor, 0.22, 1);
}

function gauss(x: number, mu: number, sigma: number): number {
  return Math.exp(-((x - mu) ** 2) / (2 * sigma * sigma));
}

export function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

/**
 * Poids du modèle de correction ML par axe (porté du MLEngine Rust) :
 * vitesse corrigée = (base × intercept) − (pluie × rain_penalty)
 *                    − (signalements actifs × report_penalty).
 */
export interface AxisWeights {
  intercept: number;
  rainPenalty: number;
  reportPenalty: number;
  /** Facteur de profil moyen pendant l'entraînement (correction en ratio). */
  trainProfileFactor?: number;
  samples: number;
  holdoutMae: number;
}

/** Profil de vitesse APPRIS pour un axe (facteurs médians mesurés). */
export interface LearnedAxisProfile {
  weekday: (number | null)[]; // 24 facteurs, heure locale
  weekend: (number | null)[];
  /** Profils par jour de semaine (0 = dimanche) — capte p. ex. le vendredi. */
  byDow?: (number | null)[][];
  /** Dérive récente (72 h) : ratio observé/prédit, borné [0,85 ; 1,10]. */
  trendFactor?: number;
  samples: number;
}

/** Facteur appris interpolé à un instant (null si le créneau est inconnu). */
export function learnedFactorAt(profile: LearnedAxisProfile | undefined, at: Date): number | null {
  if (!profile) return null;
  const dow = at.getUTCDay();
  const kindArr = dow === 0 || dow === 6 ? profile.weekend : profile.weekday;
  const dowArr = profile.byDow?.[dow];
  const arr = dowArr && dowArr.some((v) => v !== null) ? dowArr : kindArr;
  const hFloat = at.getUTCHours() + at.getUTCMinutes() / 60;
  const h0 = Math.floor(hFloat) % 24;
  const h1 = (h0 + 1) % 24;
  const frac = hFloat - Math.floor(hFloat);
  const v0 = arr[h0];
  const v1 = arr[h1];
  if (v0 !== null && v1 !== null) return v0 + (v1 - v0) * frac;
  if (v0 !== null) return v0;
  if (v1 !== null) return v1;
  for (let d = 1; d <= 3; d++) {
    const before = arr[(h0 - d + 24) % 24];
    if (before !== null) return before;
    const after = arr[(h0 + d) % 24];
    if (after !== null) return after;
  }
  // Jour précis inconnu : repli sur le profil semaine/week-end.
  if (arr !== kindArr) {
    const kv = kindArr[h0];
    if (kv !== null) return kv;
  }
  return null;
}

/**
 * Facteur de profil effectif : fusion du profil historique générique et
 * du profil APPRIS sur les mesures (poids croissant avec les échantillons,
 * plafonné à 80 % pour garder la robustesse du modèle historique).
 */
export function effectiveProfileFactor(
  axis: AxisDef,
  at: Date,
  profiles?: Map<string, LearnedAxisProfile>,
): number {
  const generic = profileFactor(axis, at);
  if (!profiles) return generic;
  const profile = profiles.get(axis.id);
  const learned = learnedFactorAt(profile, at);
  if (learned === null || !profile) return generic;
  const w = clamp(profile.samples / 48, 0, 0.8);
  let factor = (1 - w) * generic + w * learned;
  // Tendance récente (type Prophet) : dérive mesurée sur 72 h.
  if (profile.trendFactor && profile.samples >= 10) {
    factor *= clamp(profile.trendFactor, 0.85, 1.1);
  }
  return factor;
}

export interface EngineContext {
  at: Date; // heure de projection
  weather: WeatherInfo;
  incidents: IncidentImpact[]; // incidents diffusés (consensus atteint)
  measures: Map<string, MeasureBlend>; // télémétrie réelle par axe
  /** La ville a déjà reçu au moins un point GPS (réel ou démo) sur 24 h. */
  cityHasGps?: boolean;
  /** Attributs OpenStreetMap par axe (surface, voies, maxspeed, sens unique). */
  osm?: Map<string, OsmAxisMeta>;
  /** Profils de vitesse appris sur les mesures GPS (par axe). */
  profiles?: Map<string, LearnedAxisProfile>;
  /** Poids du modèle de correction ML par axe (intercept/pluie/signalements). */
  weights?: Map<string, AxisWeights>;
  /**
   * Mode léger (indices continentaux) : saute tendances, historique du
   * jour et prédictions détaillées — seul l'état courant compte.
   */
  light?: boolean;
}

/** Vitesse simulée « modèle » d'un axe à un instant donné. */
export function modelSpeed(
  axis: AxisDef,
  at: Date,
  weather: WeatherInfo,
  incidents: IncidentImpact[],
  profiles?: Map<string, LearnedAxisProfile>,
): number {
  let speed = axis.freeFlowKmh * effectiveProfileFactor(axis, at, profiles);

  // Météo : la pluie dégrade tout, les zones inondables s'effondrent.
  if (weather.level === 1) speed *= axis.floodProne ? 0.55 : 0.82;
  if (weather.level === 2) speed *= axis.floodProne ? 0.3 : 0.68;

  // Crue fluviale (débits réels Copernicus GloFAS) : un fleuve en crue
  // inonde les axes sensibles même sans pluie locale.
  if (weather.floodRiskLevel && weather.floodRiskLevel > 0 && axis.floodProne) {
    speed *= weather.floodRiskLevel === 2 ? 0.6 : 0.82;
  }

  // Incidents validés par consensus sur l'axe : impact plein à la diffusion,
  // puis décroissance exponentielle (demi-vie ≈ 60 min, plancher 35 %).
  for (const inc of incidents) {
    if (inc.axisId === axis.id) {
      const decay = Math.exp(-(inc.ageMinutes ?? 0) / 90);
      speed *= 1 - Math.min(0.5, 0.09 * inc.severity) * (0.35 + 0.65 * decay);
    }
  }

  // Micro-variation déterministe par tranche de 5 minutes.
  const bucket = Math.floor(at.getTime() / 300_000);
  speed *= 0.94 + hashNoise(`${axis.id}:${bucket}`) * 0.12;

  return clamp(speed, 4, axis.freeFlowKmh * 1.05);
}

export function computeAxisState(axis: AxisDef, ctx: EngineContext): AxisLiveState {
  // Enrichissement OpenStreetMap : la vitesse libre réelle tient compte
  // du maxspeed OSM, et une surface non asphaltée réduit la base de 40 %.
  const osmMeta = ctx.osm?.get(axis.id) ?? null;
  const effFree = osmMeta?.maxspeedKmh
    ? Math.min(axis.freeFlowKmh, osmMeta.maxspeedKmh)
    : axis.freeFlowKmh;
  const surfaceSlow =
    !!osmMeta?.surface && !["asphalt", "paved", "concrete"].includes(osmMeta.surface);
  const osmScale = (effFree / axis.freeFlowKmh) * (surfaceSlow ? 0.6 : 1);

  let model = modelSpeed(axis, ctx.at, ctx.weather, ctx.incidents, ctx.profiles) * osmScale;

  // Correction ML apprise (MLEngine), appliquée EN RATIO du profil
  // horaire courant : ratio = intercept / facteur moyen d'entraînement.
  // (Un intercept appris le soir ne doit pas gonfler le pic du matin.)
  const mlWeights = ctx.weights?.get(axis.id);
  if (mlWeights) {
    const activeReports = ctx.incidents.filter((i) => i.axisId === axis.id).length;
    const ratio = clamp(mlWeights.intercept / (mlWeights.trainProfileFactor || 1), 0.55, 1.15);
    const profileSpeed = model / (osmScale || 1);
    const mlSpeed =
      clamp(
        profileSpeed * ratio -
          (ctx.weather.precipMm ?? 0) * mlWeights.rainPenalty -
          activeReports * mlWeights.reportPenalty,
        5,
        axis.freeFlowKmh * 1.2,
      ) * osmScale;
    const mw = clamp(mlWeights.samples / 30, 0, 0.6);
    model = (1 - mw) * model + mw * mlSpeed;
  }

  const measure = ctx.measures.get(axis.id);

  let speed = model;
  let measured = false;
  if (measure && measure.freshMinutes <= 10 && measure.samples >= 2) {
    // Fusion modèle / mesures réelles (la mesure pèse d'autant plus qu'elle est dense).
    const w = clamp(0.35 + measure.samples * 0.05, 0.35, 0.75);
    speed = model * (1 - w) + measure.speedKmh * w;
    measured = true;
  }

  const fluidity = clamp(Math.round((speed / effFree) * 100), 2, 100);
  const density = clamp(1 - fluidity / 118, 0.02, 0.99);
  const vehiclesTracked = Math.round(axis.capacityVehH * density * (0.55 + hashNoise(axis.id + ":veh") * 0.3));

  const level: AxisLiveState["level"] =
    fluidity >= 70 ? "fluide" : fluidity >= 48 ? "dense" : fluidity >= 30 ? "congestion" : "sature";

  // Courbe de tendance : fluidité sur les 2 dernières heures (tranches de 10 min).
  const trend: number[] = [];
  for (let i = ctx.light ? -1 : 11; i >= 0; i--) {
    const t = new Date(ctx.at.getTime() - i * 600_000);
    const s = modelSpeed(axis, t, ctx.weather, ctx.incidents, ctx.profiles) * osmScale;
    trend.push(clamp(Math.round((s / effFree) * 100), 2, 100));
  }

  // Prédiction IA : profils horaires projetés, ajustés par la probabilité
  // de pluie de l'heure à venir (les axes inondables chutent en premier).
  const predAt = (min: number) => {
    const t = new Date(ctx.at.getTime() + min * 60_000);
    let s = modelSpeed(axis, t, ctx.weather, ctx.incidents, ctx.profiles) * osmScale;
    const rainProb = ctx.weather.precipProb1h ?? null;
    if (rainProb !== null && rainProb >= 50 && min >= 30) {
      const rainFactor = axis.floodProne ? 0.72 : 0.92;
      s *= 1 - (1 - rainFactor) * ((rainProb - 40) / 60);
    }
    // Pluie intense prévue (≥ 8 mm sur 3 h) : les axes inondables
    // se dégradent dans la prédiction même sans probabilité dominante.
    if (axis.floodProne && (ctx.weather.nextRainMm3h ?? 0) >= 8 && min >= 30) {
      s *= 0.82;
    }
    return clamp(Math.round((s / effFree) * 100), 2, 100);
  };

  const protectedSaturation = Math.round(density * 100);
  const in30Value = ctx.light ? fluidity : predAt(30);

  // Provenance de la donnée : GPS frais < 5 min > estimation IA > rien.
  const dataSource: AxisLiveState["dataSource"] =
    measure && measure.freshMinutes <= 5 && measure.samples >= 1
      ? "reel"
      : measure || ctx.cityHasGps
        ? "estime"
        : "aucune";
  const simulated = !!(measure?.simulated && dataSource === "reel");

  // Cause probable de l'état de l'axe (explication au clic).
  const incidentOnAxis = ctx.incidents.find((i) => i.axisId === axis.id);
  const profileNow = profileFactor(axis, ctx.at);
  const cause: AxisLiveState["cause"] = incidentOnAxis
    ? {
        code: "incident",
        label: "Incident validé par le consensus communautaire (3 conducteurs) — impact décroissant avec le temps",
      }
    : ctx.weather.level >= 1 && axis.floodProne
      ? { code: "pluie", label: "Pluie signalée — axe inondable fortement pénalisé" }
      : (ctx.weather.floodRiskLevel ?? 0) >= 1 && axis.floodProne
        ? { code: "crue", label: "Risque de crue du fleuve (débits GloFAS) — axe inondable pénalisé" }
        : profileNow < 0.55
          ? { code: "pointe", label: "Heure de pointe (profil historique jour × heure)" }
          : fluidity >= 70
            ? { code: "normal", label: "Circulation normale pour ce créneau (profil historique)" }
            : { code: "densite", label: "Densité élevée estimée par le modèle (historique + météo)" };

  // Historique de la journée : fluidité du profil, heure par heure.
  const dayHistory: number[] = [];
  for (let h = 0; h < (ctx.light ? 0 : 24); h++) {
    const t = new Date(ctx.at);
    t.setUTCHours(h, 0, 0, 0);
    dayHistory.push(
      clamp(Math.round((modelSpeed(axis, t, ctx.weather, [], ctx.profiles) / axis.freeFlowKmh) * 100), 2, 100),
    );
  }

  // Confiance HONNÊTE (design MLEngine) : précision mesurée en holdout +
  // volume de données (log). Jamais de score élevé sans données pour
  // l'étayer ; sans modèle entraîné, on retombe sur les libellés prudents.
  let confidence30: number;
  let confidenceLabel: string;
  let confidenceReason: string;
  if (mlWeights) {
    const errorRatio = Math.min(1, mlWeights.holdoutMae / Math.max(10, effFree));
    const accuracyScore = Math.floor((1 - errorRatio) * 100);
    const dataScore = Math.min(30, Math.floor(Math.log(Math.max(1, mlWeights.samples)) * 15));
    confidence30 = Math.min(100, accuracyScore + dataScore);
    // Plafond d'honnêteté : une erreur holdout élevée interdit les très
    // hauts scores, quel que soit le volume de données (pas de 98/100
    // avec 15 km/h d'erreur moyenne).
    const relError = mlWeights.holdoutMae / Math.max(10, effFree);
    const ceiling = relError > 0.2 ? 65 : relError > 0.12 ? 79 : relError > 0.08 ? 89 : 100;
    confidence30 = Math.min(confidence30, ceiling);
    confidenceLabel =
      confidence30 >= 80
        ? "Réel (Données terrain)"
        : confidence30 >= 50
          ? "Estimation fiable (Modèle appris)"
          : "Estimation faible (Peu de données)";
    confidenceReason =
      mlWeights.samples < 5
        ? `Basé sur l'historique OSM. Seulement ${mlWeights.samples} données réelles.`
        : `Modèle corrigé par ${mlWeights.samples} données. Erreur moyenne: ${mlWeights.holdoutMae.toFixed(1)} km/h`;
  } else if (dataSource === "reel") {
    confidence30 = 82;
    confidenceLabel = "Réel (Données terrain)";
    confidenceReason =
      "Vitesses mesurées par GPS il y a moins de 5 minutes (modèle de correction pas encore entraîné sur cet axe).";
  } else if (dataSource === "estime") {
    confidence30 = 42;
    confidenceLabel = "Estimation faible (Peu de données)";
    confidenceReason =
      "Estimation du profil historique (jour × heure) — pas encore de modèle corrigé par des données terrain sur cet axe.";
  } else {
    confidence30 = 30;
    confidenceLabel = "Estimation historique (en attente de données)";
    confidenceReason = "Aucune donnée GPS ou signalement reçu sur cet axe.";
  }


  return {
    axisId: axis.id,
    name: axis.name,
    short: axis.short,
    speedKmh: Math.round(speed * 10) / 10,
    freeFlowKmh: axis.freeFlowKmh,
    fluidity,
    density: Math.round(density * 100) / 100,
    level,
    vehiclesTracked,
    trend,
    prediction: {
      in15: ctx.light ? fluidity : predAt(15),
      in30: in30Value,
      in60: ctx.light ? fluidity : predAt(60),
      confidence30,
      confidenceLabel,
      confidenceReason,
    },
    measured,
    dataSource,
    simulated,
    cause,
    dayHistory,
    potholes: axis.potholes,
    riskScore: axis.risk,
    osm: osmMeta,
    learnedSamples: ctx.profiles?.get(axis.id)?.samples ?? 0,
    floodProne: !!axis.floodProne,
    protectedZone: axis.protectedZone ?? null,
    protectedSaturation,
    protectedBlocked: !!axis.protectedZone && protectedSaturation >= 80,
    from: axis.from,
    to: axis.to,
    path: axis.path,
  };
}

export interface CitySummary {
  index: number; // fluidité moyenne pondérée /100
  indexIn30: number;
  /** Véhicules en circulation ESTIMÉS par le modèle (capacité × densité). */
  vehiclesTracked: number;
  /** Carburant perdu estimé (ralenti en congestion), L/h. */
  fuelLostLitersPerHour: number;
  saturatedAxes: number;
  computedInMs: number;
}

export function summarizeCity(states: AxisLiveState[], axes: AxisDef[], ctx: EngineContext): CitySummary {
  let weighted = 0;
  let weight = 0;
  let vehicles = 0;
  let fuelLost = 0;
  let saturated = 0;

  states.forEach((s, i) => {
    const axis = axes[i];
    const w = axis.capacityVehH;
    weighted += s.fluidity * w;
    weight += w;
    vehicles += s.vehiclesTracked;
    if (s.level === "sature" || s.level === "congestion") saturated++;
    // Temps perdu × consommation au ralenti (~0,85 L/h par véhicule arrêté).
    const lostRatio = 1 - s.fluidity / 100;
    fuelLost += s.vehiclesTracked * lostRatio * 0.85;
  });

  const in30States = axes.map((a) => {
    const t = new Date(ctx.at.getTime() + 30 * 60_000);
    return clamp((modelSpeed(a, t, ctx.weather, ctx.incidents, ctx.profiles) / a.freeFlowKmh) * 100, 2, 100);
  });
  const indexIn30 = Math.round(
    in30States.reduce((acc, f, i) => acc + f * axes[i].capacityVehH, 0) / Math.max(1, weight),
  );

  return {
    index: Math.round(weighted / Math.max(1, weight)),
    indexIn30,
    vehiclesTracked: vehicles,
    fuelLostLitersPerHour: Math.round(fuelLost),
    saturatedAxes: saturated,
    computedInMs: 0,
  };
}

/* ------------------------------------------------------------------ */
/* Routage ventilé                                                     */
/* ------------------------------------------------------------------ */

export interface RoutePriorities {
  time: boolean;
  fuel: boolean;
  safety: boolean;
  practicability: boolean;
}

export interface RouteLeg {
  axisId: string;
  name: string;
  minutes: number;
  fluidity: number;
  /** Charge de l'axe (% de sa capacité) au moment du calcul. */
  loadPct: number;
  protectedZone: string | null;
  protectedBlocked: boolean;
}

export interface RouteOption {
  id: "A" | "B" | "C";
  kind: "principal" | "delestage" | "alternative";
  label: string;
  legs: RouteLeg[];
  minutes: number;
  distanceKm: number;
  fuelLiters: number;
  fuelFcfa: number;
  fuelSavedFcfa: number | null; // vs option A
  score: number;
  fluidityAvg: number;
  status: "recommande" | "disponible" | "quota-plein" | "zone-protegee";
  quota: { granted: number; total: number; remaining: number } | null;
  ventilatedShare: number | null; // % du trafic dévié vers cette option
  note: string;
  /** Charge maximale rencontrée sur le parcours (% de capacité). */
  maxLoadPct: number;
  /** Explication lisible de la ventilation (affichée à l'utilisateur). */
  explanation: string;
  /** Nœuds explorés par A* pour ce calcul (diagnostic performance). */
  exploredNodes?: number;
}

const FUEL_PRICE_FCFA = 775; // prix moyen du litre (Afrique de l'Ouest)

/**
 * Profils de conduite :
 * - standard : équilibre temps / carburant / sécurité ;
 * - gbaka    : transport en commun — axes structurants (forte capacité),
 *              densité modérée tolérée, voies étroites évitées ;
 * - urgence  : voiture / urgence — évitement maximal des axes saturés,
 *              même au prix d'un détour plus long.
 */
export type VehicleProfile = "standard" | "gbaka" | "urgence";

interface EdgeCost {
  minutes: number;
  scoreCost: number;
  fuelLiters: number;
}

/**
 * Multiplicateur de quota M_quota — LE mécanisme de ventilation :
 *   charge < 60 %           → 1,0 (aucune dissuasion)
 *   60 % ≤ charge < 80 %    → 1 + 2×((charge−0,6)/0,2)² (quadratique douce)
 *   charge ≥ 80 % + zone protégée → 50 (mur virtuel quasi-infranchissable)
 *   charge ≥ 80 % sinon     → 1 + 10×((charge−0,8)/0,2)² (dissuasion forte)
 */
export function quotaMultiplier(charge: number, isProtectedZone: boolean): number {
  if (charge >= 0.8) {
    if (isProtectedZone) return 50;
    return 1 + 10 * Math.pow((charge - 0.8) / 0.2, 2);
  }
  if (charge >= 0.6) {
    return 1 + 2 * Math.pow((charge - 0.6) / 0.2, 2);
  }
  return 1;
}

/**
 * Charge d'un axe (0..1) : densité estimée par le moteur (trafic réel +
 * mesures) + pression des délestages déjà accordés (grants de quota).
 */
export function axisCharge(state: AxisLiveState, granted: number, quotaTotal: number): number {
  const routedPressure = quotaTotal > 0 ? (granted / quotaTotal) * 0.1 : 0;
  return clamp(state.density + routedPressure, 0, 1);
}

/** Risque d'inondation 0..1 (tag OSM dérivé + crue GloFAS). */
export function floodRiskScore(axis: AxisLiveState, weather: WeatherInfo): number {
  // Priorité au risque INFÉRÉ des tags OSM (surface, layer), ajusté par la crue GloFAS.
  if (axis.osm) {
    return clamp(axis.osm.floodRisk + (weather.floodRiskLevel ?? 0) * 0.15, 0, 1);
  }
  if (!axis.floodProne) return 0.1;
  return clamp(0.55 + (weather.floodRiskLevel ?? 0) * 0.2 + (weather.precipMm ?? 0) * 0.02, 0, 1);
}

/**
 * LA FORMULE DU COÛT GÉNÉRALISÉ (cœur du moteur) :
 *
 *   Coût_final = (Distance / Vitesse_estimée) × M_profil
 *                × (1 + P_qualité + P_sécurité) × M_quota
 *
 * - P_qualité  = dégradation × 0,5 (+ 2,0 si pluie et axe inondable)
 * - P_sécurité = risque de l'axe (pondéré si la priorité est active)
 * - M_quota    = voir quotaMultiplier() — explose près de la capacité
 */
function generalizedCost(
  axis: AxisDef,
  state: AxisLiveState,
  prio: RoutePriorities,
  weather: WeatherInfo,
  profile: VehicleProfile,
  charge: number,
  effCapacity: number,
): EdgeCost {
  // 1. Coût de base : temps de parcours estimé (minutes).
  const minutes = (axis.lengthKm / Math.max(5, state.speedKmh)) * 60;
  let cost = minutes;

  // Sévérité de chaussée : inférée OSM si disponible, sinon attribut curé.
  const potholeSeverity = state.osm?.potholeSeverity ?? axis.potholes;

  // 2. Multiplicateur de profil.
  let profileMultiplier = 1;
  if (profile === "gbaka") {
    // Gbaka : routes dégradées très pénalisées + axes structurants favorisés.
    profileMultiplier = (potholeSeverity > 0.3 ? 3.0 : 1.0) * (1 + (1 - effCapacity / 4800) * 0.9);
    if (state.density < 0.75) profileMultiplier *= 0.92;
  } else if (profile === "urgence") {
    profileMultiplier = 0.8; // l'urgence « paie » moins le coût de base…
    if (state.fluidity < 40) profileMultiplier *= 7; // …mais fuit les saturations
    else if (state.fluidity < 52) profileMultiplier *= 2.4;
  }
  cost *= profileMultiplier;

  // 3. Pénalités qualité + sécurité.
  let qualityPenalty = potholeSeverity * 0.5;
  if (weather.level >= 1 && floodRiskScore(state, weather) > 0.3) {
    qualityPenalty += 2.0; // pénalité massive si inondable et qu'il pleut
  }
  if (prio.practicability) {
    qualityPenalty += potholeSeverity * 0.6;
    if (weather.level >= 1 && axis.floodProne) qualityPenalty += 0.8;
  }
  const securityPenalty = axis.risk * (prio.safety ? 1.0 : 0.35);
  cost *= 1 + qualityPenalty + securityPenalty;

  // 4. Priorité carburant (surconsommation en congestion).
  if (prio.fuel) {
    cost *= 1 + (1 - state.fluidity / 100) * 0.9;
  }

  // 5. LE multiplicateur de quota (ventilation).
  cost *= quotaMultiplier(charge, !!axis.protectedZone);

  // Consommation : base 7,5 L/100 + surconsommation en congestion.
  const liters = (axis.lengthKm / 100) * (7.5 + (1 - state.fluidity / 100) * 6.5);
  return { minutes, scoreCost: cost, fuelLiters: liters };
}

/** Distance haversine en km entre deux points GPS. */
export function haversineKm(a: [number, number], b: [number, number]): number {
  const R = 6371;
  const dLat = ((b[0] - a[0]) * Math.PI) / 180;
  const dLon = ((b[1] - a[1]) * Math.PI) / 180;
  const la1 = (a[0] * Math.PI) / 180;
  const la2 = (b[0] * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLon / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}

/** Coordonnées GPS approximatives des zones (extrémités des axes). */
function zoneCoordinates(city: CityDef): Map<string, [number, number]> {
  const map = new Map<string, [number, number]>();
  for (const axis of city.axes) {
    if (!map.has(axis.from)) map.set(axis.from, axis.gps[0]);
    if (!map.has(axis.to)) map.set(axis.to, axis.gps[axis.gps.length - 1]);
  }
  return map;
}

/** Tas binaire min pour la file de priorité d'A*. */
class MinHeap {
  private keys: number[] = [];
  private vals: string[] = [];
  get size(): number {
    return this.vals.length;
  }
  push(key: number, val: string): void {
    this.keys.push(key);
    this.vals.push(val);
    let i = this.vals.length - 1;
    while (i > 0) {
      const parent = (i - 1) >> 1;
      if (this.keys[parent] <= this.keys[i]) break;
      [this.keys[parent], this.keys[i]] = [this.keys[i], this.keys[parent]];
      [this.vals[parent], this.vals[i]] = [this.vals[i], this.vals[parent]];
      i = parent;
    }
  }
  pop(): { key: number; val: string } | null {
    if (this.vals.length === 0) return null;
    const top = { key: this.keys[0], val: this.vals[0] };
    const lastKey = this.keys.pop()!;
    const lastVal = this.vals.pop()!;
    if (this.vals.length > 0) {
      this.keys[0] = lastKey;
      this.vals[0] = lastVal;
      let i = 0;
      for (;;) {
        const l = 2 * i + 1;
        const r = l + 1;
        let smallest = i;
        if (l < this.keys.length && this.keys[l] < this.keys[smallest]) smallest = l;
        if (r < this.keys.length && this.keys[r] < this.keys[smallest]) smallest = r;
        if (smallest === i) break;
        [this.keys[smallest], this.keys[i]] = [this.keys[i], this.keys[smallest]];
        [this.vals[smallest], this.vals[i]] = [this.vals[i], this.vals[smallest]];
        i = smallest;
      }
    }
    return top;
  }
}

interface SearchResult {
  axes: AxisDef[];
  minutes: number;
  fuel: number;
  cost: number;
  explored: number;
}

/**
 * Recherche A* sur le graphe zones ↔ axes, avec le coût généralisé
 * (formule Distance/Vitesse × M_profil × (1+P_qualité+P_sécurité) × M_quota).
 * Heuristique : temps à vol d'oiseau (haversine) à la vitesse maximale
 * du réseau — admissible, donc le chemin retourné reste optimal.
 */
function aStar(
  city: CityDef,
  states: Map<string, AxisLiveState>,
  from: string,
  to: string,
  prio: RoutePriorities,
  weather: WeatherInfo,
  penalties: Map<string, number>,
  excluded: Set<string>,
  profile: VehicleProfile,
  charges: Map<string, number>,
  capacities: Map<string, number>,
): SearchResult | null {
  const coords = zoneCoordinates(city);
  const goal = coords.get(to);
  const maxSpeed = Math.max(40, ...city.axes.map((a) => a.freeFlowKmh));
  const heuristic = (zone: string): number => {
    const c = coords.get(zone);
    if (!c || !goal) return 0;
    return (haversineKm(c, goal) / maxSpeed) * 60 * 0.9;
  };

  const gScore = new Map<string, number>();
  const prev = new Map<string, { zone: string; axis: AxisDef; minutes: number; fuel: number }>();
  const closed = new Set<string>();
  const open = new MinHeap();
  gScore.set(from, 0);
  open.push(heuristic(from), from);
  let explored = 0;

  while (open.size > 0) {
    const current = open.pop()!.val;
    if (closed.has(current)) continue;
    closed.add(current);
    explored++;
    if (current === to) break;
    const g = gScore.get(current) ?? Infinity;

    for (const axis of city.axes) {
      if (excluded.has(axis.id)) continue;
      let next: string | null = null;
      if (axis.from === current) next = axis.to;
      else if (axis.to === current) next = axis.from;
      if (!next || closed.has(next)) continue;
      const state = states.get(axis.id);
      if (!state) continue;
      const c = generalizedCost(
        axis,
        state,
        prio,
        weather,
        profile,
        charges.get(axis.id) ?? state.density,
        capacities.get(axis.id) ?? axis.capacityVehH,
      );
      const pen = penalties.get(axis.id) ?? 1;
      const ng = g + c.scoreCost * pen;
      if (ng < (gScore.get(next) ?? Infinity)) {
        gScore.set(next, ng);
        prev.set(next, { zone: current, axis, minutes: c.minutes, fuel: c.fuelLiters });
        open.push(ng + heuristic(next), next);
      }
    }
  }

  if (!prev.has(to) && from !== to) return null;

  const axes: AxisDef[] = [];
  let minutes = 0;
  let fuel = 0;
  let cursor = to;
  while (cursor !== from) {
    const step = prev.get(cursor);
    if (!step) return null;
    axes.unshift(step.axis);
    minutes += step.minutes;
    fuel += step.fuel;
    cursor = step.zone;
  }
  return { axes, minutes, fuel, cost: gScore.get(to) ?? 0, explored };
}

export interface RoutingQuotaInfo {
  grantedByAxis: Map<string, number>; // grants accordés dans l'heure
}

export function quotaTotalForCapacity(capacityVph: number): number {
  // Quota MFD : une fraction de la capacité horaire peut absorber du délestage.
  return Math.max(24, Math.round(capacityVph * 0.16));
}

export function quotaTotalFor(axis: AxisDef): number {
  return quotaTotalForCapacity(axis.capacityVehH);
}

export function findRoutes(
  city: CityDef,
  states: AxisLiveState[],
  from: string,
  to: string,
  prio: RoutePriorities,
  weather: WeatherInfo,
  quota: RoutingQuotaInfo,
  at: Date,
  profile: VehicleProfile = "standard",
): RouteOption[] {
  const stateMap = new Map(states.map((s) => [s.axisId, s]));

  // Capacité effective : l'inférence OSM (base × voies) ne remplace la
  // capacité curée que pour les classes fiables (motorway→tertiary) —
  // le tag « residential » sous-classe souvent les grands axes ouest-africains.
  const RELIABLE_HIGHWAY = new Set(["motorway", "trunk", "primary", "secondary", "tertiary"]);
  const effCapacityOf = (axis: AxisDef): number => {
    const osm = stateMap.get(axis.id)?.osm;
    if (osm && osm.highway && RELIABLE_HIGHWAY.has(osm.highway)) return osm.capacityVph;
    return axis.capacityVehH;
  };
  const capacities = new Map<string, number>();
  for (const axis of city.axes) capacities.set(axis.id, effCapacityOf(axis));

  // Charges des axes (pour M_quota) : densité du modèle + délestages accordés.
  const charges = new Map<string, number>();
  for (const axis of city.axes) {
    const st = stateMap.get(axis.id);
    if (!st) continue;
    charges.set(
      axis.id,
      axisCharge(st, quota.grantedByAxis.get(axis.id) ?? 0, quotaTotalForCapacity(effCapacityOf(axis))),
    );
  }
  // Exclusions liées au profil : voies trop étroites pour un gbaka,
  // axes saturés pour une urgence (avec repli si aucun chemin ne subsiste).
  const excluded = new Set<string>();
  if (profile === "gbaka") {
    // Voies trop étroites pour un car de transport en commun.
    for (const axis of city.axes) {
      if (effCapacityOf(axis) < 1500) excluded.add(axis.id);
    }
  }
  if (profile === "urgence") {
    for (const s of states) {
      if (s.fluidity < 35) excluded.add(s.axisId);
    }
  }

  const build = (
    pathAxes: AxisDef[] | null,
    base: SearchResult | null,
    id: RouteOption["id"],
    kind: RouteOption["kind"],
  ): RouteOption | null => {
    if (!pathAxes || !base) return null;
    const legs: RouteLeg[] = pathAxes.map((axis) => {
      const st = stateMap.get(axis.id)!;
      return {
        axisId: axis.id,
        name: axis.name,
        minutes: Math.round(((axis.lengthKm / Math.max(5, st.speedKmh)) * 60) * 10) / 10,
        fluidity: st.fluidity,
        loadPct: Math.round((charges.get(axis.id) ?? st.density) * 100),
        protectedZone: axis.protectedZone?.name ?? null,
        protectedBlocked: st.protectedBlocked,
      };
    });
    const distanceKm = pathAxes.reduce((a, x) => a + x.lengthKm, 0);
    const fluidityAvg = Math.round(legs.reduce((a, l) => a + l.fluidity, 0) / Math.max(1, legs.length));
    const score = Math.round(fluidityAvg * (1 / (1 + (1 - fluidityAvg / 100))) * 10) / 10;
    const fuelLiters = Math.round(base.fuel * 10) / 10;

    const blockedLeg = legs.find((l) => l.protectedBlocked);
    let status: RouteOption["status"] = id === "A" ? "recommande" : "disponible";
    let quotaInfo: RouteOption["quota"] = null;
    let ventilatedShare: number | null = null;
    let note = "";

    if (kind !== "principal") {
      // Le quota porte sur le premier axe « délestage » du parcours.
      const reliefAxis = pathAxes[0];
      const total = quotaTotalFor(reliefAxis);
      const granted = quota.grantedByAxis.get(reliefAxis.id) ?? 0;
      quotaInfo = { granted, total, remaining: Math.max(0, total - granted) };
      if (blockedLeg) {
        status = "zone-protegee";
        note = `Délestage interdit : ${blockedLeg.protectedZone} à ≥ 80 % de capacité (règle des zones protégées).`;
      } else if (quotaInfo.remaining <= 0) {
        status = "quota-plein";
        note = "Quota MFD atteint sur cet axe : les prochains conducteurs restent sur l'axe principal pour ne pas engorger le délestage.";
      } else {
        status = "recommande";
        const worst = Math.min(...legs.map((l) => l.fluidity));
        ventilatedShare = worst < 45 ? 18 + Math.round(hashNoise(`share:${at.getUTCHours()}:${reliefAxis.id}`) * 12) : 8 + Math.round(hashNoise(`share:${reliefAxis.id}`) * 8);
        note = `Ventilation dosée : seuls ${quotaInfo.remaining} conducteurs supplémentaires seront admis sur ce délestage.`;
      }
    } else {
      note = "Axe principal : itinéraire de référence avant ventilation.";
    }

    return {
      id,
      kind,
      label:
        kind === "principal"
          ? "Itinéraire principal"
          : kind === "delestage"
            ? "Délestage ventilé"
            : "Alternative de délestage",
      legs,
      minutes: Math.round(base.minutes),
      distanceKm: Math.round(distanceKm * 10) / 10,
      fuelLiters,
      fuelFcfa: Math.round(fuelLiters * FUEL_PRICE_FCFA),
      fuelSavedFcfa: null,
      score,
      fluidityAvg,
      status,
      quota: quotaInfo,
      ventilatedShare,
      note,
      maxLoadPct: Math.round(Math.max(0, ...legs.map((l) => l.loadPct))),
      explanation: "",
      exploredNodes: base?.explored,
    };
  };

  // Itinéraire A — optimal selon les critères.
  let pathA = aStar(city, stateMap, from, to, prio, weather, new Map(), excluded, profile, charges, capacities);
  if (!pathA && excluded.size > 0) {
    // Profil trop restrictif sur ce graphe : on relâche les exclusions.
    excluded.clear();
    pathA = aStar(city, stateMap, from, to, prio, weather, new Map(), excluded, profile, charges, capacities);
  }
  const routeA = build(pathA?.axes ?? null, pathA, "A", "principal");
  if (!routeA) return [];

  const keyOf = (p: { axes: AxisDef[] } | null) => p?.axes.map((a) => a.id).join(",") ?? "";
  const worstAxisOf = (axes: AxisDef[]): AxisDef | null => {
    let worst: AxisDef | null = null;
    let worstFluidity = Infinity;
    for (const axis of axes) {
      const f = stateMap.get(axis.id)?.fluidity ?? 100;
      if (f < worstFluidity) {
        worstFluidity = f;
        worst = axis;
      }
    }
    return worst;
  };

  // Itinéraire B — on force un délestage : l'axe le plus saturé de A est pénalisé.
  const penaltiesB = new Map<string, number>();
  let worstA: AxisDef | null = null;
  if (pathA) {
    worstA = worstAxisOf(pathA.axes);
    for (const axis of pathA.axes) penaltiesB.set(axis.id, axis === worstA ? 4.5 : 1.8);
  }
  let pathB = aStar(city, stateMap, from, to, prio, weather, penaltiesB, excluded, profile, charges, capacities);
  if (pathB && pathA && keyOf(pathB) === keyOf(pathA) && worstA && pathA.axes.length > 0) {
    // Toujours identique : on exclut carrément l'axe saturé pour forcer la ventilation.
    const forced = aStar(city, stateMap, from, to, prio, weather, new Map(), new Set([worstA.id]), profile, charges, capacities);
    if (forced) pathB = forced;
  }
  const routeB =
    pathB && keyOf(pathB) !== keyOf(pathA) ? build(pathB.axes, pathB, "B", "delestage") : null;

  // Itinéraire C — alternative si A et B sont contraints.
  const penaltiesC = new Map<string, number>(penaltiesB);
  if (pathB) for (const axis of pathB.axes) penaltiesC.set(axis.id, 3.5);
  let pathC = aStar(city, stateMap, from, to, prio, weather, penaltiesC, excluded, profile, charges, capacities);
  if (
    pathC &&
    (keyOf(pathC) === keyOf(pathA) || (pathB && keyOf(pathC) === keyOf(pathB)))
  ) {
    const excl = new Set<string>();
    if (worstA) excl.add(worstA.id);
    if (pathB) {
      const wB = worstAxisOf(pathB.axes);
      if (wB) excl.add(wB.id);
    }
    const forced = aStar(city, stateMap, from, to, prio, weather, new Map(), excl, profile, charges, capacities);
    if (forced) pathC = forced;
  }
  const keyC = keyOf(pathC);
  const dupC = keyC === keyOf(pathA) || (pathB !== null && keyC === keyOf(pathB));
  const routeC = pathC && !dupC ? build(pathC.axes, pathC, "C", "alternative") : null;

  const options = [routeA, routeB, routeC].filter((r): r is RouteOption => r !== null);
  for (const opt of options) {
    opt.fuelSavedFcfa = opt.id === "A" ? 0 : routeA.fuelFcfa - opt.fuelFcfa;
  }

  // Explications lisibles de la ventilation (affichées au conducteur).
  const worstLegA = [...routeA.legs].sort((a, b) => b.loadPct - a.loadPct)[0];
  for (const opt of options) {
    if (opt.kind === "principal") {
      opt.explanation =
        opt.maxLoadPct >= 80
          ? `L'axe le plus chargé de ce trajet (${worstLegA?.name}) est à ${opt.maxLoadPct} % de sa capacité : le moteur a déjà dissuadé le trafic évitable via le multiplicateur de quota.`
          : "C'est actuellement l'option au meilleur coût généralisé (temps × profil × qualité × quota).";
    } else {
      const relief = opt.legs[0];
      opt.explanation = `Itinéraire ventilé : l'axe direct (${worstLegA?.name}, ${worstLegA?.loadPct} % de capacité${worstLegA?.protectedBlocked ? ", zone protégée saturée" : ""}) est contourné par ${relief?.name} pour éviter le bouchon — sans saturer la route de secours (quota MFD).`;
    }
  }

  const fromName = getZone(city, from)?.name ?? from;
  const toName = getZone(city, to)?.name ?? to;
  void fromName;
  void toName;
  void at;
  return options;
}
