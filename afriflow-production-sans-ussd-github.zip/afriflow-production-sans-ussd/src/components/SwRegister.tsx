"use client";

import { useEffect } from "react";

/**
 * Enregistre le service worker (production uniquement) : coquille
 * d'application et assets en cache pour des rechargements quasi
 * instantanés et un affichage hors-ligne de la dernière carte connue.
 */
export default function SwRegister() {
  useEffect(() => {
    if (process.env.NODE_ENV === "production" && "serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }
  }, []);
  return null;
}
