import { handleAuth } from "@/lib/auth";
export const POST = (req: Request) => handleAuth(req, "google");
