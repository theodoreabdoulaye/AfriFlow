import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { h3Density } from "@/lib/h3";
import { requirePaidAccess } from "@/lib/access";

export const dynamic = "force-dynamic";

/**
 * GET /api/h3/density?city=dakar&window=60 — densité GPS par cellule
 * hexagonale H3 (résolution 9) : nombre de points et vitesse moyenne
 * de la dernière heure, polygones GeoJSON prêts pour la carte.
 * Lisse le bruit des tronçons et révèle les zones chaudes hors axes.
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const windowMin = Math.max(5, Math.min(240, Number(req.nextUrl.searchParams.get("window") ?? 60) || 60));
  const density = await h3Density(city, windowMin);
  return NextResponse.json(density, { headers: { "Cache-Control": "private, no-store" } });
}
