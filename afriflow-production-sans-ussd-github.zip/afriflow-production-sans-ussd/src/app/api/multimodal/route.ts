import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { CITY_MAP, getZone } from "@/lib/cities";
import type { VehicleProfile } from "@/lib/engine";
import { DEFAULT_PREFS, findMultimodalRoutes, type RoutingPreferences } from "@/lib/multimodal";
import { buildHeatmap } from "@/lib/server-data";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { ensureCitySeed } from "@/lib/seed";
import { transitStopsFor, zoneLatLon } from "@/lib/transit";

export const dynamic = "force-dynamic";

/** GET /api/multimodal?city=dakar — arrêts de transport de la ville. */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  return NextResponse.json({ city: city.id, stops: transitStopsFor(city) }, { headers: { "Cache-Control": "private, no-store" } });
}

interface PointInput {
  lat?: number;
  lon?: number;
  zone?: string;
  label?: string;
}

function resolvePoint(
  city: (typeof CITY_MAP)[string],
  input: PointInput | undefined,
): { lat: number; lon: number; label: string } | null {
  if (!input) return null;
  if (typeof input.lat === "number" && typeof input.lon === "number") {
    return { lat: input.lat, lon: input.lon, label: input.label ?? "Point indiqué" };
  }
  if (input.zone) {
    const coords = zoneLatLon(city, input.zone);
    if (!coords) return null;
    return { lat: coords[0], lon: coords[1], label: getZone(city, input.zone)?.name ?? input.zone };
  }
  return null;
}

/**
 * POST /api/multimodal — itinéraires multimodaux (porté du design Rust) :
 * { city, from: {zone}|{lat,lon}, to: {...}, preferences?, profile? }
 * Combine le moteur ventilé (voiture), le TER/BRT, le Car Rapide et la
 * marche : options voiture directe, Park & Ride et transit seul notées
 * en durée, coût FCFA, CO₂, confort et fiabilité.
 */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`multimodal:${clientIp(req)}`, 120, 600_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  const body = raw as Record<string, unknown>;
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  const from = resolvePoint(city, body.from as PointInput);
  const to = resolvePoint(city, body.to as PointInput);
  if (!from || !to) {
    return NextResponse.json({ error: "Départ et arrivée requis (zone ou coordonnées)" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }

  const prefsInput = (body.preferences ?? {}) as Partial<RoutingPreferences>;
  const prefs: RoutingPreferences = {
    allowCar: prefsInput.allowCar !== false,
    allowTransit: prefsInput.allowTransit !== false,
    allowParkAndRide: prefsInput.allowParkAndRide !== false,
    maxWalkingDistanceM: Math.max(200, Math.min(4000, Number(prefsInput.maxWalkingDistanceM ?? DEFAULT_PREFS.maxWalkingDistanceM) || DEFAULT_PREFS.maxWalkingDistanceM)),
    prioritize: (["time", "cost", "comfort", "eco"].includes(String(prefsInput.prioritize))
      ? prefsInput.prioritize
      : "time") as RoutingPreferences["prioritize"],
  };
  const profile: VehicleProfile =
    body.profile === "gbaka" || body.profile === "urgence" ? body.profile : "standard";

  await ensureCitySeed(city);
  const heat = await buildHeatmap(city);
  const atLocal = new Date(Date.now() + (city.tzOffsetMin ?? 0) * 60_000);

  const routes = findMultimodalRoutes({
    city,
    states: heat.axes,
    weather: heat.weather,
    from,
    to,
    prefs,
    atLocal,
    profile,
  });

  return NextResponse.json({
    city: city.id,
    from,
    to,
    preferences: prefs,
    routes,
    transitStops: transitStopsFor(city).length,
    note: "Durées rail : horaires TER/BRT réels (fréquences et heures de service) ; durées route : moteur ventilé temps réel.",
  }, { headers: { "Cache-Control": "private, no-store" } });
}
