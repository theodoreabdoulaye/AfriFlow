"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity,
  Gauge as GaugeIcon,
  Loader2,
  RefreshCw,
  Satellite,
  Search,
  ShieldAlert,
  Sparkles,
  Users,
} from "lucide-react";
import { CITY_MAP, getZone } from "@/lib/cities";
import { cityDisplayDate } from "@/lib/format";
import { gpsToSvg } from "@/lib/projection";
import PushOptIn from "./PushOptIn";
import type { AxisLiveState } from "@/lib/engine";
import { useApp } from "./AppClient";

export const LEVEL_COLORS: Record<AxisLiveState["level"], string> = {
  fluide: "#22b573",
  dense: "#a3e635",
  congestion: "#ffb020",
  sature: "#ff5d47",
};

export const LEVEL_LABELS: Record<AxisLiveState["level"], string> = {
  fluide: "Fluide",
  dense: "Dense",
  congestion: "Congestion",
  sature: "Saturé",
};

/** Code couleur par provenance de la donnée (vue « Qualité des données »). */
export const SOURCE_COLORS: Record<AxisLiveState["dataSource"], string> = {
  reel: "#22c55e",
  estime: "#f97316",
  aucune: "#6b7280",
};

export const SOURCE_LABELS: Record<AxisLiveState["dataSource"], string> = {
  reel: "GPS réel < 5 min",
  estime: "Estimation IA (historique)",
  aucune: "Aucune donnée",
};

export function SourceBadge({ axis }: { axis: AxisLiveState }) {
  return (
    <span
      className="inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold"
      style={{ background: `${SOURCE_COLORS[axis.dataSource]}22`, color: SOURCE_COLORS[axis.dataSource] }}
      title={
        axis.dataSource === "reel"
          ? "Vitesses mesurées par des GPS il y a moins de 5 minutes"
          : axis.dataSource === "estime"
            ? "Estimation du modèle (profils historiques) — pas de GPS frais sur cet axe"
            : "Aucune couverture GPS reçue pour cette ville pour le moment"
      }
    >
      <span className="h-1.5 w-1.5 rounded-full" style={{ background: SOURCE_COLORS[axis.dataSource] }} />
      {SOURCE_LABELS[axis.dataSource]}
      {axis.simulated ? " · démo" : ""}
    </span>
  );
}

function Sparkline({ values, color }: { values: number[]; color: string }) {
  const w = 260;
  const h = 56;
  const pts = values
    .map((v, i) => `${(i / Math.max(1, values.length - 1)) * w},${h - (v / 100) * (h - 8) - 4}`)
    .join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="h-14 w-full">
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round" />
      <polyline points={`0,${h} ${pts} ${w},${h}`} fill={color} opacity="0.12" stroke="none" />
    </svg>
  );
}

function AxisDetail({ axis }: { axis: AxisLiveState }) {
  const { cityId, heat } = useApp();
  const city = CITY_MAP[cityId];
  const color = LEVEL_COLORS[axis.level];
  const preds = [
    { label: "+15 min", value: axis.prediction.in15 },
    { label: "+30 min", value: axis.prediction.in30 },
    { label: "+60 min", value: axis.prediction.in60 },
  ];
  return (
    <div className="rounded-3xl border border-night-600 bg-night-900 p-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h3 className="font-display text-lg font-bold">{axis.name}</h3>
          <p className="mt-0.5 text-[13px] text-sage">
            {getZone(city, axis.from)?.name} → {getZone(city, axis.to)?.name}
          </p>
        </div>
        <span className="flex gap-1.5">
          {!axis.measured && (
            <span className="rounded-full bg-night-700 px-2.5 py-1 text-[10.5px] font-bold text-sage">
              ESTIMATION MODÈLE
            </span>
          )}
          <span
            className="rounded-full px-3 py-1 text-[12px] font-bold"
            style={{ background: `${color}22`, color }}
          >
            {LEVEL_LABELS[axis.level]}
          </span>
        </span>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-3 text-center">
        <div className="rounded-2xl bg-night-800 px-2 py-3">
          <p className="font-display text-xl font-bold">
            {Math.round(axis.speedKmh)}
            <span className="text-[11px] font-medium text-sage"> km/h</span>
          </p>
          <p className="mt-0.5 text-[10px] tracking-wide text-sage uppercase">vitesse (libre {axis.freeFlowKmh})</p>
        </div>
        <div className="rounded-2xl bg-night-800 px-2 py-3">
          <p className="font-display text-xl font-bold" style={{ color }}>
            {axis.fluidity}
            <span className="text-[11px] font-medium text-sage">/100</span>
          </p>
          <p className="mt-0.5 text-[10px] tracking-wide text-sage uppercase">fluidité</p>
        </div>
        <div className="rounded-2xl bg-night-800 px-2 py-3">
          <p className="font-display text-xl font-bold">≈{axis.vehiclesTracked.toLocaleString("fr-FR")}</p>
          <p className="mt-0.5 text-[10px] tracking-wide text-sage uppercase">véhicules estimés (modèle)</p>
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <SourceBadge axis={axis} />
        {axis.learnedSamples > 0 && (
          <span
            className="inline-flex items-center gap-1 rounded-full bg-violet-500/15 px-2 py-0.5 text-[10px] font-bold text-violet-300"
            title="Les prédictions de cet axe utilisent un profil appris sur les vitesses réellement mesurées"
          >
            🧠 Profil IA entraîné ({axis.learnedSamples} éch.)
          </span>
        )}
        <span className="text-[11.5px] text-sage">
          {axis.dataSource === "reel"
            ? "Vitesses mesurées par GPS il y a moins de 5 minutes."
            : axis.dataSource === "estime"
              ? "Pas de GPS frais : estimation IA basée sur l'historique de l'axe."
              : "Aucune donnée GPS reçue pour cette ville — lancez le simulateur ou contribuez en GPS réel."}
        </span>
      </div>

      <p className="mt-3 flex items-start gap-2 rounded-2xl border border-night-600 bg-night-800/60 px-3 py-2.5 text-[12.5px] leading-relaxed">
        <span aria-hidden>🧭</span>
        <span>
          <b>Cause probable :</b> {axis.cause.label}
        </span>
      </p>

      {axis.osm && (
        <p className="mt-3 rounded-2xl border border-sky-500/30 bg-sky-500/8 px-3 py-2.5 text-[12px] leading-relaxed">
          <b className="text-sky-300">🗺️ Voie OpenStreetMap{axis.osm.wayName ? ` — « ${axis.osm.wayName} »` : ""}</b>
          <span className="mt-1 flex flex-wrap gap-1.5">
            {axis.osm.surface && (
              <span className="rounded-full bg-night-800 px-2 py-0.5 font-semibold">
                Surface : {axis.osm.surface}
                {axis.osm.surface !== "asphalt" && axis.osm.surface !== "paved" ? " (base −40 %)" : ""}
              </span>
            )}
            {axis.osm.lanes !== null && (
              <span className="rounded-full bg-night-800 px-2 py-0.5 font-semibold">{axis.osm.lanes} voie(s)</span>
            )}
            {axis.osm.maxspeedKmh !== null && (
              <span className="rounded-full bg-night-800 px-2 py-0.5 font-semibold">
                Vitesse max OSM : {axis.osm.maxspeedKmh} km/h
              </span>
            )}
            {axis.osm.oneway && (
              <span className="rounded-full bg-night-800 px-2 py-0.5 font-semibold">Sens unique</span>
            )}
            {axis.osm.highway && (
              <span className="rounded-full bg-night-800 px-2 py-0.5 font-semibold">highway={axis.osm.highway}</span>
            )}
          </span>
        </p>
      )}

      <div className="mt-4">
        <p className="mb-1 text-[11px] font-semibold tracking-wide text-sage uppercase">
          Historique de la journée (fluidité estimée par heure)
        </p>
        <div className="flex h-16 items-end gap-[3px]" role="img" aria-label="Historique de fluidité de la journée">
          {axis.dayHistory.map((v, h) => {
            const isNow = heat ? h === new Date(heat.cityTime).getUTCHours() : false;
            return (
              <div key={h} className="group relative flex-1" title={`${h}h : ${v}/100`}>
                <div
                  className={`w-full rounded-t transition-all ${isNow ? "ring-1 ring-white" : ""}`}
                  style={{
                    height: `${Math.max(8, v)}%`,
                    background: v >= 70 ? "#22b573" : v >= 48 ? "#a3e635" : v >= 30 ? "#ffb020" : "#ff5d47",
                    opacity: isNow ? 1 : 0.55,
                  }}
                />
                {(h % 6 === 0 || isNow) && (
                  <span className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-[8.5px] text-sage">
                    {isNow ? "▶" : `${h}h`}
                  </span>
                )}
              </div>
            );
          })}
        </div>
        <p className="mt-5 text-[10.5px] text-sage">▶ = heure actuelle de la ville · pics appris 7-9 h et 17-20 h</p>
      </div>

      <div className="mt-4">
        <p className="mb-1 flex items-center justify-between text-[11px] font-semibold tracking-wide text-sage uppercase">
          <span className="flex items-center gap-1.5">
            <Activity className="h-3.5 w-3.5" /> Tendance 2 h
          </span>
          {axis.measured ? (
            <span className="flex items-center gap-1 text-mint-300 normal-case">
              <Satellite className="h-3.5 w-3.5" /> alimenté par GPS réel
            </span>
          ) : (
            <span className="normal-case">modèle + profils appris</span>
          )}
        </p>
        <Sparkline values={axis.trend} color={color} />
      </div>

      <div className="mt-4 rounded-2xl border border-night-600 bg-night-800/60 p-4">
        <p className="flex items-center justify-between text-[12px] font-bold">
          <span className="flex items-center gap-1.5">
            <Sparkles className="h-4 w-4 text-mint-400" /> Prédiction IA
          </span>
          {heat?.coldStart ? (
            <span className="rounded-full bg-sky-500/15 px-2.5 py-1 text-[10.5px] font-bold text-sky-300">
              ❄️ Mode estimation historique (en attente de données GPS réelles)
            </span>
          ) : (
            <span
              className="rounded-full px-2.5 py-1 text-[10.5px] font-bold"
              style={{
                background:
                  axis.prediction.confidence30 >= 80
                    ? "#14532d"
                    : axis.prediction.confidence30 >= 50
                      ? "#78350f"
                      : "#334155",
                color:
                  axis.prediction.confidence30 >= 80
                    ? "#86efac"
                    : axis.prediction.confidence30 >= 50
                      ? "#fcd34d"
                      : "#cbd5e1",
              }}
              title="Confiance calculée depuis l'erreur holdout réelle et le volume de données — jamais affichée sans mesures pour l'étayer"
            >
              {axis.prediction.confidence30 >= 80 ? "🟢" : axis.prediction.confidence30 >= 50 ? "🟠" : "⚪"}{" "}
              {axis.prediction.confidence30}/100 · {axis.prediction.confidenceLabel}
            </span>
          )}
        </p>
        {!heat?.coldStart && (
          <p
            className={`mt-1.5 text-[11px] leading-relaxed ${axis.prediction.confidence30 < 50 ? "font-semibold text-amber-warn" : "text-sage"}`}
          >
            {axis.prediction.confidence30 < 50 ? "⚠️ Attention : " : ""}
            {axis.prediction.confidenceReason}
          </p>
        )}
        <div className="mt-3 space-y-2.5">
          {preds.map((p) => (
            <div key={p.label} className="flex items-center gap-3">
              <span className="w-14 text-[12px] font-medium text-sage">{p.label}</span>
              <div className="h-2.5 flex-1 overflow-hidden rounded-full bg-night-950">
                <div
                  className="h-full rounded-full transition-all duration-700"
                  style={{
                    width: `${p.value}%`,
                    background: p.value >= 70 ? "#22b573" : p.value >= 48 ? "#a3e635" : p.value >= 30 ? "#ffb020" : "#ff5d47",
                  }}
                />
              </div>
              <span className="w-10 text-right font-display text-[13px] font-bold">{p.value}</span>
            </div>
          ))}
        </div>
        <p className="mt-3 text-[12px] leading-relaxed text-sage">
          {axis.prediction.in30 < axis.fluidity - 8
            ? "Dégradation anticipée : la ventilation préventive est recommandée avant saturation."
            : axis.prediction.in30 > axis.fluidity + 8
              ? "Amélioration attendue : le pic se résorbe, aucun délestage massif nécessaire."
              : "Situation stable sur l'horizon de prédiction, surveillance continue."}
        </p>
      </div>

      {axis.protectedZone && (
        <p
          className={`mt-4 flex items-start gap-2 rounded-2xl border p-3 text-[12px] leading-relaxed ${
            axis.protectedBlocked
              ? "border-coral/40 bg-coral/10 text-coral"
              : "border-night-600 bg-night-800/60 text-sage"
          }`}
        >
          <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
          <span>
            Zone protégée : <b>{axis.protectedZone.name}</b> ({axis.protectedZone.kind.toLowerCase()}) — saturation{" "}
            {axis.protectedSaturation} %.{" "}
            {axis.protectedBlocked
              ? "Délestage interdit (règle des 80 %)."
              : "Délestage encore autorisé sous quota."}
          </span>
        </p>
      )}
      {axis.floodProne && (
        <p className="mt-3 text-[12px] text-sage">
          ⚠️ Axe inondable : fortement pénalisé par le moteur dès les premières pluies.
          {heat?.weather.floodRiskLevel !== null &&
            heat?.weather.floodRiskLevel !== undefined &&
            heat.weather.floodRiskLevel > 0 && (
              <>
                {" "}
                <b className="text-amber-warn">
                  Risque de crue GloFAS {heat.weather.floodRiskLevel === 2 ? "élevé" : "modéré"} actuellement
                </b>{" "}
                (débit {heat.weather.riverDischargeM3s} m³/s) : la vitesse de cet axe en tient déjà compte.
              </>
            )}
        </p>
      )}
    </div>
  );
}

export default function HeatmapSection() {
  const { heat, heatLoading, refreshHeat, cityId, selectedAxisId, setSelectedAxisId, clock, projectedHour, live, lastUpdateAt } =
    useApp();
  const city = CITY_MAP[cityId];
  const [axisQuery, setAxisQuery] = useState("");
  const [levelFilter, setLevelFilter] = useState<string>("tous");
  const [viewMode, setViewMode] = useState<"trafic" | "donnees" | "texte">("donnees");
  const [showRisk, setShowRisk] = useState(false);
  const [showH3, setShowH3] = useState(false);
  const [h3Cells, setH3Cells] = useState<
    { cell: string; count: number; avgSpeedKmh: number; boundary: [number, number][] }[]
  >([]);
  const [h3Points, setH3Points] = useState(0);

  // Densité hexagonale H3 (résolution 9) : GPS de la dernière heure.
  useEffect(() => {
    if (!showH3) return;
    let cancelled = false;
    const load = async () => {
      try {
        const res = await fetch(`/api/h3/density?city=${cityId}&window=60`, { cache: "no-store" });
        if (res.ok && !cancelled) {
          const json = (await res.json()) as {
            cells: typeof h3Cells;
            totalPoints: number;
          };
          setH3Cells(json.cells);
          setH3Points(json.totalPoints);
        }
      } catch {
        /* calque optionnel */
      }
    };
    void load();
    const t = setInterval(() => void load(), 60_000);
    return () => {
      cancelled = true;
      clearInterval(t);
    };
  }, [showH3, cityId]);
  const [simulating, setSimulating] = useState(false);
  const [simMsg, setSimMsg] = useState<string | null>(null);

  // ---- Mode « Démo Live » : activé par défaut à la première visite ----
  const [demoOn, setDemoOn] = useState(true);
  const [demoBusy, setDemoBusy] = useState(false);
  const [demoMsg, setDemoMsg] = useState<string | null>(null);

  useEffect(() => {
    const t = window.setTimeout(() => {
      try {
        if (window.localStorage.getItem("afri_demo_live") === "off") setDemoOn(false);
      } catch {
        /* stockage indisponible */
      }
    }, 0);
    return () => clearTimeout(t);
  }, []);

  const runScenario = useCallback(async () => {
    setDemoBusy(true);
    try {
      const res = await fetch("/api/simulate/scenario", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: cityId }),
      });
      const json = (await res.json()) as { axisName?: string; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Scénario impossible");
      setDemoMsg(`Incident de démonstration « Travaux » validé sur ${json.axisName} — regardez la carte et le flux communautaire.`);
      await refreshHeat();
    } catch {
      /* la démo réessaiera à la prochaine visite */
    } finally {
      setDemoBusy(false);
    }
  }, [cityId, refreshHeat]);

  // Première visite d'une ville sans aucune donnée : on lance la démo.
  useEffect(() => {
    if (!heat || !demoOn) return;
    if (heat.dataCoverage.aucune !== heat.axes.length) return;
    const key = `afri_demo_done_${cityId}`;
    try {
      if (window.sessionStorage.getItem(key)) return;
      window.sessionStorage.setItem(key, "1");
    } catch {
      /* sessionStorage indisponible */
    }
    const t = window.setTimeout(() => void runScenario(), 0);
    return () => clearTimeout(t);
  }, [heat, demoOn, cityId, runScenario]);

  const disableDemo = () => {
    setDemoOn(false);
    try {
      window.localStorage.setItem("afri_demo_live", "off");
    } catch {
      /* stockage indisponible */
    }
  };

  const enableDemo = () => {
    setDemoOn(true);
    try {
      window.localStorage.setItem("afri_demo_live", "on");
      window.sessionStorage.removeItem(`afri_demo_done_${cityId}`);
    } catch {
      /* stockage indisponible */
    }
    void runScenario();
  };

  const runSimulator = async () => {
    setSimulating(true);
    setSimMsg(null);
    try {
      const res = await fetch("/api/simulate/traces", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ city: cityId, vehicles: 24 }),
      });
      const json = (await res.json()) as { points?: number; axesCovered?: number; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Simulation impossible");
      setSimMsg(
        `✅ ${json.points} traces de démonstration injectées sur ${json.axesCovered} axes — la carte passe au vert (GPS < 5 min) sur les axes couverts.`,
      );
      await refreshHeat();
    } catch (e) {
      setSimMsg(e instanceof Error ? e.message : "Simulation impossible");
    } finally {
      setSimulating(false);
    }
  };

  const sortedAxes = useMemo(() => {
    if (!heat) return [];
    return [...heat.axes].sort((a, b) => a.fluidity - b.fluidity);
  }, [heat]);

  const visibleAxes = useMemo(() => {
    const q = axisQuery.trim().toLowerCase();
    return sortedAxes.filter(
      (a) =>
        (levelFilter === "tous" || a.level === levelFilter) &&
        (q === "" || a.name.toLowerCase().includes(q) || a.short.toLowerCase().includes(q)),
    );
  }, [sortedAxes, axisQuery, levelFilter]);

  // Mode « Texte seul » (low data) : les axes à éviter, en phrases,
  // avec l'alternative la plus fluide connectée à chaque fois.
  const textSummary = useMemo(() => {
    if (!heat) return [];
    return [...heat.axes]
      .filter((a) => a.fluidity < 55)
      .sort((a, b) => a.fluidity - b.fluidity)
      .slice(0, 5)
      .map((a) => {
        const alt =
          heat.axes
            .filter(
              (x) =>
                x.axisId !== a.axisId &&
                (x.from === a.from || x.from === a.to || x.to === a.from || x.to === a.to),
            )
            .sort((x, y) => y.fluidity - x.fluidity)[0] ?? null;
        return { axis: a, alt };
      });
  }, [heat]);

  const selected = useMemo(() => {
    if (!heat) return null;
    return heat.axes.find((a) => a.axisId === selectedAxisId) ?? sortedAxes[0] ?? null;
  }, [heat, selectedAxisId, sortedAxes]);

  const displayDate = heat
    ? cityDisplayDate(heat.cityTime, projectedHour, clock)
    : (() => {
        const d = new Date(clock);
        if (projectedHour !== null) d.setHours(projectedHour);
        return d;
      })();

  return (
    <section id="dashboard" className="relative mx-auto max-w-7xl scroll-mt-24 px-4 py-14 sm:px-6">
      <div data-reveal className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
            <span className="inline-block h-px w-8 bg-brand-500" /> 01 · Carte en direct
          </p>
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Carte thermique — <span className="text-brand-500">{city.name}</span>
          </h2>
          <p className="mt-2 max-w-2xl text-[14px] leading-relaxed text-sage">
            Chaque axe est recalculé à partir des pings GPS anonymisés, des profils appris, de la météo Open-Meteo,
            des débits GloFAS et des incidents validés. Les axes sans mesure GPS fraîche affichent une estimation du
            modèle, étiquetée comme telle. Cliquez un axe pour inspecter sa prédiction IA.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <p className="rounded-xl border border-night-600 bg-night-900 px-3 py-2 text-[12px] font-medium text-sage">
            Contexte : {heat ? displayDate.getUTCHours() : displayDate.getHours()}h
            {String(heat ? displayDate.getUTCMinutes() : displayDate.getMinutes()).padStart(2, "0")} ·{" "}
            {heat?.weather.label ?? "…"} · {heat ? heat.axes.length : 0} axes ·{" "}
            {heat ? `${heat.measuredAxes}/${heat.axes.length} en GPS réel · ` : ""}
            {live ? (
              <span className="font-semibold text-mint-300">TEMPS RÉEL (flux direct)</span>
            ) : (
              <>maj auto 30 s</>
            )}
            {lastUpdateAt
              ? ` · maj ${new Date(lastUpdateAt).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}`
              : ""}
          </p>
          <PushOptIn />
          <button
            onClick={() => void refreshHeat()}
            className="flex items-center gap-2 rounded-xl bg-night-800 px-3 py-2 text-[12px] font-semibold transition hover:bg-night-700"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${heatLoading ? "animate-spin" : ""}`} />
            Actualiser
          </button>
        </div>
      </div>

      {heat && demoOn && (heat.dataCoverage.simulatedAxes > 0 || demoBusy) && (
        <div className="mt-6 flex flex-wrap items-center gap-3 rounded-3xl border border-amber-warn/50 bg-amber-warn/10 px-4 py-3">
          <span className="text-lg" aria-hidden>🎬</span>
          <p className="min-w-60 flex-1 text-[12.5px] leading-relaxed">
            <b>Mode Démo Live actif sur {city.name}</b> — traces GPS et incident de démonstration (étiquetés « démo »)
            pour découvrir la plateforme.{demoMsg ? ` ${demoMsg}` : ""}
          </p>
          <button
            onClick={() => void runScenario()}
            disabled={demoBusy}
            className="rounded-xl bg-night-800 px-3 py-2 text-[12px] font-bold transition hover:bg-night-700 disabled:opacity-60"
          >
            {demoBusy ? "Génération…" : "Régénérer la démo"}
          </button>
          <button
            onClick={disableDemo}
            className="rounded-xl border border-amber-warn/50 px-3 py-2 text-[12px] font-bold text-amber-warn transition hover:bg-amber-warn/10"
          >
            Désactiver
          </button>
        </div>
      )}
      {heat && !demoOn && heat.dataCoverage.aucune === heat.axes.length && (
        <p className="mt-6 rounded-3xl border border-night-600 bg-night-900 px-4 py-3 text-[12.5px] text-sage">
          Aucune donnée GPS reçue pour {city.name} pour le moment.{" "}
          <button onClick={enableDemo} className="font-bold text-mint-300 underline">
            Activer la Démo Live
          </button>{" "}
          pour voir la plateforme en action avec des données simulées étiquetées.
        </p>
      )}

      {!heat ? (
        <div
          aria-label="Chargement des données de trafic"
          className="mt-8 grid place-items-center rounded-3xl border border-night-600 bg-night-900 px-6 py-20 text-center"
        >
          <Loader2 className="h-8 w-8 animate-spin text-brand-500" />
          <p className="mt-4 max-w-md text-sm text-sage">
            ⌛ Connexion au moteur de trafic — pings GPS, données télécos agrégées et flottes partenaires…
          </p>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 lg:grid-cols-[1.5fr_1fr]">
          <div data-reveal className="overflow-hidden rounded-3xl border border-night-600 bg-night-900">
            <div className="flex flex-wrap items-center gap-2 border-b border-night-600/70 px-4 py-2.5">
              <span className="flex items-center gap-2 text-[11px] font-semibold tracking-wide text-sage uppercase">
                <GaugeIcon className="h-4 w-4 text-brand-500" /> {city.name} ({city.country})
              </span>
              <div className="ml-auto flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: "donnees", label: "Qualité des données" },
                    { id: "trafic", label: "Niveau de trafic" },
                    { id: "texte", label: "📄 Texte seul" },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    onClick={() => setViewMode(m.id)}
                    className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                      viewMode === m.id ? "bg-brand-500 text-night-950" : "bg-night-800 text-sage hover:text-paper"
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
                <button
                  onClick={() => setShowH3((v) => !v)}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                    showH3 ? "bg-violet-500 text-white" : "bg-night-800 text-sage hover:text-paper"
                  }`}
                  title="Agréger les GPS par cellule hexagonale H3 (résolution 9) : densité et vitesse moyenne"
                >
                  ⬡ Densité H3 {showH3 ? "ON" : "OFF"}
                </button>
                <button
                  onClick={() => setShowRisk((v) => !v)}
                  className={`rounded-full px-3 py-1.5 text-[11px] font-bold transition ${
                    showRisk ? "bg-sky-500 text-white" : "bg-night-800 text-sage hover:text-paper"
                  }`}
                  title="Superposer les zones inondables (bleu) et les chaussées dégradées (ambre)"
                >
                  🌊 Zones à risque {showRisk ? "ON" : "OFF"}
                </button>
                <span className="flex items-center gap-1.5 text-[11px] font-medium text-sage normal-case">
                  <Users className="h-3.5 w-3.5" /> ≈{heat.summary.vehiclesTracked.toLocaleString("fr-FR")} véh. est.
                </span>
              </div>
            </div>
            {viewMode === "texte" ? (
              <div className="bg-night-900 px-5 py-5">
                <p className="text-[11px] font-bold tracking-wider text-sage uppercase">
                  📄 Résumé texte — {city.name}, sans carte (mode low data)
                </p>
                {textSummary.length === 0 ? (
                  <p className="mt-3 text-[14px] leading-relaxed">
                    ✅ Circulation globalement fluide à {city.name} en ce moment : aucun axe sous les 55/100 de
                    fluidité. Vous pouvez prendre vos itinéraires habituels.
                  </p>
                ) : (
                  <ul className="mt-3 space-y-3">
                    {textSummary.map(({ axis, alt }) => (
                      <li key={axis.axisId} className="rounded-2xl bg-night-800/70 px-4 py-3 text-[13.5px] leading-relaxed">
                        {axis.level === "sature" ? "🔴" : axis.level === "congestion" ? "🟠" : "🟡"}{" "}
                        <b>{axis.name}</b> : {LEVEL_LABELS[axis.level].toLowerCase()}, {Math.round(axis.speedKmh)}{" "}
                        km/h ({SOURCE_LABELS[axis.dataSource].toLowerCase()}
                        {axis.simulated ? ", simulateur démo" : ""}).
                        {alt && (
                          <>
                            {" "}
                            → Alternative plus fluide : <b className="text-mint-300">{alt.name}</b> (
                            {Math.round(alt.speedKmh)} km/h).
                          </>
                        )}
                      </li>
                    ))}
                  </ul>
                )}
                <p className="mt-4 text-[12px] text-sage">
                  Pour un trajet précis porte-à-porte, utilisez le calculateur d&apos;itinéraire ventilé ci-dessous —
                  il tient compte de ces encombrements.
                </p>
              </div>
            ) : (
            <svg viewBox="0 0 840 480" className="block w-full bg-[#0a1f12]">
              {/* fond stylisé */}
              <defs>
                <pattern id="grid" width="42" height="42" patternUnits="userSpaceOnUse">
                  <path d="M 42 0 L 0 0 0 42" fill="none" stroke="#123120" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="840" height="480" fill="url(#grid)" />
              {(cityId === "dakar" || cityId === "abidjan") && (
                <path d="M0,0 L150,0 C110,120 190,210 120,330 C80,400 120,450 90,480 L0,480 Z" fill="#0d2f45" opacity="0.85" />
              )}
              {cityId === "bamako" && (
                <path d="M0,395 C200,360 420,420 620,385 C720,368 790,385 840,375 L840,480 L0,480 Z" fill="#0d2f45" opacity="0.85" />
              )}
              {cityId === "ouagadougou" && (
                <path d="M560,480 C590,380 545,300 610,205 C650,148 640,60 690,0 L840,0 L840,480 Z" fill="#123524" opacity="0.7" />
              )}

              {/* calque H3 : densité GPS par cellule hexagonale (rés. 9) */}
              {showH3 &&
                (() => {
                  const project = gpsToSvg(city);
                  if (!project) return null;
                  const maxCount = Math.max(1, ...h3Cells.map((c) => c.count));
                  return h3Cells.map((cellData) => {
                    const pts = cellData.boundary
                      .map(([lat, lon]) => {
                        const [x, y] = project(lat, lon);
                        return `${x},${y}`;
                      })
                      .join(" ");
                    const color =
                      cellData.avgSpeedKmh >= 32
                        ? "#22b573"
                        : cellData.avgSpeedKmh >= 18
                          ? "#ffb020"
                          : "#ff5d47";
                    return (
                      <polygon
                        key={cellData.cell}
                        points={pts}
                        fill={color}
                        opacity={0.14 + (cellData.count / maxCount) * 0.4}
                        stroke={color}
                        strokeWidth={0.7}
                        strokeOpacity={0.5}
                        className="pointer-events-none"
                      >
                        <title>
                          Cellule H3 : {cellData.count} GPS · vitesse moy. {cellData.avgSpeedKmh} km/h
                        </title>
                      </polygon>
                    );
                  });
                })()}

              {/* calque Zones à risque : inondables (bleu) + chaussées dégradées (ambre) */}
              {showRisk &&
                heat.axes
                  .filter((a) => a.floodProne || a.potholes >= 0.5)
                  .map((axis) => {
                    const d = axis.path.map((p, i) => `${i === 0 ? "M" : "L"}${p[0]},${p[1]}`).join(" ");
                    return (
                      <path
                        key={`risk-${axis.axisId}`}
                        d={d}
                        fill="none"
                        stroke={axis.floodProne ? "#38bdf8" : "#f59e0b"}
                        strokeWidth={15}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        opacity={0.22}
                        className="pointer-events-none"
                      >
                        <title>{axis.floodProne ? "Zone inondable" : "Chaussée dégradée (nids-de-poule)"}</title>
                      </path>
                    );
                  })}

              {/* axes */}
              {heat.axes.map((axis) => {
                const color =
                  viewMode === "donnees" ? SOURCE_COLORS[axis.dataSource] : LEVEL_COLORS[axis.level];
                const isSel = selected?.axisId === axis.axisId;
                const d = axis.path.map((p, i) => `${i === 0 ? "M" : "L"}${p[0]},${p[1]}`).join(" ");
                const mid = axis.path[Math.floor(axis.path.length / 2)];
                return (
                  <g key={axis.axisId}>
                    <path
                      d={d}
                      fill="none"
                      stroke={isSel ? "#ffffff" : "transparent"}
                      strokeWidth={isSel ? 11 : 0}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      opacity={0.35}
                    />
                    <path
                      d={d}
                      fill="none"
                      stroke={color}
                      strokeWidth={isSel ? 6.5 : 4.5}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className={
                        viewMode === "trafic" && (axis.level === "sature" || axis.level === "congestion")
                          ? "axis-flow"
                          : undefined
                      }
                      opacity={0.95}
                    />
                    {viewMode === "trafic" && mid && (
                      <circle
                        cx={mid[0]}
                        cy={mid[1]}
                        r={4.5}
                        fill={SOURCE_COLORS[axis.dataSource]}
                        stroke="#0a1f12"
                        strokeWidth={1.6}
                        className="pointer-events-none"
                      >
                        <title>
                          {axis.name} — donnée : {SOURCE_LABELS[axis.dataSource]}
                          {axis.simulated ? " (simulateur démo)" : ""}
                        </title>
                      </circle>
                    )}
                    <path
                      d={d}
                      fill="none"
                      stroke="transparent"
                      strokeWidth={18}
                      className="cursor-pointer"
                      onClick={() => setSelectedAxisId(axis.axisId)}
                    >
                      <title>{axis.name}</title>
                    </path>
                  </g>
                );
              })}

              {/* zones */}
              {city.zones.map((z) => (
                <g key={z.id} className="pointer-events-none">
                  <circle cx={z.x} cy={z.y} r={4} fill="#e9f6ee" stroke="#0a1f12" strokeWidth={2} />
                  <text x={z.x + 8} y={z.y + 3} fontSize={11} fontWeight={600} fill="#cfe8d8" style={{ textShadow: "0 1px 3px #000" }}>
                    {z.name}
                  </text>
                </g>
              ))}
            </svg>
            )}
            <div className="flex flex-wrap gap-x-5 gap-y-1.5 border-t border-night-600/70 px-4 py-3 text-[11px] font-medium text-sage">
              {viewMode === "donnees" ? (
                <>
                  {(Object.keys(SOURCE_COLORS) as AxisLiveState["dataSource"][]).map((src) => (
                    <span key={src} className="flex items-center gap-1.5">
                      <span className="h-2 w-5 rounded-full" style={{ background: SOURCE_COLORS[src] }} />
                      {src === "reel" ? "🟢" : src === "estime" ? "🟠" : "⚪"} {SOURCE_LABELS[src]}
                      {heat ? ` (${heat.dataCoverage[src]})` : ""}
                    </span>
                  ))}
                  <span className="ml-auto">Vue « Qualité des données » : d&apos;où vient la donnée de chaque axe</span>
                </>
              ) : (
                <>
                  {(Object.keys(LEVEL_COLORS) as AxisLiveState["level"][]).map((lvl) => (
                    <span key={lvl} className="flex items-center gap-1.5">
                      <span className="h-2 w-5 rounded-full" style={{ background: LEVEL_COLORS[lvl] }} />
                      {LEVEL_LABELS[lvl]}
                    </span>
                  ))}
                  <span className="ml-auto">Pastille = provenance de la donnée (🟢 GPS &lt; 5 min · 🟠 estimation IA · ⚪ aucune) · flux animé = congestion</span>
                </>
              )}
              {showH3 && (
                <span className="w-full text-violet-300">
                  ⬡ Cellules H3 (rés. 9, ~0,1 km²) : {h3Cells.length} cellules, {h3Points} GPS sur 1 h — couleur =
                  vitesse moyenne, opacité = densité de points
                </span>
              )}
              {showRisk && (
                <span className="w-full text-sky-300">
                  🌊 Calque risque : halo bleu = axes inondables · halo ambre = chaussées dégradées (nids-de-poule ≥ 50 %)
                </span>
              )}
            </div>
          </div>

          <div className="space-y-4">
            <div data-reveal className="rounded-3xl border border-night-600 bg-night-900 p-4">
              <p className="flex items-center justify-between text-[12px] font-bold tracking-wide uppercase">
                <span className="flex items-center gap-1.5">
                  <Satellite className="h-4 w-4 text-brand-500" /> Couverture des données — {city.name}
                </span>
                <span className="font-mono text-[10.5px] font-semibold text-sage normal-case">
                  {heat.dataCoverage.reel}🟢 · {heat.dataCoverage.estime}🟠 · {heat.dataCoverage.aucune}⚪
                </span>
              </p>
              <div className="mt-2.5 flex h-2.5 overflow-hidden rounded-full bg-night-950">
                <div className="h-full bg-[#22c55e] transition-all duration-700" style={{ width: `${(heat.dataCoverage.reel / Math.max(1, heat.axes.length)) * 100}%` }} />
                <div className="h-full bg-[#f97316] transition-all duration-700" style={{ width: `${(heat.dataCoverage.estime / Math.max(1, heat.axes.length)) * 100}%` }} />
                <div className="h-full bg-[#6b7280] transition-all duration-700" style={{ width: `${(heat.dataCoverage.aucune / Math.max(1, heat.axes.length)) * 100}%` }} />
              </div>
              <p className="mt-2 text-[11.5px] leading-relaxed text-sage">
                🟢 <b className="text-paper">Vert</b> : GPS mesurés il y a &lt; 5 min · 🟠 <b className="text-paper">Orange</b> :
                estimation IA (historique) · ⚪ <b className="text-paper">Gris</b> : aucune donnée reçue.
                {heat.dataCoverage.simulatedAxes > 0 &&
                  ` ${heat.dataCoverage.simulatedAxes} axe(s) alimenté(s) par le simulateur de démonstration.`}
              </p>
              {heat.coldStart && (
                <p className="mt-2 rounded-xl border border-sky-500/40 bg-sky-500/10 px-3 py-2 text-[11.5px] leading-relaxed text-sky-200">
                  ❄️ <b>Cold start</b> : {heat.realPoints24h} point(s) GPS réel(s) reçu(s) sur 24 h à {city.name}. Tant
                  que la barre des 5 points réels n&apos;est pas atteinte, les scores de confiance de l&apos;IA sont
                  masqués et remplacés par le badge « Mode estimation historique » — pas de précision affichée sans
                  données pour l&apos;étayer.
                </p>
              )}
              <button
                onClick={() => void runSimulator()}
                disabled={simulating}
                className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-night-700 py-2.5 text-[12.5px] font-bold transition hover:bg-night-600 disabled:opacity-60"
                title="Injecte des traces GPS de démonstration qui circulent sur les axes (source « simulateur », tracée)"
              >
                {simulating ? <Loader2 className="h-4 w-4 animate-spin" /> : <Satellite className="h-4 w-4" />}
                Générer des traces GPS (simulateur démo)
              </button>
              {simMsg && <p className="mt-2 text-[11.5px] leading-relaxed text-mint-300">{simMsg}</p>}
            </div>

            <div data-reveal className="rounded-3xl border border-night-600 bg-night-900 p-3">
              <label className="relative block">
                <Search className="absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-sage" />
                <input
                  value={axisQuery}
                  onChange={(e) => setAxisQuery(e.target.value)}
                  placeholder="Rechercher un axe (ex. VDN, Corniche…)"
                  className="w-full rounded-xl border border-night-600 bg-night-800 py-2 pr-3 pl-9 text-[13px] outline-none placeholder:text-sage/60 focus:border-brand-500"
                />
              </label>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {["tous", "fluide", "dense", "congestion", "sature"].map((lvl) => (
                  <button
                    key={lvl}
                    onClick={() => setLevelFilter(lvl)}
                    className={`rounded-full px-2.5 py-1 text-[11px] font-semibold transition ${
                      levelFilter === lvl ? "bg-brand-500 text-night-950" : "bg-night-800 text-sage hover:text-paper"
                    }`}
                  >
                    {lvl === "tous" ? `Tous (${sortedAxes.length})` : LEVEL_LABELS[lvl as AxisLiveState["level"]]}
                  </button>
                ))}
              </div>
            </div>
            <div data-reveal className="thin-scroll max-h-105 overflow-y-auto rounded-3xl border border-night-600 bg-night-900 p-2">
              {visibleAxes.length === 0 && (
                <p className="px-3 py-6 text-center text-[12.5px] text-sage">
                  Aucun axe ne correspond à ces filtres.
                </p>
              )}
              {visibleAxes.map((axis) => {
                const color = LEVEL_COLORS[axis.level];
                const isSel = selected?.axisId === axis.axisId;
                return (
                  <button
                    key={axis.axisId}
                    onClick={() => setSelectedAxisId(axis.axisId)}
                    className={`flex w-full items-center gap-3 rounded-2xl px-3 py-2.5 text-left transition ${
                      isSel ? "bg-night-700 ring-1 ring-mint-400/40" : "hover:bg-night-800"
                    }`}
                  >
                    <span className="h-8 w-1.5 shrink-0 rounded-full" style={{ background: color }} />
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[13px] font-semibold">{axis.short}</span>
                      <span className="mt-0.5 flex items-center gap-1.5 text-[11px] text-sage">
                        {Math.round(axis.speedKmh)} km/h
                        <span
                          className="h-2 w-2 shrink-0 rounded-full"
                          style={{ background: SOURCE_COLORS[axis.dataSource] }}
                          title={SOURCE_LABELS[axis.dataSource]}
                        />
                        {axis.dataSource === "reel"
                          ? `GPS < 5 min${axis.simulated ? " (démo)" : ""}`
                          : axis.dataSource === "estime"
                            ? "estimation IA"
                            : "aucune donnée"}
                      </span>
                    </span>
                    <span className="text-right">
                      <span className="block font-display text-[15px] font-bold" style={{ color }}>
                        {axis.fluidity}
                      </span>
                      <span className="block text-[9px] tracking-wide text-sage uppercase">fluidité</span>
                    </span>
                  </button>
                );
              })}
            </div>
            {selected && (
              <div data-reveal>
                <AxisDetail axis={selected} />
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
}
