"use client";

import Link from "next/link";
import { ACCESS_PLANS } from "./AccountAccess";

export default function PricingSection() {
  return (
    <section id="tarifs" className="scroll-mt-24 border-t border-night-600/60 bg-night-900/50">
      <div className="mx-auto max-w-7xl px-4 py-14 sm:px-6">
        <div data-reveal>
          <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
            <span className="inline-block h-px w-8 bg-brand-500" /> 08 · Tarifs
          </p>
          <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
            Votre accès, <span className="text-brand-500">pour la durée de votre choix</span>
          </h2>
          <p className="mt-2 max-w-3xl text-[14px] leading-relaxed text-sage">
            Choisissez votre durée d’accès depuis votre compte : 24 heures, 7 jours ou un mois.
          </p>
        </div>

        <div className="mt-8 grid gap-4 md:grid-cols-3">
          {ACCESS_PLANS.map((plan) => <article key={plan.id} className="rounded-3xl border border-brand-500/40 bg-night-900 p-6">
            <h3 className="font-display text-2xl font-bold">Accès {plan.label}</h3>
            <p className="mt-3 text-sm text-sage">Prix affiché au paiement</p>
            <Link href={`/compte?plan=${plan.id}`} className="mt-5 inline-block rounded-xl bg-brand-500 px-5 py-3 text-sm font-bold text-night-950">Choisir cet accès</Link>
          </article>)}
        </div>
        <p className="mt-4 text-sm text-sage">Le paiement sécurisé est créé par notre serveur et lié à votre compte. L’accès est activé uniquement après confirmation du paiement.</p>
      </div>
    </section>
  );
}
