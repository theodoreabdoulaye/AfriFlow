/**
 * Formatage de l'heure locale d'une ville : le payload encode l'heure
 * locale en composantes UTC (cityTime), on la lit donc en getUTC*.
 */
export function formatCityClock(cityTimeIso: string | null | undefined, fallback: Date): string {
  const d = cityTimeIso ? new Date(cityTimeIso) : fallback;
  const hh = cityTimeIso ? d.getUTCHours() : d.getHours();
  const mm = cityTimeIso ? d.getUTCMinutes() : d.getMinutes();
  return `${hh}h${String(mm).padStart(2, "0")}`;
}

/** Date d'affichage du contexte : heure locale ville + projection éventuelle. */
export function cityDisplayDate(
  cityTimeIso: string | null | undefined,
  projectedHour: number | null,
  fallback: Date,
): Date {
  const base = cityTimeIso ? new Date(cityTimeIso) : new Date(fallback);
  if (projectedHour !== null) base.setUTCHours(projectedHour, base.getUTCMinutes(), 0, 0);
  return base;
}

export function cityHourLabel(d: Date, fromCityTime: boolean): string {
  const hh = fromCityTime ? d.getUTCHours() : d.getHours();
  const mm = fromCityTime ? d.getUTCMinutes() : d.getMinutes();
  return `${hh}h${String(mm).padStart(2, "0")}`;
}
