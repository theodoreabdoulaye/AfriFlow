import { getCurrentUser } from "@/lib/auth";
import { getAccess } from "@/lib/access";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
const headers = { "Cache-Control": "private, no-store", Vary: "Cookie" };

export async function GET() {
  try {
    const user = await getCurrentUser();
    const access = user ? await getAccess(user.id) : { active: false, expiresAt: null };
    return Response.json({ user, ...access }, { headers });
  } catch {
    return Response.json({ error: "Access service unavailable" }, { status: 503, headers });
  }
}
