import { test } from "node:test";
import assert from "node:assert/strict";
import { contentSecurityPolicy, securityHeaders } from "../src/lib/security-headers";
import { GET } from "../src/app/.well-known/security.txt/route";

test("production CSP uses a nonce without unsafe inline scripts or eval", () => {
  const policy = contentSecurityPolicy("unique-test-nonce");
  const script = policy.split(";").find(p => p.trim().startsWith("script-src"))!;
  assert.ok(script.includes("'nonce-unique-test-nonce'"));
  assert.ok(!script.includes("'unsafe-inline'"));
  assert.ok(!script.includes("'unsafe-eval'"));
  for (const directive of ["object-src 'none'", "base-uri 'none'", "frame-ancestors 'none'", "upgrade-insecure-requests"]) assert.ok(policy.includes(directive));
  assert.ok(contentSecurityPolicy("test", true).includes("'unsafe-eval'"));
});

test("isolation, transport and resource headers are explicit", () => {
  const headers = Object.fromEntries(securityHeaders.map(h => [h.key, h.value]));
  assert.equal(headers["Cross-Origin-Resource-Policy"], "same-origin");
  assert.equal(headers["Cross-Origin-Embedder-Policy"], "credentialless");
  assert.equal(headers["Cross-Origin-Opener-Policy"], "same-origin-allow-popups");
  assert.equal(headers["X-Frame-Options"], "DENY");
  assert.equal(headers["Strict-Transport-Security"], "max-age=31536000");
});

test("security.txt exposes a disclosure contact and an unexpired expiry", async () => {
  const response = GET();
  assert.match(response.headers.get("content-type")!, /text\/plain; charset=utf-8/);
  const text = await response.text();
  assert.ok(text.includes("Contact: https://wa.me/221772015751"));
  const expires = text.match(/Expires: (.*)/)![1];
  assert.ok(new Date(expires).getTime() > Date.now());
});
