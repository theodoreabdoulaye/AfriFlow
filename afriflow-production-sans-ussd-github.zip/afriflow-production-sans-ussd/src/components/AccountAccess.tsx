"use client";

import Link from "next/link";
import { useEffect, useState, type FormEvent } from "react";
import { COUNTRIES } from "@/lib/cities";
import GoogleAuth, { recaptchaToken } from "./GoogleAuth";

// Server product mapping: day -> prd_3axt0ryr, week -> prd_049ep2ma,
// month -> prd_bcc94ior. Only the plan key is sent; identity comes from the session.
export const ACCESS_PLANS = [
  { id: "day", label: "24h" },
  { id: "week", label: "7 jours" },
  { id: "month", label: "1 mois" },
] as const;
type Access = { user: { id: string; email: string; name: string } | null; active: boolean; expiresAt: string | null };
const field = "mt-1 w-full rounded-xl border border-night-600 bg-night-800 px-3 py-3 text-paper outline-none focus:border-brand-500";
const button = "rounded-xl bg-brand-500 px-5 py-3 text-sm font-bold text-night-950 hover:bg-mint-400 disabled:opacity-50";

export default function AccountAccess() {
  const [access, setAccess] = useState<Access | null>(null);
  const [mode, setMode] = useState<"login" | "register">("login");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");
  const [plan, setPlan] = useState<string>("day");
  const [pending, setPending] = useState(false);

  useEffect(() => {
    let disposed = false;
    let request = 0;
    const refresh = async () => {
      const current = ++request;
      try {
        const res = await fetch("/api/access", { cache: "no-store" });
        if (!res.ok) throw new Error("Impossible de vérifier votre accès. Réessayez.");
        const data = await res.json() as Access;
        if (!disposed && current === request) {
          setAccess(data); setError("");
          if (current === 1) {
            const chosen = new URLSearchParams(window.location.search).get("plan");
            if (ACCESS_PLANS.some(p => p.id === chosen)) setPlan(chosen!);
          }
        }
      } catch (err) {
        if (!disposed && current === request) { setAccess(null); setError(err instanceof Error ? err.message : "Service indisponible."); }
      }
    };
    void refresh();
    const timer = window.setInterval(() => void refresh(), 30_000);
    window.addEventListener("focus", refresh);
    window.addEventListener("afri:account", refresh);
    return () => { disposed = true; clearInterval(timer); window.removeEventListener("focus", refresh); window.removeEventListener("afri:account", refresh); };
  }, []);

  const authenticate = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setBusy(true); setError(""); setMessage("");
    try {
      const token = await recaptchaToken(mode);
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: form.get("email"), password: form.get("password"), recaptchaToken: token, ...(mode === "register" ? { name: form.get("name") } : {}) }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Connexion impossible.");
      setMessage("Compte connecté. La création d’un compte ne donne pas d’accès payant.");
      window.dispatchEvent(new Event("afri:account"));
    } catch (err) { setError(err instanceof Error ? err.message : "Service indisponible."); }
    finally { setBusy(false); }
  };

  const logout = async () => {
    setBusy(true); setError("");
    try {
      const res = await fetch("/api/auth/logout", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
      if (!res.ok) throw new Error("Déconnexion impossible. Réessayez.");
      setAccess(null); setPending(false); setMessage("Vous êtes déconnecté.");
      window.dispatchEvent(new Event("afri:account"));
    } catch (err) { setError(err instanceof Error ? err.message : "Service indisponible."); }
    finally { setBusy(false); }
  };

  const checkout = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setBusy(true); setError(""); setMessage("");
    try {
      const res = await fetch("/api/v1/payment/checkout", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan, phone: form.get("phone"), countryCode: form.get("countryCode") }),
      });
      const data = await res.json() as { error?: string; checkoutUrl: string | null; pending: boolean };
      if (!res.ok) {
        if (res.status === 401) { setAccess(null); window.dispatchEvent(new Event("afri:account")); }
        throw new Error(data.error || "Paiement indisponible.");
      }
      setPending(true);
      setMessage("Paiement en attente de confirmation. L’accès ne sera activé qu’après validation par le serveur.");
      window.dispatchEvent(new Event("afri:account"));
      if (data.checkoutUrl) {
        const url = new URL(data.checkoutUrl);
        if (url.protocol !== "https:" || url.username || url.password) throw new Error("Lien de paiement invalide.");
        window.location.assign(url.href);
      }
    } catch (err) { setError(err instanceof Error ? err.message : "Service indisponible."); }
    finally { setBusy(false); }
  };

  return <main className="min-h-screen bg-night-950 px-4 py-10 text-paper sm:px-6">
    <div className="mx-auto max-w-3xl">
      <Link href="/" className="text-sm font-semibold text-brand-500">← Retour à AfriFlow</Link>
      <h1 className="mt-6 font-display text-4xl font-bold">Mon compte <span className="text-brand-500">& mon accès</span></h1>
      <div aria-live="polite" className="mt-6">{message && <p className="rounded-xl bg-brand-500/10 p-4 text-mint-300">{message}</p>}</div>
      {error && <p role="alert" className="mt-4 rounded-xl bg-coral/10 p-4 text-coral">{error}</p>}
      <section className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-6">
        {access?.user ? <>
          <h2 className="font-display text-2xl font-bold">Bonjour {access.user.name}</h2>
          <p className="mt-2 text-sage">{access.user.email}</p>
          <p className="mt-4">{access.active ? "Accès actif" : "Aucun accès actif"}</p>
          {access.expiresAt && <p className="mt-2 text-sm text-sage">Expiration : <time dateTime={access.expiresAt}>{new Date(access.expiresAt).toLocaleString("fr-FR")}</time></p>}
          <button onClick={() => void logout()} disabled={busy} className={`${button} mt-4`}>Se déconnecter</button>
        </> : <>
          <div className="flex flex-wrap gap-3">
            <button type="button" aria-pressed={mode === "login"} onClick={() => setMode("login")} className={button}>Se connecter</button>
            <button type="button" aria-pressed={mode === "register"} onClick={() => setMode("register")} className={button}>Créer un compte</button>
          </div>
          <form onSubmit={authenticate} className="mt-6 space-y-4">
            <GoogleAuth onError={setError} onSuccess={() => { setError(""); setMessage("Compte Google connecté."); window.dispatchEvent(new Event("afri:account")); }} />
            {mode === "register" && <label className="block">Nom<input name="name" autoComplete="name" required maxLength={80} className={field} /></label>}
            <label className="block">Adresse e-mail<input name="email" type="email" autoComplete="email" required maxLength={254} className={field} /></label>
            <label className="block">Mot de passe (12 caractères minimum)<input name="password" type="password" autoComplete={mode === "register" ? "new-password" : "current-password"} required minLength={12} maxLength={128} className={field} /></label>
            <button disabled={busy} className={button}>{busy ? "Veuillez patienter…" : mode === "register" ? "Créer mon compte" : "Connexion"}</button>
            <p className="text-sm text-sage">Créer un compte est gratuit, mais ne débloque pas les services payants. La réinitialisation du mot de passe n’est pas disponible ici.</p>
          </form>
        </>}
      </section>
      <section className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-6">
        <h2 className="font-display text-2xl font-bold">Choisir ou renouveler mon accès</h2>
        <p className="mt-3 text-sm leading-relaxed text-sage">Paiement sécurisé : notre serveur crée le paiement et le lie à votre compte connecté, sans widget indépendant. Seule la confirmation du paiement active votre accès.</p>
        <form onSubmit={checkout} className="mt-6 space-y-4">
          <fieldset><legend className="mb-3">Durée d’accès</legend><div className="grid gap-3 sm:grid-cols-3">{ACCESS_PLANS.map(p => <label key={p.id} className="rounded-2xl border border-night-600 bg-night-800 p-4"><input type="radio" name="plan" value={p.id} checked={plan === p.id} onChange={() => setPlan(p.id)} className="mr-2" />{p.label}<span className="mt-2 block text-xs text-sage">Prix affiché au paiement</span></label>)}</div></fieldset>
          <label className="block">Téléphone Mobile Money<input name="phone" type="tel" autoComplete="tel" required maxLength={40} className={field} /></label>
          <label className="block">Pays du numéro<select name="countryCode" defaultValue="SN" className={field}>{COUNTRIES.map(c => <option key={c.code} value={c.code}>{c.name}</option>)}</select></label>
          <button disabled={busy || !access?.user || pending} className={button}>{pending ? "Confirmation en attente" : "Continuer vers le paiement sécurisé"}</button>
          {!access?.user && <p className="text-sm text-sage">Connectez-vous avant de payer.</p>}
        </form>
      </section>
    </div>
  </main>;
}
