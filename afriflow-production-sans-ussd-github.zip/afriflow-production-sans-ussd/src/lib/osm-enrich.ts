import type { AxisDef, CityDef } from "./cities";
import { distanceToSegmentM } from "./cities";

/**
 * Enrichissement RÉEL du graphe routier via Overpass (OpenStreetMap) :
 * pour chaque axe AfriFlow, on cherche la voie OSM correspondante et on
 * récupère ses attributs cruciaux — surface (asphalte/terre/pavé), lanes
 * (nombre de voies), maxspeed, oneway. Le moteur applique ensuite :
 *   surface ≠ asphalte  → vitesse de base −40 %
 *   maxspeed OSM        → plafond de la vitesse libre
 * Actualisation en arrière-plan, cache 24 h, requêtes coalescées.
 */

export interface OsmAxisMeta {
  /** Identifiant OSM réel de la voie appariée (way id). */
  wayId: number | null;
  surface: string | null;
  lanes: number | null;
  maxspeedKmh: number | null;
  oneway: boolean;
  wayName: string | null;
  highway: string | null;
  /** Capacité INFÉRÉE des tags OSM : base(highway) × lanes (véh/h). */
  capacityVph: number;
  /** Risque d'inondation INFÉRÉ (surface non revêtue, layer < 0) : 0..1. */
  floodRisk: number;
  /** Sévérité des nids-de-poule INFÉRÉE (smoothness, surface) : 0..1. */
  potholeSeverity: number;
}

/* ------------------------------------------------------------------ */
/* Inférence des attributs manquants depuis les tags OSM               */
/* (OSM ne taggue ni capacity_vph, ni flood_risk, ni les nids-de-poule) */
/* ------------------------------------------------------------------ */

const BASE_CAPACITY_VPH: Record<string, number> = {
  motorway: 2000,
  trunk: 2000,
  primary: 1500,
  secondary: 1000,
  tertiary: 800,
};

export function inferCapacityVph(highway: string | null, lanes: number | null): number {
  const base = BASE_CAPACITY_VPH[highway ?? ""] ?? 400; // residential, unclassified…
  return base * (lanes ?? 1);
}

export function inferFloodRisk(surface: string | null, layer: number | null): number {
  let risk = 0.1;
  if (surface && ["sand", "dirt", "unpaved", "ground", "earth", "gravel"].includes(surface)) {
    risk += 0.5; // routes non asphaltées très vulnérables (heuristique Sénégal)
  }
  if ((layer ?? 0) < 0) risk += 0.3; // sous le niveau du sol
  return Math.min(1, Math.round(risk * 100) / 100);
}

export function inferPotholeSeverity(surface: string | null, smoothness: string | null): number {
  if (smoothness === "horrible" || smoothness === "very_bad") return 0.9;
  if (smoothness === "bad") return 0.6;
  if (smoothness === "intermediate") return 0.3;
  if (surface === "unpaved") return 0.4;
  return 0.1;
}

export interface OsmEnrichment {
  cityId: string;
  status: "ready" | "pending" | "unavailable";
  fetchedAt: number | null;
  matchedAxes: number;
  totalAxes: number;
  byAxis: Map<string, OsmAxisMeta>;
}

const ENDPOINTS = [
  "https://overpass.openstreetmap.fr/api/interpreter",
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
];

const FRESH_MS = 24 * 3600_000;

const enrichments = new Map<string, OsmEnrichment>();
const inflight = new Map<string, Promise<void>>();

interface OsmWay {
  id: number | null;
  name: string | null;
  highway: string | null;
  surface: string | null;
  smoothness: string | null;
  layer: number | null;
  lanes: number | null;
  maxspeedKmh: number | null;
  oneway: boolean;
  lat: number;
  lon: number;
}

function normalize(s: string): string {
  return s
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function nameScore(wayName: string | null, axis: AxisDef): number {
  if (!wayName) return 0;
  const w = new Set(normalize(wayName).split(" ").filter((t) => t.length > 2));
  const a = new Set(normalize(`${axis.name} ${axis.short}`).split(" ").filter((t) => t.length > 2));
  let hits = 0;
  for (const t of w) if (a.has(t)) hits++;
  return hits;
}

function parseMaxspeed(raw: string | undefined): number | null {
  if (!raw) return null;
  const n = Number(raw.replace(/[^0-9]/g, ""));
  if (!Number.isFinite(n) || n <= 0) return null;
  return raw.includes("mph") ? Math.round(n * 1.609) : n;
}

async function fetchOsmWays(city: CityDef): Promise<OsmWay[] | null> {
  const query =
    `[out:json][timeout:30];` +
    `way["highway"~"^(motorway|trunk|primary|secondary|tertiary|unclassified|residential)$"]` +
    `(around:11000,${city.lat},${city.lon});out tags center 900;`;
  for (const endpoint of ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "AfriFlow/2.8 (enrichissement graphe OSM; contact: dev@afriflow.app)",
        },
        body: `data=${encodeURIComponent(query)}`,
        signal: AbortSignal.timeout(35000),
        cache: "no-store",
      });
      if (!res.ok) continue;
      const json = (await res.json()) as {
        elements?: {
          id?: number;
          tags?: Record<string, string>;
          center?: { lat: number; lon: number };
        }[];
      };
      const ways: OsmWay[] = [];
      for (const el of json.elements ?? []) {
        if (!el.center) continue;
        const tags = el.tags ?? {};
        ways.push({
          id: el.id ?? null,
          name: tags.name ?? null,
          highway: tags.highway ?? null,
          surface: tags.surface ?? null,
          smoothness: tags.smoothness ?? null,
          layer: tags.layer ? Number(tags.layer) || null : null,
          lanes: tags.lanes ? Number(tags.lanes) || null : null,
          maxspeedKmh: parseMaxspeed(tags.maxspeed),
          oneway: tags.oneway === "yes" || tags.oneway === "true" || tags.oneway === "1",
          lat: el.center.lat,
          lon: el.center.lon,
        });
      }
      if (ways.length > 0) return ways;
    } catch {
      /* instance suivante */
    }
  }
  return null;
}

function matchWays(city: CityDef, ways: OsmWay[]): Map<string, OsmAxisMeta> {
  const byAxis = new Map<string, OsmAxisMeta>();
  for (const axis of city.axes) {
    const mid = axis.gps[Math.floor(axis.gps.length / 2)];
    let best: { way: OsmWay; score: number; dist: number } | null = null;
    for (const way of ways) {
      let dist = Infinity;
      for (let i = 0; i < axis.gps.length - 1; i++) {
        dist = Math.min(dist, distanceToSegmentM([way.lat, way.lon], axis.gps[i], axis.gps[i + 1]));
      }
      if (dist > 450) continue;
      const score = nameScore(way.name, axis);
      if (
        !best ||
        score > best.score ||
        (score === best.score && dist < best.dist)
      ) {
        best = { way, score, dist };
      }
    }
    void mid;
    if (best) {
      byAxis.set(axis.id, {
        wayId: best.way.id,
        surface: best.way.surface,
        lanes: best.way.lanes,
        maxspeedKmh: best.way.maxspeedKmh,
        oneway: best.way.oneway,
        wayName: best.way.name,
        highway: best.way.highway,
        capacityVph: inferCapacityVph(best.way.highway, best.way.lanes),
        floodRisk: inferFloodRisk(best.way.surface, best.way.layer),
        potholeSeverity: inferPotholeSeverity(best.way.surface, best.way.smoothness),
      });
    }
  }
  return byAxis;
}

async function refreshEnrichment(city: CityDef): Promise<void> {
  const ways = await fetchOsmWays(city);
  if (!ways) {
    const prev = enrichments.get(city.id);
    enrichments.set(city.id, {
      cityId: city.id,
      status: prev?.status === "ready" ? "ready" : "unavailable",
      fetchedAt: prev?.fetchedAt ?? null,
      matchedAxes: prev?.matchedAxes ?? 0,
      totalAxes: city.axes.length,
      byAxis: prev?.byAxis ?? new Map(),
    });
    return;
  }
  const byAxis = matchWays(city, ways);
  enrichments.set(city.id, {
    cityId: city.id,
    status: "ready",
    fetchedAt: Date.now(),
    matchedAxes: byAxis.size,
    totalAxes: city.axes.length,
    byAxis,
  });
}

/** Déclenche (arrière-plan) l'enrichissement OSM si absent ou périmé. */
export function triggerOsmEnrichment(city: CityDef): void {
  if (inflight.has(city.id)) return;
  const current = enrichments.get(city.id);
  if (current?.status === "ready" && current.fetchedAt && Date.now() - current.fetchedAt < FRESH_MS) return;
  const task = refreshEnrichment(city).finally(() => inflight.delete(city.id));
  inflight.set(city.id, task);
  void task;
}

/**
 * Attend (au plus timeoutMs) que l'enrichissement OSM de la ville soit
 * prêt — utilisé par la synchronisation road_edges pour ne pas écrire
 * des arêtes sans attributs OSM.
 */
export async function awaitOsmEnrichment(city: CityDef, timeoutMs = 30_000): Promise<OsmEnrichment> {
  triggerOsmEnrichment(city);
  const pending = inflight.get(city.id);
  if (pending) {
    await Promise.race([
      pending,
      new Promise((resolve) => setTimeout(resolve, timeoutMs)),
    ]);
  }
  return getOsmEnrichment(city);
}

export function getOsmEnrichment(city: CityDef): OsmEnrichment {
  const current = enrichments.get(city.id);
  if (current) return current;
  return {
    cityId: city.id,
    status: inflight.has(city.id) ? "pending" : "unavailable",
    fetchedAt: null,
    matchedAxes: 0,
    totalAxes: city.axes.length,
    byAxis: new Map(),
  };
}

/* ------------------------------------------------------------------ */
/* Arrêts de transport public (OSM) — référence transport réelle       */
/* ------------------------------------------------------------------ */

const stopsCache = new Map<string, { at: number; count: number | null }>();
const stopsInflight = new Map<string, Promise<void>>();
const STOPS_FRESH_MS = 6 * 3600_000;

async function refreshBusStops(city: CityDef): Promise<void> {
  const query = `[out:json][timeout:20];node["highway"="bus_stop"](around:8000,${city.lat},${city.lon});out count;`;
  for (const endpoint of ENDPOINTS) {
    try {
      const res = await fetch(endpoint, {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "AfriFlow/2.9 (transport OSM; contact: dev@afriflow.app)",
        },
        body: `data=${encodeURIComponent(query)}`,
        signal: AbortSignal.timeout(22000),
        cache: "no-store",
      });
      if (!res.ok) continue;
      const json = (await res.json()) as { elements?: { tags?: Record<string, string> }[] };
      const tags = json?.elements?.[0]?.tags ?? {};
      const n = Number(tags.nodes ?? tags.total ?? NaN);
      if (Number.isFinite(n)) {
        stopsCache.set(city.id, { at: Date.now(), count: n });
        return;
      }
    } catch {
      /* instance suivante */
    }
  }
  const prev = stopsCache.get(city.id);
  stopsCache.set(city.id, { at: Date.now(), count: prev?.count ?? null });
}

/** Déclenche le comptage des arrêts en arrière-plan (jamais bloquant). */
export function triggerBusStopsRefresh(city: CityDef): void {
  if (stopsInflight.has(city.id)) return;
  const hit = stopsCache.get(city.id);
  if (hit && Date.now() - hit.at < STOPS_FRESH_MS) return;
  const task = refreshBusStops(city).finally(() => stopsInflight.delete(city.id));
  stopsInflight.set(city.id, task);
  void task;
}

/** Dernier comptage connu (null = jamais mesuré), sans attente réseau. */
export function busStopsSnapshot(city: CityDef): number | null {
  return stopsCache.get(city.id)?.count ?? null;
}
