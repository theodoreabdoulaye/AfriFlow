import assert from "node:assert/strict";
import { test } from "node:test";
import { hashPassword, isValidPassword, verifyPassword } from "../src/lib/password";

test("password length boundaries and type validation", () => {
  for (const value of [null, undefined, 42, "a".repeat(11), "a".repeat(129)]) assert.equal(isValidPassword(value), false);
  assert.equal(isValidPassword("a".repeat(12)), true);
  assert.equal(isValidPassword("a".repeat(128)), true);
});

test("salted hashes verify without accepting wrong passwords or corrupt hashes", async () => {
  const password = "correct horse battery staple";
  const first = await hashPassword(password);
  const second = await hashPassword(password);
  assert.notEqual(first, second);
  assert.match(first, /^scrypt\$16384\$8\$1\$[a-f0-9]{32}\$[a-f0-9]{128}$/);
  assert.equal(await verifyPassword(password, first), true);
  assert.equal(await verifyPassword("wrong password here", first), false);
  assert.equal(await verifyPassword(password, ""), false);
  assert.equal(await verifyPassword(password, first.replace("16384", "999999999")), false);
  assert.equal(await verifyPassword("short", first), false);
});

test("hashing rejects out-of-bounds passwords", async () => {
  await assert.rejects(hashPassword("short"), RangeError);
  await assert.rejects(hashPassword("a".repeat(129)), RangeError);
});
