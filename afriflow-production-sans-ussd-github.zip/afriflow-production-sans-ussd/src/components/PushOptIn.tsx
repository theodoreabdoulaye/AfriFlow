"use client";

import { useCallback, useEffect, useState } from "react";
import { Bell, BellRing, Loader2 } from "lucide-react";
import { useApp } from "./AppClient";

function urlBase64ToUint8Array(base64: string): Uint8Array {
  const padding = "=".repeat((4 - (base64.length % 4)) % 4);
  const raw = window.atob((base64 + padding).replace(/-/g, "+").replace(/_/g, "/"));
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
}

type PushState = "unknown" | "off" | "on" | "unsupported" | "denied" | "busy";

/**
 * Abonnement aux notifications push : le conducteur est alerté sur son
 * téléphone dès qu'un incident est validé par le consensus dans sa ville,
 * même application fermée.
 */
export default function PushOptIn() {
  const { cityId } = useApp();
  const [state, setState] = useState<PushState>("unknown");

  const refresh = useCallback(async () => {
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
      setState("unsupported");
      return;
    }
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.getSubscription();
      setState(sub ? "on" : "off");
    } catch {
      setState("off");
    }
  }, []);

  useEffect(() => {
    const t = window.setTimeout(() => void refresh(), 0);
    return () => clearTimeout(t);
  }, [refresh]);

  const toggle = async () => {
    if (state === "busy") return;
    setState("busy");
    try {
      const reg = await navigator.serviceWorker.ready;
      const existing = await reg.pushManager.getSubscription();
      if (existing) {
        await fetch("/api/push", {
          method: "DELETE",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ endpoint: existing.endpoint }),
        });
        await existing.unsubscribe();
        setState("off");
        return;
      }
      const permission = await Notification.requestPermission();
      if (permission !== "granted") {
        setState("denied");
        return;
      }
      const keyRes = await fetch("/api/push", { cache: "no-store" });
      const { publicKey } = (await keyRes.json()) as { publicKey?: string };
      if (!publicKey) throw new Error("Clé VAPID indisponible");
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: urlBase64ToUint8Array(publicKey) as BufferSource,
      });
      await fetch("/api/push", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ subscription: sub.toJSON(), city: cityId }),
      });
      setState("on");
    } catch {
      setState("off");
    }
  };

  if (state === "unsupported" || state === "unknown") return null;

  return (
    <button
      onClick={() => void toggle()}
      title={
        state === "denied"
          ? "Notifications refusées par le navigateur — réactivez-les dans ses réglages"
          : "Recevoir une notification dès qu'un incident est validé dans cette ville"
      }
      className={`flex items-center gap-2 rounded-xl px-3 py-2 text-[12px] font-semibold whitespace-nowrap transition ${
        state === "on"
          ? "bg-brand-500 text-night-950"
          : "bg-night-800 text-sage hover:text-paper"
      }`}
    >
      {state === "busy" ? (
        <Loader2 className="h-3.5 w-3.5 animate-spin" />
      ) : state === "on" ? (
        <BellRing className="h-3.5 w-3.5" />
      ) : (
        <Bell className="h-3.5 w-3.5" />
      )}
      {state === "on" ? "Alertes push actives" : state === "denied" ? "Push refusé" : "Alertes push"}
    </button>
  );
}
