"use client";

import { Component, type ReactNode } from "react";

interface Props {
  name: string;
  children: ReactNode;
}

interface State {
  hasError: boolean;
}

/**
 * Garde-fou d'affichage : si une section plante (données inattendues,
 * erreur de rendu), le reste de la page continue de fonctionner et
 * l'utilisateur peut réessayer la section fautive.
 */
export default class SectionBoundary extends Component<Props, State> {
  state: State = { hasError: false };

  static getDerivedStateFromError(): State {
    return { hasError: true };
  }

  componentDidCatch(error: unknown) {
    console.error(`[AfriFlow] Section « ${this.props.name} » en erreur :`, error);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
          <div className="rounded-3xl border border-coral/40 bg-night-900 px-6 py-8 text-center">
            <p className="font-display text-lg font-bold">La section « {this.props.name} » a rencontré un souci.</p>
            <p className="mt-1 text-sm text-sage">Le reste de la plateforme fonctionne normalement.</p>
            <button
              onClick={() => this.setState({ hasError: false })}
              className="mt-4 rounded-xl bg-brand-500 px-4 py-2 text-sm font-bold text-night-950 transition hover:bg-mint-400"
            >
              Réessayer cette section
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
