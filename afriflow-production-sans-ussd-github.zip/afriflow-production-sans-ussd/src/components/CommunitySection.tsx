"use client";

import Image from "next/image";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Car,
  CheckCheck,
  CloudRainWind,
  Construction,
  Info,
  Loader2,
  LocateFixed,
  MessageCircle,
  Send,
  Siren,
  Smartphone,
  TrafficCone,
  TriangleAlert,
  Wrench,
} from "lucide-react";
import { CITY_MAP, getAxis } from "@/lib/cities";
import type { IncidentRow } from "@/lib/api-types";
import { getDeviceHash } from "@/lib/device";
import { useApp } from "./AppClient";

export const INCIDENT_META: Record<string, { label: string; icon: typeof Car }> = {
  accident: { label: "Accident", icon: Car },
  bouchon: { label: "Bouchon", icon: TrafficCone },
  travaux: { label: "Travaux", icon: Construction },
  police: { label: "Police / contrôle", icon: Siren },
  inondation: { label: "Inondation", icon: CloudRainWind },
  panne: { label: "Panne / obstacle", icon: Wrench },
  danger: { label: "Danger", icon: TriangleAlert },
};

const CHANNEL_LABELS: Record<string, string> = {
  web: "📱 App / Web",
  ussd: "Signalement",
  whatsapp: "💬 WhatsApp",
  sms: "✉️ SMS",
};

export function timeAgo(iso: string): string {
  const min = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60_000));
  if (min < 1) return "à l'instant";
  if (min < 60) return `il y a ${min} min`;
  const h = Math.floor(min / 60);
  return `il y a ${h} h ${min % 60 ? `${min % 60} min` : ""}`.trim();
}

/* ------------------------------------------------------------------ */
/* Section communauté                                                  */
/* ------------------------------------------------------------------ */

export default function CommunitySection() {
  const { cityId, heat, selectedAxisId, setSelectedAxisId, refreshHeat } = useApp();
  const city = CITY_MAP[cityId];

  const [incidents, setIncidents] = useState<IncidentRow[]>([]);
  const [filter, setFilter] = useState<string>("tous");
  const [loadingFeed, setLoadingFeed] = useState(true);
  const [confirmedIds, setConfirmedIds] = useState<Set<number>>(new Set());
  const [confirmingId, setConfirmingId] = useState<number | null>(null);

  // formulaire web
  const [formType, setFormType] = useState("accident");
  const [formSeverity, setFormSeverity] = useState(3);
  const [formAxis, setFormAxis] = useState<string>(city.axes[0].id);
  const [formDesc, setFormDesc] = useState("");
  const [formDistinct, setFormDistinct] = useState(false);
  const [sending, setSending] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [locating, setLocating] = useState(false);
  const [geoMsg, setGeoMsg] = useState<string | null>(null);
  const [now, setNow] = useState<number | null>(null);

  useEffect(() => {
    const tick = () => setNow(Date.now());
    const t0 = window.setTimeout(tick, 0);
    const t = window.setInterval(tick, 30_000);
    return () => {
      clearTimeout(t0);
      clearInterval(t);
    };
  }, []);

  // Pré-remplissage intelligent : géolocalisation → axe le plus proche.
  const locateNearestAxis = () => {
    if (!("geolocation" in navigator)) {
      setGeoMsg("Géolocalisation non disponible sur cet appareil — choisissez l'axe dans la liste.");
      return;
    }
    setLocating(true);
    setGeoMsg(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        try {
          const res = await fetch(
            `/api/geo/nearest?city=${cityId}&lat=${pos.coords.latitude}&lon=${pos.coords.longitude}`,
            { cache: "no-store" },
          );
          const json = (await res.json()) as {
            axisId?: string;
            axisName?: string;
            distanceM?: number;
            place?: string | null;
            error?: string;
          };
          if (!res.ok || !json.axisId) throw new Error(json.error ?? "Position non rattachée");
          setFormAxis(json.axisId);
          setSelectedAxisId(json.axisId);
          setGeoMsg(
            `📍 Position détectée${json.place ? ` (${json.place})` : ""} → axe pré-sélectionné : ${json.axisName} (à ${json.distanceM} m).`,
          );
        } catch (e) {
          setGeoMsg(e instanceof Error ? e.message : "Impossible de rattacher votre position à un axe.");
        } finally {
          setLocating(false);
        }
      },
      () => {
        setLocating(false);
        setGeoMsg("Position refusée ou indisponible — choisissez l'axe manuellement dans la liste.");
      },
      { enableHighAccuracy: true, timeout: 12000, maximumAge: 30000 },
    );
  };

  // L'axe sélectionné sur la carte pilote le formulaire.
  useEffect(() => {
    if (!selectedAxisId) return;
    const t = window.setTimeout(() => setFormAxis(selectedAxisId), 0);
    return () => clearTimeout(t);
  }, [selectedAxisId]);

  // Changement de ville : garantir un axe du formulaire valide.
  useEffect(() => {
    const t = window.setTimeout(() => {
      setFormAxis((prev) => (city.axes.some((a) => a.id === prev) ? prev : city.axes[0].id));
      setFeedback(null);
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cityId]);

  const loadIncidents = useCallback(async () => {
    setLoadingFeed(true);
    try {
      const res = await fetch(`/api/incidents?city=${cityId}`, { cache: "no-store" });
      if (res.ok) {
        const json = (await res.json()) as { incidents: IncidentRow[] };
        setIncidents(json.incidents);
      }
    } catch {
      /* flux conservé */
    } finally {
      setLoadingFeed(false);
    }
  }, [cityId]);

  useEffect(() => {
    const t0 = window.setTimeout(() => void loadIncidents(), 0);
    const t = setInterval(() => void loadIncidents(), 25_000);
    // Une alerte vient d'être validée par le consensus : flux rafraîchi aussitôt.
    const onAlert = () => void loadIncidents();
    window.addEventListener("afri:alert", onAlert);
    return () => {
      clearTimeout(t0);
      clearInterval(t);
      window.removeEventListener("afri:alert", onAlert);
    };
  }, [loadIncidents]);

  const submitReport = async () => {
    setSending(true);
    setFeedback(null);
    try {
      const res = await fetch("/api/incidents", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          city: cityId,
          axisId: formAxis,
          type: formType,
          severity: formSeverity,
          channel: "web",
          network: "web",
          deviceHash: getDeviceHash(),
          distinct: formDistinct,
          description: formDesc.trim() || undefined,
        }),
      });
      const json = (await res.json()) as {
        merged?: boolean;
        duplicateNetwork?: boolean;
        incident?: IncidentRow;
        error?: string;
      };
      if (!res.ok) throw new Error(json.error ?? "Envoi impossible");
      setFeedback(
        json.duplicateNetwork
          ? "Vous avez déjà contribué à ce signalement (appareil ou connexion) — une seule voix par conducteur, pour un consensus fiable."
          : json.merged
            ? `Votre envoi a confirmé un signalement existant — confiance portée à ${json.incident?.confidence ?? ""} %.`
            : "Signalement enregistré (confiance 38 %). Il sera diffusé dès 3 confirmations de conducteurs distincts.",
      );
      setFormDesc("");
      setSelectedAxisId(formAxis);
      void loadIncidents();
      void refreshHeat();
    } catch (e) {
      setFeedback(e instanceof Error ? e.message : "Envoi impossible");
    } finally {
      setSending(false);
    }
  };

  const confirmIncident = async (id: number) => {
    setConfirmingId(id);
    try {
      const res = await fetch(`/api/incidents/${id}/confirm`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ network: "web", channel: "web", deviceHash: getDeviceHash() }),
      });
      if (res.ok) {
        setConfirmedIds((prev) => new Set(prev).add(id));
        void loadIncidents();
        void refreshHeat();
      }
    } catch {
      /* ignore */
    } finally {
      setConfirmingId(null);
    }
  };

  const filtered = useMemo(
    () => incidents.filter((i) => filter === "tous" || i.type === filter),
    [incidents, filter],
  );
  const formAxisName = getAxis(city, formAxis)?.short ?? "—";

  // Un signalement du même type existe-t-il déjà sur cet axe (< 45 min) ?
  // Si oui, l'envoi comptera comme une confirmation (sauf incident distinct).
  const similarIncident = useMemo(() => {
    if (now === null) return null;
    const since = now - 45 * 60_000;
    return (
      incidents.find(
        (i) =>
          i.axisId === formAxis &&
          i.type === formType &&
          new Date(i.createdAt).getTime() >= since,
      ) ?? null
    );
  }, [incidents, formAxis, formType, now]);

  return (
    <section id="communaute" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-14 sm:px-6">
      <div data-reveal>
        <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
          <span className="inline-block h-px w-8 bg-brand-500" /> 04 · Communauté
        </p>
        <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Ensemble, <span className="text-brand-500">signalons les incidents</span>
        </h2>
        <p className="mt-2 max-w-3xl text-[14px] leading-relaxed text-sage">
          Les conducteurs signalent les incidents depuis l&apos;application web. Rien n&apos;est diffusé avant
          le consensus de 3 conducteurs — fini les fausses alertes.
        </p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-2">
        <figure data-reveal className="overflow-hidden rounded-3xl border border-night-600 bg-night-900">
          <div className="relative h-64 sm:h-72">
            <Image
              src="https://images.pexels.com/photos/5835008/pexels-photo-5835008.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200"
              alt="Chauffeur de taxi consultant son téléphone dans la rue"
              fill
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
          </div>
          <figcaption className="p-5">
            <p className="text-[15px] leading-relaxed font-medium">
              « Je signale l&apos;accident dans l&apos;app. Deux collègues confirment : toute la ville est
              prévenue. »
            </p>
            <p className="mt-2 text-[12.5px] text-sage">
              Un signalement, deux confirmations : les conducteurs contribuent à une information partagée.
            </p>
          </figcaption>
        </figure>

        <div data-reveal className="rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
          <h3 className="flex items-center gap-2 font-display text-lg font-bold">
            <MessageCircle className="h-5 w-5 text-brand-500" /> Le consensus communautaire, en 3 temps
          </h3>
          <p className="mt-1.5 text-[12.5px] leading-relaxed text-sage">
            Tout passe par le <b className="text-paper">bot WhatsApp AfriFlow</b> et l&apos;app : aucun canal payant,
            aucun code à composer — un message suffit.
          </p>
          <div className="mt-4 space-y-3">
            {[
              {
                step: "1 · Signaler sur WhatsApp",
                text: "Un message au bot AfriFlow — texte ou vocal, en français ou en langue locale. 20 secondes, aucune application à installer, fonctionne aussi en vocal pour les conducteurs en route.",
              },
              {
                step: "2 · Confirmer ×3",
                text: "Deux autres conducteurs confirment directement dans WhatsApp (bouton « Je confirme ») ou dans l'app. La confiance grimpe à chaque confirmation (38 % → 71 % → 98 %).",
              },
              {
                step: "3 · Diffuser",
                text: "À 3 confirmations : alerte WhatsApp immédiate à tous les conducteurs proches, push app, bandeau radio partenaire et repondération des itinéraires — tout le monde est prévenu, même sans ouvrir l'app.",
              },
            ].map((s) => (
              <div key={s.step} className="flex gap-4 rounded-2xl bg-night-800/70 p-4">
                <p className="font-display text-[13px] font-bold whitespace-nowrap text-mint-300">{s.step}</p>
                <p className="text-[13px] leading-relaxed text-paper/85">{s.text}</p>
              </div>
            ))}
          </div>

          {/* Aperçu de la conversation WhatsApp */}
          <div className="mt-4 overflow-hidden rounded-2xl border border-night-600">
            <p className="flex items-center gap-2 bg-[#075e54] px-4 py-2.5 text-[12.5px] font-bold text-white">
              <span className="grid h-7 w-7 place-items-center rounded-full bg-white/20">
                <MessageCircle className="h-4 w-4" />
              </span>
              Bot AfriFlow — WhatsApp
              <span className="ml-auto flex items-center gap-1.5 text-[10.5px] font-medium text-white/80">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-300" /> en ligne
              </span>
            </p>
            <div className="space-y-2 bg-[#0b141a] px-3 py-3 text-[12px] leading-relaxed">
              <p className="ml-auto w-fit max-w-[85%] rounded-2xl rounded-tr-sm bg-[#005c4b] px-3 py-2 text-emerald-50">
                🚗 Accident sur la VDN, voie de droite bloquée
              </p>
              <p className="w-fit max-w-[85%] rounded-2xl rounded-tl-sm bg-[#1f2c34] px-3 py-2 text-slate-100">
                Reçu ! Gravité de l&apos;incident ?
                <span className="mt-2 flex gap-1.5">
                  <span className="rounded-full bg-[#2a3942] px-2 py-0.5 text-[10.5px] font-semibold">Faible</span>
                  <span className="rounded-full bg-[#2a3942] px-2 py-0.5 text-[10.5px] font-semibold">Forte</span>
                  <span className="rounded-full bg-[#2a3942] px-2 py-0.5 text-[10.5px] font-semibold">Bloquant</span>
                </span>
              </p>
              <p className="w-fit max-w-[85%] rounded-2xl rounded-tl-sm bg-[#1f2c34] px-3 py-2 text-slate-100">
                ✅ <b>Moussa (taxi)</b> confirme : « Je suis sur place »
              </p>
              <p className="mx-auto w-fit rounded-xl bg-amber-400/90 px-3 py-1.5 text-center text-[10.5px] font-bold text-slate-900">
                📣 Alerte diffusée — Accident VDN · 3 confirmations · confiance 98 %
              </p>
            </div>
          </div>

          <div className="mt-4 flex items-center gap-3 rounded-2xl border border-night-600 px-4 py-3">
            <div className="flex -space-x-1.5">
              {[38, 71, 98].map((c) => (
                <span
                  key={c}
                  className="grid h-8 w-8 place-items-center rounded-full border-2 border-night-900 text-[9px] font-bold text-night-950"
                  style={{ background: c === 98 ? "#22b573" : c === 71 ? "#ffb020" : "#9dbfab" }}
                >
                  {c}%
                </span>
              ))}
            </div>
            <p className="text-[12px] leading-relaxed text-sage">
              Seuil de diffusion : <b className="text-paper">3 conducteurs distincts</b> sur WhatsApp ou l&apos;app —
              identifiés par appareil anonyme, une seule voix par conducteur.
            </p>
          </div>
        </div>
      </div>

      {/* Formulaire App / Web — pleine largeur */}
      <div data-reveal className="mt-6 rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h3 className="flex items-center gap-2 font-display text-lg font-bold">
            <Smartphone className="h-5 w-5 text-brand-500" /> Signaler — App / Web
          </h3>
          <span className="rounded-full bg-brand-500/15 px-3 py-1 text-[10.5px] font-bold text-mint-300">
            CONSENSUS ×3 · DIFFUSION À 3 CONFIRMATIONS
          </span>
        </div>
        <div className="mt-3 rounded-xl bg-night-800/70 px-3 py-2 text-[12px] text-sage">
          L&apos;axe choisi est surligné sur la carte thermique ci-dessus — cliquez un axe de la carte pour remplir
          automatiquement ce formulaire.
        </div>

        <div className="mt-5 grid gap-6 lg:grid-cols-2">
          {/* Colonne gauche : type d'incident + gravité */}
          <div>
            <span className="mb-2 block text-[11px] font-semibold tracking-wide text-sage uppercase">
              Type d&apos;incident
            </span>
            <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
              {Object.entries(INCIDENT_META).map(([key, meta]) => {
                const Icon = meta.icon;
                const active = formType === key;
                return (
                  <button
                    key={key}
                    onClick={() => setFormType(key)}
                    className={`flex flex-col items-center gap-1.5 rounded-2xl border px-2 py-3 text-[12px] font-semibold transition ${
                      active ? "border-brand-500 bg-brand-500/15 text-paper" : "border-night-600 bg-night-800/60 text-sage hover:text-paper"
                    }`}
                  >
                    <Icon className={`h-5 w-5 ${active ? "text-mint-300" : ""}`} />
                    {meta.label}
                  </button>
                );
              })}
            </div>

            <span className="mt-5 mb-2 block text-[11px] font-semibold tracking-wide text-sage uppercase">
              Gravité (1 à 5)
            </span>
            <div className="flex gap-1.5">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  onClick={() => setFormSeverity(n)}
                  className={`h-11 flex-1 rounded-xl font-display text-sm font-bold transition ${
                    formSeverity === n
                      ? n >= 4
                        ? "bg-coral text-white"
                        : n === 3
                          ? "bg-amber-warn text-night-950"
                          : "bg-brand-500 text-night-950"
                      : "bg-night-800 text-sage hover:text-paper"
                  }`}
                >
                  {n}
                </button>
              ))}
            </div>
            <p className="mt-2 text-[11.5px] text-sage">
              {formSeverity >= 4
                ? "Gravité élevée : un incident grave bloque la circulation — il sera prioritaire dès sa diffusion."
                : formSeverity === 3
                  ? "Gravité moyenne : ralentissement ou gêne significative sur l'axe."
                  : "Gravité faible : gêne légère, information utile aux autres conducteurs."}
            </p>
          </div>

          {/* Colonne droite : axe, précisions, option "distinct" */}
          <div>
            <label className="block">
              <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">Axe concerné</span>
              <button
                type="button"
                onClick={locateNearestAxis}
                disabled={locating}
                className="mb-2 flex w-full items-center justify-center gap-2 rounded-xl border border-brand-500/50 bg-brand-500/10 py-2 text-[12.5px] font-bold text-mint-300 transition hover:bg-brand-500/20 disabled:opacity-60"
              >
                {locating ? <Loader2 className="h-4 w-4 animate-spin" /> : <LocateFixed className="h-4 w-4" />}
                Utiliser ma position (axe le plus proche)
              </button>
              {geoMsg && <p className="mb-2 text-[11.5px] leading-relaxed text-sage">{geoMsg}</p>}
              <select
                value={formAxis}
                onChange={(e) => {
                  setFormAxis(e.target.value);
                  setSelectedAxisId(e.target.value);
                }}
                className="w-full cursor-pointer rounded-xl border border-night-600 bg-night-800 px-3 py-2.5 text-sm outline-none focus:border-brand-500"
              >
                {city.axes.map((a) => (
                  <option key={a.id} value={a.id}>
                    {a.name}
                  </option>
                ))}
              </select>
            </label>

            <label className="mt-4 block">
              <span className="mb-1 flex items-baseline justify-between text-[11px] font-semibold tracking-wide text-sage uppercase">
                Précisions (optionnel)
                <span className="font-mono text-[10px] normal-case">{formDesc.length}/280</span>
              </span>
              <input
                value={formDesc}
                onChange={(e) => setFormDesc(e.target.value)}
                maxLength={280}
                placeholder="Ex. : voie de droite bloquée, secours attendus…"
                className="w-full rounded-xl border border-night-600 bg-night-800 px-3 py-2.5 text-sm outline-none placeholder:text-sage/60 focus:border-brand-500"
              />
            </label>

            {similarIncident && !formDistinct && (
              <p className="mt-4 flex items-start gap-2 rounded-xl border border-amber-warn/40 bg-amber-warn/10 px-3 py-2.5 text-[12.5px] leading-relaxed text-amber-warn">
                <Info className="mt-0.5 h-4 w-4 shrink-0" />
                <span>
                  Un signalement « {INCIDENT_META[similarIncident.type]?.label ?? similarIncident.type} » existe déjà
                  sur cet axe (confiance {similarIncident.confidence} %, {similarIncident.confirmations}/3
                  confirmations) : votre envoi comptera comme une <b>confirmation</b> — sauf si vous cochez « incident
                  distinct » ci-dessous.
                </span>
              </p>
            )}
            {similarIncident && formDistinct && (
              <p className="mt-4 flex items-start gap-2 rounded-xl bg-night-800/70 px-3 py-2.5 text-[12.5px] leading-relaxed text-sage">
                <Info className="mt-0.5 h-4 w-4 shrink-0" />
                <span>Vous déclarez un incident distinct : il ouvrira son propre dossier de consensus.</span>
              </p>
            )}

            <label className="mt-4 flex cursor-pointer items-start gap-2.5 text-[13px] leading-relaxed text-paper/85">
              <input
                type="checkbox"
                checked={formDistinct}
                onChange={(e) => setFormDistinct(e.target.checked)}
                className="mt-0.5 h-4 w-4 shrink-0 accent-[#22b573]"
              />
              <span>
                C&apos;est un incident <b>distinct</b> d&apos;un signalement récent sur cet axe{" "}
                <span className="text-sage">(sinon, votre envoi compte comme une confirmation)</span>
              </span>
            </label>
          </div>
        </div>

        <p className="mt-5 rounded-xl bg-night-800/70 px-3 py-2.5 text-[12.5px] leading-relaxed text-sage">
          <span className="mr-2">📱 Canal : application web</span>
          <br />
          Récapitulatif : <b className="text-paper">{INCIDENT_META[formType].label}</b> · gravité{" "}
          <b className="text-paper">{formSeverity}/5</b> · <b className="text-paper">{formAxisName}</b>. Diffusion après
          consensus de 3 conducteurs distincts (appareils distincts, tous réseaux).
        </p>

        <button
          onClick={() => void submitReport()}
          disabled={sending}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-500 py-3 text-sm font-bold text-night-950 transition hover:bg-mint-400 disabled:opacity-60"
        >
          {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
          Envoyer le signalement
        </button>
        {feedback && (
          <p className="mt-3 rounded-xl bg-brand-500/12 px-3 py-2.5 text-[12.5px] font-medium text-mint-300">{feedback}</p>
        )}
      </div>

      {/* Flux des incidents */}
      <div data-reveal id="flux-incidents" className="mt-8 scroll-mt-28">
        <div className="flex flex-wrap items-center gap-2">
          <h3 className="mr-2 font-display text-xl font-bold">Flux communautaire — {city.name}</h3>
          {["tous", ...Object.keys(INCIDENT_META)].map((key) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={`rounded-full px-3 py-1.5 text-[12px] font-semibold transition ${
                filter === key ? "bg-brand-500 text-night-950" : "bg-night-800 text-sage hover:text-paper"
              }`}
            >
              {key === "tous" ? "Tous" : INCIDENT_META[key].label}
            </button>
          ))}
          <span className="ml-auto text-[12px] text-sage">
            {heat ? `${incidents.filter((i) => i.status === "broadcast").length} incident(s) diffusé(s)` : ""}
          </span>
        </div>

        {loadingFeed ? (
          <div className="mt-4 grid place-items-center rounded-3xl border border-night-600 bg-night-900 py-14">
            <Loader2 className="h-6 w-6 animate-spin text-brand-500" />
          </div>
        ) : filtered.length === 0 ? (
          <div className="mt-4 rounded-3xl border border-night-600 bg-night-900 px-6 py-12 text-center">
            <p className="text-3xl">🕊️</p>
            <p className="mt-2 font-display text-base font-semibold">Rien à signaler dans cette catégorie</p>
            <p className="mt-1 text-[13px] text-sage">
              Les nouveaux signalements de la communauté apparaîtront ici en temps réel.
            </p>
          </div>
        ) : (
          <div className="mt-4 grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {filtered.map((inc) => {
              const meta = INCIDENT_META[inc.type] ?? INCIDENT_META.danger;
              const Icon = meta.icon;
              const axis = getAxis(city, inc.axisId);
              const broadcast = inc.status === "broadcast";
              const already = confirmedIds.has(inc.id);
              return (
                <article key={inc.id} className="rounded-3xl border border-night-600 bg-night-900 p-4">
                  <div className="flex items-start gap-3">
                    <span
                      className={`grid h-10 w-10 shrink-0 place-items-center rounded-2xl ${
                        broadcast ? "bg-coral/15 text-coral" : "bg-amber-warn/15 text-amber-warn"
                      }`}
                    >
                      <Icon className="h-5 w-5" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-bold">
                        {meta.label} — {axis?.short ?? inc.axisId}
                      </p>
                      <p className="text-[11.5px] text-sage">
                        {timeAgo(inc.createdAt)} · gravité {inc.severity}/5 · {CHANNEL_LABELS[inc.channel] ?? inc.channel} · réseau {inc.network}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2 py-1 text-[10px] font-bold ${
                        broadcast
                          ? "bg-coral/15 text-coral"
                          : inc.status === "confirmed"
                            ? "bg-amber-warn/15 text-amber-warn"
                            : "bg-night-700 text-sage"
                      }`}
                    >
                      {broadcast ? "DIFFUSÉ" : inc.status === "confirmed" ? "CONFIRMÉ" : "EN ATTENTE"}
                    </span>
                  </div>
                  {inc.description && <p className="mt-2.5 text-[12.5px] leading-relaxed text-paper/80">{inc.description}</p>}
                  <div className="mt-3">
                    <div className="flex justify-between text-[11px] font-medium text-sage">
                      <span>Confiance {inc.confidence} %</span>
                      <span>{inc.confirmations}/3 confirmations</span>
                    </div>
                    <div className="mt-1 h-2 overflow-hidden rounded-full bg-night-950">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${broadcast ? "bg-coral" : "bg-amber-warn"}`}
                        style={{ width: `${inc.confidence}%` }}
                      />
                    </div>
                  </div>
                  <button
                    disabled={broadcast || already || confirmingId === inc.id}
                    onClick={() => void confirmIncident(inc.id)}
                    className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl py-2 text-[12.5px] font-bold transition enabled:bg-night-700 enabled:hover:bg-night-600 disabled:cursor-default disabled:bg-night-800 disabled:text-sage"
                  >
                    {confirmingId === inc.id ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <CheckCheck className="h-4 w-4" />
                    )}
                    {broadcast ? "Diffusé à toute la ville" : already ? "Vous avez confirmé" : "Je confirme (je suis sur place)"}
                  </button>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
