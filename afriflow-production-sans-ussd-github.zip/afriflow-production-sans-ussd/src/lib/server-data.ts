import { and, count, desc, eq, gte, ne } from "drizzle-orm";
import { after } from "next/server";
import { db } from "@/db";
import {
  axisState,
  fleetVehicles,
  incidents,
  quotaGrants,
  subscriptions,
  telemetryPoints,
} from "@/db/schema";
import { CITIES, type CityDef } from "./cities";
import type { HeatmapPayload } from "./api-types";
import {
  CLEAR_WEATHER,
  computeAxisState,
  summarizeCity,
  type EngineContext,
  type IncidentImpact,
  type MeasureBlend,
  type WeatherInfo,
} from "./engine";
import { loadProfiles, loadWeights, maybeRetrain } from "./learning";
import { getOsmEnrichment, triggerOsmEnrichment } from "./osm-enrich";
import { syncRoadEdges } from "./road-edges";
import { fetchWeather } from "./weather";

export type { HeatmapPayload };

interface BuildOpts {
  hourOverride?: number | null;
  weatherOverride?: WeatherInfo | null;
}

/** Cache court de la carte thermique : le trafic n'évolue pas à la seconde. */
const heatCache = new Map<string, { at: number; payload: HeatmapPayload }>();
const HEAT_CACHE_MS = 10_000;

export async function buildHeatmap(city: CityDef, opts: BuildOpts = {}): Promise<HeatmapPayload> {
  const cacheKey = `${city.id}:${opts.hourOverride ?? "rt"}`;
  if (!opts.weatherOverride) {
    const hit = heatCache.get(cacheKey);
    if (hit && Date.now() - hit.at < HEAT_CACHE_MS) return hit.payload;
  }

  const started = performance.now();
  const now = new Date();
  // Instant décalé de l'offset de la ville : ses composantes UTC sont
  // l'heure locale de la ville (pics, projections et affichages cohérents).
  const at = new Date(now.getTime() + (city.tzOffsetMin ?? 0) * 60_000);
  if (typeof opts.hourOverride === "number") {
    at.setUTCHours(opts.hourOverride, at.getUTCMinutes(), 0, 0);
  }
  const weather = opts.weatherOverride ?? (await fetchWeather(city));

  // Incidents diffusés (consensus ≥ 3) des 3 dernières heures → impact vitesse.
  const threeHoursAgo = new Date(now.getTime() - 3 * 3600_000);
  let broadcast: (typeof incidents.$inferSelect)[] = [];
  let states: (typeof axisState.$inferSelect)[] = [];
  let telemetryCount = 0;
  let quotaCount24h = 0;
  let realPoints24h = 0;
  const simulatedAxes = new Set<string>();
  try {
    // Requêtes indépendantes en parallèle (une seule latence réseau au lieu de 4).
    const since24h = new Date(now.getTime() - 24 * 3600_000);
    const [b, s, rows, qgRows, recent, realRows] = await Promise.all([
      db
        .select()
        .from(incidents)
        .where(
          and(
            eq(incidents.city, city.id),
            eq(incidents.status, "broadcast"),
            gte(incidents.createdAt, threeHoursAgo),
          ),
        )
        .orderBy(desc(incidents.createdAt))
        .limit(40),
      db.select().from(axisState).where(eq(axisState.city, city.id)),
      db
        .select({ id: telemetryPoints.id })
        .from(telemetryPoints)
        .where(and(eq(telemetryPoints.city, city.id), gte(telemetryPoints.createdAt, since24h)))
        .limit(5000),
      db
        .select({ n: count() })
        .from(quotaGrants)
        .where(and(eq(quotaGrants.city, city.id), gte(quotaGrants.createdAt, since24h))),
      // Sources des mesures des 10 dernières minutes (réel vs simulateur).
      db
        .select({ axisId: telemetryPoints.axisId, source: telemetryPoints.source })
        .from(telemetryPoints)
        .where(
          and(
            eq(telemetryPoints.city, city.id),
            gte(telemetryPoints.createdAt, new Date(now.getTime() - 10 * 60_000)),
          ),
        )
        .limit(3000),
      // Points GPS RÉELS (hors simulateur) sur 24 h — seuil du cold start.
      db
        .select({ n: count() })
        .from(telemetryPoints)
        .where(
          and(
            eq(telemetryPoints.city, city.id),
            gte(telemetryPoints.createdAt, since24h),
            ne(telemetryPoints.source, "simulateur"),
          ),
        ),
    ]);
    broadcast = b;
    states = s;
    telemetryCount = rows.length;
    quotaCount24h = qgRows[0]?.n ?? 0;
    realPoints24h = realRows[0]?.n ?? 0;
    for (const r of recent) {
      if (r.axisId && r.source === "simulateur") simulatedAxes.add(r.axisId);
    }
  } catch {
    // Base indisponible : le moteur fonctionne en mode profil pur.
  }

  const impacts: IncidentImpact[] = broadcast.map((i) => ({
    axisId: i.axisId,
    severity: i.severity,
    ageMinutes: Math.max(0, (now.getTime() - new Date(i.createdAt).getTime()) / 60_000),
  }));
  const measures = new Map<string, MeasureBlend>();
  for (const s of states) {
    measures.set(s.axisId, {
      speedKmh: s.smoothedSpeedKmh,
      samples: s.samples,
      freshMinutes: (now.getTime() - new Date(s.updatedAt).getTime()) / 60_000,
      simulated: simulatedAxes.has(s.axisId),
    });
  }

  // Enrichissement OpenStreetMap (arrière-plan) : attributs réels des
  // voies — surface, maxspeed — appliqués aux vitesses par le moteur.
  triggerOsmEnrichment(city);
  const enrichment = getOsmEnrichment(city);
  // Couche spatiale road_edges : graphe enrichi persisté en base (arrière-plan).
  syncRoadEdges(city);

  // Profils de vitesse APPRIS sur les GPS collectés (réentraînement
  // automatique en arrière-plan toutes les 6 h si des données existent).
  if (telemetryCount > 0) after(async () => { await maybeRetrain(city); });
  const profiles = await loadProfiles(city);
  const weights = await loadWeights(city);

  const ctx: EngineContext = {
    at,
    weather,
    incidents: impacts,
    measures,
    cityHasGps: telemetryCount > 0,
    osm: enrichment.status === "ready" ? enrichment.byAxis : undefined,
    profiles: profiles.size > 0 ? profiles : undefined,
    weights: weights.size > 0 ? weights : undefined,
  };
  const axes = city.axes.map((a) => computeAxisState(a, ctx));
  const summary = summarizeCity(axes, city.axes, ctx);
  summary.computedInMs = Math.max(1, Math.round(performance.now() - started));

  const payload: HeatmapPayload = {
    city: city.id,
    cityName: city.name,
    at: now.toISOString(), // instant réel (UTC)
    cityTime: at.toISOString(), // heure locale de la ville, encodée en composantes UTC
    hour: at.getUTCHours(),
    weather,
    axes,
    summary,
    telemetryPoints24h: telemetryCount,
    realPoints24h,
    // Cold start : moins de 5 points GPS réels sur 24 h — l'interface
    // masque alors les scores de confiance IA derrière un badge explicite.
    coldStart: realPoints24h < 5,
    // Compteurs RÉELS (base) : délestages accordés sur 24 h et axes
    // effectivement alimentés par des mesures GPS fraîches.
    quotaGrants24h: quotaCount24h,
    measuredAxes: axes.filter((a) => a.measured).length,
    // Couverture par provenance : vert (GPS < 5 min) / orange (estimation IA) / gris.
    dataCoverage: {
      reel: axes.filter((a) => a.dataSource === "reel").length,
      estime: axes.filter((a) => a.dataSource === "estime").length,
      aucune: axes.filter((a) => a.dataSource === "aucune").length,
      simulatedAxes: axes.filter((a) => a.simulated).length,
    },
  };
  if (!opts.weatherOverride) heatCache.set(cacheKey, { at: Date.now(), payload });
  return payload;
}

/* ------------------------------------------------------------------ */
/* Vue réseau : indices prévisionnels des 112 villes (profils appris)  */
/* ------------------------------------------------------------------ */

export interface CitySummaryRow {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  axesCount: number;
  zonesCount: number;
  index: number;
  indexIn30: number;
  saturatedAxes: number;
  vehiclesTracked: number;
}

let citySummariesCache: { at: number; rows: CitySummaryRow[] } | null = null;
const CITY_SUMMARIES_CACHE_MS = 60_000;

export function buildCitySummaries(): CitySummaryRow[] {
  if (citySummariesCache && Date.now() - citySummariesCache.at < CITY_SUMMARIES_CACHE_MS) {
    return citySummariesCache.rows;
  }
  const rows = CITIES.map((city) => {
    // Chaque ville est évaluée à SON heure locale (mode léger : indices seuls).
    const ctx: EngineContext = {
      at: new Date(Date.now() + (city.tzOffsetMin ?? 0) * 60_000),
      weather: CLEAR_WEATHER,
      incidents: [],
      measures: new Map(),
      light: true,
    };
    const states = city.axes.map((a) => computeAxisState(a, ctx));
    const summary = summarizeCity(states, city.axes, ctx);
    return {
      id: city.id,
      name: city.name,
      country: city.country,
      countryCode: city.countryCode,
      axesCount: city.axes.length,
      zonesCount: city.zones.length,
      index: summary.index,
      indexIn30: summary.indexIn30,
      saturatedAxes: summary.saturatedAxes,
      vehiclesTracked: summary.vehiclesTracked,
    };
  });
  citySummariesCache = { at: Date.now(), rows };
  return rows;
}

/* ------------------------------------------------------------------ */
/* Statistiques plateforme (compteurs réels de la base)                */
/* ------------------------------------------------------------------ */

export interface PlatformStats {
  cities: number;
  countries: number;
  axesMonitored: number;
  telemetryPoints24h: number;
  incidentsToday: number;
  incidentsBroadcast: number;
  fleetVehicles: number;
  apiSubscribers: number;
}

let statsCache: { at: number; stats: PlatformStats } | null = null;
const STATS_CACHE_MS = 30_000;

export async function buildPlatformStats(): Promise<PlatformStats> {
  if (statsCache && Date.now() - statsCache.at < STATS_CACHE_MS) return statsCache.stats;

  const axesMonitored = CITIES.reduce((n, c) => n + c.axes.length, 0);
  const countries = new Set(CITIES.map((c) => c.countryCode)).size;
  let telemetryPoints24h = 0;
  let incidentsToday = 0;
  let incidentsBroadcast = 0;
  let fleetTotal = 0;
  let apiSubscribers = 0;
  try {
    const since24h = new Date(Date.now() - 24 * 3600_000);
    const since6h = new Date(Date.now() - 6 * 3600_000);
    const [t] = await db
      .select({ n: count() })
      .from(telemetryPoints)
      .where(gte(telemetryPoints.createdAt, since24h));
    telemetryPoints24h = t?.n ?? 0;
    const [it] = await db
      .select({ n: count() })
      .from(incidents)
      .where(gte(incidents.createdAt, since24h));
    incidentsToday = it?.n ?? 0;
    const [ib] = await db
      .select({ n: count() })
      .from(incidents)
      .where(and(eq(incidents.status, "broadcast"), gte(incidents.createdAt, since6h)));
    incidentsBroadcast = ib?.n ?? 0;
    const [f] = await db.select({ n: count() }).from(fleetVehicles);
    fleetTotal = f?.n ?? 0;
    const [sub] = await db.select({ n: count() }).from(subscriptions);
    apiSubscribers = sub?.n ?? 0;
  } catch {
    /* compteurs partiels si la base est injoignable */
  }

  const stats: PlatformStats = {
    cities: CITIES.length,
    countries,
    axesMonitored,
    telemetryPoints24h,
    incidentsToday,
    incidentsBroadcast,
    fleetVehicles: fleetTotal,
    apiSubscribers,
  };
  statsCache = { at: Date.now(), stats };
  return stats;
}

/** Compte des grants de quota accordés dans l'heure, par axe. */
export async function quotaGrantsLastHour(cityId: string): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  try {
    const since = new Date(Date.now() - 3600_000);
    const rows = await db
      .select()
      .from(quotaGrants)
      .where(and(eq(quotaGrants.city, cityId), gte(quotaGrants.createdAt, since)))
      .limit(2000);
    for (const r of rows) map.set(r.axisId, (map.get(r.axisId) ?? 0) + 1);
  } catch {
    /* moteur déterministe en repli */
  }
  return map;
}

function toFleetLive(v: typeof fleetVehicles.$inferSelect, axisSpeed: number, axisFluidity: number) {
  const moving = v.speedKmh > 5;
  const derivedStatus =
    v.status === "Livré"
      ? "Livré"
      : axisFluidity < 30
        ? "Bloqué"
        : axisFluidity < 50
          ? "Ralentissement"
          : "En mouvement";
  return {
    id: v.id,
    plate: v.plate,
    driver: v.driver,
    phone: v.phone ?? "",
    cargo: v.cargo,
    origin: v.origin,
    destination: v.destination,
    axisId: v.axisId,
    speedKmh: moving ? Math.round(axisSpeed * 10) / 10 : Math.round(v.speedKmh * 10) / 10,
    etaMin: axisFluidity < 30 ? v.etaMin + 18 : v.etaMin,
    fuelL: v.fuelL,
    status: derivedStatus,
    convoy: v.convoy,
    city: v.city,
  };
}

export async function buildFleet(city: CityDef, heat: HeatmapPayload) {
  let rows: (typeof fleetVehicles.$inferSelect)[] = [];
  try {
    rows = await db
      .select()
      .from(fleetVehicles)
      .where(eq(fleetVehicles.city, city.id))
      .orderBy(fleetVehicles.id);
  } catch {
    rows = [];
  }
  const stateByAxis = new Map(heat.axes.map((a) => [a.axisId, a]));
  return rows.map((v) => {
    const st = stateByAxis.get(v.axisId);
    return toFleetLive(v, st?.speedKmh ?? v.speedKmh, st?.fluidity ?? 80);
  });
}
