import webpush from "web-push";
import { eq, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { appSettings, pushSubscriptions } from "@/db/schema";
import type { ValidatedAlert } from "./alert-hub";

/**
 * Notifications Web Push sur les alertes validées par le consensus.
 * Les clés VAPID sont lues depuis l'environnement (VAPID_PUBLIC_KEY /
 * VAPID_PRIVATE_KEY) ou générées une fois puis persistées en base —
 * aucun secret n'est codé en dur. Les abonnements expirés (404/410)
 * sont purgés automatiquement.
 */

let vapidReady: Promise<{ publicKey: string; privateKey: string } | null> | null = null;

async function loadVapidKeys(): Promise<{ publicKey: string; privateKey: string } | null> {
  const envPublic = process.env.VAPID_PUBLIC_KEY;
  const envPrivate = process.env.VAPID_PRIVATE_KEY;
  if (envPublic && envPrivate) return { publicKey: envPublic, privateKey: envPrivate };
  try {
    const rows = await db.select().from(appSettings);
    const map = new Map(rows.map((r) => [r.key, r.value]));
    const existingPublic = map.get("vapid_public_key");
    const existingPrivate = map.get("vapid_private_key");
    if (existingPublic && existingPrivate) {
      return { publicKey: existingPublic, privateKey: existingPrivate };
    }
    const generated = webpush.generateVAPIDKeys();
    await db
      .insert(appSettings)
      .values({ key: "vapid_public_key", value: generated.publicKey })
      .onConflictDoNothing();
    await db
      .insert(appSettings)
      .values({ key: "vapid_private_key", value: generated.privateKey })
      .onConflictDoNothing();
    return generated;
  } catch {
    return null;
  }
}

export function getVapidKeys(): Promise<{ publicKey: string; privateKey: string } | null> {
  if (!vapidReady) vapidReady = loadVapidKeys();
  return vapidReady;
}

export async function getVapidPublicKey(): Promise<string | null> {
  const keys = await getVapidKeys();
  return keys?.publicKey ?? null;
}

/** Envoie l'alerte à tous les abonnés push de la ville (ou globaux). */
export async function sendAlertPush(alert: ValidatedAlert): Promise<void> {
  try {
    const keys = await getVapidKeys();
    if (!keys) return;
    webpush.setVapidDetails(
      process.env.VAPID_SUBJECT ?? "mailto:alertes@afriflow.app",
      keys.publicKey,
      keys.privateKey,
    );
    const subs = await db
      .select()
      .from(pushSubscriptions)
      .where(or(eq(pushSubscriptions.city, alert.city), isNull(pushSubscriptions.city)));
    const payload = JSON.stringify({
      title: `🚨 ${alert.incident_type} — ${alert.axis_name}`,
      body: `Confirmé par ${alert.confirmation_count} conducteurs (confiance ${alert.confidence_score} %). Pénalité estimée : −${alert.speed_penalty_kmh} km/h.`,
      city: alert.city,
      edge_id: alert.edge_id,
      url: `/?ville=${alert.city}#dashboard`,
    });
    await Promise.all(
      subs.map(async (sub) => {
        try {
          await webpush.sendNotification(
            { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
            payload,
            { TTL: 3600 },
          );
        } catch (err) {
          const status = (err as { statusCode?: number }).statusCode;
          if (status === 404 || status === 410) {
            // Abonnement expiré : purge silencieuse.
            await db.delete(pushSubscriptions).where(eq(pushSubscriptions.id, sub.id)).catch(() => undefined);
          }
        }
      }),
    );
  } catch {
    /* notifications best-effort : jamais bloquantes pour le consensus */
  }
}
