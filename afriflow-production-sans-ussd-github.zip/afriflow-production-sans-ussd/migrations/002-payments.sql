-- Run after the auth migration. Published License products support renewals;
-- Chariow Service/Coaching/pay-what-you-want products do not support API checkout.
CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY,
  user_id text NOT NULL REFERENCES users(id),
  plan text NOT NULL CONSTRAINT payment_orders_plan_check CHECK (plan IN ('day', 'week', 'month')),
  product_id text NOT NULL,
  sale_id text UNIQUE,
  status text NOT NULL DEFAULT 'pending' CONSTRAINT payment_orders_status_check CHECK (status IN ('pending', 'completed')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS payment_orders_user_idx ON payment_orders(user_id);
CREATE TABLE IF NOT EXISTS payment_grants (
  sale_id text PRIMARY KEY,
  user_id text NOT NULL REFERENCES users(id),
  starts_at timestamptz NOT NULL,
  expires_at timestamptz NOT NULL,
  revoked boolean NOT NULL DEFAULT false,
  CONSTRAINT payment_grants_duration_check CHECK (expires_at > starts_at)
);
CREATE INDEX IF NOT EXISTS payment_grants_user_expiry_idx ON payment_grants(user_id, expires_at);
CREATE TABLE IF NOT EXISTS payment_deliveries (
  id text PRIMARY KEY,
  sale_id text NOT NULL REFERENCES payment_grants(sale_id),
  created_at timestamptz NOT NULL DEFAULT now()
);
