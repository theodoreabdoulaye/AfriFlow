import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { and, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { quotaGrants } from "@/db/schema";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { quotaTotalFor } from "@/lib/engine";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { quotaGrantsLastHour } from "@/lib/server-data";

export const dynamic = "force-dynamic";

/**
 * POST /api/routing/accept { city, axisId }
 * Le conducteur suit le délestage : un grant de quota MFD est consommé.
 * Quand le quota est plein, l'axe est fermé aux nouveaux délestages.
 */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`accept:${clientIp(req)}`, 180, 60_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  const body = raw as Record<string, unknown>;
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const axis = getAxis(city, String(body.axisId ?? ""));
  if (!axis) return NextResponse.json({ error: "Axe inconnu" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });

  const deviceHash = typeof body.deviceHash === "string" ? body.deviceHash.slice(0, 64) : null;

  const total = quotaTotalFor(axis);
  const grantedMap = await quotaGrantsLastHour(city.id);
  const granted = grantedMap.get(axis.id) ?? 0;

  // Idempotence : ce conducteur détient déjà un grant sur cet axe (1 h).
  if (deviceHash) {
    try {
      const since = new Date(Date.now() - 3600_000);
      const mine = await db
        .select({ id: quotaGrants.id })
        .from(quotaGrants)
        .where(
          and(
            eq(quotaGrants.city, city.id),
            eq(quotaGrants.axisId, axis.id),
            eq(quotaGrants.deviceHash, deviceHash),
            gte(quotaGrants.createdAt, since),
          ),
        )
        .limit(1);
      if (mine.length > 0) {
        return NextResponse.json({
          accepted: true,
          alreadyAccepted: true,
          axisId: axis.id,
          granted,
          total,
          remaining: Math.max(0, total - granted),
        }, { headers: { "Cache-Control": "private, no-store" } });
      }
    } catch {
      /* vérification best-effort */
    }
  }

  if (granted >= total) {
    return NextResponse.json(
      { accepted: false, reason: "quota-plein", granted, total, remaining: 0 },
      { status: 409, headers: { "Cache-Control": "private, no-store" } },
    );
  }
  try {
    await db.insert(quotaGrants).values({ city: city.id, axisId: axis.id, deviceHash });
  } catch {
    return NextResponse.json({ error: "Quota indisponible" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
  }
  return NextResponse.json({
    accepted: true,
    axisId: axis.id,
    granted: granted + 1,
    total,
    remaining: total - granted - 1,
  }, { headers: { "Cache-Control": "private, no-store" } });
}
