import {
  pgTable,
  serial,
  text,
  integer,
  real,
  boolean,
  timestamp,
  index,
  uniqueIndex,
  bigint,
  jsonb,
  primaryKey,
} from "drizzle-orm/pg-core";

/**
 * AfriFlow — schéma (porté du prototype : PostGIS/geom côté Rust,
 * ici PostgreSQL classique + index, même modèle de données).
 */

/** Points GPS ingérés via POST /api/telemetry (app, flottes, partenaires). */
export const telemetryPoints = pgTable(
  "telemetry_points",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id"),
    lat: real("lat").notNull(),
    lon: real("lon").notNull(),
    speedKmh: real("speed_kmh").notNull(),
    heading: real("heading"),
    source: text("source").notNull().default("app"), // app | partner | ussd | whatsapp
    deviceHash: text("device_hash"),
    // Pluie horaire au moment du point (Open-Meteo) — variable d'entraînement ML.
    rainMm: real("rain_mm"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("telemetry_city_idx").on(t.city, t.createdAt),
    index("telemetry_axis_idx").on(t.axisId, t.createdAt),
  ],
);

/** État temps réel par axe : vitesse lissée exponentiellement (α = 0,3). */
export const axisState = pgTable(
  "axis_state",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id").notNull(),
    smoothedSpeedKmh: real("smoothed_speed_kmh").notNull(),
    samples: integer("samples").notNull().default(0),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  // Une seule ligne d'état par axe : upsert atomique côté ingestion GPS.
  (t) => [uniqueIndex("axis_state_city_axis_unique").on(t.city, t.axisId)],
);

/** Signalements communautaires (USSD / WhatsApp / SMS / App). */
export const incidents = pgTable(
  "incidents",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id").notNull(),
    type: text("type").notNull(), // accident | bouchon | travaux | police | inondation | panne | danger
    severity: integer("severity").notNull().default(3), // 1..5
    channel: text("channel").notNull().default("web"), // web | ussd | whatsapp | sms
    network: text("network").notNull().default("web"), // orange | mtn | moov | web…
    description: text("description"),
    confirmations: integer("confirmations").notNull().default(1),
    confidence: integer("confidence").notNull().default(38), // 38 % → 98 %
    status: text("status").notNull().default("pending"), // pending | confirmed | broadcast
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("incidents_city_idx").on(t.city, t.createdAt)],
);

/** Confirmations distinctes (conducteurs distincts requis pour le consensus). */
export const incidentConfirmations = pgTable("incident_confirmations", {
  id: serial("id").primaryKey(),
  incidentId: integer("incident_id").notNull(),
  network: text("network").notNull(),
  channel: text("channel").notNull().default("web"),
  // Appareil anonyme de l'émetteur : distingue deux abonnés du même réseau.
  deviceHash: text("device_hash"),
  // Poids du signalement (API /api/v1/report : confidence_score 1-10).
  score: integer("score").notNull().default(1),
  // Numéro WhatsApp du rapporteur (canal WhatsApp uniquement) : permet
  // d'envoyer la confirmation quand le consensus valide l'alerte.
  reporterContact: text("reporter_contact"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/**
 * Profils de vitesse APPRIS par l'IA : facteur de vitesse médian mesuré
 * par axe, heure et type de jour (semaine/week-end), calculé depuis les
 * points GPS réels collectés (POST /api/telemetry + simulateur tracé).
 */
export const axisProfiles = pgTable(
  "axis_profiles",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id").notNull(),
    hour: integer("hour").notNull(), // 0-23, heure locale de la ville
    dayKind: text("day_kind").notNull(), // weekday | weekend
    factor: real("factor").notNull(), // vitesse médiane / vitesse libre (0.05-1.05)
    samples: integer("samples").notNull().default(0),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("axis_profiles_unique").on(t.city, t.axisId, t.hour, t.dayKind)],
);

/**
 * Observations terrain du MLEngine (contrat exact du design sqlx) :
 * une ligne par mesure — axe, vitesse observée, vitesse libre de
 * référence, pluie horaire, signalements actifs au même moment.
 * Alimentée par les GPS (app/partenaires/simulateur) et /api/v1/telemetry.
 */
export const mlObservations = pgTable(
  "ml_observations",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id").notNull(),
    observedSpeedKmh: real("observed_speed_kmh").notNull(),
    baselineSpeedKmh: real("baseline_speed_kmh").notNull(),
    rainMm: real("rain_mm").notNull().default(0),
    activeReports: integer("active_reports").notNull().default(0),
    source: text("source").notNull().default("gps"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  // Équivalent de l'index (edge_id, timestamp DESC) du design.
  (t) => [index("ml_obs_axis_time_idx").on(t.city, t.axisId, t.createdAt)],
);

/**
 * Arêtes routières enrichies (couche spatiale, portée du design PostGIS) :
 * géométrie WGS84 en WKT + GeoJSON, attributs inférés OSM (capacité,
 * risque d'inondation, nids-de-poule), zone protégée. Si l'extension
 * PostGIS est disponible dans l'environnement, une colonne GEOMETRY
 * (LineString, 4326) + index GiST sont ajoutés à l'exécution (voir
 * road-edges.ts) ; sinon la recherche du plus proche voisin utilise
 * l'index spatial par grille applicatif.
 */
export const roadEdges = pgTable(
  "road_edges",
  {
    city: text("city").notNull(),
    id: text("id").notNull(), // identifiant d'axe AfriFlow
    osmWayId: bigint("osm_way_id", { mode: "number" }),
    name: text("name"),
    fromNode: text("from_node").notNull(),
    toNode: text("to_node").notNull(),
    lengthM: real("length_m").notNull(),
    baselineSpeedKmh: real("baseline_speed_kmh").notNull(),
    capacityVph: real("capacity_vph").notNull(),
    floodRisk: real("flood_risk").notNull().default(0.1),
    potholeSeverity: real("pothole_severity").notNull().default(0.1),
    isProtectedZone: boolean("is_protected_zone").notNull().default(false),
    highwayType: text("highway_type"),
    geomWkt: text("geom_wkt").notNull(),
    geomJson: jsonb("geom_json").$type<[number, number][]>(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [
    primaryKey({ columns: [t.city, t.id] }),
    index("road_edges_from_node_idx").on(t.fromNode),
    index("road_edges_to_node_idx").on(t.toNode),
    index("road_edges_city_idx").on(t.city),
  ],
);

/**
 * Poids du modèle de correction ML par axe (porté du MLEngine Rust) :
 * prédiction = (base × intercept) − (pluie × rain_penalty)
 *              − (signalements × report_penalty),
 * confiance honnête dérivée de l'erreur holdout et du volume de données.
 */
export const axisModelWeights = pgTable(
  "axis_model_weights",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id").notNull(),
    intercept: real("intercept").notNull(),
    rainPenalty: real("rain_penalty").notNull().default(0),
    reportPenalty: real("report_penalty").notNull().default(0),
    // Facteur de profil moyen pendant l'entraînement : la correction ML
    // s'applique en RATIO (intercept / ce facteur), jamais en absolu —
    // sinon un modèle appris le soir gonflerait les vitesses du pic du matin.
    trainProfileFactor: real("train_profile_factor").notNull().default(1),
    samples: integer("samples").notNull().default(0),
    holdoutMae: real("holdout_mae").notNull().default(0),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("axis_model_weights_unique").on(t.city, t.axisId)],
);

/**
 * Évaluations holdout des entraînements IA (découpage temporel 80/20) :
 * persistées pour rester consultables après redémarrage et servir de
 * preuve d'amélioration hors échantillon.
 */
export const modelEvaluations = pgTable(
  "model_evaluations",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    samplesTotal: integer("samples_total").notNull(),
    samplesTrain: integer("samples_train").notNull(),
    samplesTest: integer("samples_test").notNull(),
    axesTrained: integer("axes_trained").notNull(),
    maeGenericKmh: real("mae_generic_kmh"),
    maeLearnedKmh: real("mae_learned_kmh"),
    improvementPct: integer("improvement_pct"),
    trainedAt: timestamp("trained_at").notNull().defaultNow(),
  },
  (t) => [index("model_eval_city_idx").on(t.city, t.trainedAt)],
);

/** Parkings (moteur de stationnement + Park & Ride). */
export const parkingLots = pgTable(
  "parking_lots",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    name: text("name").notNull(),
    lat: real("lat").notNull(),
    lon: real("lon").notNull(),
    totalSpots: integer("total_spots").notNull(),
    // Occupation réelle (capteur/opérateur) ; null = occupation modélisée.
    currentOccupancy: integer("current_occupancy"),
    occupancyUpdatedAt: timestamp("occupancy_updated_at"),
    pricePerHourFcfa: integer("price_per_hour_fcfa").notNull().default(300),
    nearestTransitStop: text("nearest_transit_stop"),
    parkingType: text("parking_type").notNull().default("PrivateLot"), // Street | PrivateLot | ParkAndRide | ShoppingMall
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("parking_city_idx").on(t.city)],
);

/** Offres de covoiturage publiées par les conducteurs. */
export const carpoolOffers = pgTable(
  "carpool_offers",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    driverName: text("driver_name").notNull(),
    driverPhone: text("driver_phone").notNull(),
    fromLat: real("from_lat").notNull(),
    fromLon: real("from_lon").notNull(),
    toLat: real("to_lat").notNull(),
    toLon: real("to_lon").notNull(),
    fromLabel: text("from_label").notNull(),
    toLabel: text("to_label").notNull(),
    departureTime: timestamp("departure_time").notNull(),
    seatsTotal: integer("seats_total").notNull().default(3),
    seatsTaken: integer("seats_taken").notNull().default(0),
    pricePerSeatFcfa: integer("price_per_seat_fcfa").notNull().default(500),
    vehicleType: text("vehicle_type").notNull().default("Berline"),
    status: text("status").notNull().default("active"), // active | full | completed | cancelled
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("carpool_city_status_idx").on(t.city, t.status, t.departureTime)],
);

/**
 * Notes conducteur/passager après le trajet (confiance communautaire) :
 * une note par rôle et par réservation, note de 1 à 5 étoiles.
 */
export const carpoolRatings = pgTable(
  "carpool_ratings",
  {
    id: serial("id").primaryKey(),
    bookingId: integer("booking_id").notNull(),
    raterPhone: text("rater_phone").notNull(),
    raterRole: text("rater_role").notNull(), // passenger | driver
    rateePhone: text("ratee_phone").notNull(),
    stars: integer("stars").notNull(), // 1..5
    comment: text("comment"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("carpool_ratings_unique").on(t.bookingId, t.raterRole),
    index("carpool_ratings_ratee_idx").on(t.rateePhone),
  ],
);

/** Réservations de places sur les offres de covoiturage. */
export const carpoolBookings = pgTable("carpool_bookings", {
  id: serial("id").primaryKey(),
  offerId: integer("offer_id").notNull(),
  passengerName: text("passenger_name").notNull(),
  passengerPhone: text("passenger_phone").notNull(),
  seats: integer("seats").notNull().default(1),
  status: text("status").notNull().default("confirmed"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Abonnements Web Push (notifications d'alertes validées). */
export const pushSubscriptions = pgTable(
  "push_subscriptions",
  {
    id: serial("id").primaryKey(),
    endpoint: text("endpoint").notNull().unique(),
    p256dh: text("p256dh").notNull(),
    auth: text("auth").notNull(),
    city: text("city"), // null = toutes les villes
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [index("push_subs_city_idx").on(t.city)],
);

/** Paramètres applicatifs persistés (clés VAPID générées, etc.). */
export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

/** Candidatures au programme Waze for Cities (partenariat données villes). */
export const wazeApplications = pgTable("waze_applications", {
  id: serial("id").primaryKey(),
  organisation: text("organisation").notNull(),
  contactName: text("contact_name").notNull(),
  email: text("email").notNull(),
  city: text("city").notNull(),
  message: text("message"),
  status: text("status").notNull().default("dossier généré"), // transmis via le portail Waze par l'organisation
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

/** Flotte « Convoi Industriel ». */
export const fleetVehicles = pgTable(
  "fleet_vehicles",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    plate: text("plate").notNull(),
    driver: text("driver").notNull(),
    phone: text("phone"),
    cargo: text("cargo").notNull(),
    origin: text("origin").notNull(),
    destination: text("destination").notNull(),
    axisId: text("axis_id").notNull(),
    speedKmh: real("speed_kmh").notNull().default(0),
    etaMin: integer("eta_min").notNull().default(0),
    fuelL: real("fuel_l").notNull().default(0),
    status: text("status").notNull().default("En mouvement"), // En mouvement | Ralentissement | Bloqué | Livré
    convoy: boolean("convoy").notNull().default(false), // ligne surlignée (convoi ciblé)
    createdAt: timestamp("created_at").notNull().defaultNow(),
    updatedAt: timestamp("updated_at").notNull().defaultNow(),
  },
  (t) => [index("fleet_city_idx").on(t.city)],
);

/** Grants de quota MFD accordés aux délestages (fenêtre glissante 1 h). */
export const quotaGrants = pgTable(
  "quota_grants",
  {
    id: serial("id").primaryKey(),
    city: text("city").notNull(),
    axisId: text("axis_id").notNull(),
    // Appareil bénéficiaire : un même conducteur ne consomme qu'un grant
    // par axe et par heure (idempotence anti-abus du délestage).
    deviceHash: text("device_hash"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  (t) => [
    index("quota_city_axis_idx").on(t.city, t.axisId, t.createdAt),
    index("quota_device_idx").on(t.deviceHash),
  ],
);

/** Inscriptions aux offres (Premium, SaaS, API, Intelligence Urbaine). */
export const subscriptions = pgTable(
  "subscriptions",
  {
    id: serial("id").primaryKey(),
    plan: text("plan").notNull(),
    name: text("name").notNull(),
    phone: text("phone").notNull(),
    apiKey: text("api_key"),
    createdAt: timestamp("created_at").notNull().defaultNow(),
  },
  // Vérification de clé à chaque ping partenaire : index dédié.
  (t) => [index("subscriptions_api_key_idx").on(t.apiKey)],
);
