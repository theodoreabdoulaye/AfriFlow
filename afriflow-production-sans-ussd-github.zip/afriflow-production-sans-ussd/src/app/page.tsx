import AppClient from "@/components/AppClient";
import { CITY_MAP } from "@/lib/cities";
import { buildHeatmap } from "@/lib/server-data";
import { ensureSeed } from "@/lib/seed";
import type { HeatmapPayload } from "@/lib/api-types";
import { getCurrentUser } from "@/lib/auth";
import { getAccess } from "@/lib/access";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  let initialHeat: HeatmapPayload | null = null;
  try {
    const user = await getCurrentUser();
    if (user && (await getAccess(user.id)).active) {
      await ensureSeed();
      initialHeat = (await buildHeatmap(CITY_MAP.dakar)) as HeatmapPayload;
    }
  } catch {
    initialHeat = null;
  }
  return <AppClient initialHeat={initialHeat} />;
}
