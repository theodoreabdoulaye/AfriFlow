import { NextRequest, NextResponse } from "next/server";
import { and, count, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { fleetVehicles, telemetryPoints, wazeApplications } from "@/db/schema";
import { CITY_MAP, type CityDef } from "@/lib/cities";
import { jsonCached } from "@/lib/http-cache";
import { busStopsSnapshot, triggerBusStopsRefresh } from "@/lib/osm-enrich";
import { constructionSnapshot, triggerConstructionRefresh } from "@/lib/overpass";
import { ensureSeed } from "@/lib/seed";
import { visionConfigured } from "@/lib/vision";
import { fetchWeather } from "@/lib/weather";

export const dynamic = "force-dynamic";

async function ping(url: string, timeoutMs = 4500): Promise<{ ok: boolean; ms: number | null }> {
  const started = performance.now();
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(timeoutMs), cache: "no-store" });
    return { ok: res.ok || res.status < 500, ms: Math.round(performance.now() - started) };
  } catch {
    return { ok: false, ms: null };
  }
}

interface SourcesPayloadCache {
  at: number;
  payload: Record<string, unknown>;
}

const cache = new Map<string, SourcesPayloadCache>();
const CACHE_MS = 30_000;

const FLOOD_RISK_LABELS = ["risque faible", "risque modéré", "risque élevé"] as const;

/**
 * HERE Traffic API v7 — vitesses et incidents par tronçon.
 * Activation automatique dès que la clé HERE_API_KEY est présente dans
 * l'environnement ; sans clé, le statut indique honnêtement la marche à suivre.
 */
async function probeHereTraffic(city: CityDef): Promise<{ status: string; latencyMs: number | null; metric: string }> {
  const apiKey = process.env.HERE_API_KEY;
  if (!apiKey) {
    return {
      status: "configuration requise",
      latencyMs: null,
      metric:
        "Clé absente : définissez la variable d'environnement HERE_API_KEY pour activer le flux trafic HERE v7 (vitesses moyennes et incidents par tronçon).",
    };
  }
  const started = performance.now();
  const d = 0.12;
  const bbox = `${city.lon - d},${city.lat - d},${city.lon + d},${city.lat + d}`;
  try {
    const res = await fetch(
      `https://data.traffic.hereapi.com/v7/flow?in=bbox:${bbox}&locationReferencing=shape&apiKey=${encodeURIComponent(apiKey)}`,
      { signal: AbortSignal.timeout(8000), cache: "no-store" },
    );
    if (!res.ok) {
      return {
        status: res.status === 401 || res.status === 403 ? "clé refusée" : "injoignable",
        latencyMs: Math.round(performance.now() - started),
        metric: `HERE Traffic a répondu HTTP ${res.status} — vérifiez la clé API et ses droits (Traffic API v7).`,
      };
    }
    const json = (await res.json()) as {
      results?: { currentFlow?: { speed?: number } }[];
    };
    const results = json.results ?? [];
    const speeds = results
      .map((r) => r.currentFlow?.speed)
      .filter((s): s is number => typeof s === "number");
    const avg = speeds.length ? Math.round(speeds.reduce((a, b) => a + b, 0) / speeds.length) : null;
    return {
      status: "opérationnel",
      latencyMs: Math.round(performance.now() - started),
      metric: `${results.length} tronçon(s) HERE autour de ${city.name}${avg !== null ? ` — vitesse moyenne mesurée ${avg} km/h` : ""}`,
    };
  } catch {
    return { status: "injoignable", latencyMs: null, metric: "HERE Traffic injoignable depuis le serveur." };
  }
}

function ageLabel(fetchedAt: number): string {
  const ageMin = Math.max(0, Math.round((Date.now() - fetchedAt) / 60_000));
  if (ageMin < 2) return "à jour à l'instant";
  if (ageMin < 60) return `maj il y a ${ageMin} min`;
  const h = Math.floor(ageMin / 60);
  if (h < 24) return `maj il y a ${h} h`;
  return `maj le ${new Date(fetchedAt).toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" })}`;
}

const OVERPASS_STATUS: Record<string, string> = {
  fresh: "opérationnel",
  stale: "opérationnel (cache)",
  refreshing: "actualisation en cours",
  unavailable: "saturé (requêtes en attente)",
};

type SourceLevel = "ok" | "degraded" | "info" | "off";

interface RawSource {
  id: string;
  status: string;
  [key: string]: unknown;
}

function levelFor(s: RawSource): SourceLevel {
  if (s.status.startsWith("opérationnel")) return "ok";
  if (s.id === "whatsapp") return s.status === "webhook actif" ? "ok" : "info";
  if (s.id === "here" && s.status === "configuration requise") return "info";
  if (s.id === "waze") return "info";
  if (s.status.includes("actualisation")) return "degraded";
  if (s.status.includes("saturé")) return "degraded";
  return "off";
}

const PUBLIC_STATUS: Record<string, string> = {
  here: "activation partenaire en cours",
  waze: "flux prêt à connecter",
};

/**
 * Vue publique (par défaut) : aucune erreur technique brute — statuts
 * apaisés, pas de latences, replis automatiques invisibles.
 * Vue debug (?debug=1) : statuts techniques complets pour les admins.
 */
function presentSources(sources: RawSource[], debug: boolean): Record<string, unknown>[] {
  return sources.map((s) => {
    const level = levelFor(s);
    if (debug) return { ...s, level };
    const status =
      level === "ok" ? s.status : (PUBLIC_STATUS[s.id] ?? "données de repli actives");
    let metric = s.metric as string;
    if (s.id === "here" && level !== "ok") {
      metric = "Flux trafic partenaire — activation en cours, aucune action requise de votre part.";
    }
    if (s.id === "open-meteo" && level === "off") {
      metric = "Dernières données météo connues — réactualisation automatique dès rétablissement du flux.";
    }
    return { ...s, status, level, latencyMs: null, metric };
  });
}

async function buildSources(city: CityDef, debug: boolean): Promise<Record<string, unknown>> {
  const started = performance.now();

  // Chantiers OSM : actualisation en arrière-plan (jamais bloquante),
  // réponse construite sur le dernier état connu du client Overpass.
  triggerConstructionRefresh(city);
  const construction = constructionSnapshot(city);

  const meteoUrl = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=weather_code&timezone=auto`;
  const floodUrl = `https://flood-api.open-meteo.com/v1/flood?latitude=${city.lat}&longitude=${city.lon}&daily=river_discharge&forecast_days=3`;

  const [meteo, glofasPing, weather] = await Promise.all([
    ping(meteoUrl),
    ping(floodUrl),
    fetchWeather(city),
  ]);

  let telemetry24h = 0;
  let partnerVehicles = 0;
  let wazeApps = 0;
  try {
    const since = new Date(Date.now() - 24 * 3600_000);
    const [t] = await db
      .select({ n: count() })
      .from(telemetryPoints)
      .where(and(eq(telemetryPoints.city, city.id), gte(telemetryPoints.createdAt, since)));
    telemetry24h = t?.n ?? 0;
    const [f] = await db
      .select({ n: count() })
      .from(fleetVehicles)
      .where(eq(fleetVehicles.city, city.id));
    partnerVehicles = f?.n ?? 0;
    const [w] = await db.select({ n: count() }).from(wazeApplications);
    wazeApps = w?.n ?? 0;
  } catch {
    /* compteurs à zéro si la base est injoignable */
  }

  // Arrêts de transport : jamais bloquant (arrière-plan + dernier connu).
  triggerBusStopsRefresh(city);
  const busStops = busStopsSnapshot(city);
  const here = await probeHereTraffic(city);

  const computedInMs = Math.max(1, Math.round(performance.now() - started));
  const discharge = weather.riverDischargeM3s;
  const floodRisk = weather.floodRiskLevel;

  const built = {
    city: city.id,
    computedInMs,
    sources: [
      {
        id: "open-meteo",
        name: "Open-Meteo — météo observée",
        detail: "Température, précipitations, vent et probabilité de pluie horaire par ville.",
        status: meteo.ok ? "opérationnel" : "injoignable",
        latencyMs: meteo.ms,
        metric: meteo.ok
          ? `${weather.tempC !== null ? `${weather.tempC} °C` : "—"}, ${weather.label.toLowerCase()} à ${city.name} (mesuré en direct)`
          : "repli : dernier profil connu",
      },
      {
        id: "overpass",
        name: "OpenStreetMap / Overpass — graphe & chantiers",
        detail:
          "Chantiers routiers réellement cartographiés sur OpenStreetMap, comptés via le pool d'instances Overpass (OSM France en priorité, bascule automatique et disjoncteur par hôte).",
        status: OVERPASS_STATUS[construction.state],
        latencyMs: construction.durationMs,
        metric:
          construction.count !== null
            ? `${construction.count} chantier(s) routier(s) OSM relevé(s) (rayon 7 km, ${city.name}) — ${construction.fetchedAt ? ageLabel(construction.fetchedAt) : ""} · source ${construction.endpoint ?? "Overpass"}`
            : construction.state === "refreshing"
              ? "comptage des chantiers en cours en arrière-plan — la valeur s'affichera dès réception"
              : "instances publiques Overpass saturées — réessai automatique en arrière-plan",
      },
      {
        id: "glofas",
        name: "Copernicus GloFAS — débits des fleuves",
        detail: "Débit du cours d'eau de référence et risque de crue à 3 jours, injectés dans le moteur pour les axes inondables.",
        status: glofasPing.ok ? "opérationnel" : "injoignable",
        latencyMs: glofasPing.ms,
        metric:
          discharge !== null && floodRisk !== null && floodRisk !== undefined
            ? `débit du jour : ${discharge} m³/s — crue : ${FLOOD_RISK_LABELS[floodRisk]}`
            : discharge !== null
              ? `débit du jour : ${discharge} m³/s — cours d'eau mineur, crue fluviale non modélisée`
              : "pas de cours d'eau majeur modélisé à proximité",
      },
      {
        id: "air",
        name: "CAMS — qualité de l'air (Open-Meteo)",
        detail: "Indice européen de qualité de l'air : poussières d'harmattan et particules, affichés au centre de contrôle.",
        status: weather.aqiEu !== null && weather.aqiEu !== undefined ? "opérationnel" : "injoignable",
        latencyMs: null,
        metric:
          weather.aqiEu !== null && weather.aqiEu !== undefined
            ? `IQA européen actuel : ${weather.aqiEu}/500 à ${city.name}`
            : "mesure indisponible pour cette ville",
      },
      {
        id: "telemetry",
        name: "GPS conducteurs — app AfriFlow",
        detail: "Pings anonymisés toutes les 30-60 s via POST /api/telemetry, lissage α = 0,3.",
        status: "opérationnel",
        latencyMs: null,
        metric: `${telemetry24h} point(s) réel(s) reçu(s) sur 24 h à ${city.name}`,
      },
      {
        id: "fleets",
        name: "Flottes partenaires — GPS transporteurs",
        detail: "Transporteurs et livreurs partenaires, échangés contre un accès Premium gratuit.",
        status: "opérationnel",
        latencyMs: null,
        metric: `${partnerVehicles} véhicule(s) déclaré(s) à ${city.name}`,
      },
      {
        id: "whatsapp",
        name: "WhatsApp Business — bot de signalement (Meta)",
        detail: "Webhook Meta : messages texte, vocaux (transcription Whisper) et localisations partagées, extraits par NLP FR/Wolof/Pulaar puis versés au consensus.",
        status: process.env.WHATSAPP_VERIFY_TOKEN ? "webhook actif" : "configuration requise",
        latencyMs: null,
        metric: process.env.WHATSAPP_VERIFY_TOKEN
          ? "Webhook vérifiable par Meta · envoi des réponses : " +
            (process.env.WHATSAPP_TOKEN ? "jeton d'envoi configuré" : "WHATSAPP_TOKEN absent (réponses journalisées, non envoyées)")
          : "Définissez WHATSAPP_VERIFY_TOKEN (+ WHATSAPP_TOKEN et WHATSAPP_PHONE_NUMBER_ID pour répondre) pour connecter le bot",
      },
      {
        id: "vision",
        name: "Vision IA — dégradations routières (YOLOv8/Roboflow)",
        detail: "Analyse des photos envoyées par les usagers (nids-de-poule, inondations, fissures) pour valider les signalements sans intervention humaine.",
        status: visionConfigured() ? "opérationnel" : "configuration requise",
        latencyMs: null,
        metric: visionConfigured()
          ? "Modèle Roboflow connecté : les photos WhatsApp sont analysées automatiquement"
          : "Définissez ROBOFLOW_API_KEY et ROBOFLOW_MODEL_ID pour activer l'analyse photo (repli : description texte)",
      },
      {
        id: "here",
        name: "HERE Traffic API (v7) — vitesses & incidents",
        detail: "Vitesse moyenne actuelle et incidents (fermetures, accidents) par tronçon, fournis par HERE Technologies.",
        status: here.status,
        latencyMs: here.latencyMs,
        metric: here.metric,
      },
      {
        id: "transit",
        name: "Transport public — arrêts OSM & WhereIsMyTransport",
        detail: "Arrêts de transport formel et informel cartographiés sur OpenStreetMap ; WhereIsMyTransport est la référence partenaire pour les itinéraires complets (accès sur jeton).",
        status: busStops !== null ? "opérationnel" : "injoignable",
        latencyMs: null,
        metric:
          busStops !== null
            ? `${busStops} arrêt(s) de transport relevé(s) sur OSM (rayon 8 km, ${city.name}) · WhereIsMyTransport : jeton partenaire requis pour les lignes`
            : "comptage des arrêts OSM momentanément indisponible",
      },
      {
        id: "waze",
        name: "Waze for Cities — partenariat données",
        detail: "Programme Connected Citizens : échange d'alertes validées avec la communauté Waze (flux au format Waze Traffic View + webhook de réception).",
        status: "flux prêt — adhésion portail requise",
        latencyMs: null,
        metric: `${wazeApps} candidature(s) générée(s) · flux prêt : /api/waze/feed?city=${city.id} · réception : POST /api/waze/webhook`,
      },
    ],
  };
  return { ...built, sources: presentSources(built.sources as RawSource[], debug) };
}

/**
 * GET /api/sources?city=dakar[&fresh=1] — état en direct des sources
 * authentiques : Open-Meteo, OpenStreetMap/Overpass, GloFAS, CAMS,
 * télémétrie GPS des conducteurs et flottes partenaires.
 * Le paramètre fresh=1 contourne le cache de réponse (30 s).
 */
export async function GET(req: NextRequest) {
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  await ensureSeed();

  const force = req.nextUrl.searchParams.get("fresh") === "1";
  const debug = req.nextUrl.searchParams.get("debug") === "1";
  if (force) triggerConstructionRefresh(city);

  const cacheKey = `${city.id}:${debug ? "dbg" : "pub"}`;
  const cached = cache.get(cacheKey);
  if (!force && cached && Date.now() - cached.at < CACHE_MS) {
    return jsonCached(req, cached.payload, 25, 60);
  }
  const payload = await buildSources(city, debug);
  cache.set(cacheKey, { at: Date.now(), payload });
  return jsonCached(req, payload, 25, 60);
}
