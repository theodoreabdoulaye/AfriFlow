"use client";

import { Check } from "lucide-react";
import type { MultimodalRoute } from "@/lib/multimodal";

/**
 * Sélecteur d'itinéraires multimodaux (composant demandé) : cartes avec
 * trophée pour l'option recommandée, timeline verticale des segments
 * (pastilles colorées par mode reliées par un trait), coût/durée/CO₂
 * et bouton « Choisir » qui sélectionne l'itinéraire.
 */

const MODE_STYLE: Record<string, { emoji: string; bg: string }> = {
  car: { emoji: "🚗", bg: "#3b82f6" },
  ter: { emoji: "🚆", bg: "#22c55e" },
  walking: { emoji: "🚶", bg: "#6b7280" },
  brt: { emoji: "🚌", bg: "#a78bfa" },
  carrapide: { emoji: "🚌", bg: "#f59e0b" },
  bike: { emoji: "🚲", bg: "#14b8a6" },
};

interface Props {
  routes: MultimodalRoute[];
  selectedId: string | null;
  onChoose: (route: MultimodalRoute) => void;
}

export default function MultimodalRouteSelector({ routes, selectedId, onChoose }: Props) {
  return (
    <div className="space-y-4">
      {routes.map((route, index) => {
        const selected = selectedId === route.id;
        return (
          <div
            key={route.id}
            className={`rounded-3xl border p-5 transition-shadow hover:shadow-2xl ${
              selected
                ? "border-brand-500 bg-gradient-to-b from-brand-500/15 to-night-900 shadow-xl shadow-brand-500/10"
                : index === 0
                  ? "border-brand-500/50 bg-night-900"
                  : "border-night-600 bg-night-900"
            }`}
          >
            <div className="mb-3 flex items-start justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-bold">
                  {index === 0 && "🏆 Recommandé · "}
                  {route.totalDurationMin} min · {route.totalCostFcfa.toLocaleString("fr-FR")} FCFA
                </h3>
                <div className="mt-0.5 text-sm text-sage">
                  {route.label} — Confort : {route.comfortScore}/100 · Fiabilité : {route.reliabilityScore}/100
                </div>
              </div>
              <button
                onClick={() => onChoose(route)}
                className={`flex shrink-0 items-center gap-1.5 rounded-lg px-4 py-2 text-sm font-bold transition ${
                  selected
                    ? "bg-mint-400 text-night-950"
                    : "bg-brand-500 text-night-950 hover:bg-mint-400"
                }`}
              >
                {selected && <Check className="h-4 w-4" />}
                {selected ? "Choisi" : "Choisir"}
              </button>
            </div>

            {/* Timeline des segments */}
            <div className="space-y-2">
              {route.segments.map((segment, idx) => {
                const style = MODE_STYLE[segment.mode] ?? MODE_STYLE.carrapide;
                return (
                  <div key={idx} className="flex items-start gap-3">
                    <div className="flex flex-col items-center">
                      <div
                        className="flex h-8 w-8 items-center justify-center rounded-full text-[15px]"
                        style={{ background: style.bg }}
                        aria-hidden
                      >
                        {style.emoji}
                      </div>
                      {idx < route.segments.length - 1 && <div className="h-8 w-0.5 bg-night-600" />}
                    </div>
                    <div className="flex-1 pb-1">
                      <div className="text-[13.5px] font-medium">
                        {segment.fromName} → {segment.toName}
                      </div>
                      <div className="text-sm text-sage">
                        {segment.durationMin} min · {segment.distanceKm.toFixed(1)} km
                        {segment.costFcfa > 0 && ` · ${segment.costFcfa.toLocaleString("fr-FR")} FCFA`}
                        {segment.departureTime && ` · Départ ${segment.departureTime}`}
                        {segment.walkingDistanceM > 0 && ` · ${segment.walkingDistanceM} m à pied`}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Écologie */}
            <div className="mt-3 text-sm font-medium text-emerald-400">🌱 CO₂ : {route.co2Kg} kg</div>
          </div>
        );
      })}
    </div>
  );
}
