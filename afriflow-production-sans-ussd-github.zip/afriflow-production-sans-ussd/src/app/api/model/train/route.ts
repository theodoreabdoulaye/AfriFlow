import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { getLastEvaluation, loadProfiles, trainCityProfiles } from "@/lib/learning";

export const dynamic = "force-dynamic";

/**
 * POST /api/model/train { city } — entraîne les profils de vitesse appris
 * de la ville à partir des points GPS collectés (7 derniers jours) :
 * médianes par axe × heure × type de jour, persistées en base, puis
 * fusionnées aux prédictions du moteur.
 * Évaluation intégrée en holdout temporel 80/20 (jamais vu → test) :
 * erreur du profil historique générique vs profil appris, en km/h.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`train:${clientIp(req)}`, 12, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown = null;
  try {
    raw = await req.json();
  } catch {
    /* corps optionnel */
  }
  const body = raw && typeof raw === "object" && !Array.isArray(raw) ? (raw as Record<string, unknown>) : {};
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  try {
    const result = await trainCityProfiles(city);
    return NextResponse.json({
      ...result,
      evaluation:
        result.maeGenericKmh !== null && result.maeLearnedKmh !== null
          ? `Holdout temporel 80/20 : erreur moyenne ${result.maeGenericKmh} km/h (historique générique) → ${result.maeLearnedKmh} km/h (profils appris), soit ${result.improvementPct} % d'erreur en moins sur des points jamais vus à l'entraînement.`
          : "Pas assez de points GPS pour évaluer (il en faut au moins 10, dont 5 de test) : collectez des traces via la contribution GPS ou le simulateur, puis réentraînez.",
    });
  } catch {
    return NextResponse.json({ error: "Entraînement indisponible" }, { status: 503 });
  }
}

/** GET /api/model/train?city=dakar — état des profils appris de la ville. */
export async function GET(req: NextRequest) {
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  const profiles = await loadProfiles(city);
  const axes = [...profiles.entries()].map(([axisId, p]) => ({
    axisId,
    samples: p.samples,
    learnedHours: {
      weekday: p.weekday.filter((v) => v !== null).length,
      weekend: p.weekend.filter((v) => v !== null).length,
    },
  }));
  return NextResponse.json({
    city: city.id,
    trainedAxes: profiles.size,
    totalSamples: axes.reduce((a, x) => a + x.samples, 0),
    lastEvaluation: await getLastEvaluation(city),
    axes,
  });
}
