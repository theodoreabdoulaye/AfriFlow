import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { roadEdges } from "@/db/schema";
import type { CityDef } from "./cities";
import { awaitOsmEnrichment, getOsmEnrichment } from "./osm-enrich";

/**
 * Couche spatiale « road_edges » (portée du design PostGIS/sqlx) :
 * - table des arêtes enrichies (géométrie WGS84 en WKT + GeoJSON,
 *   capacité, risque d'inondation, nids-de-poule, zone protégée) ;
 * - au premier usage, on TENTE d'activer l'extension PostGIS : si elle
 *   est disponible, colonne GEOMETRY(LineString, 4326) + index GiST sont
 *   créés et remplis ; sinon (cas de cet environnement), la recherche du
 *   plus proche voisin repose sur l'index spatial par grille applicatif
 *   (spatial.ts), aux performances équivalentes pour notre graphe ;
 * - le graphe est synchronisé depuis les axes curés + l'enrichissement
 *   OSM réel (Overpass), puis servi depuis la base.
 */

const RELIABLE_HIGHWAY = new Set(["motorway", "trunk", "primary", "secondary", "tertiary"]);

let postgisState: "unknown" | "available" | "unavailable" = "unknown";

export function isPostgisAvailable(): boolean {
  return postgisState === "available";
}

async function ensurePostgis(): Promise<void> {
  if (postgisState !== "unknown") return;
  try {
    await db.execute(sql`CREATE EXTENSION IF NOT EXISTS postgis`);
    await db.execute(
      sql`ALTER TABLE road_edges ADD COLUMN IF NOT EXISTS geometry geometry(LineString, 4326)`,
    );
    await db.execute(
      sql`CREATE INDEX IF NOT EXISTS idx_road_edges_geom ON road_edges USING GIST (geometry)`,
    );
    await db.execute(
      sql`UPDATE road_edges SET geometry = ST_GeomFromText(geom_wkt, 4326) WHERE geometry IS NULL`,
    );
    postgisState = "available";
  } catch {
    // Extension absente de cet environnement PostgreSQL : repli grille.
    postgisState = "unavailable";
  }
}

function toWkt(coords: [number, number][]): string {
  // PostGIS : ordre (longitude, latitude).
  return `LINESTRING(${coords.map(([lat, lon]) => `${lon} ${lat}`).join(", ")})`;
}

const lastSync = new Map<string, number>();
const SYNC_TTL_MS = 10 * 60_000;
const syncInflight = new Map<string, Promise<void>>();

async function doSyncRoadEdges(city: CityDef): Promise<void> {
  await ensurePostgis();
  // Attendre les attributs OSM (arrière-plan) pour écrire des arêtes complètes.
  const enrichment = await awaitOsmEnrichment(city, 30_000);
  const now = new Date();
  for (const axis of city.axes) {
    const osm = enrichment.byAxis.get(axis.id) ?? null;
    const capacityVph =
      osm && osm.highway && RELIABLE_HIGHWAY.has(osm.highway) ? osm.capacityVph : axis.capacityVehH;
    const coords = axis.gps;
    const values = {
      osmWayId: osm?.wayId ?? null,
      name: axis.name,
      fromNode: axis.from,
      toNode: axis.to,
      lengthM: Math.round(axis.lengthKm * 1000),
      baselineSpeedKmh: osm?.maxspeedKmh
        ? Math.min(axis.freeFlowKmh, osm.maxspeedKmh)
        : axis.freeFlowKmh,
      capacityVph,
      floodRisk: osm?.floodRisk ?? (axis.floodProne ? 0.65 : 0.1),
      potholeSeverity: osm?.potholeSeverity ?? axis.potholes,
      isProtectedZone: !!axis.protectedZone,
      highwayType: osm?.highway ?? null,
      geomWkt: toWkt(coords),
      geomJson: coords,
      updatedAt: now,
    };
    await db
      .insert(roadEdges)
      .values({ city: city.id, id: axis.id, ...values })
      .onConflictDoUpdate({
        target: [roadEdges.city, roadEdges.id],
        set: values,
      });
    if (postgisState === "available") {
      try {
        await db.execute(
          sql`UPDATE road_edges SET geometry = ST_GeomFromText(${values.geomWkt}, 4326) WHERE city = ${city.id} AND id = ${axis.id}`,
        );
      } catch {
        /* colonne géométrie indisponible : WKT/GeoJSON suffisent */
      }
    }
  }
  lastSync.set(city.id, Date.now());
}

/** Synchronise le graphe enrichi en base (arrière-plan, ≤ 1×/10 min par ville). */
export function syncRoadEdges(city: CityDef): void {
  if (syncInflight.has(city.id)) return;
  const last = lastSync.get(city.id) ?? 0;
  if (Date.now() - last < SYNC_TTL_MS) return;
  const task = doSyncRoadEdges(city)
    .catch(() => undefined)
    .finally(() => syncInflight.delete(city.id));
  syncInflight.set(city.id, task);
  void task;
}

/** Force une synchronisation immédiate (endpoint d'administration). */
export async function syncRoadEdgesNow(city: CityDef): Promise<number> {
  await doSyncRoadEdges(city);
  const rows = await db.select({ id: roadEdges.id }).from(roadEdges);
  return rows.length;
}

export interface RoadEdgeRow {
  id: string;
  osmWayId: number | null;
  name: string | null;
  fromNode: string;
  toNode: string;
  lengthM: number;
  baselineSpeedKmh: number;
  capacityVph: number;
  floodRisk: number;
  potholeSeverity: number;
  isProtectedZone: boolean;
  highwayType: string | null;
  geometry: { type: "LineString"; coordinates: [number, number][] };
}

/** Lit les arêtes persistées d'une ville (géométries GeoJSON prêtes pour le frontend). */
export async function loadRoadEdges(city: CityDef): Promise<RoadEdgeRow[]> {
  try {
    const rows = await db.select().from(roadEdges).where(eq(roadEdges.city, city.id));
    return rows
      .map((r) => ({
        id: r.id,
        osmWayId: r.osmWayId,
        name: r.name,
        fromNode: r.fromNode,
        toNode: r.toNode,
        lengthM: r.lengthM,
        baselineSpeedKmh: r.baselineSpeedKmh,
        capacityVph: r.capacityVph,
        floodRisk: r.floodRisk,
        potholeSeverity: r.potholeSeverity,
        isProtectedZone: r.isProtectedZone,
        highwayType: r.highwayType,
        // GeoJSON : ordre [longitude, latitude].
        geometry: {
          type: "LineString" as const,
          coordinates: (r.geomJson ?? []).map(([lat, lon]) => [lon, lat] as [number, number]),
        },
      }));
  } catch {
    return [];
  }
}

/** Géométries GeoJSON d'une liste d'axes (depuis la base, repli graphe curé). */
export async function getRoadEdgeGeometries(
  city: CityDef,
  axisIds: string[],
): Promise<{ type: "LineString"; coordinates: [number, number][] }[]> {
  const rows = await loadRoadEdges(city);
  const byId = new Map(rows.map((r) => [r.id, r.geometry]));
  return axisIds.map((id) => {
    const fromDb = byId.get(id);
    if (fromDb) return fromDb;
    const axis = city.axes.find((a) => a.id === id);
    return {
      type: "LineString" as const,
      coordinates: (axis?.gps ?? []).map(([lat, lon]) => [lon, lat] as [number, number]),
    };
  });
}

export function postgisStatus(): string {
  return postgisState;
}
