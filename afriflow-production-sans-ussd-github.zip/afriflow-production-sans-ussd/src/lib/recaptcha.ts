export async function verifyRecaptcha(token: unknown, action: string, origin: string) {
  const secret = process.env.RECAPTCHA_SECRET_KEY;
  if (!secret || typeof token !== "string" || !token || token.length > 4096) return false;
  const response = await fetch("https://www.google.com/recaptcha/api/siteverify", {
    method: "POST", body: new URLSearchParams({ secret, response: token }), signal: AbortSignal.timeout(8000),
  });
  if (!response.ok) return false;
  const result = await response.json() as { success?: boolean; score?: number; action?: string; hostname?: string };
  // Google's public test secret deliberately omits score/action and reports
  // hostname "testkey.google.com". It is accepted only in development when
  // explicitly configured; production must use real reCAPTCHA keys.
  if (process.env.NODE_ENV !== "production" && secret === "6LeIxAcTAAAAAGG-vFI1TnRWxMZNFuojJ4WifJWe") return result.success === true;
  return result.success === true && (result.score ?? 0) >= 0.5 && result.action === action && result.hostname === new URL(origin).hostname;
}
