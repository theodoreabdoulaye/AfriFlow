import { config } from "dotenv";
import { validateProductionEnv } from "./production-env";

// Next.js production precedence; exported variables always win.
for (const path of [".env.production.local", ".env.local", ".env.production", ".env"]) {
  config({ path, override: false, quiet: true });
}
const errors = validateProductionEnv(process.env);
if (errors.length) {
  console.error("Production preflight failed (values withheld):");
  for (const error of errors) console.error(`- ${error}`);
  process.exitCode = 1;
} else {
  console.log("Production preflight passed: configuration syntax only; no external connections or migrations performed.");
}
