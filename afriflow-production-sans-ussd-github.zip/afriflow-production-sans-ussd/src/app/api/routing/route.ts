import { NextRequest, NextResponse } from "next/server";
import { and, count, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { CITY_MAP, getZone } from "@/lib/cities";
import {
  axisCharge,
  findRoutes,
  quotaTotalFor,
  type RoutePriorities,
  type VehicleProfile,
} from "@/lib/engine";
import { requirePaidAccess } from "@/lib/access";
import { parseHourParam } from "@/lib/params";
import type { HeatmapPayload } from "@/lib/api-types";
import { buildHeatmap, quotaGrantsLastHour } from "@/lib/server-data";
import { fetchWeather } from "@/lib/weather";

export const dynamic = "force-dynamic";

/**
 * Cache de corridors (équivalent moka du prototype) : TTL 5 minutes,
 * 1000 corridors maximum, clé = départ:arrivée:profil:météo:quotas:monde.
 * À chaque HIT, le chemin est REVALIDÉ : si un axe a atteint 80 % de
 * charge, le cache est invalidé silencieusement et A* recalcule.
 */
const corridorCache = new Map<
  string,
  { at: number; payload: Record<string, unknown> }
>();
const CORRIDOR_TTL_MS = 300_000;
const CORRIDOR_MAX_ENTRIES = 1000;

interface CachedRouteLeg {
  axisId: string;
}
interface CachedRoute {
  legs: CachedRouteLeg[];
}

/** Un chemin caché reste valide si aucun de ses axes n'a atteint 80 %. */
function isRouteStillValid(
  payload: Record<string, unknown>,
  heat: HeatmapPayload,
  grantedByAxis: Map<string, number>,
  city: (typeof CITY_MAP)[string],
): boolean {
  const stateMap = new Map(heat.axes.map((a) => [a.axisId, a]));
  const routes = (payload.routes ?? []) as CachedRoute[];
  for (const route of routes) {
    for (const leg of route.legs) {
      const state = stateMap.get(leg.axisId);
      const axisDef = city.axes.find((a) => a.id === leg.axisId);
      if (!state || !axisDef) continue;
      const charge = axisCharge(
        state,
        grantedByAxis.get(leg.axisId) ?? 0,
        quotaTotalFor(axisDef),
      );
      if (charge >= 0.8) return false;
    }
  }
  return true;
}

/**
 * GET /api/routing?city=dakar&from=plateau&to=pikine&time=1&fuel=1&safety=0&practicability=1&hour=18
 * Itinéraire ventilé : principal + délestage sous quota MFD + alternative,
 * zones protégées bloquées à ≥ 80 % de capacité.
 * score = fluidité × 1/(1+densité) × critères
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const params = req.nextUrl.searchParams;
  const city = CITY_MAP[params.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  const from = params.get("from") ?? city.zones[0].id;
  const to = params.get("to") ?? city.zones[city.zones.length - 1].id;
  if (!getZone(city, from) || !getZone(city, to)) {
    return NextResponse.json(
      { error: "Zone de départ ou de destination inconnue pour cette ville." },
      { status: 422, headers: { "Cache-Control": "private, no-store" } },
    );
  }
  if (from === to) {
    return NextResponse.json(
      { error: "Le départ et la destination sont identiques : choisissez deux zones différentes." },
      { status: 422, headers: { "Cache-Control": "private, no-store" } },
    );
  }
  const hour = parseHourParam(params.get("hour"));

  const prio: RoutePriorities = {
    time: params.get("time") !== "0",
    fuel: params.get("fuel") === "1",
    safety: params.get("safety") === "1",
    practicability: params.get("practicability") === "1",
  };

  // Carte, météo, quotas et état du monde en parallèle (une seule latence).
  const [heat, weather, grantedByAxis, worldRows] = await Promise.all([
    buildHeatmap(city, { hourOverride: hour }),
    fetchWeather(city),
    quotaGrantsLastHour(city.id),
    db
      .select({ n: count(), m: sql<number | null>`max(${incidents.id})` })
      .from(incidents)
      .where(
        and(
          eq(incidents.city, city.id),
          eq(incidents.status, "broadcast"),
          gte(incidents.createdAt, new Date(Date.now() - 3 * 3600_000)),
        ),
      )
      .catch(() => [{ n: 0, m: null }]),
  ]);
  // Empreinte d'état du monde : nombre + dernier incident diffusé
  // (toute création/validation change la clé, pas seulement le compteur).
  const worldFingerprint = `${worldRows[0]?.n ?? 0}:${worldRows[0]?.m ?? 0}`;

  const at = new Date(Date.now() + (city.tzOffsetMin ?? 0) * 60_000);
  if (hour !== null) at.setUTCHours(hour, at.getUTCMinutes(), 0, 0);

  const profileParam = params.get("profile");
  const profile: VehicleProfile =
    profileParam === "gbaka" || profileParam === "urgence" ? profileParam : "standard";

  // Clé de corridor : itinéraire + profil + priorités + heure + état des quotas.
  const grantsHash = [...grantedByAxis.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([k, v]) => `${k}:${v}`)
    .join(",");
  const corridorKey = [
    city.id,
    from,
    to,
    profile,
    prio.time ? 1 : 0,
    prio.fuel ? 1 : 0,
    prio.safety ? 1 : 0,
    prio.practicability ? 1 : 0,
    hour ?? "rt",
    grantsHash,
    `w${worldFingerprint}`,
    `m${heat.weather.level}:${heat.weather.floodRiskLevel ?? 0}`,
  ].join("|");
  let cacheStatus: "miss" | "hit-invalidé" = "miss";
  const cachedCorridor = corridorCache.get(corridorKey);
  if (cachedCorridor && Date.now() - cachedCorridor.at < CORRIDOR_TTL_MS) {
    if (isRouteStillValid(cachedCorridor.payload, heat, grantedByAxis, city)) {
      return NextResponse.json(
        {
          ...cachedCorridor.payload,
          meta: {
            algorithm: "A* (heuristique haversine)",
            computeMs: 0,
            fromCache: true,
            cacheStatus: "hit-validé",
          },
        },
        { headers: { "Cache-Control": "private, no-store" } },
      );
    }
    // Invalidation silencieuse : un axe du chemin a atteint son quota.
    corridorCache.delete(corridorKey);
    cacheStatus = "hit-invalidé";
  }

  const startedAt = performance.now();
  const routes = findRoutes(city, heat.axes, from, to, prio, weather, { grantedByAxis }, at, profile);
  if (routes.length === 0) {
    return NextResponse.json({ error: "Aucun itinéraire trouvé entre ces deux zones." }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }
  const computeMs = Math.max(1, Math.round(performance.now() - startedAt));
  const nodesExplored = routes.reduce((a, r) => a + (r.exploredNodes ?? 0), 0);

  const payload: Record<string, unknown> = {
    city: city.id,
    from,
    to,
    profile,
    priorities: prio,
    weather: { label: weather.label.toLowerCase(), level: weather.level },
    routes,
    engine:
      "Coût généralisé = (Distance/Vitesse) × M_profil × (1 + P_qualité + P_sécurité) × M_quota — A*, porté du prototype Rust",
  };
  if (corridorCache.size >= CORRIDOR_MAX_ENTRIES) {
    // Éviction des plus anciennes entrées (Map ordonnée par insertion).
    for (const k of corridorCache.keys()) {
      corridorCache.delete(k);
      if (corridorCache.size < CORRIDOR_MAX_ENTRIES) break;
    }
  }
  corridorCache.set(corridorKey, { at: Date.now(), payload });

  return NextResponse.json(
    {
      ...payload,
      meta: {
        algorithm: "A* (heuristique haversine)",
        computeMs,
        fromCache: false,
        cacheStatus,
        nodesExplored,
      },
    },
    { headers: { "Cache-Control": "private, no-store" } },
  );
}
