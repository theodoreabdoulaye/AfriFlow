import { and, asc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { paymentGrants } from "@/db/payment-schema";
import { getCurrentUser } from "@/lib/auth";

export async function getAccess(userId: string): Promise<{ active: boolean; expiresAt: string | null }> {
  const now = new Date();
  const grants = await db.select({ startsAt: paymentGrants.startsAt, expiresAt: paymentGrants.expiresAt }).from(paymentGrants)
    .where(and(eq(paymentGrants.userId, userId), eq(paymentGrants.revoked, false), gt(paymentGrants.expiresAt, now)))
    .orderBy(asc(paymentGrants.startsAt));
  let expiry = now.getTime();
  // Merge stacked renewals, but do not bridge a gap left by a revoked grant.
  for (const grant of grants) {
    if (grant.startsAt.getTime() > expiry) break;
    expiry = Math.max(expiry, grant.expiresAt.getTime());
  }
  return { active: expiry > now.getTime(), expiresAt: expiry > now.getTime() ? new Date(expiry).toISOString() : null };
}

export async function requirePaidAccess(): Promise<Response | null> {
  try {
    const user = await getCurrentUser();
    if (!user) return Response.json({ error: "Authentication required" }, { status: 401, headers: { "Cache-Control": "private, no-store" } });
    if (!(await getAccess(user.id)).active) return Response.json({ error: "Paid access required" }, { status: 402, headers: { "Cache-Control": "private, no-store" } });
    return null;
  } catch {
    return Response.json({ error: "Access service unavailable" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
  }
}
