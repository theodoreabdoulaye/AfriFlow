import { createHash, randomBytes, randomUUID } from "node:crypto";
import { and, eq, gt } from "drizzle-orm";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, userSessions } from "@/db/auth-schema";
import { hashPassword, isValidPassword, verifyPassword } from "@/lib/password";
import { clientIp, rateLimit } from "@/lib/rate-limit";
import { verifyRecaptcha } from "@/lib/recaptcha";
import { OAuth2Client } from "google-auth-library";

export const SESSION_COOKIE = "afriflow_session";
const sessionSeconds = 30 * 24 * 60 * 60;
const cookieOptions = { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: "lax" as const, path: "/" };
const publicUser = { id: users.id, email: users.email, name: users.name };
const tokenHash = (token: string) => createHash("sha256").update(token).digest("hex");

export function requireSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return req.method !== "POST";
  try {
    const expected = new URL(process.env.NEXT_PUBLIC_SITE_URL ?? req.url).origin;
    return expected !== "null" && origin === expected;
  } catch {
    return false;
  }
}

export async function getCurrentUser(): Promise<{ id: string; email: string; name: string } | null> {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const [user] = await db.select(publicUser).from(userSessions)
    .innerJoin(users, eq(users.id, userSessions.userId))
    .where(and(eq(userSessions.tokenHash, tokenHash(token)), gt(userSessions.expiresAt, new Date()))).limit(1);
  // Database failures intentionally propagate so callers do not mistake an outage for logout.
  return user ?? null;
}

function reply(body: unknown, status = 200) {
  return NextResponse.json(body, { status, headers: { "Cache-Control": "no-store" } });
}

class BodyError extends Error {
  constructor(readonly status: number) { super("Invalid request"); }
}

async function readBody(req: Request): Promise<Record<string, unknown>> {
  if (!req.headers.get("content-type")?.toLowerCase().startsWith("application/json")) throw new BodyError(415);
  if (Number(req.headers.get("content-length")) > 4096) throw new BodyError(413);
  const reader = req.body?.getReader();
  if (!reader) throw new BodyError(400);
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 4096) { await reader.cancel(); throw new BodyError(413); }
      chunks.push(value);
    }
    const body: unknown = JSON.parse(Buffer.concat(chunks).toString("utf8"));
    if (!body || typeof body !== "object" || Array.isArray(body)) throw new BodyError(400);
    return body as Record<string, unknown>;
  } catch (error) {
    if (error instanceof BodyError) throw error;
    throw new BodyError(400);
  } finally { reader.releaseLock(); }
}

export async function handleAuth(req: Request, action: "register" | "login" | "google" | "logout" | "me") {
  if (action !== "me" && !requireSameOrigin(req)) return reply({ error: "Forbidden origin" }, 403);
  // This reused limiter is per process, not distributed; proxy IP headers must be trusted.
  // Production multi-instance deployments need a shared edge/Redis limiter as well.
  if (action !== "me") {
    const ip = clientIp(req).slice(0, 128);
    const limit = rateLimit(`auth:${action}:${ip}`, action === "logout" ? 30 : 10, 60_000);
    if (!limit.ok) {
      const response = reply({ error: "Too many requests" }, 429);
      response.headers.set("Retry-After", String(limit.retryAfterSec));
      return response;
    }
  }
  try {
    if (action === "me") return reply({ user: await getCurrentUser() });
    if (action === "logout") {
      const token = (await cookies()).get(SESSION_COOKIE)?.value;
      if (token && /^[a-f0-9]{64}$/.test(token)) await db.delete(userSessions).where(eq(userSessions.tokenHash, tokenHash(token)));
      const response = reply({ user: null });
      response.cookies.set(SESSION_COOKIE, "", { ...cookieOptions, maxAge: 0, expires: new Date(0) });
      return response;
    }
    const body = await readBody(req);
    if (!process.env.RECAPTCHA_SECRET_KEY) return reply({ error: "Protection reCAPTCHA non configuree." }, 503);
    if (!await verifyRecaptcha(body.recaptchaToken, action, process.env.NEXT_PUBLIC_SITE_URL ?? req.url)) return reply({ error: "Verification reCAPTCHA refusee. Reessayez." }, 400);
    if (action === "google") {
      const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;
      if (!clientId) return reply({ error: "Connexion Google non configuree." }, 503);
      if (typeof body.credential !== "string" || body.credential.length > 3000) return reply({ error: "Identifiant Google invalide." }, 400);
      let payload;
      try {
        payload = (await new OAuth2Client(clientId).verifyIdToken({ idToken: body.credential, audience: clientId })).getPayload();
      } catch { return reply({ error: "Identifiant Google invalide." }, 401); }
      if (!payload?.sub || !payload.email || !payload.email_verified) return reply({ error: "Adresse Google non verifiee." }, 401);
      const email = payload.email.toLowerCase();
      const token = randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + sessionSeconds * 1000);
      // Never silently link Google to an existing password account.
      const marker = `google:${payload.sub}`;
      const user = await db.transaction(async (tx) => {
        await tx.insert(users).values({ id: randomUUID(), email, name: (payload.name || email).slice(0, 80), passwordHash: marker }).onConflictDoNothing({ target: users.email });
        const [record] = await tx.select().from(users).where(eq(users.email, email)).limit(1);
        if (!record || record.passwordHash !== marker) return null;
        await tx.insert(userSessions).values({ tokenHash: tokenHash(token), userId: record.id, expiresAt });
        return { id: record.id, email: record.email, name: record.name };
      });
      if (!user) return reply({ error: "Cette adresse possede deja un compte. Utilisez votre mot de passe." }, 409);
      const response = reply({ user });
      response.cookies.set(SESSION_COOKIE, token, { ...cookieOptions, maxAge: sessionSeconds, expires: expiresAt });
      return response;
    }
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const name = typeof body.name === "string" ? body.name.trim() : "";
    if (typeof body.email !== "string" || body.email.length > 254 || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      || !isValidPassword(body.password) || (action === "register" && (!name || name.length > 80 || (body.name as string).length > 80))) {
      return reply({ error: "Invalid email, name, or password (12 to 128 characters)" }, 400);
    }
    // Account key is hashed, so limiter keys do not retain email addresses.
    const accountLimit = rateLimit(`auth:account:${tokenHash(email)}`, 20, 15 * 60_000);
    if (!accountLimit.ok) {
      const response = reply({ error: "Too many requests" }, 429);
      response.headers.set("Retry-After", String(accountLimit.retryAfterSec));
      return response;
    }
    const token = randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + sessionSeconds * 1000);
    let user: { id: string; email: string; name: string };
    if (action === "register") {
      const passwordHash = await hashPassword(body.password);
      const created = await db.transaction(async (tx) => {
        const [record] = await tx.insert(users).values({ id: randomUUID(), email, name, passwordHash }).onConflictDoNothing({ target: users.email }).returning(publicUser);
        if (!record) return null;
        await tx.insert(userSessions).values({ tokenHash: tokenHash(token), userId: record.id, expiresAt });
        return record;
      });
      if (!created) return reply({ error: "Unable to register with these details" }, 409);
      user = created;
    } else {
      const [record] = await db.select().from(users).where(eq(users.email, email)).limit(1);
      const valid = await verifyPassword(body.password, record?.passwordHash ?? "");
      if (!valid || !record) return reply({ error: "Invalid email or password" }, 401);
      user = { id: record.id, email: record.email, name: record.name };
      await db.insert(userSessions).values({ tokenHash: tokenHash(token), userId: user.id, expiresAt });
    }
    const response = reply({ user }, action === "register" ? 201 : 200);
    response.cookies.set(SESSION_COOKIE, token, { ...cookieOptions, maxAge: sessionSeconds, expires: expiresAt });
    return response;
  } catch (error) {
    if (error instanceof BodyError) return reply({ error: "Invalid request body" }, error.status);
    // Never expose database diagnostics, credentials, or password material.
    return reply({ error: "Authentication temporarily unavailable" }, 503);
  }
}
