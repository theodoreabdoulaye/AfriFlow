import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { jsonCached } from "@/lib/http-cache";
import { ensureCitySeed, ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * GET /api/incidents/export?city=dakar&type=accident — export GeoJSON des
 * signalements communautaires des 6 dernières heures, positionnés sur
 * l'axe concerné. Pensé pour les SIG des villes et les réutilisations
 * (QGIS, uMap, portails open data) : format RFC 7946.
 */
export async function GET(req: NextRequest) {
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  const typeFilter = req.nextUrl.searchParams.get("type");
  await ensureSeed();
  await ensureCitySeed(city);

  let features: Record<string, unknown>[] = [];
  try {
    const sixHoursAgo = new Date(Date.now() - 6 * 3600_000);
    const rows = await db
      .select()
      .from(incidents)
      .where(and(eq(incidents.city, city.id), gte(incidents.createdAt, sixHoursAgo)))
      .orderBy(desc(incidents.createdAt))
      .limit(500);
    features = rows
      .filter((i) => !typeFilter || i.type === typeFilter)
      .map((i) => {
        const axis = getAxis(city, i.axisId);
        const mid = axis?.gps[Math.floor(axis.gps.length / 2)] ?? [city.lat, city.lon];
        return {
          type: "Feature",
          geometry: { type: "Point", coordinates: [mid[1], mid[0]] },
          properties: {
            id: i.id,
            type: i.type,
            severity: i.severity,
            confidence: i.confidence,
            confirmations: i.confirmations,
            status: i.status,
            channel: i.channel,
            network: i.network,
            description: i.description,
            axis: axis?.name ?? i.axisId,
            city: city.name,
            country: city.country,
            createdAt: i.createdAt,
          },
        };
      });
  } catch {
    features = [];
  }

  return jsonCached(
    req,
    {
      type: "FeatureCollection",
      name: `afriflow-incidents-${city.id}`,
      generatedAt: new Date().toISOString(),
      features,
    },
    20,
    60,
  );
}
