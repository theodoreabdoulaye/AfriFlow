"use client";
import Script from "next/script";
import { useContext, useRef } from "react";
import { NonceContext } from "./SecurityNonce";

declare global {
  interface Window {
    grecaptcha?: { ready: (callback: () => void) => void; execute: (key: string, options: { action: string }) => Promise<string> };
    google?: { accounts: { id: {
      initialize: (options: { client_id: string; callback: (response: { credential: string }) => void }) => void;
      renderButton: (element: HTMLElement, options: { theme: string; size: string; text: string }) => void;
    } } };
  }
}
export async function recaptchaToken(action: string): Promise<string> {
  const key = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY;
  const captcha = window.grecaptcha;
  if (!key || !captcha) throw new Error("Protection reCAPTCHA indisponible. Rechargez la page ou contactez le support.");
  return new Promise((resolve, reject) => captcha.ready(() => { captcha.execute(key, { action }).then(resolve, reject); }));
}
export default function GoogleAuth({ onError, onSuccess }: { onError: (message: string) => void; onSuccess: () => void }) {
  const container = useRef<HTMLDivElement>(null);
  const nonce = useContext(NonceContext);
  const clientId = process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID;
  const key = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY;
  return <>
    {key && <Script nonce={nonce} src={`https://www.google.com/recaptcha/api.js?render=${encodeURIComponent(key)}`} />}
    {clientId && <>
      <Script nonce={nonce} src="https://accounts.google.com/gsi/client" onReady={() => {
        window.google?.accounts.id.initialize({ client_id: clientId, callback: async ({ credential }) => {
          try {
            const token = await recaptchaToken("google");
            const res = await fetch("/api/auth/google", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ credential, recaptchaToken: token }) });
            const data = await res.json();
            if (!res.ok) throw new Error(data.error || "Connexion Google impossible.");
            onSuccess();
          } catch (error) { onError(error instanceof Error ? error.message : "Connexion Google impossible."); }
        } });
        if (container.current) window.google?.accounts.id.renderButton(container.current, { theme: "outline", size: "large", text: "signin_with" });
      }} />
      <div ref={container} className="mt-6 overflow-x-auto" />
    </>}
    <p className="mt-4 text-xs text-sage">Ce site est protege par reCAPTCHA. Les <a href="https://policies.google.com/privacy" className="underline">regles de confidentialite</a> et <a href="https://policies.google.com/terms" className="underline">conditions de Google</a> s&apos;appliquent.</p>
  </>;
}
