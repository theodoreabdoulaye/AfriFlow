/**
 * AfriFlow — déploiement régional : toutes les villes activées des pays
 * couverts (Sénégal, Gambie, Cap-Vert, Guinée, Guinée-Bissau, Mali,
 * Côte d'Ivoire, Burkina Faso, Bénin, Togo, Nigéria, Cameroun, Gabon).
 *
 * Chaque ville est décrite par ses quartiers réels ; le graphe routier
 * (zones + axes radiaux, périphérique et liaisons) est généré de façon
 * déterministe (même ville = même réseau à chaque redémarrage), avec les
 * mêmes attributs métier que les villes historiques : vitesses libres,
 * capacités, pics horaires, zones inondables, zones protégées.
 */
import type { AxisDef, CityDef, ZoneDef } from "./cities";

type Lang = "fr" | "en" | "pt";

interface CitySpec {
  id: string;
  name: string;
  country: string;
  countryCode: string;
  lat: number;
  lon: number;
  /** Quartiers réels — le premier est le centre-ville. */
  zones: string[];
  lang?: Lang;
  /** 0..1 — probabilité d'axes inondables (villes côtières / delta). */
  floodRisk?: number;
}

export const COUNTRY_ORDER = [
  // Afrique de l'Ouest
  "SN", "GM", "CV", "GN", "GW", "ML", "CI", "BF", "BJ", "TG", "GH", "NE", "NG", "LR", "SL",
  // Afrique centrale
  "CM", "GA", "TD", "CF", "CG", "CD", "GQ", "ST", "AO",
  // Afrique du Nord
  "MR", "DZ", "MA", "TN", "LY", "EG",
  // Afrique de l'Est et Corne
  "SD", "SS", "ER", "DJ", "SO", "ET", "KE", "UG", "TZ", "RW", "BI", "MW", "MZ",
  // Afrique australe et océan Indien
  "NA", "BW", "ZA", "ZM", "ZW", "LS", "SZ", "MG", "MU", "SC", "KM",
];

const SPECS: CitySpec[] = [
  /* ---------------- Sénégal ---------------- */
  { id: "thies", name: "Thiès", country: "Sénégal", countryCode: "SN", lat: 14.79, lon: -16.93, zones: ["Centre-ville", "Nguinth", "Randoulène", "Cité Lamy", "Hersent", "Diamaguène", "Médina Fall", "Dixième"] },
  { id: "saint-louis", name: "Saint-Louis", country: "Sénégal", countryCode: "SN", lat: 16.03, lon: -16.5, floodRisk: 0.5, zones: ["Île — Centre", "Sor", "Guet Ndar", "Pikine Saint-Louis", "Ndiolofène", "Hydrobase", "Darou", "Boudiouck"] },
  { id: "ziguinchor", name: "Ziguinchor", country: "Sénégal", countryCode: "SN", lat: 12.57, lon: -16.27, floodRisk: 0.4, zones: ["Centre-ville", "Tilène", "Lyndiane", "Kandialang", "Boucotte", "Djibock", "Castor"] },
  { id: "touba", name: "Touba", country: "Sénégal", countryCode: "SN", lat: 14.85, lon: -15.88, zones: ["Grande Mosquée", "Darou Minam", "Darou Khoudoss", "Gouye Mbind", "Ndindy", "Keur Niang", "Mbar"] },
  { id: "kaolack", name: "Kaolack", country: "Sénégal", countryCode: "SN", lat: 14.16, lon: -16.25, floodRisk: 0.35, zones: ["Centre-ville", "Kabatoki", "Ndangane", "Sam", "Boustane", "Léona", "Kasnack"] },
  { id: "mbour", name: "Mbour", country: "Sénégal", countryCode: "SN", lat: 14.41, lon: -16.97, floodRisk: 0.4, zones: ["Centre-ville", "Grand Mbour", "Thiocé Est", "Médine", "Saly Portudal", "Nianing", "Somone"] },
  { id: "diourbel", name: "Diourbel", country: "Sénégal", countryCode: "SN", lat: 14.66, lon: -16.23, zones: ["Centre-ville", "Keur Goumack", "Ndayane", "Cheikh Anta", "Keur Cheikh", "Ndiawdoune"] },
  { id: "louga", name: "Louga", country: "Sénégal", countryCode: "SN", lat: 15.62, lon: -16.22, zones: ["Centre-ville", "Ndiang", "Santhiaba Nord", "Keur Serigne Bara", "Artillerie", "Montagne"] },
  { id: "tambacounda", name: "Tambacounda", country: "Sénégal", countryCode: "SN", lat: 13.77, lon: -13.67, zones: ["Centre-ville", "Médina Coura", "Saré Guilel", "Plateau", "Liberté", "Dépôt"] },
  { id: "kolda", name: "Kolda", country: "Sénégal", countryCode: "SN", lat: 12.89, lon: -14.94, floodRisk: 0.3, zones: ["Centre-ville", "Doumassou", "Sikilo Ouest", "Saré Moussa", "Bouna Kane", "Gadapara"] },
  { id: "tivaouane", name: "Tivaouane", country: "Sénégal", countryCode: "SN", lat: 14.95, lon: -16.82, zones: ["Centre-ville", "Keur Massamba", "Khalifa", "Seydi", "Mbawane"] },

  /* ---------------- Gambie ---------------- */
  { id: "banjul", name: "Banjul", country: "Gambie", countryCode: "GM", lat: 13.45, lon: -16.58, lang: "en", floodRisk: 0.6, zones: ["Albert Market", "Half Die", "Crab Island", "Soldier Town", "Tobacco Road", "Box Bar"] },
  { id: "serekunda", name: "Serekunda", country: "Gambie", countryCode: "GM", lat: 13.44, lon: -16.72, lang: "en", floodRisk: 0.4, zones: ["Serekunda Central", "Latrikunda", "Dippa Kunda", "Bakoteh", "Kololi", "Fajara", "Bundung", "Tallinding"] },
  { id: "brikama", name: "Brikama", country: "Gambie", countryCode: "GM", lat: 13.27, lon: -16.65, lang: "en", floodRisk: 0.3, zones: ["Brikama Central", "Nyambai", "Kabafita", "Misera", "Jalanbang", "Kunkujang"] },
  { id: "bakau", name: "Bakau", country: "Gambie", countryCode: "GM", lat: 13.48, lon: -16.68, lang: "en", floodRisk: 0.5, zones: ["Bakau Central", "Cape Point", "Kachikally", "New Town", "Old Town"] },
  { id: "farafenni", name: "Farafenni", country: "Gambie", countryCode: "GM", lat: 13.57, lon: -15.6, lang: "en", zones: ["Farafenni Central", "Médina", "Bamba Tenda", "Keur Ayib Road", "Illiassa Road"] },

  /* ---------------- Cap-Vert ---------------- */
  { id: "praia", name: "Praia", country: "Cap-Vert", countryCode: "CV", lat: 14.92, lon: -23.51, lang: "pt", floodRisk: 0.25, zones: ["Platô", "Achada Santo António", "Fazenda", "Várzea", "Palmarejo", "Tira Chapéu", "Achadinha", "Gamboa"] },
  { id: "mindelo", name: "Mindelo", country: "Cap-Vert", countryCode: "CV", lat: 16.89, lon: -24.99, lang: "pt", floodRisk: 0.2, zones: ["Centro", "Alto Miramar", "Ribeira Bote", "Fonte Cônego", "Lazareto", "Monte Sossego", "Chã de Alecrim"] },
  { id: "assomada", name: "Assomada", country: "Cap-Vert", countryCode: "CV", lat: 15.1, lon: -23.67, lang: "pt", zones: ["Centro", "Cutelo Gomes", "Achada Além", "Nhagar", "Chã de Santos"] },
  { id: "pedra-badejo", name: "Pedra Badejo", country: "Cap-Vert", countryCode: "CV", lat: 15.13, lon: -23.53, lang: "pt", floodRisk: 0.25, zones: ["Pedra Badejo Centro", "Achada Fazenda", "Renque Purga", "Saltos", "Porto Formoso"] },
  { id: "espargos", name: "Espargos", country: "Cap-Vert", countryCode: "CV", lat: 16.75, lon: -22.95, lang: "pt", zones: ["Espargos Centro", "Preguiça", "Hortelã", "Chã de Matias", "Terra Boa"] },

  /* ---------------- Guinée ---------------- */
  { id: "conakry", name: "Conakry", country: "Guinée", countryCode: "GN", lat: 9.54, lon: -13.68, floodRisk: 0.5, zones: ["Kaloum", "Dixinn", "Ratoma", "Matam", "Matoto", "Kipé", "Cosa", "Entag"] },
  { id: "kankan", name: "Kankan", country: "Guinée", countryCode: "GN", lat: 10.38, lon: -9.31, floodRisk: 0.25, zones: ["Centre-ville", "Sénkéfra", "Missira", "Salamanida", "Kabada", "Bordo"] },
  { id: "nzerekore", name: "Nzérékoré", country: "Guinée", countryCode: "GN", lat: 7.75, lon: -8.82, floodRisk: 0.3, zones: ["Centre-ville", "Dorota", "Gonia", "Nakoyakpala", "Mohomou", "Boma"] },
  { id: "kindia", name: "Kindia", country: "Guinée", countryCode: "GN", lat: 10.06, lon: -12.87, zones: ["Centre-ville", "Wondy", "Sambaya", "Gare routière", "Damakania"] },
  { id: "labe", name: "Labé", country: "Guinée", countryCode: "GN", lat: 11.32, lon: -12.29, zones: ["Centre-ville", "Pounthioun", "Daka", "Tata 1", "Konkola", "Nadhel"] },
  { id: "boke", name: "Boké", country: "Guinée", countryCode: "GN", lat: 10.94, lon: -14.3, floodRisk: 0.35, zones: ["Centre-ville", "Corréra", "Tamakènè", "Kamsar Route", "Baralandé"] },
  { id: "mamou", name: "Mamou", country: "Guinée", countryCode: "GN", lat: 10.38, lon: -12.09, zones: ["Centre-ville", "Pétel", "Sabouyah", "Horé-Fello", "Dounet Route"] },
  { id: "fria", name: "Fria", country: "Guinée", countryCode: "GN", lat: 10.38, lon: -13.58, zones: ["Centre-ville", "Katourou", "Aviation", "Sabendé", "Tanènè Route"] },

  /* ---------------- Guinée-Bissau ---------------- */
  { id: "bissau", name: "Bissau", country: "Guinée-Bissau", countryCode: "GW", lat: 11.86, lon: -15.6, lang: "pt", floodRisk: 0.5, zones: ["Centro", "Bairro Militar", "Cupelon de Baixo", "Antula", "Cuntum", "Quelelé", "Penha", "Luanda"] },
  { id: "bafata", name: "Bafatá", country: "Guinée-Bissau", countryCode: "GW", lat: 12.17, lon: -14.66, lang: "pt", floodRisk: 0.3, zones: ["Centro", "Bairro 14", "Bairro Novo", "Xalana", "Bambadinca Route"] },
  { id: "gabu", name: "Gabú", country: "Guinée-Bissau", countryCode: "GW", lat: 12.28, lon: -14.22, lang: "pt", zones: ["Centro", "Bairro Pitchi", "Sintcha Bocho", "Canamine Route", "Pirada Route"] },
  { id: "cacheu", name: "Cacheu", country: "Guinée-Bissau", countryCode: "GW", lat: 12.27, lon: -16.17, lang: "pt", floodRisk: 0.45, zones: ["Centro", "Pontão", "Cacheu Velho", "São Domingos Route", "Cabana"] },
  { id: "bolama", name: "Bolama", country: "Guinée-Bissau", countryCode: "GW", lat: 11.58, lon: -15.48, lang: "pt", floodRisk: 0.4, zones: ["Centro", "Bairro Novo", "Mussé", "São João Route"] },

  /* ---------------- Mali ---------------- */
  { id: "sikasso", name: "Sikasso", country: "Mali", countryCode: "ML", lat: 11.32, lon: -5.67, floodRisk: 0.2, zones: ["Centre-ville", "Wayerma 1", "Lafiabougou", "Hamdallaye", "Kamélé", "Médina"] },
  { id: "mopti", name: "Mopti", country: "Mali", countryCode: "ML", lat: 14.49, lon: -4.19, floodRisk: 0.55, zones: ["Vieux Mopti", "Sévaré", "Gangal", "Komoguel 1", "Mossinkoré", "Taïkiri"] },
  { id: "segou", name: "Ségou", country: "Mali", countryCode: "ML", lat: 13.45, lon: -6.27, floodRisk: 0.45, zones: ["Centre-ville", "Angoulème", "Dar Salam", "Missira", "Pelengana", "Soninkoura"] },
  { id: "kayes", name: "Kayes", country: "Mali", countryCode: "ML", lat: 14.44, lon: -11.44, floodRisk: 0.3, zones: ["Centre-ville", "Kayes N'Di", "Légal Ségou", "Lafiabougou", "Plateau", "Khasso"] },
  { id: "koutiala", name: "Koutiala", country: "Mali", countryCode: "ML", lat: 12.39, lon: -5.47, zones: ["Centre-ville", "Kokoun", "Koko", "Darsalam", "Hérémakono"] },
  { id: "gao", name: "Gao", country: "Mali", countryCode: "ML", lat: 16.27, lon: -0.04, floodRisk: 0.35, zones: ["Centre-ville", "Boulgoundié 1", "Sosso-Koïra", "Château d'eau", "Aljanabandia", "Forgho"] },
  { id: "tombouctou", name: "Tombouctou", country: "Mali", countryCode: "ML", lat: 16.77, lon: -3.01, floodRisk: 0.25, zones: ["Sankoré", "Djingareyber", "Sareikaina", "Hammabangou", "Abaradjou", "Kabara Route"] },
  { id: "bougouni", name: "Bougouni", country: "Mali", countryCode: "ML", lat: 11.42, lon: -7.48, zones: ["Centre-ville", "Massablacoro", "Torakabougou", "Farablé", "N'Tomikorobougou"] },

  /* ---------------- Côte d'Ivoire ---------------- */
  { id: "bouake", name: "Bouaké", country: "Côte d'Ivoire", countryCode: "CI", lat: 7.69, lon: -5.03, zones: ["Commerce", "Air France 1", "Koko", "Ahougnansou", "Nimbo", "Dar-es-Salam", "Belleville 1"] },
  { id: "yamoussoukro", name: "Yamoussoukro", country: "Côte d'Ivoire", countryCode: "CI", lat: 6.82, lon: -5.27, zones: ["Centre-ville", "Assabou", "Dioulakro", "Habitat", "Kokrénou", "N'Zuessy"] },
  { id: "san-pedro", name: "San-Pédro", country: "Côte d'Ivoire", countryCode: "CI", lat: 4.75, lon: -6.64, floodRisk: 0.5, zones: ["Centre-ville", "Bardot", "Zone portuaire", "Séwéké", "Balmer", "Lac Balmer"] },
  { id: "daloa", name: "Daloa", country: "Côte d'Ivoire", countryCode: "CI", lat: 6.88, lon: -6.45, floodRisk: 0.2, zones: ["Centre-ville", "Kennedy 2", "Lobia", "Tazibouo", "Soleil 1", "Gbokora"] },
  { id: "korhogo", name: "Korhogo", country: "Côte d'Ivoire", countryCode: "CI", lat: 9.46, lon: -5.64, zones: ["Centre-ville", "Koko", "Petit Paris", "Sinistré", "Cocody", "Natio"] },
  { id: "man", name: "Man", country: "Côte d'Ivoire", countryCode: "CI", lat: 7.41, lon: -7.55, zones: ["Centre-ville", "Commerce", "Zélé", "Libreville", "Dompleu Route", "Krico"] },
  { id: "gagnoa", name: "Gagnoa", country: "Côte d'Ivoire", countryCode: "CI", lat: 6.13, lon: -5.95, zones: ["Centre-ville", "Dioulabougou", "Garahio", "Babré", "Résidentiel", "Soleil"] },
  { id: "abengourou", name: "Abengourou", country: "Côte d'Ivoire", countryCode: "CI", lat: 6.73, lon: -3.5, zones: ["Centre-ville", "Dioulakro", "Cafétou", "Habitat", "Plateau", "Château"] },
  { id: "divo", name: "Divo", country: "Côte d'Ivoire", countryCode: "CI", lat: 5.84, lon: -5.36, zones: ["Centre-ville", "Grémien", "Dialogue", "Bada", "Konankro", "Plateau"] },

  /* ---------------- Burkina Faso ---------------- */
  { id: "bobo-dioulasso", name: "Bobo-Dioulasso", country: "Burkina Faso", countryCode: "BF", lat: 11.18, lon: -4.3, floodRisk: 0.25, zones: ["Centre-ville", "Konsa", "Dafra", "Sarfalao", "Ouezzinville", "Kua", "Bindougousso"] },
  { id: "koudougou", name: "Koudougou", country: "Burkina Faso", countryCode: "BF", lat: 12.25, lon: -2.37, zones: ["Centre-ville", "Issouka", "Bourkina", "Palogo", "Nayalgué"] },
  { id: "ouahigouya", name: "Ouahigouya", country: "Burkina Faso", countryCode: "BF", lat: 13.58, lon: -2.42, zones: ["Centre-ville", "Oufré", "Gondologo", "Youba", "Aoréma"] },
  { id: "banfora", name: "Banfora", country: "Burkina Faso", countryCode: "BF", lat: 10.63, lon: -4.76, floodRisk: 0.3, zones: ["Centre-ville", "Nafona 1", "Tangora", "Tatana", "Korona"] },
  { id: "kaya", name: "Kaya", country: "Burkina Faso", countryCode: "BF", lat: 13.09, lon: -1.08, zones: ["Centre-ville", "Pissila Route", "Pibaoré", "Boulsa Route", "Namissiguima"] },
  { id: "dedougou", name: "Dédougou", country: "Burkina Faso", countryCode: "BF", lat: 12.46, lon: -3.46, zones: ["Centre-ville", "Daboura", "Passakongo", "Kari", "Soukoura"] },
  { id: "fada-ngourma", name: "Fada N'Gourma", country: "Burkina Faso", countryCode: "BF", lat: 12.06, lon: 0.36, zones: ["Centre-ville", "Diapangou", "Tambaga Route", "Pouytenga Route", "Bogandé Route"] },
  { id: "gaoua", name: "Gaoua", country: "Burkina Faso", countryCode: "BF", lat: 10.33, lon: -3.18, zones: ["Centre-ville", "Tonkar", "Kampti Route", "Holly", "Djindjirma"] },

  /* ---------------- Bénin ---------------- */
  { id: "cotonou", name: "Cotonou", country: "Bénin", countryCode: "BJ", lat: 6.36, lon: 2.43, floodRisk: 0.5, zones: ["Ganhi", "Akpakpa", "Fidjrossè", "Godomey", "Cadjèhoun", "Jéricho", "Missèbo", "Zogbo"] },
  { id: "porto-novo", name: "Porto-Novo", country: "Bénin", countryCode: "BJ", lat: 6.5, lon: 2.61, floodRisk: 0.45, zones: ["Ouando", "Attakê", "Houinvié", "Djassin", "Tokpota", "Catchi"] },
  { id: "abomey-calavi", name: "Abomey-Calavi", country: "Bénin", countryCode: "BJ", lat: 6.45, lon: 2.36, floodRisk: 0.4, zones: ["Centre-ville", "Tankpè", "Akassato", "Zinvié", "Ouèdo", "Cocotomey"] },
  { id: "parakou", name: "Parakou", country: "Bénin", countryCode: "BJ", lat: 9.34, lon: 2.63, zones: ["Centre-ville", "Albarika", "Banikanni", "Tourou", "Wansirou", "Gbira"] },
  { id: "djougou", name: "Djougou", country: "Bénin", countryCode: "BJ", lat: 9.71, lon: 1.67, zones: ["Centre-ville", "Kamouhou", "Sassirou", "Zongo", "Madina"] },
  { id: "bohicon", name: "Bohicon", country: "Bénin", countryCode: "BJ", lat: 7.18, lon: 2.07, zones: ["Centre-ville", "Sodohomè", "Passagon", "Lissèzoun", "Avogbana"] },
  { id: "natitingou", name: "Natitingou", country: "Bénin", countryCode: "BJ", lat: 10.3, lon: 1.38, zones: ["Centre-ville", "Kotopounga", "Boriyouré", "Ourbouga", "Yarikou"] },
  { id: "abomey", name: "Abomey", country: "Bénin", countryCode: "BJ", lat: 7.18, lon: 1.99, zones: ["Hounli", "Vidolé", "Adja", "Djègbè", "Sogon"] },

  /* ---------------- Togo ---------------- */
  { id: "lome", name: "Lomé", country: "Togo", countryCode: "TG", lat: 6.14, lon: 1.22, floodRisk: 0.45, zones: ["Tokoin", "Bè Centre", "Adidogomé", "Agoè Nyivé", "Hédzranawoé", "Baguida", "Kégué", "Nyékonakpoè"] },
  { id: "sokode", name: "Sokodé", country: "Togo", countryCode: "TG", lat: 8.98, lon: 1.14, zones: ["Centre-ville", "Kpangalam", "Komah 1", "Tchawanda", "Akamadé", "Koma"] },
  { id: "kara", name: "Kara", country: "Togo", countryCode: "TG", lat: 9.55, lon: 1.19, zones: ["Centre-ville", "Tomdè", "Tchintchinda", "Chaminade", "Lama-Tessi"] },
  { id: "kpalime", name: "Kpalimé", country: "Togo", countryCode: "TG", lat: 6.91, lon: 0.63, zones: ["Centre-ville", "Agomé Kpalimé", "Tsavié", "Yokélé", "Adéta Route"] },
  { id: "atakpame", name: "Atakpamé", country: "Togo", countryCode: "TG", lat: 7.53, lon: 1.13, zones: ["Centre-ville", "Agbonou", "Djama", "Houdou", "Kamina Route"] },
  { id: "dapaong", name: "Dapaong", country: "Togo", countryCode: "TG", lat: 10.86, lon: 0.21, zones: ["Centre-ville", "Nassablé", "Tantigou", "Boumong", "Worgou"] },
  { id: "aneho", name: "Aného", country: "Togo", countryCode: "TG", lat: 6.23, lon: 1.6, floodRisk: 0.5, zones: ["Centre-ville", "Glidji", "Adjido", "Zébé", "Agbodrafo Route"] },

  /* ---------------- Nigéria ---------------- */
  { id: "lagos", name: "Lagos", country: "Nigéria", countryCode: "NG", lat: 6.52, lon: 3.37, lang: "en", floodRisk: 0.6, zones: ["Lagos Island", "Ikeja", "Victoria Island", "Lekki Phase 1", "Surulere", "Yaba", "Apapa", "Oshodi", "Ikorodu", "Ajah"] },
  { id: "abuja", name: "Abuja", country: "Nigéria", countryCode: "NG", lat: 9.06, lon: 7.49, lang: "en", zones: ["Wuse 2", "Garki", "Maitama", "Asokoro", "Gwarinpa", "Kubwa", "Nyanya", "Jabi"] },
  { id: "kano", name: "Kano", country: "Nigéria", countryCode: "NG", lat: 12.0, lon: 8.52, lang: "en", zones: ["Nassarawa", "Fagge", "Dala", "Gwale", "Tarauni", "Sabon Gari", "Bompai"] },
  { id: "ibadan", name: "Ibadan", country: "Nigéria", countryCode: "NG", lat: 7.38, lon: 3.9, lang: "en", floodRisk: 0.3, zones: ["Mapo", "Bodija", "Ring Road", "Mokola", "Challenge", "Agodi GRA", "Iyaganku"] },
  { id: "port-harcourt", name: "Port Harcourt", country: "Nigéria", countryCode: "NG", lat: 5.01, lon: 6.98, lang: "en", floodRisk: 0.7, zones: ["Old GRA", "D-Line", "Rumuola", "Mile One", "Rumuokoro", "Woji", "Choba"] },
  { id: "benin-city", name: "Benin City", country: "Nigéria", countryCode: "NG", lat: 6.34, lon: 5.62, lang: "en", zones: ["Ring Road", "GRA", "Ugbowo", "Sapele Road", "Aduwawa", "New Benin"] },
  { id: "onitsha", name: "Onitsha", country: "Nigéria", countryCode: "NG", lat: 6.15, lon: 6.78, lang: "en", floodRisk: 0.4, zones: ["Main Market", "Fegge", "GRA Onitsha", "Awka Road", "Nkpor", "Upper Iweka"] },
  { id: "aba", name: "Aba", country: "Nigéria", countryCode: "NG", lat: 5.11, lon: 7.37, lang: "en", floodRisk: 0.4, zones: ["Eziama", "Ariaria Market", "Ogbor Hill", "Asa Road", "PH Road", "Umuola"] },
  { id: "enugu", name: "Enugu", country: "Nigéria", countryCode: "NG", lat: 6.44, lon: 7.5, lang: "en", zones: ["Ogbete", "GRA Enugu", "Independence Layout", "New Haven", "Trans Ekulu", "Emene"] },
  { id: "jos", name: "Jos", country: "Nigéria", countryCode: "NG", lat: 9.93, lon: 8.89, lang: "en", zones: ["Terminus", "Anglo Jos", "Rayfield", "Bukuru", "Naraguta", "Tudun Wada"] },
  { id: "ilorin", name: "Ilorin", country: "Nigéria", countryCode: "NG", lat: 8.5, lon: 4.55, lang: "en", zones: ["Post Office Area", "GRA Ilorin", "Tanke", "Taiwo Road", "Fate", "Sango"] },
  { id: "maiduguri", name: "Maiduguri", country: "Nigéria", countryCode: "NG", lat: 11.83, lon: 13.15, lang: "en", floodRisk: 0.35, zones: ["Maiduguri Centre", "Old GRA", "Bulumkutu", "Gomari", "Baga Road", "Monday Market"] },
  { id: "calabar", name: "Calabar", country: "Nigéria", countryCode: "NG", lat: 4.95, lon: 8.32, lang: "en", floodRisk: 0.55, zones: ["Calabar Centre", "Marian Road", "Calabar South", "Atimbo", "Ikot Ansa", "Satellite Town"] },
  { id: "warri", name: "Warri", country: "Nigéria", countryCode: "NG", lat: 5.52, lon: 5.75, lang: "en", floodRisk: 0.6, zones: ["Effurun", "Enerhen Junction", "Udu", "Ekpan", "Aladja", "Ogunu"] },
  { id: "kaduna", name: "Kaduna", country: "Nigéria", countryCode: "NG", lat: 10.52, lon: 7.44, lang: "en", floodRisk: 0.3, zones: ["Kawo", "Kakuri", "Barnawa", "Ungwan Rimi", "Malali", "Tudun Wada Kaduna"] },
  { id: "akure", name: "Akure", country: "Nigéria", countryCode: "NG", lat: 7.25, lon: 5.2, lang: "en", zones: ["Alagbaka", "Oba-Ile", "Ondo Road", "FUTA South Gate", "Ijoka", "Araromi"] },
  { id: "bauchi", name: "Bauchi", country: "Nigéria", countryCode: "NG", lat: 10.31, lon: 9.84, lang: "en", zones: ["Bauchi Centre", "GRA Bauchi", "Yelwa", "Wuntin Dada", "Kofar Ran", "Tudun Salmanu"] },
  { id: "zaria", name: "Zaria", country: "Nigéria", countryCode: "NG", lat: 11.08, lon: 7.72, lang: "en", zones: ["Zaria City", "Sabon Gari Zaria", "Samaru", "Tudun Wada Zaria", "Kwangila", "Dan Magaji"] },

  /* ---------------- Cameroun ---------------- */
  { id: "douala", name: "Douala", country: "Cameroun", countryCode: "CM", lat: 4.06, lon: 9.71, floodRisk: 0.6, zones: ["Akwa", "Bonanjo", "Deïdo", "Bonabéri", "New Bell", "Bépanda", "Logbaba", "Makepe"] },
  { id: "yaounde", name: "Yaoundé", country: "Cameroun", countryCode: "CM", lat: 3.85, lon: 11.5, zones: ["Centre-ville", "Bastos", "Mokolo", "Elig-Essono", "Mvan", "Nkolbisson", "Mendong", "Nsimeyong"] },
  { id: "bafoussam", name: "Bafoussam", country: "Cameroun", countryCode: "CM", lat: 5.48, lon: 10.42, zones: ["Centre-ville", "Marché A", "Tougang Village", "Djeleng", "Famla", "Banéfo"] },
  { id: "bamenda", name: "Bamenda", country: "Cameroun", countryCode: "CM", lat: 5.96, lon: 10.16, lang: "en", zones: ["Commercial Avenue", "Old Town", "Nkwen", "Mankon", "Bambili Road", "Meta Quarter"] },
  { id: "garoua", name: "Garoua", country: "Cameroun", countryCode: "CM", lat: 9.3, lon: 13.4, floodRisk: 0.35, zones: ["Centre-ville", "Roumdé Adjia", "Plateau", "Kolléré", "Poumpoumré", "Djalingo"] },
  { id: "maroua", name: "Maroua", country: "Cameroun", countryCode: "CM", lat: 10.59, lon: 14.32, floodRisk: 0.3, zones: ["Centre-ville", "Kakataré", "Zokok Laddé", "Ouro-Tchédé", "Pallar", "Doualaré"] },
  { id: "ngaoundere", name: "Ngaoundéré", country: "Cameroun", countryCode: "CM", lat: 7.32, lon: 13.58, zones: ["Centre-ville", "Madagascar 1", "Joli Soir", "Baladji 2", "Dang", "Onaref"] },
  { id: "kribi", name: "Kribi", country: "Cameroun", countryCode: "CM", lat: 2.94, lon: 9.91, floodRisk: 0.5, zones: ["Centre-ville", "Grand Batanga", "Dombé", "Londji", "Afan Mabe"] },
  { id: "limbe", name: "Limbé", country: "Cameroun", countryCode: "CM", lat: 4.02, lon: 9.21, lang: "en", floodRisk: 0.5, zones: ["Down Beach", "Bota", "Mile Four", "Moliwe", "Batoke"] },
  { id: "bertoua", name: "Bertoua", country: "Cameroun", countryCode: "CM", lat: 4.58, lon: 13.68, zones: ["Centre-ville", "Mokolo Bertoua", "Tigaza", "Kano Bertoua", "Haoussa", "Nkolbikon"] },

  /* ---------------- Gabon ---------------- */
  { id: "libreville", name: "Libreville", country: "Gabon", countryCode: "GA", lat: 0.42, lon: 9.43, floodRisk: 0.4, zones: ["Centre-ville", "Akanda", "Owendo", "Lalala", "Nzeng-Ayong", "Alibandeng", "PK 12", "IAI"] },
  { id: "port-gentil", name: "Port-Gentil", country: "Gabon", countryCode: "GA", lat: -0.72, lon: 8.78, floodRisk: 0.55, zones: ["Centre-ville", "Balise", "Grand Village", "Mosquée", "Chic", "Quartier Sud"] },
  { id: "franceville", name: "Franceville", country: "Gabon", countryCode: "GA", lat: -1.63, lon: 13.58, zones: ["Centre-ville", "Potos 1", "Yoko", "Ondili", "Mbaya"] },
  { id: "oyem", name: "Oyem", country: "Gabon", countryCode: "GA", lat: 1.6, lon: 11.58, zones: ["Centre-ville", "Akoakam", "Quartier Administratif", "Angone", "Mitzic Route"] },
  { id: "moanda", name: "Moanda", country: "Gabon", countryCode: "GA", lat: -1.57, lon: 13.2, zones: ["Centre-ville", "Alliance", "Comilog", "Quartier Commercial", "Makouké Route"] },
  { id: "lambarene", name: "Lambaréné", country: "Gabon", countryCode: "GA", lat: -0.7, lon: 10.24, floodRisk: 0.6, zones: ["Centre-ville", "Isaac", "Adouma", "Petit Paris", "Mbigou Route"] },

  /* ---------------- Ghana ---------------- */
  { id: "accra", name: "Accra", country: "Ghana", countryCode: "GH", lat: 5.6, lon: -0.19, lang: "en", floodRisk: 0.45, zones: ["Osu", "Accra Central", "East Legon", "Spintex", "Tema", "Dansoman", "Madina", "Achimota"] },
  { id: "kumasi", name: "Kumasi", country: "Ghana", countryCode: "GH", lat: 6.69, lon: -1.62, lang: "en", floodRisk: 0.3, zones: ["Adum", "Asokwa", "Bantama", "Ahodwo", "Suame"] },
  { id: "takoradi", name: "Takoradi", country: "Ghana", countryCode: "GH", lat: 4.9, lon: -1.76, lang: "en", floodRisk: 0.4, zones: ["Centre", "Effia", "Anaji"] },
  { id: "tamale", name: "Tamale", country: "Ghana", countryCode: "GH", lat: 9.4, lon: -0.84, lang: "en", zones: ["Centre", "Lamashegu", "Sagnarigu"] },
  { id: "cape-coast", name: "Cape Coast", country: "Ghana", countryCode: "GH", lat: 5.11, lon: -1.24, lang: "en", floodRisk: 0.4, zones: ["Centre", "Pedu", "Abura"] },

  /* ---------------- Niger ---------------- */
  { id: "niamey", name: "Niamey", country: "Niger", countryCode: "NE", lat: 13.51, lon: 2.11, floodRisk: 0.45, zones: ["Plateau", "Niamey 2000", "Yantala", "Goudel", "Talladjé", "Lamordé", "Kirkissoye", "Koubia"] },
  { id: "zinder", name: "Zinder", country: "Niger", countryCode: "NE", lat: 13.8, lon: 8.99, zones: ["Centre-ville", "Birni", "Karkada", "Zengou", "HLL"] },
  { id: "maradi", name: "Maradi", country: "Niger", countryCode: "NE", lat: 13.5, lon: 7.1, zones: ["Centre-ville", "Ali Dan Sofo", "Soura", "Zaria"] },
  { id: "agadez", name: "Agadez", country: "Niger", countryCode: "NE", lat: 16.97, lon: 7.99, zones: ["Centre-ville", "Katanga", "Arguit", "Toudou"] },
  { id: "tahoua", name: "Tahoua", country: "Niger", countryCode: "NE", lat: 14.89, lon: 5.27, zones: ["Centre-ville", "Sabon Gari", "Toulaoua"] },

  /* ---------------- Mauritanie ---------------- */
  { id: "nouakchott", name: "Nouakchott", country: "Mauritanie", countryCode: "MR", lat: 18.09, lon: -15.95, floodRisk: 0.45, zones: ["Tevragh-Zeina", "Ksar", "Arafat", "Sebkha", "Dar Naim", "Toujounine", "El Mina", "Riadh"] },
  { id: "nouadhibou", name: "Nouadhibou", country: "Mauritanie", countryCode: "MR", lat: 20.93, lon: -17.03, floodRisk: 0.3, zones: ["Centre-ville", "Cansado", "Numérowatt", "Imlili"] },
  { id: "rosso", name: "Rosso", country: "Mauritanie", countryCode: "MR", lat: 16.51, lon: -15.8, floodRisk: 0.5, zones: ["Centre-ville", "Escale", "Satara"] },

  /* ---------------- Algérie ---------------- */
  { id: "alger", name: "Alger", country: "Algérie", countryCode: "DZ", lat: 36.75, lon: 3.06, floodRisk: 0.25, zones: ["Alger Centre", "Bab El Oued", "Sidi M'Hamed", "Hydra", "El Biar", "Kouba", "Bab Ezzouar", "Draria"] },
  { id: "oran", name: "Oran", country: "Algérie", countryCode: "DZ", lat: 35.7, lon: -0.64, floodRisk: 0.25, zones: ["Centre-ville", "Sidi El Houari", "Bir El Djir", "Es Senia", "Ain El Turk", "El Braya"] },
  { id: "constantine", name: "Constantine", country: "Algérie", countryCode: "DZ", lat: 36.36, lon: 6.61, zones: ["Centre-ville", "Sidi Mabrouk", "El Khroub", "Ain Smara", "Coudiat"] },
  { id: "blida", name: "Blida", country: "Algérie", countryCode: "DZ", lat: 36.47, lon: 2.83, zones: ["Centre-ville", "Ouled Yaich", "Beni Mered", "Chréa Route"] },
  { id: "annaba", name: "Annaba", country: "Algérie", countryCode: "DZ", lat: 36.9, lon: 7.77, floodRisk: 0.35, zones: ["Centre-ville", "El Bouni", "Sidi Amar", "Chétaibi Route"] },
  { id: "setif", name: "Sétif", country: "Algérie", countryCode: "DZ", lat: 36.19, lon: 5.41, zones: ["Centre-ville", "El Eulma", "Ain Oulmene", "Bougaa Route"] },

  /* ---------------- Maroc ---------------- */
  { id: "casablanca", name: "Casablanca", country: "Maroc", countryCode: "MA", lat: 33.59, lon: -7.62, floodRisk: 0.3, zones: ["Maârif", "Anfa", "Ain Sebaâ", "Sidi Bernoussi", "Hay Hassani", "Derb Sultan", "Bourgogne", "Sidi Moumen"] },
  { id: "rabat", name: "Rabat", country: "Maroc", countryCode: "MA", lat: 34.02, lon: -6.84, zones: ["Agdal", "Hay Riad", "Hassan", "Yacoub El Mansour", "Souissi", "Salé_route"] },
  { id: "marrakech", name: "Marrakech", country: "Maroc", countryCode: "MA", lat: 31.63, lon: -7.99, zones: ["Guéliz", "Médina", "Menara", "Sidi Youssef Ben Ali", "El Massira", "Daoudiate"] },
  { id: "tanger", name: "Tanger", country: "Maroc", countryCode: "MA", lat: 35.78, lon: -5.81, floodRisk: 0.3, zones: ["Centre-ville", "Iberia", "Marshan", "Charf", "Béni Makada"] },
  { id: "agadir", name: "Agadir", country: "Maroc", countryCode: "MA", lat: 30.42, lon: -9.6, floodRisk: 0.25, zones: ["Centre-ville", "Talborjt", "Founty", "Hay Mohammadi", "Inezgane_route"] },
  { id: "fes", name: "Fès", country: "Maroc", countryCode: "MA", lat: 34.02, lon: -5.0, zones: ["Ville Nouvelle", "Fès el Bali", "Saiss", "Bensouda", "Narjiss"] },

  /* ---------------- Tunisie ---------------- */
  { id: "tunis", name: "Tunis", country: "Tunisie", countryCode: "TN", lat: 36.8, lon: 10.18, floodRisk: 0.35, zones: ["Centre-ville", "El Menzah", "La Marsa", "Ariana", "Ben Arous", "Le Kram", "La Goulette"] },
  { id: "sfax", name: "Sfax", country: "Tunisie", countryCode: "TN", lat: 34.74, lon: 10.76, floodRisk: 0.3, zones: ["Centre-ville", "Sakiet Ezzit", "Gremda", "El Ain"] },
  { id: "sousse", name: "Sousse", country: "Tunisie", countryCode: "TN", lat: 35.83, lon: 10.64, floodRisk: 0.3, zones: ["Centre-ville", "Sahloul", "Hammam Sousse", "Khezama"] },
  { id: "monastir", name: "Monastir", country: "Tunisie", countryCode: "TN", lat: 35.77, lon: 10.83, floodRisk: 0.3, zones: ["Centre-ville", "Sakiet", "Zone Touristique"] },

  /* ---------------- Libye, Égypte, vallée du Nil ---------------- */
  { id: "tripoli", name: "Tripoli", country: "Libye", countryCode: "LY", lat: 32.9, lon: 13.18, floodRisk: 0.25, zones: ["Centre-ville", "Tajura", "Janzour", "Ain Zara", "Hay Al Andalus", "Souk Al Juma"] },
  { id: "benghazi", name: "Benghazi", country: "Libye", countryCode: "LY", lat: 32.12, lon: 20.07, floodRisk: 0.25, zones: ["Centre-ville", "Al Hawari", "Al Laithi", "Garyounis"] },
  { id: "misrata", name: "Misrata", country: "Libye", countryCode: "LY", lat: 32.38, lon: 15.09, zones: ["Centre-ville", "Zawiyat al-Mahjoub", "Al Ghayran"] },
  { id: "le-caire", name: "Le Caire", country: "Égypte", countryCode: "EG", lat: 30.04, lon: 31.24, floodRisk: 0.2, zones: ["Nasr City", "Héliopolis", "Maadi", "Zamalek", "Gizeh", "Shubra", "Nouveau Caire", "6 Octobre"] },
  { id: "alexandrie", name: "Alexandrie", country: "Égypte", countryCode: "EG", lat: 31.2, lon: 29.92, floodRisk: 0.5, zones: ["Smouha", "Sidi Gaber", "Montazah", "Agami", "Moharam Bek", "Bacos"] },
  { id: "port-said", name: "Port-Saïd", country: "Égypte", countryCode: "EG", lat: 31.26, lon: 32.3, floodRisk: 0.5, zones: ["Centre-ville", "Port Fouad", "El Arab"] },
  { id: "suez", name: "Suez", country: "Égypte", countryCode: "EG", lat: 29.97, lon: 32.55, floodRisk: 0.3, zones: ["Centre-ville", "Arbaeen", "Faisal"] },
  { id: "mansoura", name: "Mansoura", country: "Égypte", countryCode: "EG", lat: 31.04, lon: 31.38, floodRisk: 0.4, zones: ["Centre-ville", "Talkha", "Sandoub"] },
  { id: "khartoum", name: "Khartoum", country: "Soudan", countryCode: "SD", lat: 15.5, lon: 32.53, floodRisk: 0.55, zones: ["Centre-ville", "Omdurman", "Bahri", "Amarat", "Riyadh", "Soba"] },
  { id: "port-soudan", name: "Port-Soudan", country: "Soudan", countryCode: "SD", lat: 19.62, lon: 37.22, floodRisk: 0.3, zones: ["Centre-ville", "Deim", "Abu Hashish"] },
  { id: "kassala", name: "Kassala", country: "Soudan", countryCode: "SD", lat: 15.45, lon: 36.4, floodRisk: 0.45, zones: ["Centre-ville", "Khatmiya", "El Sawra"] },
  { id: "djouba", name: "Djouba", country: "Soudan du Sud", countryCode: "SS", lat: 4.86, lon: 31.57, lang: "en", floodRisk: 0.45, zones: ["Juba Town", "Gudele", "Munuki", "Kator", "Hai Malakal", "Tongping"] },
  { id: "wau", name: "Wau", country: "Soudan du Sud", countryCode: "SS", lat: 7.7, lon: 28.0, lang: "en", zones: ["Centre", "Lokoloko", "Daraj"] },

  /* ---------------- Corne de l'Afrique ---------------- */
  { id: "asmara", name: "Asmara", country: "Érythrée", countryCode: "ER", lat: 15.32, lon: 38.93, lang: "en", zones: ["Centro", "Acria", "Ghezzabanda", "Sembel", "Godaif"] },
  { id: "keren", name: "Keren", country: "Érythrée", countryCode: "ER", lat: 15.78, lon: 38.45, lang: "en", zones: ["Centre", "Mentel", "Giro Fiori"] },
  { id: "massawa", name: "Massawa", country: "Érythrée", countryCode: "ER", lat: 15.61, lon: 39.45, lang: "en", floodRisk: 0.4, zones: ["Centre", "Taulud", "Edaga"] },
  { id: "djibouti-ville", name: "Djibouti", country: "Djibouti", countryCode: "DJ", lat: 11.59, lon: 43.15, floodRisk: 0.5, zones: ["Plateau", "Balbala", "Ambouli", "Quartier 7", "Heron", "Gabode"] },
  { id: "ali-sabieh", name: "Ali Sabieh", country: "Djibouti", countryCode: "DJ", lat: 11.15, lon: 42.72, zones: ["Centre-ville", "Ferostar"] },
  { id: "mogadiscio", name: "Mogadiscio", country: "Somalie", countryCode: "SO", lat: 2.05, lon: 45.32, lang: "en", floodRisk: 0.4, zones: ["Hodan", "Waberi", "Hamar Weyne", "Medina", "Karaan", "Yaaqshiid", "Bondhere"] },
  { id: "hargeisa", name: "Hargeisa", country: "Somalie", countryCode: "SO", lat: 9.56, lon: 44.07, lang: "en", zones: ["Centre", "Jigjiga Yar", "Ahmed Dhagah", "Mohamed Mooge"] },
  { id: "garowe", name: "Garowe", country: "Somalie", countryCode: "SO", lat: 8.4, lon: 48.48, lang: "en", zones: ["Centre", "Hantiwadaag"] },
  { id: "baidoa", name: "Baidoa", country: "Somalie", countryCode: "SO", lat: 3.11, lon: 43.65, lang: "en", floodRisk: 0.45, zones: ["Centre", "Horseed"] },
  { id: "addis-abeba", name: "Addis-Abeba", country: "Éthiopie", countryCode: "ET", lat: 9.02, lon: 38.75, lang: "en", zones: ["Bole", "Kirkos", "Arada", "Yeka", "Nifas Silk-Lafto", "Kolfe Keranio", "Akaky Kaliti", "CMC"] },
  { id: "adama", name: "Adama", country: "Éthiopie", countryCode: "ET", lat: 8.54, lon: 39.27, lang: "en", zones: ["Centre", "Melka Adama", "Boku"] },
  { id: "hawassa", name: "Hawassa", country: "Éthiopie", countryCode: "ET", lat: 7.05, lon: 38.48, lang: "en", floodRisk: 0.3, zones: ["Centre", "Tabor", "Addis Ketema"] },
  { id: "mekelle", name: "Mekelle", country: "Éthiopie", countryCode: "ET", lat: 13.49, lon: 39.47, lang: "en", zones: ["Centre", "Ayder", "Quiha"] },
  { id: "dire-dawa", name: "Dire Dawa", country: "Éthiopie", countryCode: "ET", lat: 9.6, lon: 41.87, lang: "en", floodRisk: 0.35, zones: ["Centre", "Kezira", "Megala"] },

  /* ---------------- Afrique de l'Est ---------------- */
  { id: "nairobi", name: "Nairobi", country: "Kenya", countryCode: "KE", lat: -1.29, lon: 36.82, lang: "en", floodRisk: 0.35, zones: ["CBD", "Westlands", "Karen", "Kasarani", "Eastleigh", "Kibera", "Upper Hill", "Embakasi"] },
  { id: "mombasa", name: "Mombasa", country: "Kenya", countryCode: "KE", lat: -4.05, lon: 39.67, lang: "en", floodRisk: 0.45, zones: ["Mvita", "Nyali", "Likoni", "Changamwe", "Bamburi", "Kisauni"] },
  { id: "kisumu", name: "Kisumu", country: "Kenya", countryCode: "KE", lat: -0.09, lon: 34.77, lang: "en", floodRisk: 0.4, zones: ["Centre", "Milimani", "Nyalenda", "Kondele"] },
  { id: "nakuru", name: "Nakuru", country: "Kenya", countryCode: "KE", lat: -0.3, lon: 36.07, lang: "en", zones: ["Centre", "Lanet", "Free Area"] },
  { id: "eldoret", name: "Eldoret", country: "Kenya", countryCode: "KE", lat: 0.51, lon: 35.27, lang: "en", zones: ["Centre", "Kapsoya", "Langas"] },
  { id: "kampala", name: "Kampala", country: "Ouganda", countryCode: "UG", lat: 0.35, lon: 32.58, lang: "en", floodRisk: 0.4, zones: ["Central", "Nakawa", "Makindye", "Kawempe", "Rubaga", "Ntinda", "Muyenga"] },
  { id: "entebbe", name: "Entebbe", country: "Ouganda", countryCode: "UG", lat: 0.05, lon: 32.46, lang: "en", floodRisk: 0.3, zones: ["Centre", "Kitoro", "Lugonjo"] },
  { id: "jinja", name: "Jinja", country: "Ouganda", countryCode: "UG", lat: 0.42, lon: 33.2, lang: "en", floodRisk: 0.35, zones: ["Centre", "Bugembe", "Walukuba"] },
  { id: "mbarara", name: "Mbarara", country: "Ouganda", countryCode: "UG", lat: -0.61, lon: 30.66, lang: "en", zones: ["Centre", "Kakoba", "Nyamitanga"] },
  { id: "dar-es-salaam", name: "Dar es Salaam", country: "Tanzanie", countryCode: "TZ", lat: -6.81, lon: 39.28, lang: "en", floodRisk: 0.45, zones: ["Ilala", "Kinondoni", "Temeke", "Ubungo", "Masaki", "Mikocheni", "Kariakoo"] },
  { id: "dodoma", name: "Dodoma", country: "Tanzanie", countryCode: "TZ", lat: -6.16, lon: 35.75, lang: "en", zones: ["Centre", "Makulu", "Nzuguni"] },
  { id: "mwanza", name: "Mwanza", country: "Tanzanie", countryCode: "TZ", lat: -2.52, lon: 32.9, lang: "en", floodRisk: 0.35, zones: ["Centre", "Kirumba", "Ilemela"] },
  { id: "arusha", name: "Arusha", country: "Tanzanie", countryCode: "TZ", lat: -3.39, lon: 36.68, lang: "en", zones: ["Centre", "Sakina", "Njiro"] },
  { id: "zanzibar", name: "Zanzibar", country: "Tanzanie", countryCode: "TZ", lat: -6.16, lon: 39.19, lang: "en", floodRisk: 0.5, zones: ["Stone Town", "Migombani", "Bububu", "Mwanakwerekwe"] },
  { id: "mbeya", name: "Mbeya", country: "Tanzanie", countryCode: "TZ", lat: -8.91, lon: 33.46, lang: "en", zones: ["Centre", "Uyole", "Iyunga"] },
  { id: "kigali", name: "Kigali", country: "Rwanda", countryCode: "RW", lat: -1.95, lon: 30.06, lang: "en", zones: ["Nyarugenge", "Kicukiro", "Gasabo", "Kimironko", "Remera", "Gikondo", "Nyamirambo"] },
  { id: "huye", name: "Huye", country: "Rwanda", countryCode: "RW", lat: -2.6, lon: 29.74, lang: "en", zones: ["Centre", "Ngoma", "Tumba"] },
  { id: "musanze", name: "Musanze", country: "Rwanda", countryCode: "RW", lat: -1.5, lon: 29.63, lang: "en", zones: ["Centre", "Muhoza", "Cyuve"] },
  { id: "rubavu", name: "Rubavu", country: "Rwanda", countryCode: "RW", lat: -1.68, lon: 29.33, lang: "en", floodRisk: 0.3, zones: ["Centre", "Gisenyi", "Rubavu Plage"] },
  { id: "bujumbura", name: "Bujumbura", country: "Burundi", countryCode: "BI", lat: -3.38, lon: 29.36, floodRisk: 0.4, zones: ["Rohero", "Ngagara", "Kamenge", "Kinindo", "Buterere", "Gihosha", "Musaga"] },
  { id: "gitega", name: "Gitega", country: "Burundi", countryCode: "BI", lat: -3.43, lon: 29.93, zones: ["Centre", "Shatanya", "Nyabututsi"] },
  { id: "ngozi", name: "Ngozi", country: "Burundi", countryCode: "BI", lat: -2.91, lon: 29.83, zones: ["Centre", "Muremera"] },
  { id: "lilongwe", name: "Lilongwe", country: "Malawi", countryCode: "MW", lat: -13.96, lon: 33.77, lang: "en", floodRisk: 0.4, zones: ["Area 25", "Area 47", "Kanengo", "Old Town", "Chinsapo", "Likuni"] },
  { id: "blantyre", name: "Blantyre", country: "Malawi", countryCode: "MW", lat: -15.79, lon: 34.99, lang: "en", floodRisk: 0.35, zones: ["Limbe", "Ndirande", "Chigumula", "Soche", "Chilomoni"] },
  { id: "mzuzu", name: "Mzuzu", country: "Malawi", countryCode: "MW", lat: -11.46, lon: 34.01, lang: "en", zones: ["Centre", "Katawa", "Chibanja"] },
  { id: "maputo", name: "Maputo", country: "Mozambique", countryCode: "MZ", lat: -25.97, lon: 32.58, lang: "pt", floodRisk: 0.5, zones: ["Baixa", "Polana", "Sommerschield", "Matola", "Zimpeto", "Alto Maé"] },
  { id: "beira", name: "Beira", country: "Mozambique", countryCode: "MZ", lat: -19.84, lon: 34.85, lang: "pt", floodRisk: 0.6, zones: ["Centro", "Manga", "Ponta-Gêa", "Macurungo"] },
  { id: "nampula", name: "Nampula", country: "Mozambique", countryCode: "MZ", lat: -15.12, lon: 39.27, lang: "pt", zones: ["Centro", "Muahivire", "Muatala"] },
  { id: "quelimane", name: "Quelimane", country: "Mozambique", countryCode: "MZ", lat: -17.88, lon: 36.89, lang: "pt", floodRisk: 0.55, zones: ["Centro", "Torne", "Icidua"] },
  { id: "tete", name: "Tete", country: "Mozambique", countryCode: "MZ", lat: -16.16, lon: 33.59, lang: "pt", floodRisk: 0.4, zones: ["Centro", "Matundo", "Chingodzi"] },

  /* ---------------- Afrique centrale ---------------- */
  { id: "ndjamena", name: "N'Djamena", country: "Tchad", countryCode: "TD", lat: 12.13, lon: 15.04, floodRisk: 0.5, zones: ["Centre-ville", "Moursal", "Chagoua", "Ndjari", "Walia", "Farcha", "Amtoukoui"] },
  { id: "moundou", name: "Moundou", country: "Tchad", countryCode: "TD", lat: 8.57, lon: 16.08, floodRisk: 0.4, zones: ["Centre-ville", "Doheri", "Gueldjem"] },
  { id: "sarh", name: "Sarh", country: "Tchad", countryCode: "TD", lat: 9.15, lon: 18.38, floodRisk: 0.4, zones: ["Centre-ville", "Bégou", "Kassai"] },
  { id: "bangui", name: "Bangui", country: "République centrafricaine", countryCode: "CF", lat: 4.39, lon: 18.56, floodRisk: 0.45, zones: ["Centre-ville", "KM5", "Begoua", "Fatima", "Gobongo", "Boy Rabe"] },
  { id: "bimbo", name: "Bimbo", country: "République centrafricaine", countryCode: "CF", lat: 4.33, lon: 18.41, floodRisk: 0.4, zones: ["Centre-ville", "Pétévo", "K pal"] },
  { id: "brazzaville", name: "Brazzaville", country: "Congo", countryCode: "CG", lat: -4.26, lon: 15.24, floodRisk: 0.4, zones: ["Bacongo", "Poto-Poto", "Moungali", "Ouenzé", "Talangaï", "Makélékélé", "Djiri"] },
  { id: "pointe-noire", name: "Pointe-Noire", country: "Congo", countryCode: "CG", lat: -4.79, lon: 11.85, floodRisk: 0.45, zones: ["Lumumba", "Tié-Tié", "Loandjili", "Mpaka", "Vindoulou"] },
  { id: "dolisie", name: "Dolisie", country: "Congo", countryCode: "CG", lat: -4.2, lon: 12.67, zones: ["Centre-ville", "Kitsina", "Mouindi"] },
  { id: "kinshasa", name: "Kinshasa", country: "RD Congo", countryCode: "CD", lat: -4.32, lon: 15.31, floodRisk: 0.45, zones: ["Gombe", "Lingwala", "Barumbu", "Kasa-Vubu", "Ngaliema", "Mont Ngafula", "N'Djili", "Kimbanseke", "Bandalungwa"] },
  { id: "lubumbashi", name: "Lubumbashi", country: "RD Congo", countryCode: "CD", lat: -11.66, lon: 27.48, zones: ["Centre-ville", "Kampemba", "Kenya", "Katuba", "Annexe", "Kamalondo"] },
  { id: "goma", name: "Goma", country: "RD Congo", countryCode: "CD", lat: -1.68, lon: 29.22, floodRisk: 0.3, zones: ["Centre-ville", "Birere", "Karisimbi", "Himbi", "Les Volcans"] },
  { id: "bukavu", name: "Bukavu", country: "RD Congo", countryCode: "CD", lat: -2.51, lon: 28.86, floodRisk: 0.35, zones: ["Ibanda", "Kadutu", "Bagira", "Nguba"] },
  { id: "kolwezi", name: "Kolwezi", country: "RD Congo", countryCode: "CD", lat: -10.71, lon: 25.47, zones: ["Centre-ville", "Manika", "Dilala"] },
  { id: "malabo", name: "Malabo", country: "Guinée équatoriale", countryCode: "GQ", lat: 3.75, lon: 8.78, floodRisk: 0.35, zones: ["Centro", "Elá Nguema", "Alcaide", "Paraíso"] },
  { id: "bata", name: "Bata", country: "Guinée équatoriale", countryCode: "GQ", lat: 1.87, lon: 9.77, floodRisk: 0.4, zones: ["Centro", "Nkoantoma", "Ekuku"] },
  { id: "sao-tome", name: "São Tomé", country: "Sao Tomé-et-Principe", countryCode: "ST", lat: 0.34, lon: 6.73, lang: "pt", floodRisk: 0.4, zones: ["Centro", "Água Grande", "Madre de Deus", "Campo de Milho"] },
  { id: "santo-amaro", name: "Santo Amaro", country: "Sao Tomé-et-Principe", countryCode: "ST", lat: 0.36, lon: 6.69, lang: "pt", zones: ["Centro", "Santana_route"] },
  { id: "luanda", name: "Luanda", country: "Angola", countryCode: "AO", lat: -8.84, lon: 13.23, lang: "pt", floodRisk: 0.45, zones: ["Maianga", "Viana", "Cazenga", "Talatona", "Samba", "Ingombota", "Kilamba Kiaxi", "Cacuaco"] },
  { id: "benguela", name: "Benguela", country: "Angola", countryCode: "AO", lat: -12.58, lon: 13.42, lang: "pt", floodRisk: 0.35, zones: ["Centro", "Baía Azul", "Graça", "Calomanda"] },
  { id: "lubango", name: "Lubango", country: "Angola", countryCode: "AO", lat: -14.92, lon: 13.51, lang: "pt", zones: ["Centro", "Mitcha", "João de Almeida"] },
  { id: "huambo", name: "Huambo", country: "Angola", countryCode: "AO", lat: -12.78, lon: 15.74, lang: "pt", zones: ["Centro", "Benfica", "São João"] },
  { id: "cabinda", name: "Cabinda", country: "Angola", countryCode: "AO", lat: -5.56, lon: 12.19, lang: "pt", floodRisk: 0.4, zones: ["Centro", "Luvassa", "Simulambuco"] },

  /* ---------------- Afrique australe & îles ---------------- */
  { id: "windhoek", name: "Windhoek", country: "Namibie", countryCode: "NA", lat: -22.56, lon: 17.07, lang: "en", zones: ["Central", "Katutura", "Khomasdal", "Eros", "Klein Windhoek", "Otjomuise", "Wanaheda"] },
  { id: "walvis-bay", name: "Walvis Bay", country: "Namibie", countryCode: "NA", lat: -22.96, lon: 14.51, lang: "en", floodRisk: 0.3, zones: ["Centre", "Kuisebmond", "Meersig"] },
  { id: "swakopmund", name: "Swakopmund", country: "Namibie", countryCode: "NA", lat: -22.68, lon: 14.53, lang: "en", floodRisk: 0.25, zones: ["Centre", "Mondesa", "Vineta"] },
  { id: "gaborone", name: "Gaborone", country: "Botswana", countryCode: "BW", lat: -24.63, lon: 25.91, lang: "en", floodRisk: 0.3, zones: ["Broadhurst", "Phase 2", "Mogoditshane", "Tlokweng", "CBD", "Old Naledi", "Block 8"] },
  { id: "francistown", name: "Francistown", country: "Botswana", countryCode: "BW", lat: -21.17, lon: 27.51, lang: "en", zones: ["Centre", "Monarch", "Somerset", "Gerald"] },
  { id: "maun", name: "Maun", country: "Botswana", countryCode: "BW", lat: -19.98, lon: 23.42, lang: "en", floodRisk: 0.45, zones: ["Centre", "Boseja", "Sedie"] },
  { id: "kanye", name: "Kanye", country: "Botswana", countryCode: "BW", lat: -24.98, lon: 25.33, lang: "en", zones: ["Centre", "Mahikana"] },
  { id: "johannesburg", name: "Johannesburg", country: "Afrique du Sud", countryCode: "ZA", lat: -26.2, lon: 28.05, lang: "en", zones: ["Sandton", "Soweto", "Roodepoort", "Midrand", "Alexandra", "Rosebank", "Randburg"] },
  { id: "le-cap", name: "Le Cap", country: "Afrique du Sud", countryCode: "ZA", lat: -33.92, lon: 18.42, lang: "en", floodRisk: 0.35, zones: ["City Bowl", "Bellville", "Khayelitsha", "Constantia", "Sea Point", "Milnerton"] },
  { id: "durban", name: "Durban", country: "Afrique du Sud", countryCode: "ZA", lat: -29.86, lon: 31.02, lang: "en", floodRisk: 0.45, zones: ["Centre", "Umhlanga", "Pinetown", "Chatsworth", "Phoenix", "Berea"] },
  { id: "pretoria", name: "Pretoria", country: "Afrique du Sud", countryCode: "ZA", lat: -25.75, lon: 28.19, lang: "en", zones: ["Centre", "Centurion", "Sunnyside", "Hatfield", "Menlo Park"] },
  { id: "gqeberha", name: "Gqeberha", country: "Afrique du Sud", countryCode: "ZA", lat: -33.96, lon: 25.6, lang: "en", floodRisk: 0.3, zones: ["Centre", "Summerstrand", "Walmer", "Korsten"] },
  { id: "bloemfontein", name: "Bloemfontein", country: "Afrique du Sud", countryCode: "ZA", lat: -29.12, lon: 26.21, lang: "en", zones: ["Centre", "Navalsig", "Mangaung"] },
  { id: "lusaka", name: "Lusaka", country: "Zambie", countryCode: "ZM", lat: -15.42, lon: 28.28, lang: "en", floodRisk: 0.35, zones: ["CBD", "Kabulonga", "Chelstone", "Matero", "Woodlands", "Kabwata", "Emmasdale"] },
  { id: "kitwe", name: "Kitwe", country: "Zambie", countryCode: "ZM", lat: -12.8, lon: 28.21, lang: "en", zones: ["Centre", "Nkana", "Wusakile", "Chimwemwe"] },
  { id: "ndola", name: "Ndola", country: "Zambie", countryCode: "ZM", lat: -12.97, lon: 28.64, lang: "en", zones: ["Centre", "Itawa", "Masala"] },
  { id: "livingstone", name: "Livingstone", country: "Zambie", countryCode: "ZM", lat: -17.84, lon: 25.85, lang: "en", floodRisk: 0.3, zones: ["Centre", "Dambwa", "Maramba"] },
  { id: "harare", name: "Harare", country: "Zimbabwe", countryCode: "ZW", lat: -17.83, lon: 31.05, lang: "en", floodRisk: 0.3, zones: ["CBD", "Borrowdale", "Avondale", "Mbare", "Highfield", "Chitungwiza", "Mount Pleasant"] },
  { id: "bulawayo", name: "Bulawayo", country: "Zimbabwe", countryCode: "ZW", lat: -20.16, lon: 28.58, lang: "en", zones: ["Centre", "Nkulumane", "Luveve", "Famona"] },
  { id: "mutare", name: "Mutare", country: "Zimbabwe", countryCode: "ZW", lat: -18.97, lon: 32.67, lang: "en", floodRisk: 0.35, zones: ["Centre", "Sakubva", "Dangamvura"] },
  { id: "maseru", name: "Maseru", country: "Lesotho", countryCode: "LS", lat: -29.31, lon: 27.48, lang: "en", floodRisk: 0.3, zones: ["Central", "Ha Mabote", "Khubetsoana", "Thetsane", "Masowe"] },
  { id: "teyateyaneng", name: "Teyateyaneng", country: "Lesotho", countryCode: "LS", lat: -29.15, lon: 27.74, lang: "en", zones: ["Centre", "Ha Mokhele"] },
  { id: "mbabane", name: "Mbabane", country: "Eswatini", countryCode: "SZ", lat: -26.31, lon: 31.14, lang: "en", zones: ["Central", "Sidvwashini", "Eveni", "Fonteyn"] },
  { id: "manzini", name: "Manzini", country: "Eswatini", countryCode: "SZ", lat: -26.48, lon: 31.37, lang: "en", floodRisk: 0.3, zones: ["Centre", "Fairview", "Ngwane Park"] },
  { id: "antananarivo", name: "Antananarivo", country: "Madagascar", countryCode: "MG", lat: -18.91, lon: 47.52, floodRisk: 0.4, zones: ["Analakely", "Isoraka", "Ankorondrano", "Itaosy", "Tanjombato", "Ambohidratrimo", "Ivato"] },
  { id: "toamasina", name: "Toamasina", country: "Madagascar", countryCode: "MG", lat: -18.15, lon: 49.4, floodRisk: 0.5, zones: ["Centre-ville", "Tanambao", "Ankirihiry"] },
  { id: "antsirabe", name: "Antsirabe", country: "Madagascar", countryCode: "MG", lat: -19.87, lon: 47.03, zones: ["Centre-ville", "Mahazoarivo", "Ambohimena"] },
  { id: "mahajanga", name: "Mahajanga", country: "Madagascar", countryCode: "MG", lat: -15.72, lon: 46.32, floodRisk: 0.45, zones: ["Centre-ville", "Mahabibo", "Tsararano"] },
  { id: "fianarantsoa", name: "Fianarantsoa", country: "Madagascar", countryCode: "MG", lat: -21.45, lon: 47.09, zones: ["Centre-ville", "Ambalavao Route", "Isandra"] },
  { id: "port-louis", name: "Port-Louis", country: "Maurice", countryCode: "MU", lat: -20.16, lon: 57.5, floodRisk: 0.35, zones: ["Centre-ville", "Plaine Verte", "Vallée Pitot", "Cassis", "Tranquebar"] },
  { id: "beau-bassin", name: "Beau Bassin-Rose Hill", country: "Maurice", countryCode: "MU", lat: -20.22, lon: 57.47, zones: ["Centre-ville", "Barkly", "Mont Roches"] },
  { id: "quatre-bornes", name: "Quatre Bornes", country: "Maurice", countryCode: "MU", lat: -20.27, lon: 57.48, zones: ["Centre-ville", "Palma", "Sodnac"] },
  { id: "curepipe", name: "Curepipe", country: "Maurice", countryCode: "MU", lat: -20.32, lon: 57.53, floodRisk: 0.3, zones: ["Centre-ville", "Floreal", "Forest Side"] },
  { id: "victoria-sc", name: "Victoria", country: "Seychelles", countryCode: "SC", lat: -4.62, lon: 55.45, floodRisk: 0.4, zones: ["Centre-ville", "Mont Fleuri", "Beau Vallon", "Anse Royale", "Cascade"] },
  { id: "anse-boileau", name: "Anse Boileau", country: "Seychelles", countryCode: "SC", lat: -4.71, lon: 55.49, floodRisk: 0.35, zones: ["Centre", "Anse à la Mouche"] },
  { id: "moroni", name: "Moroni", country: "Comores", countryCode: "KM", lat: -11.72, lon: 43.25, floodRisk: 0.45, zones: ["Badjanani", "Itsandra", "Mboueni", "Couloir", "Hankounou"] },
  { id: "mutsamudu", name: "Mutsamudu", country: "Comores", countryCode: "KM", lat: -12.17, lon: 44.4, floodRisk: 0.4, zones: ["Centre-ville", "Mirontsy", "Chitrouni"] },
  { id: "fomboni", name: "Fomboni", country: "Comores", countryCode: "KM", lat: -12.28, lon: 43.74, floodRisk: 0.4, zones: ["Centre-ville", "Bangoma"] },
  { id: "monrovia", name: "Monrovia", country: "Liberia", countryCode: "LR", lat: 6.31, lon: -10.8, lang: "en", floodRisk: 0.5, zones: ["Sinkor", "Congo Town", "Paynesville", "Brewerville", "Gardnersville", "New Kru Town", "West Point"] },
  { id: "gbarnga", name: "Gbarnga", country: "Liberia", countryCode: "LR", lat: 6.99, lon: -9.47, lang: "en", floodRisk: 0.35, zones: ["Centre", "Civilised"] },
  { id: "freetown", name: "Freetown", country: "Sierra Leone", countryCode: "SL", lat: 8.48, lon: -13.23, lang: "en", floodRisk: 0.45, zones: ["Central", "Aberdeen", "Lumley", "Waterloo", "Kissy", "Goderich", "Wilberforce"] },
  { id: "bo-sl", name: "Bo", country: "Sierra Leone", countryCode: "SL", lat: 7.96, lon: -11.74, lang: "en", floodRisk: 0.35, zones: ["Centre", "New London", "Kortumahun"] },
  { id: "kenema", name: "Kenema", country: "Sierra Leone", countryCode: "SL", lat: 7.88, lon: -11.19, lang: "en", floodRisk: 0.35, zones: ["Centre", "Combema"] },
];

/** Décalage horaire par pays (minutes vs UTC, sans heure d'été dans la zone). */
export const TZ_OFFSET_MIN: Record<string, number> = {
  SN: 0, GM: 0, CV: -60, GN: 0, GW: 0, ML: 0, CI: 0, BF: 0, BJ: 60, TG: 0,
  NE: 60, NG: 60, LR: 0, SL: 0, GH: 0,
  CM: 60, GA: 60, TD: 60, CF: 60, CG: 60, CD: 60, GQ: 60, ST: 0, AO: 60,
  MR: 0, DZ: 60, MA: 60, TN: 60, LY: 120, EG: 120,
  SD: 120, SS: 120, ER: 180, DJ: 180, SO: 180, ET: 180, KE: 180, UG: 180,
  TZ: 180, RW: 120, BI: 120, MW: 120, MZ: 120,
  NA: 120, BW: 120, ZA: 120, ZM: 120, ZW: 120, LS: 120, SZ: 120, MG: 180,
  MU: 240, SC: 240, KM: 180,
};

/** Indicatif téléphonique international par pays. */
export const CALLING_CODES: Record<string, string> = {
  SN: "221", GM: "220", CV: "238", GN: "224", GW: "245", ML: "223",
  CI: "225", BF: "226", BJ: "229", TG: "228", NE: "227", NG: "234", GH: "233",
  LR: "231", SL: "232",
  CM: "237", GA: "241", TD: "235", CF: "236", CG: "242", CD: "243",
  GQ: "240", ST: "239", AO: "244",
  MR: "222", DZ: "213", MA: "212", TN: "216", LY: "218", EG: "20",
  SD: "249", SS: "211", ER: "291", DJ: "253", SO: "252", ET: "251",
  KE: "254", UG: "256", TZ: "255", RW: "250", BI: "257", MW: "265", MZ: "258",
  NA: "264", BW: "267", ZA: "27", ZM: "260", ZW: "263", LS: "266",
  SZ: "268", MG: "261", MU: "230", SC: "248", KM: "269",
};

/* ------------------------------------------------------------------ */
/* Générateur déterministe de graphe urbain                            */
/* ------------------------------------------------------------------ */

function hashSeed(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: string): () => number {
  let a = hashSeed(seed);
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function slugify(name: string, fallback: string): string {
  const slug = name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug || fallback;
}

const NAME_TEMPLATES: Record<Lang, { radial: ((z: string) => string)[]; ring: ((a: string, b: string) => string)[]; school: string; hospital: string; district: string }> = {
  fr: {
    radial: [
      (z) => `Route de ${z}`,
      (z) => `Avenue de ${z}`,
      (z) => `Avenue ${z}`,
      (z) => `Boulevard de ${z}`,
    ],
    ring: [
      (a, b) => `Boulevard ${a} – ${b}`,
      (a, b) => `Liaison ${a} – ${b}`,
      (a, b) => `Route ${a} – ${b}`,
    ],
    school: "École",
    hospital: "Hôpital",
    district: "Quartier résidentiel",
  },
  en: {
    radial: [
      (z) => `${z} Road`,
      (z) => `${z} Avenue`,
      (z) => `Road to ${z}`,
      (z) => `${z} Boulevard`,
    ],
    ring: [
      (a, b) => `${a} – ${b} Link Road`,
      (a, b) => `${a} – ${b} Boulevard`,
      (a, b) => `${a} – ${b} Road`,
    ],
    school: "School",
    hospital: "Hospital",
    district: "Residential district",
  },
  pt: {
    radial: [
      (z) => `Estrada de ${z}`,
      (z) => `Avenida de ${z}`,
      (z) => `Avenida ${z}`,
    ],
    ring: [
      (a, b) => `Ligação ${a} – ${b}`,
      (a, b) => `Estrada ${a} – ${b}`,
    ],
    school: "Escola",
    hospital: "Hospital",
    district: "Bairro residencial",
  },
};

function buildCity(spec: CitySpec): CityDef {
  const lang: Lang = spec.lang ?? "fr";
  const tpl = NAME_TEMPLATES[lang];
  const floodRisk = spec.floodRisk ?? 0.15;
  const rng = mulberry32(`city:${spec.id}`);

  // --- Zones : centre + couronne de quartiers ---
  const usedSlugs = new Set<string>();
  const zones: ZoneDef[] = spec.zones.map((name, i) => {
    let slug = slugify(name, `zone-${i}`);
    if (usedSlugs.has(slug)) slug = `${slug}-${i}`;
    usedSlugs.add(slug);
    if (i === 0) {
      return { id: slug, name, x: 420 + Math.round((rng() - 0.5) * 40), y: 250 + Math.round((rng() - 0.5) * 30) };
    }
    const outerIdx = i - 1;
    const outerCount = spec.zones.length - 1;
    const angle = (outerIdx / outerCount) * Math.PI * 2 - Math.PI / 2 + (rng() - 0.5) * 0.25;
    const rx = 165 + rng() * 175;
    const ry = 95 + rng() * 85;
    const x = Math.max(48, Math.min(792, Math.round(420 + Math.cos(angle) * rx)));
    const y = Math.max(52, Math.min(428, Math.round(250 + Math.sin(angle) * ry)));
    return { id: slug, name, x, y };
  });

  const zoneById = new Map(zones.map((z) => [z.id, z]));
  const gpsOf = (z: ZoneDef): [number, number] => [
    Math.round((spec.lat + (250 - z.y) * 0.00009) * 1e6) / 1e6,
    Math.round((spec.lon + (z.x - 420) * 0.00011) * 1e6) / 1e6,
  ];

  // --- Axes : radiales centre→quartiers, périphérique, 2 liaisons ---
  const axes: AxisDef[] = [];
  const pairKeys = new Set<string>();
  const axisIds = new Set<string>();

  const pushAxis = (fromId: string, toId: string, kind: "radial" | "ring") => {
    const a = zoneById.get(fromId);
    const b = zoneById.get(toId);
    if (!a || !b || a.id === b.id) return;
    const key = [a.id, b.id].sort().join("|");
    if (pairKeys.has(key)) return;
    pairKeys.add(key);

    const distPx = Math.hypot(b.x - a.x, b.y - a.y);
    const lengthKm = Math.max(1.2, Math.min(14, Math.round((distPx / 36) * 10) / 10));
    const midX = (a.x + b.x) / 2 + (rng() - 0.5) * 26;
    const midY = (a.y + b.y) / 2 + (rng() - 0.5) * 26;
    const [ga, gb] = [gpsOf(a), gpsOf(b)];
    const midGps: [number, number] = [
      Math.round(((ga[0] + gb[0]) / 2 + (rng() - 0.5) * 0.004) * 1e6) / 1e6,
      Math.round(((ga[1] + gb[1]) / 2 + (rng() - 0.5) * 0.004) * 1e6) / 1e6,
    ];

    const radial = kind === "radial";
    const name = radial
      ? tpl.radial[Math.floor(rng() * tpl.radial.length)](b.name)
      : tpl.ring[Math.floor(rng() * tpl.ring.length)](a.name, b.name);
    const short = (radial ? b.name : `${a.name} – ${b.name}`).slice(0, 24);

    let id = slugify(name, `axe-${axes.length + 1}`);
    if (axisIds.has(id)) id = `${id}-${axes.length + 1}`;
    axisIds.add(id);

    const floodProne = rng() < 0.1 + floodRisk * 0.4;
    const withProtected = rng() < 0.34;
    const kindIdx = axes.length % 3;

    axes.push({
      id,
      name,
      short,
      from: a.id,
      to: b.id,
      lengthKm,
      freeFlowKmh: radial ? 40 + Math.round(rng() * 20) : 50 + Math.round(rng() * 22),
      capacityVehH: Math.round((1500 + rng() * 1900) / 50) * 50,
      path: [
        [a.x, a.y],
        [Math.round(midX), Math.round(midY)],
        [b.x, b.y],
      ],
      gps: [ga, midGps, gb],
      ...(floodProne ? { floodProne: true } : {}),
      risk: Math.round((0.24 + rng() * 0.34) * 100) / 100,
      potholes: Math.round((0.18 + rng() * 0.45) * 100) / 100,
      morningPeak: Math.round((0.68 + rng() * 0.32) * 100) / 100,
      eveningPeak: Math.round((0.68 + rng() * 0.32) * 100) / 100,
      ...(withProtected
        ? {
            protectedZone: {
              name:
                kindIdx === 0
                  ? `${tpl.school} — ${b.name}`
                  : kindIdx === 1
                    ? `${tpl.hospital} — ${a.name}`
                    : `${tpl.district} — ${b.name}`,
              kind: (kindIdx === 0 ? "École" : kindIdx === 1 ? "Hôpital" : "Quartier résidentiel") as
                | "École"
                | "Hôpital"
                | "Quartier résidentiel",
            },
          }
        : {}),
    });
  };

  const center = zones[0];
  const outer = zones.slice(1);
  for (const z of outer) pushAxis(center.id, z.id, "radial");
  for (let i = 0; i < outer.length; i++) {
    pushAxis(outer[i].id, outer[(i + 1) % outer.length].id, "ring");
  }
  if (outer.length >= 5) {
    pushAxis(outer[0].id, outer[Math.floor(outer.length / 2)].id, "ring");
    pushAxis(outer[1].id, outer[outer.length - 1].id, "ring");
  }

  return {
    id: spec.id,
    name: spec.name,
    country: spec.country,
    countryCode: spec.countryCode,
    lat: spec.lat,
    lon: spec.lon,
    active: true,
    coastal: floodRisk >= 0.38,
    tzOffsetMin: TZ_OFFSET_MIN[spec.countryCode] ?? 0,
    lang,
    zones,
    axes,
  };
}

/** Toutes les villes déployées au-delà des 4 villes historiques. */
export const MORE_CITIES: CityDef[] = SPECS.map(buildCity);
