"use client";

import { Compass, MessageCircle, Smartphone } from "lucide-react";
import { useApp } from "./AppClient";
import { CITY_COUNT, CITY_MAP, COUNTRIES } from "@/lib/cities";

export default function Footer() {
  const { cityId } = useApp();
  const city = CITY_MAP[cityId];
  return (
    <footer className="border-t border-night-600/60 bg-night-950">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <p className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-brand-500 text-night-950">
              <Compass className="h-5 w-5" strokeWidth={2.4} />
            </span>
            <span className="font-display text-lg font-bold">
              Afri<span className="text-brand-500">Flow</span>
            </span>
          </p>
          <p className="mt-3 max-w-md text-[13px] leading-relaxed text-sage">
            Les bouchons se prévoient, la ville respire. Trafic temps réel et prédictif pour {CITY_COUNT} villes
            d&apos;Afrique de l&apos;Ouest et centrale — sans aucun capteur coûteux, avec les conducteurs.
          </p>
          <p className="mt-3 max-w-md text-[11.5px] leading-relaxed text-sage/80">
            Sources de données réelles : Open-Meteo (météo observée), Copernicus GloFAS (débits des fleuves), CAMS
            (qualité de l&apos;air), OpenStreetMap / Overpass (graphe routier et chantiers), GPS des conducteurs et
            flottes partenaires. Toute valeur non mesurée est une estimation du modèle, affichée comme telle.
          </p>
          <p className="mt-4 flex flex-wrap gap-2 text-[12px] font-semibold">
            <a href="https://wa.me/221772015751" target="_blank" rel="noopener noreferrer" className="flex items-center gap-1.5 rounded-full bg-night-800 px-3 py-1.5 hover:text-mint-300">
              <MessageCircle className="h-3.5 w-3.5 text-brand-500" /> Contacter sur WhatsApp
            </a>
            <span className="flex items-center gap-1.5 rounded-full bg-night-800 px-3 py-1.5">
              <Smartphone className="h-3.5 w-3.5 text-mint-300" /> App AfriFlow
            </span>
          </p>
        </div>
        <div>
          <h4 className="text-[12px] font-bold tracking-wider text-sage uppercase">Plateforme</h4>
          <ul className="mt-3 space-y-2 text-[13px]">
            <li><a href="#dashboard" className="hover:text-mint-300">Carte thermique en direct</a></li>
            <li><a href="#routage" className="hover:text-mint-300">Itinéraires ventilés</a></li>
            <li><a href="#communaute" className="hover:text-mint-300">Signalements communautaires</a></li>
            <li><a href="/convoi" className="hover:text-mint-300">Convoi Industriel — page flottes</a></li>
            <li><a href="#donnees" className="hover:text-mint-300">Données &amp; IA</a></li>
            <li><a href="#reseau" className="hover:text-mint-300">Réseau — {CITY_COUNT} villes</a></li>
          </ul>
        </div>
        <div>
          <h4 className="text-[12px] font-bold tracking-wider text-sage uppercase">Ville active</h4>
          <p className="mt-3 text-[13px] leading-relaxed text-sage">
            {city.name} · {city.country}
            <br />
            Centre de contrôle régional — {COUNTRIES.map((c) => c.name).join(" · ")}.
          </p>
          <p className="mt-3 font-mono text-[11px] leading-relaxed text-sage">
            POST /api/telemetry
            <br />
            GET /api/heatmap · /api/routing
          </p>
        </div>
      </div>
      <div className="border-t border-night-600/50 py-4 text-center text-[12px] text-sage">
        © {new Date().getFullYear()} AfriFlow — Circulation surveillée en temps réel.
        <p className="mt-2">By TérangaStudio · <a href="tel:+221772015751" className="hover:text-mint-300">+221772015751</a> · <a href="/.well-known/security.txt" className="underline">Contact sécurité</a></p>
      </div>
    </footer>
  );
}
