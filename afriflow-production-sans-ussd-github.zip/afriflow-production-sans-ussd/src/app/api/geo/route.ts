import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP, distanceToSegmentM, getZone } from "@/lib/cities";

/** Axe le plus proche d'un lieu (rayon large : échelle d'une ville). */
function closestAxis(city: (typeof CITY_MAP)[string], lat: number, lon: number, maxM = 5000) {
  let bestAxis: (typeof city.axes)[number] | null = null;
  let bestDist = maxM;
  for (const axis of city.axes) {
    for (let i = 0; i < axis.gps.length - 1; i++) {
      const d = distanceToSegmentM([lat, lon], axis.gps[i], axis.gps[i + 1]);
      if (d < bestDist) {
        bestDist = d;
        bestAxis = axis;
      }
    }
  }
  return bestAxis ? { axis: bestAxis, distanceM: Math.round(bestDist) } : null;
}
import { searchPlaces } from "@/lib/geocode";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/**
 * GET /api/geo?q=université&city=dakar — recherche d'adresses et de lieux
 * réels (Nominatim / OpenStreetMap) bornée à la ville, chaque résultat
 * étant rattaché à l'axe surveillé le plus proche et à sa zone de départ.
 */
export async function GET(req: NextRequest) {
  const rl = rateLimit(`geo:${clientIp(req)}`, 40, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  const q = req.nextUrl.searchParams.get("q") ?? "";
  if (q.trim().length < 2) {
    return NextResponse.json({ error: "Requête trop courte (2 caractères minimum)." }, { status: 422 });
  }

  const places = await searchPlaces(city, q);
  const results = places.map((p) => {
    const found = closestAxis(city, p.lat, p.lon);
    let zoneId: string | null = null;
    if (found) {
      const { axis } = found;
      // Zone d'attache = l'extrémité de l'axe la plus proche du lieu.
      const dFrom = distanceToSegmentM([p.lat, p.lon], axis.gps[0], axis.gps[0]);
      const dTo = distanceToSegmentM([p.lat, p.lon], axis.gps[axis.gps.length - 1], axis.gps[axis.gps.length - 1]);
      zoneId = dFrom <= dTo ? axis.from : axis.to;
    }
    return {
      ...p,
      axisId: found?.axis.id ?? null,
      axisName: found?.axis.name ?? null,
      axisDistanceM: found?.distanceM ?? null,
      zoneId,
      zoneName: zoneId ? (getZone(city, zoneId)?.name ?? null) : null,
      walkDistanceM: found?.distanceM ?? null,
    };
  });

  return NextResponse.json({ city: city.id, query: q, results });
}
