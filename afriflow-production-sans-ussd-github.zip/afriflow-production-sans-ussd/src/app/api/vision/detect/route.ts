import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { ingestCrowdReport } from "@/lib/crowd";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { ensureCitySeed } from "@/lib/seed";
import { detectRoadDamage, visionConfigured } from "@/lib/vision";

export const dynamic = "force-dynamic";

/**
 * POST /api/vision/detect — analyse d'une photo de dégradation routière
 * (YOLOv8 via Roboflow) :
 *   { imageBase64, city?, lat?, lon?, confirm?: boolean }
 * Sans clé Roboflow : { configured: false } — le signalement repasse
 * alors par la description texte (aucune détection inventée).
 * Avec confirm=true et des coordonnées : un incident validé par la
 * vision (confiance ≥ 50 %) entre dans le consensus communautaire.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`vision:${clientIp(req)}`, 30, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  if (!visionConfigured()) {
    return NextResponse.json({
      configured: false,
      detections: [],
      message:
        "Vision IA non activée : définissez ROBOFLOW_API_KEY et ROBOFLOW_MODEL_ID (modèle YOLOv8 de dégradations routières) pour analyser les photos. En attendant, décrivez l'incident en texte ou partagez votre position.",
    });
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;
  const base64 = typeof body.imageBase64 === "string" ? body.imageBase64 : "";
  if (base64.length < 100) {
    return NextResponse.json({ error: "imageBase64 requis (image encodée en base64)" }, { status: 422 });
  }
  let bytes: ArrayBuffer;
  try {
    const buf = Buffer.from(base64, "base64");
    if (buf.length > 8_000_000) {
      return NextResponse.json({ error: "Image trop lourde (8 Mo maximum)" }, { status: 413 });
    }
    bytes = buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) as ArrayBuffer;
  } catch {
    return NextResponse.json({ error: "Base64 illisible" }, { status: 422 });
  }

  const result = await detectRoadDamage(bytes);

  // Validation automatique : détection nette + coordonnées + demande explicite.
  let incident: unknown = null;
  const lat = Number(body.lat);
  const lon = Number(body.lon);
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (
    body.confirm === true &&
    result.topType &&
    result.topConfidence >= 0.5 &&
    Number.isFinite(lat) &&
    Number.isFinite(lon) &&
    city
  ) {
    await ensureCitySeed(city);
    const ingested = await ingestCrowdReport(city, {
      source: "whatsapp",
      lat,
      lon,
      incidentType: result.topType,
      confidenceScore: Math.max(5, Math.round(result.topConfidence * 10)),
      reporterKey: "vision-ia",
      description: `[Vision IA] Dégradation détectée automatiquement sur photo (${result.detections[0]?.className}, confiance ${Math.round(result.topConfidence * 100)} %).`,
    });
    incident = ingested
      ? { id: ingested.incident.id, axis: ingested.axisName, status: ingested.incident.status }
      : null;
  }

  return NextResponse.json({ ...result, incident });
}
