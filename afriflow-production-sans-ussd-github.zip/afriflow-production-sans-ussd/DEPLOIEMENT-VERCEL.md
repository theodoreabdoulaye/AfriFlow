# AfriFlow : preparation Vercel

MISE A JOUR : les comptes, paiements et controles d'acces sont maintenant ajoutes.
Consulter COMPTE-CHARIOW.md et appliquer les migrations de comptes/paiements avant d'utiliser ces fonctions.
Les notes de verification et limites ci-dessous decrivent la premiere preparation Vercel ; le guide Chariow precise les modifications recentes, notamment la protection des API flotte et la suppression du cache des pages privees.

La structure src/app, src/components, src/lib et src/db est conservee.
Cette version est compilee et testee localement, pas deployee sur Vercel.

## Configuration

1. Importer les sources dans un depot Git et connecter ce depot a Vercel.
2. Choisir le framework Next.js et Node.js 22.x. La racine du projet est le dossier contenant package.json (pas src).
3. Ajouter DATABASE_URL dans les environnements Preview et Production. Utiliser le point de connexion pooler fourni par le prestataire PostgreSQL, avec TLS selon ses instructions. Ne pas utiliser localhost sur Vercel.
4. Definir NEXT_PUBLIC_SITE_URL avec l'adresse publique HTTPS du site. Redeployer apres modification des variables NEXT_PUBLIC_*.
5. Preparer la base selon la section Migrations ci-dessous. Aucune migration n'est lancee automatiquement pendant le build.
6. Configurer les integrations optionnelles d'apres .env.example. WhatsApp exige WHATSAPP_APP_SECRET (secret de l'application Meta) pour verifier les signatures POST, en plus du jeton de verification GET.
7. Deployer puis tester /api/health, les lectures et ecritures de donnees, les flux SSE et les integrations avec la vraie base.

Installation reproductible : npm ci. Le fichier package-lock.json est inclus.

## Precontrole local de production

```sh
npm run preflight
npm run typecheck
npm test
NODE_OPTIONS=--max-old-space-size=1024 npm run build
```

Vercel execute `npm run preflight && npm run build` (Node 22.x). Le build local seul reste possible sans base pour verifier la compilation ; il ne valide pas la configuration de production.

Le precontrole lit les variables exportees puis, sans les ecraser, .env.production.local, .env.local, .env.production et .env, dans cet ordre. Il ne lit pas .env.example. Ne jamais versionner ces fichiers prives, afficher leurs valeurs ou fournir des secrets en arguments de commande.

Il exige DATABASE_URL (URL PostgreSQL avec hote et nom de base), NEXT_PUBLIC_SITE_URL (origine HTTPS sans identifiants, chemin, query ou fragment, hors loopback) et les deux cles reCAPTCHA. Google reste optionnel : seul NEXT_PUBLIC_GOOGLE_CLIENT_ID est utilise, avec le format OAuth Web attendu ; aucun secret Google serveur n'est requis par ce parcours. WhatsApp doit etre entierement absent ou avoir ses quatre variables. Chariow doit avoir les deux cles ou aucune ; le secret Pulse doit commencer par whsec_. Les alias publics des secrets serveur controles sont refuses. Les diagnostics ne contiennent que des noms de variables et des erreurs statiques ; le code de sortie est 1 en cas d'echec.

Ce controle est exclusivement syntaxique : aucune connexion reseau, verification de cle, requete SQL, migration ou modification distante. Il ne prouve pas la validite des cles, le TLS PostgreSQL, les domaines autorises Google/reCAPTCHA ou la disponibilite des partenaires. Verifier ces points dans un environnement de validation avant ouverture. Utiliser des bases et cles distinctes pour Preview et Production, et une origine exacte pour chaque environnement ; toute modification NEXT_PUBLIC_* exige un nouveau build.

## Migrations

`migrations/001-auth.sql` et `migrations/002-payments.sql` sont des scripts SQL manuels, pas des migrations Drizzle. Aucun dossier drizzle ni journal/meta de migrations generees n'est fourni. `npm run db:migrate` ne les execute pas et n'est pas une commande d'initialisation utilisable avec l'historique actuel.

- Base vide : depuis un poste de confiance, examiner puis appliquer `npm run db:push` pour creer le schema complet des trois fichiers declares dans drizzle.config.ts. Cette commande se connecte et modifie la base : jamais dans le build Vercel.
- Base existante : sauvegarder, tester la restauration et verifier la compatibilite des tables, puis appliquer les ajouts comptes/paiements dans l'ordre, avec le client PostgreSQL et une variable DATABASE_URL deja injectee. Les deux scripts ne creent pas le schema metier de base.

```sh
psql -X "$DATABASE_URL" -v ON_ERROR_STOP=1 --single-transaction -f migrations/001-auth.sql -f migrations/002-payments.sql
```

Les scripts utilisent IF NOT EXISTS : cela ne corrige pas des tables incompatibles. Examiner le schema reel et les droits apres execution. La commande ci-dessus est une instruction pour l'operateur, pas une action executee ici ; sur un poste partage, preferer un service libpq/pgpass protege pour eviter l'URL dans les arguments de processus. Pour adopter Drizzle ensuite, etablir et relire une baseline correspondant au schema reel avant generate/migrate ; ne pas generer une creation complete puis l'appliquer aveuglement sur la base existante. Aucun historique ni metadata n'a ete invente.

## Corrections

- Connexion PostgreSQL initialisee a la premiere utilisation, pas lors de l'import des routes pendant le build. DATABASE_URL reste obligatoire pour les fonctions utilisant la base.
- Pool reutilise dans une instance, limite a trois connexions. Cette limite n'est pas globale : le pooler du prestataire reste important sous charge.
- Configuration Drizzle basee sur DATABASE_URL, sans adresse locale inscrite en dur.
- Flux SSE Node.js declares pour 60 secondes et fermes vers 50 secondes. EventSource peut se reconnecter automatiquement ; les clients personnalises doivent gerer la reconnexion.
- Actualisations SSE serialisees et nettoyage des timers sur fermeture/deconnexion.
- Alertes SSE relues depuis PostgreSQL toutes les dix secondes, au lieu d'un abonnement limite a la memoire d'une instance. Les alertes actives sont renvoyees a chaque connexion, avec detection des changements et expirations pendant la connexion.
- Notifications et reentrainements concernes rattaches au cycle de vie Next.js avec after().
- Verification HMAC des notifications WhatsApp avant traitement.
- Icones PNG 192 et 512 ajoutees ; manifeste corrige ; service worker non cache et pages hors ligne conservees par URL. Les reponses en erreur et les domaines tiers ne sont pas mis en cache.
- Base des URL des metadonnees sociales configuree.

## Verifications effectuees

- Validation locale actuelle : npm run lint, npm run typecheck, npm test (16/16) et npm run build (54 routes) : succes.
- Precontrole avec valeurs fictives exportees : succes sans connexion externe. Le precontrole local reel echoue volontairement car NEXT_PUBLIC_SITE_URL vaut http://localhost:3000 et la paire reCAPTCHA de test n'est pas une configuration de production.
- Fullstack local : PostgreSQL sur le port 55432, schema applique (24 tables), compte de demonstration et grant de paiement seedes.
- API verifiees : /api/health (base OK, 263 villes, 54 pays), lectures publiques et privees, pages /, /compte, /convoi, manifeste, service worker, robots, sitemap et security.txt.
- SSE verifies : /api/stream et /api/v1/stream.
- Ecritures verifiees : /api/report, /api/incidents (fusion/confirmation), /api/fleet, /api/fleet/reroute, /api/parking/occupancy, /api/subscriptions, /api/routing/accept, /api/nlp/extract, /api/simulate/scenario, /api/v1/report, /api/v1/telemetry et /api/v1/route.
- Vision IA non configuree : reponse explicite configured:false, aucun echec.
- Les integrations tierces reelles (HERE, OpenAI, Roboflow, WhatsApp, Chariow, Google OAuth, Sentry) n'ont pas ete testees faute de cles.

## Archive de sources

Le zip contient les sources, package-lock.json, vercel.json, migrations, scripts, tests et .env.example. Il exclut node_modules, .next, tsconfig.tsbuildinfo, next-env.d.ts, les fichiers .env/.env.local et tout secret local. Pour deployer : importer le contenu dans un depot Git, connecter le depot a Vercel, definir les variables d'environnement dans le projet Vercel, appliquer le schema a la base, puis deployer.

## Limites et points a securiser avant usage reel

- Aucune base, cle partenaire ou connexion Vercel n'etait fournie. Les migrations, les operations SQL, le rendu visuel et les integrations n'ont pas ete testes de bout en bout.
- Les API flotte ont maintenant un controle de session/acces payant ; cela ne remplace pas les autorisations d'appartenance par flotte/reservation. Ajouter ces controles avant d'y stocker des donnees reelles.
- Le webhook Waze n'authentifie pas son partenaire ; le proteger avant activation.
- Valider strictement les destinations des abonnements Web Push avant usage public, afin d'eviter les requetes serveur vers des destinations arbitraires. Stabiliser aussi la paire VAPID : sa generation concurrente actuelle reste a corriger.
- Les limites de debit et plusieurs caches restent locaux aux instances. Pour une protection globale, utiliser un stockage partage ou Vercel Firewall. REDIS_URL seul n'active pas de cache Redis.
- L'initialisation de donnees de demonstration dans les requetes comporte des risques de concurrence et melange des incidents synthetiques aux tables applicatives. La separer des donnees de production avant lancement.
- Le flux d'alertes lit au maximum les 1000 incidents broadcast les plus recents de la fenetre de trois heures. Il ne fournit ni journal durable de livraison, ni curseur de reprise, ni garantie de livraison exactement une fois. Les reconnexions peuvent repeter des alertes.
- after() ameliore la tenue des taches courtes mais ne remplace pas une file durable avec reprises. Les notifications et entrainements longs, les autres enrichissements opportunistes et les purges planifiees doivent etre externalises si leur execution est critique.
- Les fonctions restent soumises aux plafonds Vercel ; adapter l'offre et les budgets de temps apres mesure avec une vraie base.

Cette preparation ne constitue pas une certification de securite ou de tenue en charge. Aucun deploiement, changement DNS ou migration distante n'a ete effectue. L'archive de sources preparee pour Vercel exclut les secrets et les artefacts de build ; les variables doivent etre definies dans le projet Vercel.
