import type { Metadata } from "next";
import Link from "next/link";
import ConvoyPage from "@/components/ConvoyPage";
import { CITY_COUNT } from "@/lib/cities";
import { getCurrentUser } from "@/lib/auth";
import { getAccess } from "@/lib/access";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Convoi Industriel — AfriFlow",
  description:
    `Centre de contrôle flottes & industrie AfriFlow : suivi de camions en direct dans ${CITY_COUNT} villes, reroutage collectif en un clic réparti sur les délestages, ordres SMS + WhatsApp aux chauffeurs.`,
};

export default async function Page() {
  let active = false;
  let unavailable = false;
  try {
    const user = await getCurrentUser();
    active = !!user && (await getAccess(user.id)).active;
  } catch {
    unavailable = true;
  }
  if (!active) {
    return (
      <main className="mx-auto flex min-h-screen max-w-xl flex-col justify-center gap-4 px-6">
        <h1 className="text-2xl font-semibold">Convoi Industriel</h1>
        <p>
          {unavailable
            ? "La verification de votre acces est temporairement indisponible. Veuillez reessayer."
            : "Connectez-vous avec un acces payant actif pour consulter et gerer les convois."}
        </p>
        <Link href="/compte" className="w-fit rounded-lg bg-emerald-600 px-4 py-2 font-medium text-white">
          Acceder a mon compte
        </Link>
      </main>
    );
  }
  return <ConvoyPage />;
}
