import { CITIES, CITY_MAP, type CityDef } from "./cities";
import {
  findRatableTrip,
  handleDriverDecision,
  recordRating,
} from "./carpool-decisions";
import { ingestCrowdReport } from "./crowd";
import { searchPlaces } from "./geocode";
import { extractIncidentEntities, resolveInGraph } from "./extract";
import { extractIncidentLocal, severityFromText, type NlpExtraction } from "./nlp";
import { ensureCitySeed } from "./seed";
import { detectRoadDamage, visionConfigured } from "./vision";
import { sendWhatsAppText } from "./wa-sender";

/**
 * Pipeline WhatsApp Business (Meta Graph API), porté du design Rust :
 *   message → (audio → Whisper) → extraction NLP → géocodage Nominatim
 *           → map matching → consensus communautaire → réponse au chauffeur.
 *
 * Sans clés (WHATSAPP_TOKEN / OPENAI_API_KEY), le pipeline reste utile :
 * messages texte et localisations sont traités par l'extraction locale
 * multilingue, et les vocaux reçoivent une réponse honnête invitant à
 * écrire ou partager la position. Les réponses ne sont envoyées via
 * l'API Meta que si le jeton et l'identifiant du numéro sont configurés.
 */

export interface WaMessage {
  from: string;
  type: string;
  text?: { body?: string };
  location?: { latitude?: number; longitude?: number };
  audio?: { id?: string };
  image?: { id?: string; caption?: string };
}

export interface WaProcessResult {
  from: string;
  type: string;
  action: string;
  reply: string;
  incidentId?: number;
  replySent: boolean;
}

const GRAPH = "https://graph.facebook.com/v17.0";

function waToken(): string | null {
  return process.env.WHATSAPP_TOKEN ?? null;
}
function waPhoneId(): string | null {
  return process.env.WHATSAPP_PHONE_NUMBER_ID ?? null;
}
function openAiKey(): string | null {
  return process.env.OPENAI_API_KEY ?? null;
}

async function getMediaUrl(mediaId: string): Promise<string | null> {
  const token = waToken();
  if (!token) return null;
  try {
    const res = await fetch(`${GRAPH}/${mediaId}`, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { url?: string };
    return json.url ?? null;
  } catch {
    return null;
  }
}

async function downloadMedia(url: string): Promise<ArrayBuffer | null> {
  const token = waToken();
  if (!token) return null;
  try {
    const res = await fetch(url, {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    return await res.arrayBuffer();
  } catch {
    return null;
  }
}

/** Transcription OpenAI Whisper (français/wolof/pulaar bien gérés). */
async function transcribeAudio(bytes: ArrayBuffer): Promise<string | null> {
  const key = openAiKey();
  if (!key) return null;
  try {
    const form = new FormData();
    form.append("model", "whisper-1");
    form.append("file", new Blob([bytes], { type: "audio/ogg" }), "audio.ogg");
    const res = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}` },
      body: form,
      signal: AbortSignal.timeout(30000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as { text?: string };
    return json.text ?? null;
  } catch {
    return null;
  }
}

/* ----------------- Localisations en attente (par expéditeur) ----------------- */

interface PendingLocation {
  lat: number;
  lon: number;
  cityId: string;
  at: number;
}
const pendingLocations = new Map<string, PendingLocation>();
const PENDING_TTL_MS = 10 * 60_000;

function nearestCity(lat: number, lon: number): CityDef {
  let best = CITY_MAP.dakar;
  let bestDist = Infinity;
  for (const c of CITIES) {
    const d = Math.hypot(c.lat - lat, c.lon - lon);
    if (d < bestDist) {
      bestDist = d;
      best = c;
    }
  }
  return best;
}

function cityMentionedIn(text: string): CityDef | null {
  const t = text
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
  for (const c of CITIES) {
    const name = c.name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");
    if (t.includes(name)) return c;
  }
  return null;
}

async function finalizeIncident(
  msg: WaMessage,
  city: CityDef,
  lat: number,
  lon: number,
  extraction: NlpExtraction,
  originalText: string,
): Promise<WaProcessResult> {
  await ensureCitySeed(city);
  const result = await ingestCrowdReport(city, {
    source: "whatsapp",
    lat,
    lon,
    incidentType: extraction.incidentType,
    confidenceScore: Math.max(1, Math.min(10, Math.round(extraction.confidence * 10))),
    reporterKey: msg.from,
    reporterContact: msg.from,
    severity: severityFromText(originalText),
    description: `[WhatsApp] ${originalText.slice(0, 240)}`,
  });
  const reply = !result
    ? "📍 Position reçue, mais aucun axe surveillé à proximité. Merci quand même !"
    : result.validated
      ? `📣 Alerte diffusée à toute la ville ! Incident « ${extraction.incidentType} » confirmé sur ${result.axisName} (consensus atteint). Merci, la carte est à jour.`
      : `✅ Alerte '${extraction.incidentType}' enregistrée près de ${result.axisName}. Confiance actuelle : ${result.incident.confidence} % (${result.incident.confirmations}/3 confirmations) — deux autres conducteurs doivent confirmer pour diffuser.`;
  const replySent = await sendWhatsAppText(msg.from, reply);
  return {
    from: msg.from,
    type: msg.type,
    action: result ? (result.merged ? "incident-confirmé" : "incident-créé") : "sans-axe",
    reply,
    incidentId: result?.incident.id,
    replySent,
  };
}

async function processTextContent(msg: WaMessage, text: string): Promise<WaProcessResult> {
  const extraction = extractIncidentLocal(text);

  // 1) Localisation partagée juste avant : elle fait foi.
  const pending = pendingLocations.get(msg.from);
  if (pending && Date.now() - pending.at < PENDING_TTL_MS) {
    pendingLocations.delete(msg.from);
    const city = CITY_MAP[pending.cityId] ?? CITY_MAP.dakar;
    return finalizeIncident(msg, city, pending.lat, pending.lon, extraction, text);
  }

  // 2) Lieu nommé : extraction structurée {edge_id, type, severite}
  //    (graphe d'abord pour les noms locaux, Nominatim en repli).
  const mentionedCity = cityMentionedIn(text);
  if (extraction.locationName) {
    const city = mentionedCity ?? CITY_MAP.dakar;
    const entities = await extractIncidentEntities(text, city);
    if (entities.edge_id && entities.lat !== null && entities.lon !== null) {
      return finalizeIncident(
        msg,
        city,
        entities.lat,
        entities.lon,
        {
          incidentType: entities.type,
          locationName: entities.location_name,
          confidence: entities.confidence,
          typeFound: true,
        },
        text,
      );
    }
  }

  // 3) Type reconnu mais lieu non extrait (ex. wolof « Aksidaan am na
  //    pont des martyrs ») : on cherche le lieu dans tout le message.
  if (extraction.typeFound && mentionedCity) {
    const inGraph = resolveInGraph(mentionedCity, text);
    if (inGraph) {
      return finalizeIncident(msg, mentionedCity, inGraph.lat, inGraph.lon, extraction, text);
    }
  }

  const reply =
    "👋 Merci pour votre message ! Pour signaler un incident, partagez votre position (📎 → Localisation) puis écrivez le type : accident, bouchon, travaux, police, inondation ou panne. Vous pouvez aussi écrire par exemple : « Accident sur la VDN à Dakar ».";
  const replySent = await sendWhatsAppText(msg.from, reply);
  return { from: msg.from, type: msg.type, action: "demande-précision", reply, replySent };
}

/** Point d'entrée principal du pipeline (appelé par le webhook). */
export async function processWhatsAppMessage(msg: WaMessage): Promise<WaProcessResult> {
  if (msg.type === "location" && msg.location) {
    const lat = Number(msg.location.latitude);
    const lon = Number(msg.location.longitude);
    if (Number.isFinite(lat) && Number.isFinite(lon)) {
      const city = nearestCity(lat, lon);
      pendingLocations.set(msg.from, { lat, lon, cityId: city.id, at: Date.now() });
      const reply = `📍 Position reçue (${lat.toFixed(4)}, ${lon.toFixed(4)}) près de ${city.name}. Quel est le type d'incident ? Répondez par exemple : accident, bouchon, travaux, police, inondation ou panne.`;
      const replySent = await sendWhatsAppText(msg.from, reply);
      return { from: msg.from, type: "location", action: "position-enregistrée", reply, replySent };
    }
  }

  if (msg.type === "text" && msg.text?.body) {
    const rawBody = msg.text.body.trim();
    const normalizedBody = rawBody
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/[!.,\s]+$/g, "");

    // 1) Réponse OUI/NON du conducteur à une demande de covoiturage.
    const isOui = ["oui", "yes", "ok", "accepte", "j'accepte", "d'accord", "daccord"].includes(normalizedBody);
    const isNon = ["non", "no", "refuse", "refuser", "annuler", "non merci"].includes(normalizedBody);
    if (isOui || isNon) {
      const outcome = await handleDriverDecision(msg.from, isOui ? "oui" : "non");
      if (outcome.handled) {
        const replySent = await sendWhatsAppText(msg.from, outcome.reply);
        return {
          from: msg.from,
          type: "text",
          action: isOui ? "covoiturage-accepté" : "covoiturage-refusé",
          reply: outcome.reply,
          replySent,
        };
      }
      // Pas de demande en attente : on laisse le flux normal traiter le message.
    }

    // 2) Notation post-trajet : "5", "5/5", "note 5", "4 étoiles"…
    const ratingMatch =
      normalizedBody.match(/^([1-5])(\s*\/\s*5|\s+etoiles?)?$/) ??
      normalizedBody.match(/^note\s*:?\s*([1-5])/);
    if (ratingMatch) {
      const trip = await findRatableTrip(msg.from);
      if (trip) {
        const outcome = await recordRating({
          bookingId: trip.bookingId,
          raterPhone: msg.from,
          stars: Number(ratingMatch[1]),
        });
        const reply = outcome.ok
          ? `⭐ Merci pour votre note de ${ratingMatch[1]} étoile(s) ! ${trip.rateeLabel} affiche désormais ${outcome.average}★ (${outcome.count} avis). À bientôt sur AfriFlow !`
          : outcome.message;
        const replySent = await sendWhatsAppText(msg.from, reply);
        return { from: msg.from, type: "text", action: "trajet-noté", reply, replySent };
      }
    }

    return processTextContent(msg, msg.text.body);
  }

  if (msg.type === "audio") {
    const token = waToken();
    const key = openAiKey();
    if (!token || !key || !msg.audio?.id) {
      const reply =
        "🎙️ Message vocal bien reçu ! La transcription automatique des vocaux n'est pas encore activée sur ce numéro. Écrivez le type d'incident et le lieu (ex. « Accident sur la VDN »), ou partagez votre position (📎 → Localisation).";
      const replySent = await sendWhatsAppText(msg.from, reply);
      return { from: msg.from, type: "audio", action: "vocal-non-transcrit", reply, replySent };
    }
    const mediaUrl = await getMediaUrl(msg.audio.id);
    const bytes = mediaUrl ? await downloadMedia(mediaUrl) : null;
    const transcript = bytes ? await transcribeAudio(bytes) : null;
    if (!transcript) {
      const reply = "🎙️ Je n'ai pas réussi à transcrire votre vocal. Pouvez-vous écrire le type d'incident et le lieu ?";
      const replySent = await sendWhatsAppText(msg.from, reply);
      return { from: msg.from, type: "audio", action: "transcription-échouée", reply, replySent };
    }
    const result = await processTextContent(msg, transcript);
    return { ...result, type: "audio", action: `vocal-transcrit: ${result.action}` };
  }

  if (msg.type === "image") {
    if (!waToken() || !visionConfigured() || !msg.image?.id) {
      const reply =
        "📸 Photo bien reçue ! L'analyse automatique des dégradations (nids-de-poule, inondations) n'est pas encore activée sur ce numéro. Décrivez l'incident en texte ou partagez votre position (📎 → Localisation).";
      const replySent = await sendWhatsAppText(msg.from, reply);
      return { from: msg.from, type: "image", action: "photo-non-analysée", reply, replySent };
    }
    const mediaUrl = await getMediaUrl(msg.image.id);
    const bytes = mediaUrl ? await downloadMedia(mediaUrl) : null;
    const vision = bytes ? await detectRoadDamage(bytes) : null;
    if (!vision || !vision.topType || vision.topConfidence < 0.5) {
      const reply =
        "📸 Photo analysée : je n'ai pas détecté de dégradation nette. Pouvez-vous décrire l'incident en texte (type + lieu) ?";
      const replySent = await sendWhatsAppText(msg.from, reply);
      return { from: msg.from, type: "image", action: "photo-sans-détection", reply, replySent };
    }
    const pending = pendingLocations.get(msg.from);
    if (pending && Date.now() - pending.at < PENDING_TTL_MS) {
      pendingLocations.delete(msg.from);
      const city = CITY_MAP[pending.cityId] ?? CITY_MAP.dakar;
      const result = await finalizeIncident(
        msg,
        city,
        pending.lat,
        pending.lon,
        {
          incidentType: vision.topType,
          locationName: null,
          confidence: vision.topConfidence,
          typeFound: true,
        },
        `Photo analysée par vision IA : ${vision.detections[0]?.className} (${Math.round(vision.topConfidence * 100)} %)`,
      );
      return { ...result, type: "image", action: `photo-détectée: ${result.action}` };
    }
    const reply = `📸 Analyse : ${vision.detections[0]?.className} détecté (confiance ${Math.round(vision.topConfidence * 100)} %). Partagez maintenant votre position (📎 → Localisation) pour placer l'alerte sur la carte.`;
    const replySent = await sendWhatsAppText(msg.from, reply);
    return { from: msg.from, type: "image", action: "photo-détectée-sans-position", reply, replySent };
  }

  const reply = "Type de message non supporté pour le moment : envoyez un texte, un vocal ou votre localisation.";
  const replySent = await sendWhatsAppText(msg.from, reply);
  return { from: msg.from, type: msg.type, action: "non-supporté", reply, replySent };
}
