import { eq } from "drizzle-orm";
import { after } from "next/server";
import { db } from "@/db";
import { incidentConfirmations, incidents } from "@/db/schema";
import type { CityDef } from "./cities";
import { getAxis } from "./cities";
import { sendAlertPush } from "./push";
import { buildConfirmationMessage, sendWhatsAppText } from "./wa-sender";

/**
 * Hub d'alertes temps réel (porté du design Rust : ConsensusService →
 * broadcast::channel → SSE Hub + WhatsApp Sender).
 *
 * Quand un incident franchit le consensus (statut « broadcast »), le hub :
 *  1. publie l'alerte à tous les clients SSE abonnés (par ville ou global) ;
 *  2. envoie, en arrière-plan, la confirmation WhatsApp personnalisée à
 *     chaque rapporteur joignable (numéro connu via le canal WhatsApp) ;
 *  3. émet « alert_expired » quand l'alerte sort de sa fenêtre d'impact (3 h).
 */

export interface ValidatedAlert {
  id: number;
  city: string;
  edge_id: string;
  axis_name: string;
  incident_type: string;
  severity: number;
  confirmation_count: number;
  confidence_score: number;
  speed_penalty_kmh: number;
  expires_at: string;
}

export interface AlertEvent {
  event_type: "alert_validated" | "alert_expired";
  alert: ValidatedAlert;
  timestamp: number;
  message: string;
}

type Subscriber = (event: AlertEvent) => void;

const subscribers = new Map<string, Set<Subscriber>>(); // clé : cityId ou "*"
const published = new Map<number, { alert: ValidatedAlert; expired: boolean }>();
let sweeperStarted = false;

export function toValidatedAlert(city: CityDef, incident: typeof incidents.$inferSelect): ValidatedAlert {
  const axis = getAxis(city, incident.axisId);
  const penaltyFactor = Math.min(0.5, 0.09 * incident.severity);
  return {
    id: incident.id,
    city: city.id,
    edge_id: incident.axisId,
    axis_name: axis?.name ?? incident.axisId,
    incident_type: incident.type,
    severity: incident.severity,
    confirmation_count: incident.confirmations,
    confidence_score: incident.confidence,
    speed_penalty_kmh: Math.round((axis?.freeFlowKmh ?? 40) * penaltyFactor * 10) / 10,
    expires_at: new Date(new Date(incident.createdAt).getTime() + 3 * 3600_000).toISOString(),
  };
}

function dispatch(event: AlertEvent): void {
  const targets = new Set<Subscriber>([
    ...(subscribers.get("*") ?? []),
    ...(subscribers.get(event.alert.city) ?? []),
  ]);
  for (const cb of targets) {
    try {
      cb(event);
    } catch {
      /* abonné défaillant ignoré (équivalent Lagged du design) */
    }
  }
}

/** Remercie les rapporteurs joignables par WhatsApp (arrière-plan). */
async function notifyReporters(alert: ValidatedAlert): Promise<void> {
  try {
    const rows = await db
      .select({ contact: incidentConfirmations.reporterContact })
      .from(incidentConfirmations)
      .where(eq(incidentConfirmations.incidentId, alert.id));
    const contacts = [...new Set(rows.map((r) => r.contact).filter((c): c is string => !!c))];
    for (const contact of contacts) {
      await sendWhatsAppText(
        contact,
        buildConfirmationMessage(alert.incident_type, alert.axis_name, alert.confidence_score),
      );
    }
  } catch {
    /* notifications best-effort */
  }
}

function startSweeper(): void {
  if (sweeperStarted) return;
  sweeperStarted = true;
  const timer = setInterval(() => {
    const now = Date.now();
    for (const entry of published.values()) {
      if (!entry.expired && new Date(entry.alert.expires_at).getTime() <= now) {
        entry.expired = true;
        dispatch({
          event_type: "alert_expired",
          alert: entry.alert,
          timestamp: Math.floor(now / 1000),
          message: `⌛ Alerte expirée : ${entry.alert.incident_type} sur ${entry.alert.axis_name} (fenêtre d'impact de 3 h écoulée)`,
        });
      }
    }
  }, 60_000);
  // Ne pas retenir le processus pour ce seul timer.
  (timer as { unref?: () => void }).unref?.();
}

/**
 * Publie une alerte fraîchement validée par le consensus.
 * À appeler à la transition vers le statut « broadcast », une seule fois.
 */
export function emitValidatedAlert(city: CityDef, incident: typeof incidents.$inferSelect): void {
  if (published.has(incident.id)) return;
  const alert = toValidatedAlert(city, incident);
  published.set(incident.id, { alert, expired: false });
  startSweeper();
  dispatch({
    event_type: "alert_validated",
    alert,
    timestamp: Math.floor(Date.now() / 1000),
    message: `🚨 ${alert.incident_type} confirmé sur ${alert.axis_name} (confiance ${alert.confidence_score}%)`,
  });
  after(async () => {
    await Promise.allSettled([notifyReporters(alert), sendAlertPush(alert)]);
  });
}

/** Abonnement au flux d'alertes (ville donnée ou "*" pour tout le réseau). */
export function subscribeAlerts(cityKey: string, cb: Subscriber): () => void {
  startSweeper();
  const set = subscribers.get(cityKey) ?? new Set<Subscriber>();
  set.add(cb);
  subscribers.set(cityKey, set);
  return () => {
    set.delete(cb);
    if (set.size === 0) subscribers.delete(cityKey);
  };
}
