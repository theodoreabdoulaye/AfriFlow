import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { test } from "node:test";
import { extendExpiry, parseCheckoutInput, PRODUCTS, verifySignature, readPaymentBody } from "../src/lib/chariow";

test("signature authenticates exact unicode raw bytes, not reserialized JSON", () => {
  const raw = Buffer.from('{"name":"\u00c9lodie","url":"https:\\/\\/example.com"}\n', "utf8");
  const secret = "whsec_test";
  const signature = "sha256=" + createHmac("sha256", secret).update(raw).digest("hex");
  assert.equal(verifySignature(raw, signature, secret), true);
  assert.equal(verifySignature(Buffer.from(JSON.stringify(JSON.parse(raw.toString()))), signature, secret), false);
  assert.equal(verifySignature(Buffer.concat([raw, Buffer.from(" ")]), signature, secret), false);
  assert.equal(verifySignature(raw, signature, "wrong"), false);
  for (const invalid of [null, "", signature.slice(7), signature.replace("sha256=", "sha512="), "sha256=abc", signature.toUpperCase()]) {
    assert.equal(verifySignature(raw, invalid, secret), false);
  }
  assert.equal(verifySignature(raw, signature, ""), false);
});

test("day and week are exact elapsed durations, expired access starts now", () => {
  const now = new Date("2026-03-29T01:30:00Z");
  for (const [plan, days] of [["day", 1], ["week", 7]] as const) {
    const result = extendExpiry(plan, now, new Date("2020-01-01Z"));
    assert.equal(result.startsAt.getTime(), now.getTime());
    assert.equal(result.expiresAt.getTime() - now.getTime(), days * 86_400_000);
  }
});

test("calendar months clamp month ends and preserve UTC time", () => {
  for (const [start, end] of [
    ["2026-01-31T12:34:56.789Z", "2026-02-28T12:34:56.789Z"],
    ["2024-01-31T12:34:56.789Z", "2024-02-29T12:34:56.789Z"],
    ["2026-08-31T12:34:56.789Z", "2026-09-30T12:34:56.789Z"],
    ["2026-12-31T12:34:56.789Z", "2027-01-31T12:34:56.789Z"],
  ]) assert.equal(extendExpiry("month", new Date(start), null).expiresAt.toISOString(), end);
  assert.throws(() => extendExpiry("day", new Date(NaN), null));
  assert.throws(() => extendExpiry("month", new Date(), new Date(NaN)));
});

test("renewals extend existing paid time without overlapping", () => {
  const now = new Date("2026-01-01Z");
  const first = extendExpiry("week", now, null);
  const second = extendExpiry("day", now, first.expiresAt);
  assert.equal(second.startsAt.toISOString(), first.expiresAt.toISOString());
  assert.equal(second.expiresAt.toISOString(), "2026-01-09T00:00:00.000Z");
});

test("checkout accepts only the server-mapped plan and normalized phone", () => {
  const input = { plan: "day", phone: "+225 (07) 12-34-56-78", countryCode: "ci" };
  assert.deepEqual(parseCheckoutInput(input), { plan: "day", phone: "2250712345678", countryCode: "CI" });
  for (const invalid of [{ ...input, amount: 1 }, { ...input, userId: "attacker" }, { ...input, plan: "toString" }, { ...input, phone: "abc123456" }, { ...input, countryCode: "+225" }, null, []]) {
    assert.equal(parseCheckoutInput(invalid), null);
  }
  assert.deepEqual(PRODUCTS, { day: "prd_3axt0ryr", week: "prd_049ep2ma", month: "prd_bcc94ior" });
});

test("payment bodies preserve bytes and enforce size without content-length", async () => {
  const raw = Buffer.from('{"name":"\u00c9lodie"}\n', "utf8");
  assert.deepEqual(await readPaymentBody(new Request("https://example.com", { method: "POST", body: raw }), raw.length), raw);
  await assert.rejects(readPaymentBody(new Request("https://example.com", { method: "POST", body: raw }), raw.length - 1), RangeError);
  await assert.rejects(readPaymentBody(new Request("https://example.com", { method: "POST", body: "{}", headers: { "Content-Length": "9999" } }), 10), RangeError);
});
