import { createHmac, timingSafeEqual } from "node:crypto";

// https://chariow.dev/en/guides/checkout : publish API-supported products.
// Renewals require repeat purchases (License supports them); Service/Coaching
// and pay-what-you-want products cannot use this API. A widget is not identity.
export const PRODUCTS = {
  day: "prd_3axt0ryr",
  week: "prd_049ep2ma",
  month: "prd_bcc94ior",
} as const;
export type Plan = keyof typeof PRODUCTS;
export const STORE_ORIGIN = "https://nicbtvnz.mychariow.store";

export async function readPaymentBody(req: Request, limit: number): Promise<Buffer> {
  if (Number(req.headers.get("content-length")) > limit) throw new RangeError("Body too large");
  const reader = req.body?.getReader();
  if (!reader) return Buffer.alloc(0);
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > limit) { await reader.cancel(); throw new RangeError("Body too large"); }
      chunks.push(value);
    }
    return Buffer.concat(chunks);
  } finally { reader.releaseLock(); }
}

export function verifySignature(raw: Uint8Array, signature: string | null, secret: string): boolean {
  if (!secret || !signature || !/^sha256=[a-f0-9]{64}$/.test(signature)) return false;
  const expected = createHmac("sha256", secret).update(raw).digest();
  return timingSafeEqual(Buffer.from(signature.slice(7), "hex"), expected);
}

export function extendExpiry(plan: Plan, now: Date, currentExpiry: Date | null): { startsAt: Date; expiresAt: Date } {
  if (!Number.isFinite(now.getTime()) || (currentExpiry && !Number.isFinite(currentExpiry.getTime()))) {
    throw new Error("Invalid date");
  }
  const startsAt = new Date(Math.max(now.getTime(), currentExpiry?.getTime() ?? 0));
  const expiresAt = new Date(startsAt);
  if (plan === "day" || plan === "week") {
    expiresAt.setTime(startsAt.getTime() + (plan === "day" ? 1 : 7) * 86_400_000);
  } else if (plan === "month") {
    const day = expiresAt.getUTCDate();
    expiresAt.setUTCDate(1);
    expiresAt.setUTCMonth(expiresAt.getUTCMonth() + 1);
    const lastDay = new Date(Date.UTC(expiresAt.getUTCFullYear(), expiresAt.getUTCMonth() + 1, 0)).getUTCDate();
    expiresAt.setUTCDate(Math.min(day, lastDay));
  } else {
    throw new Error("Invalid plan");
  }
  if (!Number.isFinite(expiresAt.getTime())) throw new Error("Invalid expiry");
  return { startsAt, expiresAt };
}

export function parseCheckoutInput(value: unknown): { plan: Plan; phone: string; countryCode: string } | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const input = value as Record<string, unknown>;
  if (Object.keys(input).length !== 3 || Object.keys(input).some(k => !["plan", "phone", "countryCode"].includes(k))) return null;
  if (typeof input.plan !== "string" || !Object.hasOwn(PRODUCTS, input.plan) || typeof input.phone !== "string" || typeof input.countryCode !== "string") return null;
  if (input.phone.length > 40 || !/^\+?[\d\s().-]+$/.test(input.phone.trim())) return null;
  const phone = input.phone.replace(/\D/g, "");
  const countryCode = input.countryCode.trim().toUpperCase();
  if (!/^\d{6,15}$/.test(phone) || !/^[A-Z]{2}$/.test(countryCode)) return null;
  return { plan: input.plan as Plan, phone, countryCode };
}

export class CheckoutError extends Error {
  constructor(public readonly code: "already_purchased" | "provider_unavailable", public readonly status: number) {
    super(code === "already_purchased" ? "This product is already owned. Configure a repeat-purchase License product for renewals." : "Payment provider unavailable.");
  }
}

export async function createCheckout(input: { plan: Plan; phone: string; countryCode: string; orderId: string; email: string; name: string }): Promise<{ checkoutUrl: string | null; saleId: string }> {
  const key = process.env.CHARIOW_API_KEY;
  const site = new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "");
  if (!key || site.protocol !== "https:" || site.username || site.password) throw new CheckoutError("provider_unavailable", 503);
  const names = input.name.trim().split(/\s+/);
  try {
    const response = await fetch("https://api.chariow.com/v1/checkout", {
      method: "POST",
      headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      cache: "no-store",
      signal: AbortSignal.timeout(15_000),
      body: JSON.stringify({
        product_id: PRODUCTS[input.plan],
        email: input.email.toLowerCase(),
        first_name: (names[0] || "Customer").slice(0, 50),
        last_name: (names.slice(1).join(" ") || names[0] || "Customer").slice(0, 50),
        phone: { number: input.phone, country_code: input.countryCode },
        redirect_url: new URL("/?payment=pending", site.origin).href,
        custom_metadata: { order_id: input.orderId },
      }),
    });
    const result = await response.json();
    if (response.ok && result?.data?.step === "already_purchased") throw new CheckoutError("already_purchased", 409);
    const data = result?.data;
    if (!response.ok || !["payment", "completed"].includes(data?.step) || typeof data?.purchase?.id !== "string" || !/^sal_[A-Za-z0-9]+$/.test(data.purchase.id)) throw new Error("Invalid provider response");
    const checkoutUrl = data.payment?.checkout_url;
    if (data.step === "completed" && checkoutUrl === null) return { checkoutUrl: null, saleId: data.purchase.id };
    if (data.step !== "payment" || typeof checkoutUrl !== "string") throw new Error("Invalid checkout URL");
    const url = new URL(checkoutUrl);
    if (url.protocol !== "https:" || url.username || url.password) throw new Error("Invalid checkout URL");
    return { checkoutUrl, saleId: data.purchase.id };
  } catch (error) {
    if (error instanceof CheckoutError) throw error;
    throw new CheckoutError("provider_unavailable", 502);
  }
}
