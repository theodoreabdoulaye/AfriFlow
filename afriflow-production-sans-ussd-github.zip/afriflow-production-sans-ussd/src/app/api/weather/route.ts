import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { jsonCached } from "@/lib/http-cache";
import { fetchWeather } from "@/lib/weather";

export const dynamic = "force-dynamic";

/** GET /api/weather?city=dakar — météo observée en direct (Open-Meteo). */
export async function GET(req: NextRequest) {
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  const weather = await fetchWeather(city);
  return jsonCached(req, { city: city.id, ...weather }, 120, 300);
}
