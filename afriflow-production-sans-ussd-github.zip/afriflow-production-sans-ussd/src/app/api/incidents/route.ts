import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { incidentConfirmations, incidents } from "@/db/schema";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { INCIDENT_TYPES, alreadyCounted } from "@/lib/consensus";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { emitValidatedAlert } from "@/lib/alert-hub";
import { ensureCitySeed, ensureSeed } from "@/lib/seed";
import { hasVoted, markVoted } from "@/lib/vote-guard";

export const dynamic = "force-dynamic";

/**
 * Incrément atomique du compteur de confirmations : la confiance et le
 * statut sont recalculés dans la même instruction SQL (CASE), donc deux
 * confirmations simultanées ne peuvent ni se perdre ni se contredire.
 */
async function bumpIncident(id: number) {
  const [updated] = await db
    .update(incidents)
    .set({
      confirmations: sql`${incidents.confirmations} + 1`,
      confidence: sql`CASE WHEN ${incidents.confirmations} + 1 >= 3 THEN 98 WHEN ${incidents.confirmations} + 1 = 2 THEN 71 ELSE 38 END`,
      status: sql`CASE WHEN ${incidents.confirmations} + 1 >= 3 THEN 'broadcast' WHEN ${incidents.confirmations} + 1 = 2 THEN 'confirmed' ELSE 'pending' END`,
      updatedAt: new Date(),
    })
    .where(eq(incidents.id, id))
    .returning();
  return updated;
}

/** GET /api/incidents?city=dakar — flux communautaire temps réel. */
export async function GET(req: NextRequest) {
  const cityId = req.nextUrl.searchParams.get("city") ?? "dakar";
  if (!CITY_MAP[cityId]) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  await ensureSeed();
  await ensureCitySeed(CITY_MAP[cityId]);
  try {
    const sixHoursAgo = new Date(Date.now() - 6 * 3600_000);
    const rows = await db
      .select()
      .from(incidents)
      .where(and(eq(incidents.city, cityId), gte(incidents.createdAt, sixHoursAgo)))
      .orderBy(desc(incidents.createdAt))
      .limit(60);
    return NextResponse.json({ city: cityId, incidents: rows });
  } catch {
    return NextResponse.json({ city: cityId, incidents: [] });
  }
}

/**
 * POST /api/incidents — nouveau signalement (app/web, USSD, WhatsApp, SMS).
 * Si un incident du même type existe déjà sur l'axe (< 45 min) et que
 * l'envoi n'est pas déclaré « distinct », il compte comme une confirmation
 * du conducteur (identifié par son appareil anonyme, sinon par son réseau).
 */
export async function POST(req: NextRequest) {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;

  // Limite par appareil quand il est identifié (les conducteurs derrière
  // un même NAT d'opérateur ne se bloquent pas entre eux), sinon par IP.
  const ip = clientIp(req);
  const deviceForLimit = typeof body.deviceHash === "string" ? body.deviceHash.slice(0, 64) : null;
  const rl = deviceForLimit
    ? rateLimit(`incidents:dev:${deviceForLimit}`, 20, 600_000)
    : rateLimit(`incidents:ip:${ip}`, 60, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  const cityId = String(body.city ?? "dakar");
  const city = CITY_MAP[cityId];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  const axisId = String(body.axisId ?? "");
  const axis = getAxis(city, axisId);
  if (!axis) return NextResponse.json({ error: "Axe inconnu" }, { status: 422 });

  const type = String(body.type ?? "accident");
  if (!INCIDENT_TYPES.includes(type as (typeof INCIDENT_TYPES)[number])) {
    return NextResponse.json({ error: "Type d'incident inconnu" }, { status: 422 });
  }
  const severity = Math.max(1, Math.min(5, Number(body.severity ?? 3) || 3));
  const channel = ["web", "ussd", "whatsapp", "sms"].includes(String(body.channel))
    ? String(body.channel)
    : "web";
  const network = ["orange", "mtn", "moov", "airtel", "web"].includes(String(body.network))
    ? String(body.network)
    : channel === "web"
      ? "web"
      : "orange";
  const deviceHash = typeof body.deviceHash === "string" ? body.deviceHash.slice(0, 64) : null;
  const distinct = body.distinct === true;
  const description = typeof body.description === "string" ? body.description.slice(0, 280) : null;

  await ensureSeed();
  await ensureCitySeed(city);
  try {
    if (!distinct) {
      const windowStart = new Date(Date.now() - 45 * 60_000);
      const similar = await db
        .select()
        .from(incidents)
        .where(
          and(
            eq(incidents.city, cityId),
            eq(incidents.axisId, axisId),
            eq(incidents.type, type),
            gte(incidents.createdAt, windowStart),
          ),
        )
        .orderBy(desc(incidents.createdAt))
        .limit(1);
      if (similar.length > 0) {
        const target = similar[0];
        // Anti-Sybil : une même connexion ne vote qu'une fois par incident,
        // même en faisant tourner les identifiants d'appareil.
        if (hasVoted(ip, target.id)) {
          return NextResponse.json({ merged: true, duplicateNetwork: true, incident: target });
        }
        const prior = await db
          .select()
          .from(incidentConfirmations)
          .where(eq(incidentConfirmations.incidentId, target.id));
        if (!alreadyCounted(prior, network, deviceHash)) {
          await db
            .insert(incidentConfirmations)
            .values({ incidentId: target.id, network, channel, deviceHash });
          markVoted(ip, target.id);
          const updated = await bumpIncident(target.id);
          if (updated.status === "broadcast" && target.status !== "broadcast") {
            emitValidatedAlert(city, updated);
          }
          return NextResponse.json({ merged: true, incident: updated });
        }
        return NextResponse.json({ merged: true, duplicateNetwork: true, incident: target });
      }
    }

    const [created] = await db
      .insert(incidents)
      .values({
        city: cityId,
        axisId,
        type,
        severity,
        channel,
        network,
        description,
        confirmations: 1,
        confidence: 38,
        status: "pending",
      })
      .returning();
    await db
      .insert(incidentConfirmations)
      .values({ incidentId: created.id, network, channel, deviceHash });
    markVoted(ip, created.id);
    return NextResponse.json({ merged: false, incident: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Signalement indisponible" }, { status: 503 });
  }
}
