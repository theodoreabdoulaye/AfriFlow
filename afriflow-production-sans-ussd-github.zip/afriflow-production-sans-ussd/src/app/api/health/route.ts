import { sql } from "drizzle-orm";
import { db } from "@/db";
import { CITY_COUNT, COUNTRY_COUNT } from "@/lib/cities";

export const dynamic = "force-dynamic";

/** Santé du service : connectivité base + latence + périmètre du réseau. */
export async function GET() {
  const started = performance.now();
  let dbOk = false;
  try {
    await db.execute(sql`select 1`);
    dbOk = true;
  } catch {
    dbOk = false;
  }
  return Response.json(
    {
      ok: true,
      version: "5.1.0",
      uptimeSec: Math.round(process.uptime()),
      db: { ok: dbOk, latencyMs: Math.round(performance.now() - started) },
      network: { cities: CITY_COUNT, countries: COUNTRY_COUNT },
    },
    { status: 200 },
  );
}
