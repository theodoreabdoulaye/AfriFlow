import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { count, eq } from "drizzle-orm";
import { db } from "@/db";
import { telemetryPoints } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { getOsmEnrichment, triggerOsmEnrichment } from "@/lib/osm-enrich";

export const dynamic = "force-dynamic";

/**
 * GET /api/osm/graph?city=dakar — graphe routier enrichi par OpenStreetMap
 * (Overpass, instances publiques OSM France en priorité) : pour chaque axe
 * AfriFlow, les attributs RÉELS de la voie OSM correspondante — surface
 * (asphalte/terre/pavé), nombre de voies, vitesse maximale, sens unique —
 * et l'ajustement appliqué par le moteur (surface ≠ asphalte → base −40 %,
 * maxspeed → plafond de vitesse libre). Actualisation en arrière-plan.
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  triggerOsmEnrichment(city);
  const enrichment = getOsmEnrichment(city);

  // Points GPS déjà collectés près des axes (preuve d'activité terrain).
  let gpsPoints = 0;
  try {
    const [row] = await db
      .select({ n: count() })
      .from(telemetryPoints)
      .where(eq(telemetryPoints.city, city.id));
    gpsPoints = row?.n ?? 0;
  } catch {
    gpsPoints = 0;
  }

  const axes = city.axes.map((axis) => {
    const osm = enrichment.byAxis.get(axis.id) ?? null;
    const surfaceFactor =
      osm?.surface && !["asphalt", "paved", "concrete", "asphalt:lanes"].includes(osm.surface) ? 0.6 : 1;
    const effectiveFreeFlowKmh = osm?.maxspeedKmh
      ? Math.min(axis.freeFlowKmh, osm.maxspeedKmh)
      : axis.freeFlowKmh;
    return {
      axisId: axis.id,
      name: axis.name,
      baselineSpeedKmh: axis.freeFlowKmh,
      effectiveFreeFlowKmh,
      osm: osm
        ? {
            wayName: osm.wayName,
            highway: osm.highway,
            surface: osm.surface,
            lanes: osm.lanes,
            maxspeedKmh: osm.maxspeedKmh,
            oneway: osm.oneway,
            surfaceFactor,
            // Attributs INFÉRÉS des tags OSM (absents tels quels d'OSM) :
            inferred: {
              capacityVph: osm.capacityVph,
              floodRisk: osm.floodRisk,
              potholeSeverity: osm.potholeSeverity,
              rules:
                "capacité = base(highway) × voies · inondation : surface non revêtue +0,5, layer<0 +0,3 · nids-de-poule : smoothness/surface",
            },
            adjustment:
              surfaceFactor < 1
                ? "surface non asphaltée → vitesse de base −40 %"
                : osm.maxspeedKmh && osm.maxspeedKmh < axis.freeFlowKmh
                  ? "vitesse libre plafonnée par maxspeed OSM"
                  : "aucun ajustement",
          }
        : null,
    };
  });

  return NextResponse.json({
    city: city.id,
    cityName: city.name,
    source: "OpenStreetMap / Overpass (instances publiques)",
    status: enrichment.status,
    fetchedAt: enrichment.fetchedAt ? new Date(enrichment.fetchedAt).toISOString() : null,
    matchedAxes: enrichment.matchedAxes,
    totalAxes: enrichment.totalAxes,
    gpsPointsCollected: gpsPoints,
    axes,
  }, { headers: { "Cache-Control": "private, no-store" } });
}
