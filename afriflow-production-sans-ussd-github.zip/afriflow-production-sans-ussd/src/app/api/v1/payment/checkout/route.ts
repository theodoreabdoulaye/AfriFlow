import { randomUUID } from "node:crypto";
import { and, eq, isNull, or } from "drizzle-orm";
import { db } from "@/db";
import { paymentOrders } from "@/db/payment-schema";
import { getCurrentUser, requireSameOrigin } from "@/lib/auth";
import { CheckoutError, createCheckout, parseCheckoutInput, PRODUCTS, readPaymentBody } from "@/lib/chariow";
import { clientIp, rateLimit } from "@/lib/rate-limit";

export const runtime = "nodejs";
const headers = { "Cache-Control": "private, no-store" };

export async function POST(req: Request) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Invalid origin" }, { status: 403, headers });
  const ipLimit = rateLimit(`checkout:ip:${clientIp(req)}`, 20, 60_000);
  if (!ipLimit.ok) return Response.json({ error: "Trop de demandes de paiement" }, { status: 429, headers });
  try {
    const user = await getCurrentUser();
    if (!user) return Response.json({ error: "Authentication required" }, { status: 401, headers });
    const limit = rateLimit(`checkout:user:${user.id}`, 5, 60_000);
    if (!limit.ok) return Response.json({ error: "Trop de demandes de paiement" }, { status: 429, headers });
    let body;
    try { body = JSON.parse((await readPaymentBody(req, 4096)).toString("utf8")); } catch (error) {
      return Response.json({ error: "Corps de requete invalide" }, { status: error instanceof RangeError ? 413 : 400, headers });
    }
    const input = parseCheckoutInput(body);
    if (!input) return Response.json({ error: "Expected plan, phone and countryCode only" }, { status: 400, headers });
    if (!process.env.CHARIOW_API_KEY || !process.env.NEXT_PUBLIC_SITE_URL) return Response.json({ error: "Payment service unavailable" }, { status: 503, headers });
    const orderId = randomUUID();
    // Keep pending even on timeout: Chariow may have created a sale already.
    await db.insert(paymentOrders).values({ id: orderId, userId: user.id, plan: input.plan, productId: PRODUCTS[input.plan] });
    let checkout;
    try {
      checkout = await createCheckout({ ...input, orderId, email: user.email, name: user.name });
    } catch (error) {
      if (error instanceof CheckoutError) return Response.json({ error: error.message, code: error.code }, { status: error.status, headers });
      return Response.json({ error: "Payment service unavailable" }, { status: 503, headers });
    }
    // A webhook may already have bound the sale and completed this order.
    const saved = await db.update(paymentOrders).set({ saleId: checkout.saleId })
      .where(and(eq(paymentOrders.id, orderId), or(isNull(paymentOrders.saleId), eq(paymentOrders.saleId, checkout.saleId))))
      .returning({ id: paymentOrders.id });
    if (!saved.length) return Response.json({ error: "Payment reconciliation unavailable" }, { status: 503, headers });
    return Response.json({ checkoutUrl: checkout.checkoutUrl, pending: true }, { headers });
  } catch {
    return Response.json({ error: "Payment service unavailable" }, { status: 503, headers });
  }
}
