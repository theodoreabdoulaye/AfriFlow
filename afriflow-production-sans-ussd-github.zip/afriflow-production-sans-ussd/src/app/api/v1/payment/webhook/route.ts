import { and, desc, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/auth-schema";
import { paymentDeliveries, paymentGrants, paymentOrders } from "@/db/payment-schema";
import { extendExpiry, PRODUCTS, STORE_ORIGIN, verifySignature, readPaymentBody, type Plan } from "@/lib/chariow";

export const runtime = "nodejs";
const headers = { "Cache-Control": "no-store" };

export async function POST(req: Request) {
  const secret = process.env.CHARIOW_WEBHOOK_SECRET;
  if (!secret) return Response.json({ error: "Webhook unavailable" }, { status: 503, headers });
  let raw: Buffer;
  try { raw = await readPaymentBody(req, 524288); } catch (error) {
    return Response.json({ error: "Invalid body" }, { status: error instanceof RangeError ? 413 : 400, headers });
  }
  if (!verifySignature(raw, req.headers.get("x-chariow-signature"), secret)) return Response.json({ error: "Invalid signature" }, { status: 401, headers });
  let payload;
  try { payload = JSON.parse(raw.toString("utf8")); } catch {
    return Response.json({ error: "Invalid payload" }, { status: 400, headers });
  }
  if (!payload || typeof payload !== "object" || Array.isArray(payload)) return Response.json({ error: "Invalid payload" }, { status: 400, headers });
  // Dashboard test bodies are signed too, but must never generate access.
  if (Object.hasOwn(payload, "note") || [payload.sale?.id, payload.product?.id, payload.sale?.custom_metadata?.order_id].some(id => typeof id === "string" && id.startsWith("test_"))) {
    return Response.json({ ignored: true }, { headers });
  }
  if (payload.event !== "successful.sale") return Response.json({ ignored: true }, { headers });
  const saleId = payload.sale?.id;
  const orderId = payload.sale?.custom_metadata?.order_id;
  const productId = payload.product?.id;
  const email = payload.customer?.email;
  const deliveryId = req.headers.get("x-pulse-delivery-id");
  let validStore = false;
  try {
    const store = new URL(payload.store?.url);
    validStore = store.origin === STORE_ORIGIN && !store.username && !store.password;
  } catch { /* Invalid store URLs cannot establish ownership. */ }
  if (!validStore || payload.sale?.status !== "completed" || typeof saleId !== "string" || !/^sal_[A-Za-z0-9]+$/.test(saleId) || typeof orderId !== "string" || !/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(orderId) || !Object.values(PRODUCTS).includes(productId) || typeof email !== "string" || !deliveryId || deliveryId.length > 255) {
    return Response.json({ error: "Invalid sale" }, { status: 400, headers });
  }
  try {
    const accepted = await db.transaction(async tx => {
      const [order] = await tx.select().from(paymentOrders).where(eq(paymentOrders.id, orderId)).for("update");
      if (!order || order.productId !== productId || !Object.hasOwn(PRODUCTS, order.plan) || PRODUCTS[order.plan as Plan] !== productId || (order.saleId !== null && order.saleId !== saleId)) return false;
      // User lock serializes different orders renewing the same account.
      const [user] = await tx.select({ id: users.id, email: users.email }).from(users).where(eq(users.id, order.userId)).for("update");
      if (!user || user.email.toLowerCase() !== email.toLowerCase()) return false;
      const [delivery] = await tx.select().from(paymentDeliveries).where(eq(paymentDeliveries.id, deliveryId));
      if (delivery) return delivery.saleId === saleId;
      const [existing] = await tx.select().from(paymentGrants).where(eq(paymentGrants.saleId, saleId));
      if (existing) {
        if (existing.userId !== user.id || order.status !== "completed" || order.saleId !== saleId) return false;
      } else {
        if (order.status !== "pending") return false;
        const now = new Date();
        // Future queued renewals count toward the end of the paid access chain.
        const [latest] = await tx.select({ expiresAt: paymentGrants.expiresAt }).from(paymentGrants)
          .where(and(eq(paymentGrants.userId, user.id), eq(paymentGrants.revoked, false), gt(paymentGrants.expiresAt, now)))
          .orderBy(desc(paymentGrants.expiresAt)).limit(1);
        const duration = extendExpiry(order.plan as Plan, now, latest?.expiresAt ?? null);
        await tx.insert(paymentGrants).values({ saleId, userId: user.id, ...duration });
        await tx.update(paymentOrders).set({ saleId, status: "completed" }).where(eq(paymentOrders.id, order.id));
      }
      // Unsigned delivery IDs alone cannot mint access: the signed sale is unique.
      await tx.insert(paymentDeliveries).values({ id: deliveryId, saleId });
      return true;
    });
    if (!accepted) return Response.json({ error: "Sale does not match an order" }, { status: 400, headers });
    return Response.json({ received: true }, { headers });
  } catch {
    // Acknowledge only after COMMIT, so provider retries database failures.
    return Response.json({ error: "Payment processing unavailable" }, { status: 503, headers });
  }
}
