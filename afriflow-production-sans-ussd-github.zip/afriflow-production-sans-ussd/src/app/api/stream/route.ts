import { NextRequest } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { CITY_MAP } from "@/lib/cities";
import type { HeatmapPayload } from "@/lib/api-types";
import { buildHeatmap } from "@/lib/server-data";
import { ensureCitySeed, ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";
export const maxDuration = 60;

interface AxisSnapshot {
  speedKmh: number;
  fluidity: number;
  level: string;
  dataSource: string;
}

/**
 * GET /api/stream?city=dakar — flux temps réel (Server-Sent Events).
 * Premier évènement : la carte complète (event: heatmap). Ensuite, seuls
 * les DELTAS sont envoyés (event: delta) : axes dont la vitesse, la
 * fluidité, le niveau ou la provenance ont changé — payload typiquement
 * 10 à 30× plus léger, pensé pour la 3G/Edge et la data comptée.
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const deadline = Date.now() + 50_000;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) {
    return new Response(JSON.stringify({ error: "Ville inconnue" }), {
      status: 404,
      headers: { "Content-Type": "application/json", "Cache-Control": "private, no-store" },
    });
  }
  await ensureSeed();
  await ensureCitySeed(city);

  const encoder = new TextEncoder();
  let closed = false;
  let tick: ReturnType<typeof setInterval> | null = null;
  let beat: ReturnType<typeof setInterval> | null = null;
  let timeout: ReturnType<typeof setTimeout> | null = null;
  let sending = false;
  let close: (() => void) | null = null;
  let previous: Map<string, AxisSnapshot> | null = null;
  let previousIndex: number | null = null;

  const cleanup = () => {
    closed = true;
    if (tick) clearInterval(tick);
    if (beat) clearInterval(beat);
    if (timeout) clearTimeout(timeout);
    req.signal.removeEventListener("abort", onAbort);
  };
  const onAbort = () => close?.();

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      close = () => {
        if (closed) return;
        cleanup();
        try {
          controller.close();
        } catch {
          /* déjà fermé */
        }
      };
      req.signal.addEventListener("abort", onAbort, { once: true });
      if (req.signal.aborted || Date.now() >= deadline) {
        close();
        return;
      }
      timeout = setTimeout(close, Math.max(0, deadline - Date.now()));
      const send = async () => {
        if (closed || sending) return;
        sending = true;
        try {
          if (await requirePaidAccess()) {
            close?.();
            return;
          }
          if (closed) return;
          const payload: HeatmapPayload = await buildHeatmap(city);
          if (await requirePaidAccess()) {
            close?.();
            return;
          }
          if (closed) return;
          if (!previous) {
            controller.enqueue(encoder.encode(`event: heatmap\ndata: ${JSON.stringify(payload)}\n\n`));
          } else {
            const changed = payload.axes
              .filter((a) => {
                const p = previous!.get(a.axisId);
                return (
                  !p ||
                  Math.abs(p.speedKmh - a.speedKmh) >= 0.5 ||
                  Math.abs(p.fluidity - a.fluidity) >= 1 ||
                  p.level !== a.level ||
                  p.dataSource !== a.dataSource
                );
              })
              .map((a) => ({
                axisId: a.axisId,
                speedKmh: a.speedKmh,
                fluidity: a.fluidity,
                level: a.level,
                vehiclesTracked: a.vehiclesTracked,
                measured: a.measured,
                dataSource: a.dataSource,
                simulated: a.simulated,
              }));
            const indexChanged = previousIndex !== payload.summary.index;
            if (changed.length > 0 || indexChanged) {
              controller.enqueue(
                encoder.encode(
                  `event: delta\ndata: ${JSON.stringify({
                    city: payload.city,
                    at: payload.at,
                    cityTime: payload.cityTime,
                    changed,
                    ...(indexChanged ? { summary: payload.summary, dataCoverage: payload.dataCoverage } : {}),
                  })}\n\n`,
                ),
              );
            }
          }
          previous = new Map(
            payload.axes.map((a) => [
              a.axisId,
              { speedKmh: a.speedKmh, fluidity: a.fluidity, level: a.level, dataSource: a.dataSource },
            ]),
          );
          previousIndex = payload.summary.index;
        } catch {
          /* on réessaiera au prochain cycle */
        } finally {
          sending = false;
        }
      };
      void send();
      tick = setInterval(() => void send(), 15_000);
      beat = setInterval(() => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(`: heartbeat ${Date.now()}\n\n`));
        } catch {
          close?.();
        }
      }, 25_000);
    },
    cancel() {
      cleanup();
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "private, no-store, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
