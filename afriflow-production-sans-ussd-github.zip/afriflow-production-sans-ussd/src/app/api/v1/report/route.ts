import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP } from "@/lib/cities";
import { CROWD_SOURCES, ingestCrowdReport, type CrowdSource } from "@/lib/crowd";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { ensureCitySeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/report — ingestion de signalements crowdsourcés
 * (portée du prototype Rust/axum `ingest_crowd_report`).
 *
 * Corps : { source: "ussd" | "whatsapp" | "waze_webhook" | "scraper_facebook",
 *           city?, lat, lon, incident_type: "accident" | "police" |
 *           "inondation" | "nid_de_poule" | "bouchon" | "travaux" | "panne",
 *           confidence_score: 1..10, reporter? }
 *
 * 1. Map matching sur l'axe le plus proche (index spatial grille).
 * 2. Consensus pondéré : 3 signalements distincts en 10 min OU score
 *    cumulé ≥ 20 → incident validé et diffusé.
 * 3. L'incident validé met à jour l'état du trafic de l'axe (ralentissement).
 *
 * Réponse 202 : { accepted, edge_id, edge_name, merged, validated, status }
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`v1report:${clientIp(req)}`, 120, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;

  const source = String(body.source ?? "") as CrowdSource;
  if (!CROWD_SOURCES.includes(source)) {
    return NextResponse.json(
      { error: `source invalide — valeurs acceptées : ${CROWD_SOURCES.join(", ")}` },
      { status: 422 },
    );
  }
  const lat = Number(body.lat);
  const lon = Number(body.lon);
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return NextResponse.json({ error: "lat/lon invalides" }, { status: 422 });
  }

  // Ville : explicite, sinon la plus proche du point parmi les villes actives.
  let city = CITY_MAP[String(body.city ?? "")];
  if (!city) {
    let bestDist = Infinity;
    for (const c of Object.values(CITY_MAP)) {
      const d = Math.hypot(c.lat - lat, c.lon - lon);
      if (d < bestDist) {
        bestDist = d;
        city = c;
      }
    }
    if (!city || bestDist > 1.5) {
      return NextResponse.json({ error: "Aucune ville AfriFlow à proximité de ce point" }, { status: 422 });
    }
  }

  await ensureCitySeed(city);
  try {
    const result = await ingestCrowdReport(city, {
      source,
      lat,
      lon,
      incidentType: String(body.incident_type ?? "bouchon"),
      confidenceScore: Number(body.confidence_score ?? 5),
      reporterKey: typeof body.reporter === "string" ? body.reporter : null,
      severity: Number.isFinite(Number(body.severity)) ? Number(body.severity) : undefined,
    });
    if (!result) {
      return NextResponse.json({ error: "Map matching impossible pour ce point" }, { status: 422 });
    }
    return NextResponse.json(
      {
        accepted: true,
        city: city.id,
        edge_id: result.axisId,
        edge_name: result.axisName,
        merged: result.merged,
        validated: result.validated,
        status: result.incident.status,
        confirmations: result.incident.confirmations,
        confidence: result.incident.confidence,
        score_total: result.scoreTotal,
        consensus: "3 signalements distincts en 10 min OU score cumulé ≥ 20",
      },
      { status: 202 },
    );
  } catch {
    return NextResponse.json({ error: "Ingestion indisponible" }, { status: 503 });
  }
}
