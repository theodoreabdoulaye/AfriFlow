"use client";

import * as Sentry from "@sentry/nextjs";
import { useEffect } from "react";

/** Dernier rempart : capture l'erreur dans Sentry et propose un retour sûr. */
export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    Sentry.captureException(error);
  }, [error]);

  return (
    <html lang="fr">
      <body
        style={{
          background: "#060f0a",
          color: "#e9f6ee",
          fontFamily: "system-ui, sans-serif",
          display: "grid",
          placeItems: "center",
          minHeight: "100vh",
          margin: 0,
          padding: 24,
        }}
      >
        <div style={{ maxWidth: 480, textAlign: "center" }}>
          <p style={{ fontSize: 40, margin: 0 }}>🧭</p>
          <h1 style={{ fontSize: 22, marginTop: 12 }}>AfriFlow a rencontré un souci</h1>
          <p style={{ color: "#9dbfab", fontSize: 14, lineHeight: 1.6 }}>
            L&apos;erreur a été signalée à notre équipe. Le trafic continue d&apos;être surveillé —
            réessayez dans un instant.
          </p>
          <button
            onClick={reset}
            style={{
              marginTop: 16,
              background: "#22b573",
              color: "#04140a",
              border: 0,
              borderRadius: 12,
              padding: "10px 18px",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            Réessayer
          </button>
        </div>
      </body>
    </html>
  );
}
