import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { and, desc, eq, gt, sql } from "drizzle-orm";
import { db } from "@/db";
import { carpoolBookings, carpoolOffers } from "@/db/schema";
import { CITY_MAP, getZone } from "@/lib/cities";
import { ratingAggregates, recordRating } from "@/lib/carpool-decisions";
import { matchCarpoolOffers } from "@/lib/multimodal";
import { sendWhatsAppText } from "@/lib/wa-sender";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { zoneLatLon } from "@/lib/transit";

export const dynamic = "force-dynamic";

async function activeOffers(cityId: string) {
  const since = new Date(Date.now() - 2 * 3600_000);
  try {
    return await db
      .select()
      .from(carpoolOffers)
      .where(
        and(
          eq(carpoolOffers.city, cityId),
          eq(carpoolOffers.status, "active"),
          gt(carpoolOffers.departureTime, since),
        ),
      )
      .orderBy(desc(carpoolOffers.departureTime))
      .limit(100);
  } catch {
    return [];
  }
}

/** GET /api/carpool?city=dakar — offres de covoiturage actives de la ville. */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const offers = await activeOffers(city.id);
  const aggregates = await ratingAggregates(offers.map((o) => o.driverPhone));
  return NextResponse.json({
    city: city.id,
    offers: offers.map((o) => ({
      ...o,
      seatsLeft: o.seatsTotal - o.seatsTaken,
      driverPhone: undefined, // jamais exposé dans les listes publiques
      driverRating: aggregates.get(o.driverPhone) ?? { average: null, count: 0 },
    })),
  }, { headers: { "Cache-Control": "private, no-store" } });
}

interface PointInput {
  lat?: number;
  lon?: number;
  zone?: string;
  label?: string;
}

function resolvePoint(
  city: (typeof CITY_MAP)[string],
  input: PointInput | undefined,
): { lat: number; lon: number; label: string } | null {
  if (!input) return null;
  if (typeof input.lat === "number" && typeof input.lon === "number") {
    return { lat: input.lat, lon: input.lon, label: input.label ?? "Point indiqué" };
  }
  if (input.zone) {
    const coords = zoneLatLon(city, input.zone);
    if (!coords) return null;
    return { lat: coords[0], lon: coords[1], label: getZone(city, input.zone)?.name ?? input.zone };
  }
  return null;
}

/**
 * POST /api/carpool — actions covoiturage :
 *  { action: "publish", ... }  publier une offre (conducteur) ;
 *  { action: "match", ... }    chercher les offres compatibles (passager) ;
 *  { action: "book", ... }     réserver des places sur une offre.
 */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`carpool:${clientIp(req)}`, 60, 600_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  const body = raw as Record<string, unknown>;
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const action = String(body.action ?? "");

  if (action === "publish") {
    const from = resolvePoint(city, body.from as PointInput);
    const to = resolvePoint(city, body.to as PointInput);
    const driverName = String(body.driverName ?? "").trim().slice(0, 60);
    const driverPhone = String(body.driverPhone ?? "").trim().slice(0, 24);
    const departure = new Date(String(body.departureTime ?? ""));
    const seats = Math.max(1, Math.min(8, Number(body.seats ?? 3) || 3));
    const price = Math.max(0, Math.min(10000, Number(body.pricePerSeatFcfa ?? 500) || 500));
    if (!from || !to || driverName.length < 2 || driverPhone.replace(/[^\d]/g, "").length < 8) {
      return NextResponse.json(
        { error: "Conducteur, téléphone valide, départ et arrivée requis." },
        { status: 422, headers: { "Cache-Control": "private, no-store" } },
      );
    }
    if (Number.isNaN(departure.getTime()) || departure.getTime() < Date.now() - 3600_000) {
      return NextResponse.json({ error: "Heure de départ invalide ou passée." }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
    }
    try {
      const [created] = await db
        .insert(carpoolOffers)
        .values({
          city: city.id,
          driverName,
          driverPhone,
          fromLat: from.lat,
          fromLon: from.lon,
          toLat: to.lat,
          toLon: to.lon,
          fromLabel: from.label,
          toLabel: to.label,
          departureTime: departure,
          seatsTotal: seats,
          seatsTaken: 0,
          pricePerSeatFcfa: price,
          vehicleType: String(body.vehicleType ?? "Berline").slice(0, 30),
          status: "active",
        })
        .returning();
      return NextResponse.json({ offer: { ...created, driverPhone: undefined } }, { status: 201, headers: { "Cache-Control": "private, no-store" } });
    } catch {
      return NextResponse.json({ error: "Publication indisponible" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
    }
  }

  if (action === "match") {
    const from = resolvePoint(city, body.from as PointInput);
    const to = resolvePoint(city, body.to as PointInput);
    if (!from || !to) {
      return NextResponse.json({ error: "Départ et arrivée requis" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
    }
    const desired = body.desiredDeparture ? new Date(String(body.desiredDeparture)) : new Date();
    const offers = await activeOffers(city.id);
    const matches = matchCarpoolOffers(
      offers.map((o) => ({
        id: o.id,
        driverName: o.driverName,
        fromLat: o.fromLat,
        fromLon: o.fromLon,
        toLat: o.toLat,
        toLon: o.toLon,
        fromLabel: o.fromLabel,
        toLabel: o.toLabel,
        departureTime: o.departureTime,
        seatsTotal: o.seatsTotal,
        seatsTaken: o.seatsTaken,
        pricePerSeatFcfa: o.pricePerSeatFcfa,
        vehicleType: o.vehicleType,
      })),
      {
        fromLat: from.lat,
        fromLon: from.lon,
        toLat: to.lat,
        toLon: to.lon,
        desiredDeparture: Number.isNaN(desired.getTime()) ? new Date() : desired,
        maxPriceFcfa: Math.max(0, Number(body.maxPriceFcfa ?? 2000) || 2000),
      },
    );
    return NextResponse.json({
      matches: matches.map((m) => ({
        ...m,
        offer: { ...m.offer, departureTime: new Date(m.offer.departureTime).toISOString() },
      })),
    }, { headers: { "Cache-Control": "private, no-store" } });
  }

  if (action === "book") {
    const offerId = Number(body.offerId);
    const passengerName = String(body.passengerName ?? "").trim().slice(0, 60);
    const passengerPhone = String(body.passengerPhone ?? "").trim().slice(0, 24);
    const seats = Math.max(1, Math.min(6, Number(body.seats ?? 1) || 1));
    if (!Number.isFinite(offerId) || passengerName.length < 2 || passengerPhone.replace(/[^\d]/g, "").length < 8) {
      return NextResponse.json(
        { error: "Offre, nom et téléphone du passager requis." },
        { status: 422, headers: { "Cache-Control": "private, no-store" } },
      );
    }
    try {
      const [offer] = await db
        .select()
        .from(carpoolOffers)
        .where(eq(carpoolOffers.id, offerId))
        .limit(1);
      if (!offer || offer.status !== "active") {
        return NextResponse.json({ error: "Offre complète ou introuvable." }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
      }
      if (offer.seatsTaken + seats > offer.seatsTotal) {
        return NextResponse.json(
          { error: "Plus assez de places sur cette offre — choisissez-en une autre." },
          { status: 409, headers: { "Cache-Control": "private, no-store" } },
        );
      }
      // Demande EN ATTENTE : le conducteur accepte (OUI) ou refuse (NON)
      // en répondant simplement sur WhatsApp. La place n'est bloquée
      // qu'à l'acceptation.
      const [booking] = await db
        .insert(carpoolBookings)
        .values({ offerId, passengerName, passengerPhone, seats, status: "pending" })
        .returning();
      const when = new Date(offer.departureTime).toLocaleString("fr-FR", {
        day: "2-digit",
        month: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      });
      const notified = await sendWhatsAppText(
        offer.driverPhone,
        `🚗 Nouvelle demande de covoiturage AfriFlow !\n${passengerName} veut ${seats} place(s) : ${offer.fromLabel} → ${offer.toLabel}, départ ${when}, ${offer.pricePerSeatFcfa} F/pers.\nRépondez *OUI* pour accepter ou *NON* pour refuser.`,
      );
      return NextResponse.json(
        {
          booking,
          offer: { ...offer, driverPhone: undefined },
          driverNotified: notified,
          message: notified
            ? `Demande envoyée à ${offer.driverName} sur WhatsApp — il peut accepter en répondant OUI. Vous serez prévenu dès sa réponse.`
            : `Demande enregistrée (en attente). Le conducteur sera notifié dès que le canal WhatsApp est actif ; sa réponse OUI/NON confirmera automatiquement.`,
        },
        { status: 201, headers: { "Cache-Control": "private, no-store" } },
      );
    } catch {
      return NextResponse.json({ error: "Réservation indisponible" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
    }
  }

  if (action === "rate") {
    const bookingId = Number(body.bookingId);
    const raterPhone = String(body.raterPhone ?? "").trim().slice(0, 24);
    const stars = Number(body.stars);
    if (!Number.isFinite(bookingId) || raterPhone.replace(/[^\d]/g, "").length < 8) {
      return NextResponse.json(
        { error: "Réservation et téléphone du noteur requis." },
        { status: 422, headers: { "Cache-Control": "private, no-store" } },
      );
    }
    const outcome = await recordRating({
      bookingId,
      raterPhone,
      stars,
      comment: typeof body.comment === "string" ? body.comment.slice(0, 280) : null,
    });
    if (!outcome.ok) {
      return NextResponse.json({ error: outcome.message }, { status: 409, headers: { "Cache-Control": "private, no-store" } });
    }
    return NextResponse.json(outcome, { status: 201, headers: { "Cache-Control": "private, no-store" } });
  }

  return NextResponse.json({ error: "Action inconnue (publish | match | book)" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
}
