import { handleAuth } from "@/lib/auth";

export const runtime = "nodejs";
export async function GET(req: Request) { return handleAuth(req, "me"); }
