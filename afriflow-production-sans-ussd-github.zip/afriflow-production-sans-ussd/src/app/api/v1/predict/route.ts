import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { and, count, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { incidents } from "@/db/schema";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { clamp } from "@/lib/engine";
import { ephemeralWeights, loadWeights } from "@/lib/learning";
import { buildHeatmap } from "@/lib/server-data";

export const dynamic = "force-dynamic";

/**
 * GET /api/v1/predict?city=dakar&axis=vdn — prédiction HONNÊTE pour un axe
 * (porté du MLEngine Rust) :
 * - si des poids persistés existent pour l'axe : prédiction du modèle
 *   corrigé entraîné, confiance = précision holdout + volume (plafonnée
 *   par l'erreur relative — jamais 98/100 avec une grosse erreur) ;
 * - sinon, s'il existe des observations : poids éphémères calculés en
 *   direct sur les 50 dernières observations ;
 * - sinon : repli historique, confiance 20 (aucune donnée).
 */
export async function GET(req: NextRequest) {
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });
  const axisId = req.nextUrl.searchParams.get("axis") ?? req.nextUrl.searchParams.get("edge_id");
  if (!axisId || !getAxis(city, axisId)) {
    return NextResponse.json({ error: "Axe inconnu — précisez ?axis=<id d'axe de la ville>" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }
  const axisDef = getAxis(city, axisId)!;
  const heat = await buildHeatmap(city);
  const axis = heat.axes.find((a) => a.axisId === axisId);
  if (!axis) return NextResponse.json({ error: "Axe introuvable dans la carte" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  const base = {
    city: city.id,
    edge_id: axis.axisId,
    edge_name: axis.name,
    baseline_speed_kmh: axisDef.freeFlowKmh,
    rain_mm: heat.weather.precipMm ?? 0,
    data_source: axis.dataSource,
    learned_samples: axis.learnedSamples,
  };

  // 1) Poids persistés : la réponse du modèle entraîné (via la carte).
  const weights = await loadWeights(city);
  if (weights.has(axisId)) {
    return NextResponse.json({
      ...base,
      predicted_speed_kmh: Math.round(axis.speedKmh * 10) / 10,
      predicted_in_30min: axis.prediction.in30,
      confidence_score: axis.prediction.confidence30,
      confidence_label: axis.prediction.confidenceLabel,
      reason: axis.prediction.confidenceReason,
      model: "poids persistés (entraînés)",
    }, { headers: { "Cache-Control": "private, no-store" } });
  }

  // 2) Observations présentes mais pas encore de poids persistés :
  //    calcul éphémère en direct (50 dernières observations de l'axe).
  const { weights: ephemeral, count: obsCount } = await ephemeralWeights(city, axisId);
  if (ephemeral) {
    const twoHoursAgo = new Date(Date.now() - 2 * 3600_000);
    const [rep] = await db
      .select({ n: count() })
      .from(incidents)
      .where(
        and(
          eq(incidents.city, city.id),
          eq(incidents.axisId, axisId),
          eq(incidents.status, "broadcast"),
          gte(incidents.createdAt, twoHoursAgo),
        ),
      );
    const reports = rep?.n ?? 0;
    const predicted = clamp(
      axisDef.freeFlowKmh * ephemeral.intercept -
        (heat.weather.precipMm ?? 0) * ephemeral.rainPenalty -
        reports * ephemeral.reportPenalty,
      5,
      axisDef.freeFlowKmh * 1.2,
    );
    const errorRatio = Math.min(1, ephemeral.holdoutMae / Math.max(10, axisDef.freeFlowKmh));
    const accuracy = Math.floor((1 - errorRatio) * 100);
    const dataScore = Math.min(30, Math.floor(Math.log(Math.max(1, obsCount)) * 15));
    const relError = ephemeral.holdoutMae / Math.max(10, axisDef.freeFlowKmh);
    const ceiling = relError > 0.2 ? 65 : relError > 0.12 ? 79 : relError > 0.08 ? 89 : 100;
    const confidence = Math.min(100, accuracy + dataScore, ceiling);
    return NextResponse.json({
      ...base,
      predicted_speed_kmh: Math.round(predicted * 10) / 10,
      predicted_in_30min: axis.prediction.in30,
      confidence_score: confidence,
      confidence_label:
        confidence >= 80
          ? "Réel (Données terrain)"
          : confidence >= 50
            ? "Estimation fiable (Modèle appris)"
            : "Estimation faible (Peu de données)",
      reason: `Poids éphémères (non persistés) calculés sur ${obsCount} observations. Erreur moyenne: ${ephemeral.holdoutMae.toFixed(1)} km/h`,
      model: "poids éphémères (direct)",
    }, { headers: { "Cache-Control": "private, no-store" } });
  }

  // 3) Aucune donnée : repli historique, confiance minimale (design Rust).
  return NextResponse.json({
    ...base,
    predicted_speed_kmh: Math.round(axis.speedKmh * 10) / 10,
    predicted_in_30min: axis.prediction.in30,
    confidence_score: 20,
    confidence_label: "Estimation historique (en attente de données)",
    reason: "Aucune donnée GPS ou signalement reçu sur cet axe.",
    model: "historique (aucune observation)",
  }, { headers: { "Cache-Control": "private, no-store" } });
}
