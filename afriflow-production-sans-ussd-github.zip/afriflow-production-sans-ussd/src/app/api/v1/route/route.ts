import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { CITY_MAP, getZone } from "@/lib/cities";
import { findRoutes, type RoutePriorities, type VehicleProfile } from "@/lib/engine";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { getRoadEdgeGeometries, syncRoadEdges } from "@/lib/road-edges";
import { buildHeatmap, quotaGrantsLastHour } from "@/lib/server-data";
import { nearestAxisFast } from "@/lib/spatial";
import { fetchWeather } from "@/lib/weather";

export const dynamic = "force-dynamic";

/**
 * POST /api/v1/route — itinéraire ventilé depuis des coordonnées GPS
 * (porté de l'endpoint axum du design PostGIS) :
 *   { start_lat, start_lon, end_lat, end_lon, is_raining?,
 *     profile?: "standard" | "gbaka" | "urgence", city? }
 *
 * 1. Map matching des deux points sur les arêtes les plus proches
 *    (index spatial grille — équivalent KNN PostGIS `<->`).
 * 2. Routage A* ventilé (coût généralisé × M_quota) entre les zones.
 * 3. Réponse : edge_ids, eta_minutes, geometries (GeoJSON LineString
 *    depuis la couche road_edges), ventilation_reason, alternatives.
 */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`v1route:${clientIp(req)}`, 120, 60_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400, headers: { "Cache-Control": "private, no-store" } });
  }
  const body = raw as Record<string, unknown>;

  const startLat = Number(body.start_lat);
  const startLon = Number(body.start_lon);
  const endLat = Number(body.end_lat);
  const endLon = Number(body.end_lon);
  const coordsOk = [startLat, startLon, endLat, endLon].every(
    (v, i) => Number.isFinite(v) && (i % 2 === 0 ? Math.abs(v) <= 90 : Math.abs(v) <= 180),
  );
  if (!coordsOk) {
    return NextResponse.json({ error: "Coordonnées start/end invalides" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }

  // Ville : explicite ou la plus proche du point de départ.
  let city = CITY_MAP[String(body.city ?? "")];
  if (!city) {
    let bestDist = Infinity;
    for (const c of Object.values(CITY_MAP)) {
      const d = Math.hypot(c.lat - startLat, c.lon - startLon);
      if (d < bestDist) {
        bestDist = d;
        city = c;
      }
    }
    if (!city || bestDist > 1.5) {
      return NextResponse.json({ error: "Aucune ville AfriFlow à proximité du départ" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
    }
  }

  // 1. Map matching (index spatial) départ / arrivée.
  const startMatch = nearestAxisFast(city, startLat, startLon, 3000);
  const endMatch = nearestAxisFast(city, endLat, endLon, 3000);
  if (!startMatch || !endMatch) {
    return NextResponse.json(
      { error: "Points de départ/arrivée trop éloignés d'un axe surveillé (> 3 km)" },
      { status: 422, headers: { "Cache-Control": "private, no-store" } },
    );
  }
  const nearestZone = (match: typeof startMatch, lat: number, lon: number): string => {
    const axis = match.axis;
    const dFrom = Math.hypot(axis.gps[0][0] - lat, axis.gps[0][1] - lon);
    const dTo = Math.hypot(axis.gps[axis.gps.length - 1][0] - lat, axis.gps[axis.gps.length - 1][1] - lon);
    return dFrom <= dTo ? axis.from : axis.to;
  };
  const fromZone = nearestZone(startMatch, startLat, startLon);
  const toZone = nearestZone(endMatch, endLat, endLon);
  if (fromZone === toZone) {
    return NextResponse.json(
      { error: "Départ et arrivée sont rattachés à la même zone — précisez deux lieux distincts." },
      { status: 422, headers: { "Cache-Control": "private, no-store" } },
    );
  }

  syncRoadEdges(city);

  // 2. État du trafic + météo (pluie forcée si is_raining est signalé).
  const realWeather = await fetchWeather(city);
  const weather =
    body.is_raining === true && realWeather.level === 0
      ? { ...realWeather, level: 1 as const, label: "Pluie (signalée)" }
      : realWeather;
  const heat = await buildHeatmap(city, { weatherOverride: weather });
  const grantedByAxis = await quotaGrantsLastHour(city.id);

  const prio: RoutePriorities = { time: true, fuel: true, safety: false, practicability: true };
  const profile: VehicleProfile =
    body.profile === "gbaka" || body.profile === "urgence" ? body.profile : "standard";
  const routes = findRoutes(city, heat.axes, fromZone, toZone, prio, weather, { grantedByAxis }, new Date(), profile);
  if (routes.length === 0) {
    return NextResponse.json({ error: "Aucun itinéraire ventilé entre ces deux points" }, { status: 422, headers: { "Cache-Control": "private, no-store" } });
  }
  const best = routes.find((r) => r.status === "recommande") ?? routes[0];
  const edgeIds = best.legs.map((l) => l.axisId);
  const geometries = await getRoadEdgeGeometries(city, edgeIds);

  return NextResponse.json({
    city: city.id,
    start: {
      edge_id: startMatch.axis.id,
      zone: fromZone,
      zone_name: getZone(city, fromZone)?.name ?? fromZone,
      distance_m: startMatch.distanceM,
    },
    end: {
      edge_id: endMatch.axis.id,
      zone: toZone,
      zone_name: getZone(city, toZone)?.name ?? toZone,
      distance_m: endMatch.distanceM,
    },
    route: {
      edge_ids: edgeIds,
      eta_minutes: best.minutes,
      distance_km: best.distanceKm,
      fuel_fcfa: best.fuelFcfa,
      max_load_pct: best.maxLoadPct,
      reason: best.kind === "principal" ? "Itinéraire principal" : "Itinéraire ventilé",
      ventilation_reason: best.explanation,
      geometries,
    },
    alternatives: routes
      .filter((r) => r.id !== best.id)
      .map((r) => ({
        name: r.label,
        eta_minutes: r.minutes,
        max_load_pct: r.maxLoadPct,
        status: r.status,
        warning:
          r.maxLoadPct >= 80
            ? `⚠️ Axe à ${r.maxLoadPct} % de saturation`
            : r.status === "zone-protegee"
              ? "⚠️ Zone protégée saturée — délestage interdit"
              : r.status === "quota-plein"
                ? "⚠️ Quota de délestage atteint"
                : null,
        edge_ids: r.legs.map((l) => l.axisId),
      })),
  }, { headers: { "Cache-Control": "private, no-store" } });
}
