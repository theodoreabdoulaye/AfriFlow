import { NextRequest, NextResponse } from "next/server";
import { and, desc, eq, gte, isNotNull } from "drizzle-orm";
import { db } from "@/db";
import { telemetryPoints } from "@/db/schema";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { jsonCached } from "@/lib/http-cache";
import { clamp, learnedFactorAt, modelSpeed, profileFactor, type WeatherInfo } from "@/lib/engine";
import { getLastEvaluation, loadProfiles, modelVersion } from "@/lib/learning";
import { fetchWeather } from "@/lib/weather";

export const dynamic = "force-dynamic";

const cache = new Map<string, { at: number; payload: Record<string, unknown> }>();
const CACHE_MS = 5 * 60_000;

interface GpsValidation {
  samples: number;
  /** Erreur du profil historique générique (km/h). */
  maeKmh: number;
  within5KmhPct: number;
  /** Erreur du modèle entraîné (profils appris), null si pas encore entraîné. */
  maeLearnedKmh: number | null;
  within5LearnedPct: number | null;
  improvementPct: number | null;
  periodDays: number;
}

/**
 * Validation TERRAIN : pour chaque point GPS réel reçu (7 derniers jours),
 * on compare la vitesse prédite par le profil horaire appris de l'axe à la
 * vitesse réellement mesurée par l'appareil du conducteur.
 */
async function validateOnRealGps(cityId: string, tzOffsetMin: number): Promise<GpsValidation | null> {
  try {
    const city = CITY_MAP[cityId];
    const since = new Date(Date.now() - 7 * 24 * 3600_000);
    const rows = await db
      .select()
      .from(telemetryPoints)
      .where(
        and(
          eq(telemetryPoints.city, cityId),
          isNotNull(telemetryPoints.axisId),
          gte(telemetryPoints.createdAt, since),
        ),
      )
      .orderBy(desc(telemetryPoints.createdAt))
      .limit(4000);
    const profiles = await loadProfiles(city);
    const errors: number[] = [];
    const errorsLearned: number[] = [];
    for (const p of rows) {
      if (!p.axisId) continue;
      const axis = getAxis(city, p.axisId);
      if (!axis) continue;
      // Instant local de la ville au moment du ping (profils en heure locale).
      const localInstant = new Date(new Date(p.createdAt).getTime() + tzOffsetMin * 60_000);
      const genericKmh = axis.freeFlowKmh * profileFactor(axis, localInstant);
      errors.push(Math.abs(genericKmh - p.speedKmh));
      const profile = profiles.get(p.axisId);
      const learned = learnedFactorAt(profile, localInstant);
      if (learned !== null && profile) {
        const w = clamp(profile.samples / 48, 0, 0.8);
        const learnedKmh = axis.freeFlowKmh * ((1 - w) * profileFactor(axis, localInstant) + w * learned);
        errorsLearned.push(Math.abs(learnedKmh - p.speedKmh));
      }
    }
    if (errors.length === 0) return null;
    const mae = errors.reduce((a, b) => a + b, 0) / errors.length;
    const within5 = (errors.filter((e) => e <= 5).length / errors.length) * 100;
    const maeLearned =
      errorsLearned.length >= 5
        ? Math.round((errorsLearned.reduce((a, b) => a + b, 0) / errorsLearned.length) * 10) / 10
        : null;
    const within5Learned =
      errorsLearned.length >= 5
        ? Math.round((errorsLearned.filter((e) => e <= 5).length / errorsLearned.length) * 100)
        : null;
    return {
      samples: errors.length,
      maeKmh: Math.round(mae * 10) / 10,
      within5KmhPct: Math.round(within5),
      maeLearnedKmh: maeLearned,
      within5LearnedPct: within5Learned,
      improvementPct:
        maeLearned !== null && mae > 0 ? Math.round((1 - maeLearned / mae) * 100) : null,
      periodDays: 7,
    };
  } catch {
    return null;
  }
}

/**
 * GET /api/model/metrics?city=dakar
 * 1) gpsValidation — vérité terrain sur les points GPS réels des conducteurs.
 * 2) coherence — AUTO-TEST interne (le modèle comparé à lui-même sur 24 h) :
 *    il mesure la stabilité des profils, PAS une exactitude terrain.
 */
export async function GET(req: NextRequest) {
  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  const cached = cache.get(city.id);
  if (cached && Date.now() - cached.at < CACHE_MS && cached.at >= modelVersion()) {
    return jsonCached(req, cached.payload, 240, 300);
  }

  const weather: WeatherInfo = await fetchWeather(city);
  const now = Date.now();
  const horizons = [15, 30, 60] as const;
  const errors: Record<number, number[]> = { 15: [], 30: [], 60: [] };

  for (let step = 0; step <= 48; step++) {
    const t = new Date(now - (48 - step) * 30 * 60_000);
    for (const axis of city.axes) {
      for (const h of horizons) {
        const target = new Date(t.getTime() + h * 60_000);
        const predicted = clamp(profileFactor(axis, target) * 100, 2, 100);
        const fullModel = clamp((modelSpeed(axis, target, weather, []) / axis.freeFlowKmh) * 100, 2, 100);
        errors[h].push(Math.abs(predicted - fullModel));
      }
    }
  }

  const coherence = Object.fromEntries(
    horizons.map((h) => {
      const list = errors[h];
      const mae = list.reduce((a, b) => a + b, 0) / Math.max(1, list.length);
      const within10 = (list.filter((e) => e <= 10).length / Math.max(1, list.length)) * 100;
      return [`${h}`, { mae: Math.round(mae * 10) / 10, within10: Math.round(within10), samples: list.length }];
    }),
  );

  const gpsValidation = await validateOnRealGps(city.id, city.tzOffsetMin ?? 0);
  const holdout = await getLastEvaluation(city);

  const payload: Record<string, unknown> = {
    city: city.id,
    cityName: city.name,
    generatedAt: new Date().toISOString(),
    gpsValidation,
    holdout,
    coherence,
    notes: {
      gpsValidation:
        "Vérité terrain : profils horaires comparés aux vitesses réellement mesurées par les GPS des conducteurs (POST /api/telemetry, 7 derniers jours).",
      coherence:
        "Auto-test de cohérence interne : écart entre la prédiction « profils seuls » et le modèle complet (météo réelle incluse). Ne constitue pas une mesure d'exactitude terrain.",
    },
    weather: { label: weather.label, source: weather.source },
  };
  cache.set(city.id, { at: Date.now(), payload });
  return jsonCached(req, payload, 240, 300);
}
