import { and, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { fleetVehicles, incidents, parkingLots } from "@/db/schema";
import type { CityDef } from "./cities";
import { CALLING_CODES } from "./more-cities";
import { hashNoise } from "./engine";
import { zoneLatLon } from "./transit";

let seeded = false;

/**
 * Données initiales : comme sur la plateforme en production, le flux
 * communautaire et la flotte partenaire contiennent déjà de l'activité.
 * Inséré une seule fois (si les tables sont vides).
 */
export async function ensureSeed(): Promise<void> {
  if (seeded) return;
  seeded = true;
  try {
    const existingIncidents = await db.select({ id: incidents.id }).from(incidents).limit(1);
    if (existingIncidents.length === 0) {
      const now = Date.now();
      const rows: (typeof incidents.$inferInsert)[] = [
        // Dakar
        { city: "dakar", axisId: "vdn", type: "accident", severity: 4, channel: "ussd", network: "orange", confirmations: 4, confidence: 98, status: "broadcast", description: "Collision voiture / car rapide à hauteur de la Patte d'Oie, voie de droite bloquée.", createdAt: new Date(now - 24 * 60_000), updatedAt: new Date(now - 6 * 60_000) },
        { city: "dakar", axisId: "route-rufisque", type: "bouchon", severity: 3, channel: "whatsapp", network: "mtn", confirmations: 3, confidence: 92, status: "broadcast", description: "Ralentissement dense depuis le rond-point de Pikine, marché qui déborde sur la chaussée.", createdAt: new Date(now - 42 * 60_000), updatedAt: new Date(now - 11 * 60_000) },
        { city: "dakar", axisId: "cheikh-anta-diop-sud", type: "travaux", severity: 2, channel: "web", network: "web", confirmations: 2, confidence: 71, status: "confirmed", description: "Réfection de la chaussée devant l'université, circulation alternée.", createdAt: new Date(now - 65 * 60_000), updatedAt: new Date(now - 20 * 60_000) },
        { city: "dakar", axisId: "patte-oie", type: "panne", severity: 2, channel: "ussd", network: "moov", confirmations: 1, confidence: 38, status: "pending", description: "Camion en panne sur la bretelle, en attente de confirmation.", createdAt: new Date(now - 9 * 60_000), updatedAt: new Date(now - 9 * 60_000) },
        // Abidjan
        { city: "abidjan", axisId: "bvge-centre", type: "inondation", severity: 4, channel: "whatsapp", network: "orange", confirmations: 5, confidence: 98, status: "broadcast", description: "Eau sur la chaussée à Koumassi après l'averse, passage possible uniquement sur la voie de gauche.", createdAt: new Date(now - 35 * 60_000), updatedAt: new Date(now - 4 * 60_000) },
        { city: "abidjan", axisId: "pont-hkb", type: "bouchon", severity: 3, channel: "web", network: "web", confirmations: 3, confidence: 90, status: "broadcast", description: "File lente dès la descente du pont côté Marcory.", createdAt: new Date(now - 18 * 60_000), updatedAt: new Date(now - 3 * 60_000) },
        { city: "abidjan", axisId: "autoroute-nord", type: "police", severity: 1, channel: "ussd", network: "mtn", confirmations: 1, confidence: 38, status: "pending", description: "Contrôle routier signalé à la sortie Yopougon.", createdAt: new Date(now - 14 * 60_000), updatedAt: new Date(now - 14 * 60_000) },
        // Bamako
        { city: "bamako", axisId: "pont-martyrs", type: "bouchon", severity: 4, channel: "ussd", network: "orange", confirmations: 4, confidence: 96, status: "broadcast", description: "Pont saturé dans les deux sens, privilégier le Pont de l'Amitié.", createdAt: new Date(now - 28 * 60_000), updatedAt: new Date(now - 5 * 60_000) },
        { city: "bamako", axisId: "route-aeroport-nord", type: "travaux", severity: 2, channel: "web", network: "web", confirmations: 2, confidence: 68, status: "confirmed", description: "Travaux de voirie à Sogoniko, une voie neutralisée.", createdAt: new Date(now - 80 * 60_000), updatedAt: new Date(now - 30 * 60_000) },
        // Ouagadougou
        { city: "ouagadougou", axisId: "bd-cdg", type: "accident", severity: 3, channel: "whatsapp", network: "moov", confirmations: 3, confidence: 91, status: "broadcast", description: "Accident impliquant un car et une moto, secours sur place.", createdAt: new Date(now - 21 * 60_000), updatedAt: new Date(now - 7 * 60_000) },
        { city: "ouagadougou", axisId: "route-fada", type: "danger", severity: 3, channel: "ussd", network: "orange", confirmations: 1, confidence: 38, status: "pending", description: "Nid-de-poule profond signalé après Karpala, dangereux pour les deux-roues.", createdAt: new Date(now - 12 * 60_000), updatedAt: new Date(now - 12 * 60_000) },
      ];
      await db.insert(incidents).values(rows);
    }

    const existingFleet = await db.select({ id: fleetVehicles.id }).from(fleetVehicles).limit(1);
    if (existingFleet.length === 0) {
      const rows: (typeof fleetVehicles.$inferInsert)[] = [
        // Dakar — convoi portuaire
        { city: "dakar", plate: "DK-4821-AB", driver: "Moussa Diop", phone: "+221770000001", cargo: "Conteneur 40' — textile", origin: "Port de Dakar", destination: "Diamniadio", axisId: "autoroute-peage", speedKmh: 62, etaMin: 38, fuelL: 210, status: "En mouvement" },
        { city: "dakar", plate: "DK-9034-CB", driver: "Awa Ndiaye", phone: "+221770000002", cargo: "Ciment — 28 t", origin: "Hann", destination: "Rufisque", axisId: "route-rufisque", speedKmh: 14, etaMin: 64, fuelL: 165, status: "Ralentissement" },
        { city: "dakar", plate: "DK-2210-AA", driver: "Ibrahima Fall", phone: "+221770000003", cargo: "Produits frais — frigorifique", origin: "Pikine", destination: "Plateau", axisId: "patte-oie", speedKmh: 31, etaMin: 44, fuelL: 98, status: "En mouvement" },
        { city: "dakar", plate: "DK-7755-ZZ", driver: "Cheikh Sarr", phone: "+221770000004", cargo: "Hydrocarbures — citerne 30 m³", origin: "Port de Dakar", destination: "Keur Massar", axisId: "route-keur-massar", speedKmh: 8, etaMin: 81, fuelL: 240, status: "Bloqué" },
        // Abidjan
        { city: "abidjan", plate: "CI-6543-KP", driver: "Koffi Mensah", phone: "+2250700000001", cargo: "Cacao — 25 t", origin: "Port d'Abidjan (Vridi)", destination: "Bingerville", axisId: "express-port", speedKmh: 22, etaMin: 57, fuelL: 180, status: "Ralentissement" },
        { city: "abidjan", plate: "CI-1187-RT", driver: "Fatou Koné", phone: "+2250700000002", cargo: "Conteneur 20' — électronique", origin: "Vridi — Port", destination: "Cocody", axisId: "bvge-centre", speedKmh: 12, etaMin: 73, fuelL: 145, status: "Bloqué" },
        { city: "abidjan", plate: "CI-3320-AB", driver: "Yao Brou", phone: "+2250700000003", cargo: "Matériaux de construction", origin: "Yopougon", destination: "Abobo", axisId: "autoroute-nord", speedKmh: 54, etaMin: 29, fuelL: 120, status: "En mouvement" },
        // Bamako
        { city: "bamako", plate: "ML-7845-BKO", driver: "Sékou Traoré", phone: "+22376000001", cargo: "Coton — 30 t", origin: "Zone industrielle", destination: "Route de Koulikoro", axisId: "route-koulikoro", speedKmh: 58, etaMin: 41, fuelL: 260, status: "En mouvement" },
        { city: "bamako", plate: "ML-2091-AQ", driver: "Mariam Coulibaly", phone: "+22376000002", cargo: "Denrées alimentaires", origin: "Badalabougou", destination: "Aéroport — Sénou", axisId: "route-aeroport-nord", speedKmh: 18, etaMin: 66, fuelL: 132, status: "Ralentissement" },
        // Ouagadougou
        { city: "ouagadougou", plate: "BF-4512-OUA", driver: "Boureima Sawadogo", phone: "+22670000001", cargo: "Céréales — 22 t", origin: "Kossodo", destination: "Saaba", axisId: "echangeur-est", speedKmh: 47, etaMin: 33, fuelL: 155, status: "En mouvement" },
        { city: "ouagadougou", plate: "BF-9038-KD", driver: "Aïcha Ouédraogo", phone: "+22670000002", cargo: "Boissons — distribution", origin: "Centre-ville", destination: "Karpala", axisId: "bd-cdg", speedKmh: 16, etaMin: 52, fuelL: 88, status: "Ralentissement" },
      ];
      await db.insert(fleetVehicles).values(rows);
    }
  } catch {
    // Base pas encore prête : l'app fonctionne avec les profils du moteur.
  }
}

export async function isSeededCheck(cityId: string): Promise<boolean> {
  try {
    const rows = await db.select({ id: incidents.id }).from(incidents).where(eq(incidents.city, cityId)).limit(1);
    return rows.length > 0;
  } catch {
    return false;
  }
}

/* ------------------------------------------------------------------ */
/* Seed par ville : activité initiale des villes du déploiement        */
/* régional (signalements communautaires + flotte partenaire),         */
/* générée de façon déterministe à la première visite de la ville.     */
/* ------------------------------------------------------------------ */

const citySeeded = new Set<string>();
const citySeedInflight = new Map<string, Promise<void>>();

/** Texte d'amorçage des signalements, dans la langue de la ville. */
function seedDescription(city: CityDef, axisName: string): string {
  if (city.lang === "en") {
    return `Community report — ${axisName} (${city.name}). Traffic monitored by partner drivers.`;
  }
  if (city.lang === "pt") {
    return `Relato da comunidade — ${axisName} (${city.name}). Trânsito monitorado por motoristas parceiros.`;
  }
  return `Signalement communautaire — ${axisName} (${city.name}). Circulation surveillée par les conducteurs partenaires.`;
}

const DRIVER_NAMES = [
  "Abdoulaye Barry",
  "Mariam Diallo",
  "Ibrahim Touré",
  "Kadidiatou Bah",
  "Moussa Camara",
  "Aïcha Sy",
  "Ousmane Baldé",
  "Fatoumata Sow",
  "Sekou Condé",
  "Aminata Traoré",
  "Cheikh Fall",
  "Ndeye Diop",
  "Kwame Mensah",
  "Akosua Frimpong",
  "Chinedu Okafor",
  "Ngozi Eze",
  "Fatima Bello",
  "Yusuf Abdullahi",
  "Grace Adeyemi",
  "Jean-Marc Eyene",
  "Sandrine Mba",
  "Patrick Nkomo",
  "Léonie Abena",
  "Ruth Ekindi",
];

const CARGO_TYPES = [
  "Conteneur 20' — marchandises diverses",
  "Ciment — 25 t",
  "Riz importé — 20 t",
  "Produits frais — frigorifique",
  "Matériaux de construction",
  "Boissons — distribution",
  "Textile — balles",
  "Hydrocarbures — citerne",
  "Pièces détachées automobile",
  "Céréales — 18 t",
];

function pick<T>(arr: readonly T[], seed: string): T {
  return arr[Math.floor(hashNoise(seed) * arr.length) % arr.length];
}

export function ensureCitySeed(city: CityDef): Promise<void> {
  if (citySeeded.has(city.id)) return Promise.resolve();
  const inflight = citySeedInflight.get(city.id);
  if (inflight) return inflight;

  const task = (async () => {
    try {
      const now = Date.now();
      // Activité vivante : si aucun signalement récent (< 6 h) n'existe pour
      // cette ville, on réamorce un trio communautaire (toutes villes,
      // y compris les historiques dont le seed initial a expiré du flux).
      const sixHoursAgo = new Date(now - 6 * 3600_000);
      const recentIncidents = await db
        .select({ id: incidents.id })
        .from(incidents)
        .where(and(eq(incidents.city, city.id), gte(incidents.createdAt, sixHoursAgo)))
        .limit(1);
      if (recentIncidents.length === 0 && city.axes.length > 0) {
        const types = ["accident", "bouchon", "travaux"] as const;
        const channels = ["ussd", "whatsapp", "web"] as const;
        const networks = ["orange", "mtn", "moov"] as const;
        const stage = [
          { confirmations: 3, confidence: 95, status: "broadcast", minutesAgo: 16 },
          { confirmations: 2, confidence: 71, status: "confirmed", minutesAgo: 43 },
          { confirmations: 1, confidence: 38, status: "pending", minutesAgo: 8 },
        ];
        const axisIdx = [0, Math.floor(city.axes.length / 3), Math.floor((2 * city.axes.length) / 3)];
        await db.insert(incidents).values(
          stage.map((s, i) => {
            const axis = city.axes[axisIdx[i] % city.axes.length];
            return {
              city: city.id,
              axisId: axis.id,
              type: types[i],
              severity: 2 + i,
              channel: channels[i],
              network: networks[i],
              description: seedDescription(city, axis.name),
              confirmations: s.confirmations,
              confidence: s.confidence,
              status: s.status,
              createdAt: new Date(now - s.minutesAgo * 60_000),
              updatedAt: new Date(now - Math.max(2, s.minutesAgo - 5) * 60_000),
            };
          }),
        );
      }

      const existingFleet = await db
        .select({ id: fleetVehicles.id })
        .from(fleetVehicles)
        .where(eq(fleetVehicles.city, city.id))
        .limit(1);
      if (existingFleet.length === 0 && city.zones.length >= 3) {
        const letters = "ABCDEFGHJKLMNPRSTUVXYZ";
        const mkPlate = (seed: string) =>
          `${city.countryCode}-${1000 + Math.floor(hashNoise(seed) * 9000)}-${letters[Math.floor(hashNoise(seed + ":l1") * letters.length)]}${letters[Math.floor(hashNoise(seed + ":l2") * letters.length)]}`;
        await db.insert(fleetVehicles).values(
          [0, 1, 2].map((i) => {
            const seedKey = `fleet:${city.id}:${i}`;
            const origin = city.zones[1 + (i % (city.zones.length - 1))];
            const destination = city.zones[city.zones.length - 1 - (i % (city.zones.length - 1))];
            return {
              city: city.id,
              plate: mkPlate(seedKey),
              driver: pick(DRIVER_NAMES, seedKey + ":driver"),
              phone: `+${CALLING_CODES[city.countryCode] ?? "225"}7000000${10 + i}`,
              cargo: pick(CARGO_TYPES, seedKey + ":cargo"),
              origin: origin.name,
              destination: destination.name,
              axisId: city.axes[Math.floor(hashNoise(seedKey + ":axis") * city.axes.length)].id,
              speedKmh: 18 + Math.floor(hashNoise(seedKey + ":speed") * 40),
              etaMin: 25 + Math.floor(hashNoise(seedKey + ":eta") * 55),
              fuelL: 90 + Math.floor(hashNoise(seedKey + ":fuel") * 190),
              status: "En mouvement",
              convoy: false,
            };
          }),
        );
      }
      // Parkings : réels à Dakar (P+R TER, port, marché), dérivés des
      // quartiers pour les autres villes (occupation modélisée ensuite).
      const existingParking = await db
        .select({ id: parkingLots.id })
        .from(parkingLots)
        .where(eq(parkingLots.city, city.id))
        .limit(1);
      if (existingParking.length === 0) {
        if (city.id === "dakar") {
          await db.insert(parkingLots).values([
            { city: city.id, name: "Parking Gare de Dakar — P+R TER", lat: 14.6735, lon: -17.4375, totalSpots: 200, pricePerHourFcfa: 300, nearestTransitStop: "ter-dakar", parkingType: "ParkAndRide" },
            { city: city.id, name: "Parking du Port de Dakar", lat: 14.677, lon: -17.432, totalSpots: 350, pricePerHourFcfa: 500, nearestTransitStop: "ter-dakar", parkingType: "PrivateLot" },
            { city: city.id, name: "Parking Marché Sandaga", lat: 14.67, lon: -17.437, totalSpots: 120, pricePerHourFcfa: 400, nearestTransitStop: "cr-petersen", parkingType: "Street" },
            { city: city.id, name: "Parking Diamniadio — P+R TER", lat: 14.7235, lon: -17.1825, totalSpots: 500, pricePerHourFcfa: 200, nearestTransitStop: "ter-diamniadio", parkingType: "ParkAndRide" },
            { city: city.id, name: "Parking AIBD — P+R", lat: 14.6735, lon: -17.0735, totalSpots: 1000, pricePerHourFcfa: 400, nearestTransitStop: "ter-aibd", parkingType: "ParkAndRide" },
            { city: city.id, name: "Parking Pikine — P+R TER", lat: 14.7525, lon: -17.3875, totalSpots: 80, pricePerHourFcfa: 200, nearestTransitStop: "ter-pikine", parkingType: "ParkAndRide" },
          ]);
        } else if (city.zones.length >= 2) {
          const picks = [
            { zone: city.zones[0], name: `Parking Gare routière — ${city.zones[0].name}`, type: "ParkAndRide", spots: 150, price: 250 },
            { zone: city.zones[Math.floor(city.zones.length / 2)], name: `Parking Marché — ${city.zones[Math.floor(city.zones.length / 2)].name}`, type: "PrivateLot", spots: 90, price: 300 },
            { zone: city.zones[city.zones.length - 1], name: `Parking ${city.zones[city.zones.length - 1].name}`, type: "Street", spots: 60, price: 200 },
          ];
          const values = picks
            .map((pk) => {
              const coords = zoneLatLon(city, pk.zone.id);
              if (!coords) return null;
              return {
                city: city.id,
                name: pk.name,
                lat: coords[0],
                lon: coords[1],
                totalSpots: pk.spots,
                pricePerHourFcfa: pk.price,
                parkingType: pk.type,
              };
            })
            .filter((v) => v !== null);
          if (values.length > 0) await db.insert(parkingLots).values(values);
        }
      }
    } catch {
      // Base indisponible : la ville fonctionne avec les profils du moteur.
    } finally {
      citySeeded.add(city.id);
      citySeedInflight.delete(city.id);
    }
  })();

  citySeedInflight.set(city.id, task);
  return task;
}
