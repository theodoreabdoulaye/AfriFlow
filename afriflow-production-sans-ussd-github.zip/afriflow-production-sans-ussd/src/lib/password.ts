import { randomBytes, scrypt, timingSafeEqual } from "node:crypto";

const options = { N: 16384, r: 8, p: 1, maxmem: 32 * 1024 * 1024 };
let active = 0;
export class PasswordCapacityError extends Error {}

export function isValidPassword(password: unknown): password is string {
  return typeof password === "string" && password.length >= 12 && password.length <= 128;
}

async function derive(password: string, salt: Buffer): Promise<Buffer> {
  // No unbounded queue of memory-heavy work during an authentication flood.
  if (active >= 4) throw new PasswordCapacityError("Authentication busy");
  active++;
  try {
    return await new Promise<Buffer>((resolve, reject) => {
      scrypt(password, salt, 64, options, (error, key) => error ? reject(error) : resolve(key));
    });
  } finally {
    active--;
  }
}

export async function hashPassword(password: string): Promise<string> {
  if (!isValidPassword(password)) throw new RangeError("Password must be 12 to 128 characters");
  const salt = randomBytes(16);
  const key = await derive(password, salt);
  return `scrypt$16384$8$1$${salt.toString("hex")}$${key.toString("hex")}`;
}

export async function verifyPassword(password: string, encoded: string): Promise<boolean> {
  if (!isValidPassword(password)) return false;
  const match = /^scrypt\$16384\$8\$1\$([a-f0-9]{32})\$([a-f0-9]{128})$/.exec(encoded);
  // Unknown accounts and invalid stored hashes still pay for one full scrypt.
  const salt = Buffer.from(match?.[1] ?? "00000000000000000000000000000000", "hex");
  const expected = Buffer.from(match?.[2] ?? "00".repeat(64), "hex");
  const actual = await derive(password, salt);
  return timingSafeEqual(actual, expected) && match !== null;
}
