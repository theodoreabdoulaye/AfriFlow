"use client";

import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight,
  CalendarClock,
  Coins,
  Loader2,
  MapPin,
  Search,
  Users,
} from "lucide-react";
import { CITY_MAP } from "@/lib/cities";
import type { MultimodalRoute } from "@/lib/multimodal";
import MultimodalRouteSelector from "./MultimodalRouteSelector";
import { useApp } from "./AppClient";

interface ParkingLot {
  id: number;
  name: string;
  distanceM: number;
  totalSpots: number;
  availableSpots: number;
  availabilityPct: number;
  predictedAvailabilityPct: number;
  occupancySource: string;
  pricePerHourFcfa: number;
  parkingType: string;
  nearestTransitStop: { name: string; mode: string; walkingDistanceM: number } | null;
}

interface CarpoolMatch {
  offer: {
    id: number;
    driverName: string;
    fromLabel: string;
    toLabel: string;
    departureTime: string;
    pricePerSeatFcfa: number;
    vehicleType: string;
    driverRating?: { average: number | null; count: number };
  };
  compatibilityScore: number;
  detourMinutes: number;
  seatsLeft: number;
}

interface MultimodalResponse {
  routes: MultimodalRoute[];
  from: { lat: number; lon: number; label: string };
  to: { lat: number; lon: number; label: string };
}

export default function MultimodalSection() {
  const { cityId } = useApp();
  const city = CITY_MAP[cityId];

  const [fromZone, setFromZone] = useState(city.zones[0].id);
  const [toZone, setToZone] = useState(city.zones[city.zones.length - 1].id);
  const [allowCar, setAllowCar] = useState(true);
  const [allowTransit, setAllowTransit] = useState(true);
  const [allowPR, setAllowPR] = useState(true);
  const [prioritize, setPrioritize] = useState("time");
  const [result, setResult] = useState<MultimodalResponse | null>(null);
  const [selectedRouteId, setSelectedRouteId] = useState<string | null>(null);
  const [chosenRoute, setChosenRoute] = useState<MultimodalRoute | null>(null);

  const chooseRoute = (route: MultimodalRoute) => {
    setSelectedRouteId(route.id);
    setChosenRoute(route);
    try {
      window.localStorage.setItem(
        "afri_chosen_route",
        JSON.stringify({ cityId, routeId: route.id, label: route.label, at: Date.now() }),
      );
    } catch {
      /* stockage indisponible */
    }
  };
  const [computing, setComputing] = useState(false);
  const [computeError, setComputeError] = useState<string | null>(null);

  const [parkings, setParkings] = useState<ParkingLot[]>([]);

  const [offerForm, setOfferForm] = useState({ name: "", phone: "", time: "", seats: 3, price: 500, vehicle: "Berline" });
  const [passenger, setPassenger] = useState({ name: "", phone: "", maxPrice: 1500 });
  const [matches, setMatches] = useState<CarpoolMatch[]>([]);
  const [carpoolMsg, setCarpoolMsg] = useState<string | null>(null);
  const [carpoolBusy, setCarpoolBusy] = useState(false);
  const [lastBookingId, setLastBookingId] = useState<number | null>(null);
  const [ratingStars, setRatingStars] = useState(5);
  const [ratingMsg, setRatingMsg] = useState<string | null>(null);

  // Changement de ville : zones par défaut valides.
  useEffect(() => {
    const t = window.setTimeout(() => {
      setFromZone(city.zones[0].id);
      setToZone(city.zones[city.zones.length - 1].id);
      setResult(null);
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cityId]);

  const loadParkings = useCallback(
    async (lat: number, lon: number) => {
      try {
        const res = await fetch(`/api/parking?city=${cityId}&lat=${lat}&lon=${lon}&maxDistanceM=8000`, {
          cache: "no-store",
        });
        if (res.ok) {
          const json = (await res.json()) as { lots: ParkingLot[] };
          setParkings(json.lots);
        }
      } catch {
        /* parkings optionnels */
      }
    },
    [cityId],
  );

  useEffect(() => {
    const t = window.setTimeout(() => void loadParkings(city.lat, city.lon), 0);
    return () => clearTimeout(t);
  }, [loadParkings, city]);

  const compute = async () => {
    setComputing(true);
    setComputeError(null);
    try {
      const res = await fetch("/api/multimodal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          city: cityId,
          from: { zone: fromZone },
          to: { zone: toZone },
          preferences: {
            allowCar,
            allowTransit,
            allowParkAndRide: allowPR,
            maxWalkingDistanceM: 1200,
            prioritize,
          },
        }),
      });
      const json = (await res.json()) as MultimodalResponse & { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Calcul impossible");
      setResult(json);
      void loadParkings(json.from.lat, json.from.lon);
    } catch (e) {
      setComputeError(e instanceof Error ? e.message : "Calcul impossible");
      setResult(null);
    } finally {
      setComputing(false);
    }
  };

  const publishOffer = async () => {
    setCarpoolBusy(true);
    setCarpoolMsg(null);
    try {
      const departure = offerForm.time
        ? new Date(offerForm.time).toISOString()
        : new Date(Date.now() + 3600_000).toISOString();
      const res = await fetch("/api/carpool", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "publish",
          city: cityId,
          driverName: offerForm.name,
          driverPhone: offerForm.phone,
          from: { zone: fromZone },
          to: { zone: toZone },
          departureTime: departure,
          seats: offerForm.seats,
          pricePerSeatFcfa: offerForm.price,
          vehicleType: offerForm.vehicle,
        }),
      });
      const json = (await res.json()) as { error?: string };
      if (!res.ok) throw new Error(json.error ?? "Publication impossible");
      setCarpoolMsg("✅ Offre publiée ! Les passagers sur ce trajet peuvent maintenant vous trouver.");
    } catch (e) {
      setCarpoolMsg(e instanceof Error ? e.message : "Publication impossible");
    } finally {
      setCarpoolBusy(false);
    }
  };

  const searchMatches = async () => {
    setCarpoolBusy(true);
    setCarpoolMsg(null);
    try {
      const res = await fetch("/api/carpool", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "match",
          city: cityId,
          from: { zone: fromZone },
          to: { zone: toZone },
          maxPriceFcfa: passenger.maxPrice,
        }),
      });
      const json = (await res.json()) as { matches?: CarpoolMatch[]; error?: string };
      if (!res.ok) throw new Error(json.error ?? "Recherche impossible");
      setMatches(json.matches ?? []);
      if ((json.matches ?? []).length === 0) {
        setCarpoolMsg("Aucune offre compatible pour le moment sur ce trajet — publiez la vôtre si vous conduisez !");
      }
    } catch (e) {
      setCarpoolMsg(e instanceof Error ? e.message : "Recherche impossible");
    } finally {
      setCarpoolBusy(false);
    }
  };

  const book = async (offerId: number) => {
    setCarpoolBusy(true);
    try {
      const res = await fetch("/api/carpool", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "book",
          city: cityId,
          offerId,
          passengerName: passenger.name,
          passengerPhone: passenger.phone,
          seats: 1,
        }),
      });
      const json = (await res.json()) as {
        message?: string;
        error?: string;
        booking?: { id: number };
      };
      if (!res.ok) throw new Error(json.error ?? "Réservation impossible");
      setCarpoolMsg(`⏳ ${json.message}`);
      if (json.booking?.id) setLastBookingId(json.booking.id);
      void searchMatches();
    } catch (e) {
      setCarpoolMsg(e instanceof Error ? e.message : "Réservation impossible");
    } finally {
      setCarpoolBusy(false);
    }
  };

  const selectCls =
    "w-full cursor-pointer rounded-xl border border-night-600 bg-night-800 px-3 py-2.5 text-sm outline-none focus:border-brand-500";
  const inputCls =
    "w-full rounded-xl border border-night-600 bg-night-800 px-3 py-2 text-[13px] outline-none placeholder:text-sage/50 focus:border-brand-500";

  return (
    <section id="multimodal" className="mx-auto max-w-7xl scroll-mt-24 px-4 py-14 sm:px-6">
      <div data-reveal>
        <p className="mb-2 flex items-center gap-2 text-[11px] font-bold tracking-[0.18em] text-brand-500 uppercase">
          <span className="inline-block h-px w-8 bg-brand-500" /> 03 · Multimodal, parkings &amp; covoiturage
        </p>
        <h2 className="font-display text-3xl font-bold tracking-tight sm:text-4xl">
          Pas que la voiture : <span className="text-brand-500">TER, BRT, Car Rapide, Park &amp; Ride</span>
        </h2>
        <p className="mt-2 max-w-3xl text-[14px] leading-relaxed text-sage">
          Le moteur compare la voiture ventilée aux transports collectifs réels de {city.name}
          {city.id === "dakar" ? " (TER Dakar–AIBD toutes les 15 min, BRT, cars rapides)" : " (cars rapides / gbakas)"} :
          durée porte-à-porte, coût en FCFA, CO₂, confort et fiabilité — puis les parkings relais et le covoiturage
          pour compléter le trajet.
        </p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-[0.95fr_1.55fr]">
        {/* Formulaire */}
        <div data-reveal className="h-fit rounded-3xl border border-night-600 bg-night-900 p-5">
          <h3 className="font-display text-base font-semibold">Votre trajet multimodal</h3>
          <div className="mt-4 space-y-3">
            <label className="block">
              <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">Départ (quartier)</span>
              <select value={fromZone} onChange={(e) => setFromZone(e.target.value)} className={selectCls}>
                {city.zones.map((z) => (
                  <option key={z.id} value={z.id}>{z.name}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">Arrivée (quartier)</span>
              <select value={toZone} onChange={(e) => setToZone(e.target.value)} className={selectCls}>
                {city.zones.map((z) => (
                  <option key={z.id} value={z.id}>{z.name}</option>
                ))}
              </select>
            </label>
          </div>

          <div className="mt-4 space-y-2">
            {[
              { label: "Voiture (itinéraire ventilé)", value: allowCar, set: setAllowCar },
              { label: "Transports collectifs (TER / BRT / Car Rapide)", value: allowTransit, set: setAllowTransit },
              { label: "Park & Ride (voiture → gare → marche)", value: allowPR, set: setAllowPR },
            ].map((opt) => (
              <label
                key={opt.label}
                className={`flex cursor-pointer items-center gap-3 rounded-xl border px-3 py-2.5 text-[13px] font-medium transition ${
                  opt.value ? "border-brand-500/50 bg-brand-500/10 text-paper" : "border-night-600 bg-night-800/60 text-sage"
                }`}
              >
                <input
                  type="checkbox"
                  checked={opt.value}
                  onChange={(e) => opt.set(e.target.checked)}
                  className="h-4 w-4 accent-[#22b573]"
                />
                {opt.label}
              </label>
            ))}
          </div>

          <label className="mt-4 block">
            <span className="mb-1 block text-[11px] font-semibold tracking-wide text-sage uppercase">Priorité de tri</span>
            <select value={prioritize} onChange={(e) => setPrioritize(e.target.value)} className={selectCls}>
              <option value="time">⏱️ Le plus rapide</option>
              <option value="cost">💰 Le moins cher</option>
              <option value="comfort">🛋️ Le plus confortable</option>
              <option value="eco">🌿 Le plus écologique</option>
            </select>
          </label>

          <button
            onClick={() => void compute()}
            disabled={computing}
            className="mt-4 flex w-full items-center justify-center gap-2 rounded-2xl bg-brand-500 py-3 text-sm font-bold text-night-950 transition hover:bg-mint-400 disabled:opacity-60"
          >
            {computing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
            Comparer les modes de transport
          </button>
          {computeError && (
            <p className="mt-3 rounded-xl bg-coral/10 px-3 py-2 text-[12.5px] font-medium text-coral">{computeError}</p>
          )}
        </div>

        {/* Résultats multimodaux */}
        <div data-reveal>
          {!result ? (
            <div className="grid h-full place-items-center rounded-3xl border border-dashed border-night-500 bg-night-900/60 px-6 py-14 text-center">
              <div>
                <span className="text-4xl">🚆</span>
                <p className="mt-3 font-display text-lg font-semibold">Comparez voiture, TER, BRT et Car Rapide</p>
                <p className="mx-auto mt-1 max-w-md text-[13px] leading-relaxed text-sage">
                  {city.id === "dakar"
                    ? "Exemple parlant : Plateau → AIBD. La voiture peut prendre 70 minutes au pic ; le Park & Ride + TER (35 min de train, départ toutes les 15 min) gagne souvent."
                    : `À ${city.name}, le Car Rapide bat souvent la voiture au pic — et coûte 5 à 10 fois moins cher.`}
                </p>
              </div>
            </div>
          ) : result.routes.length === 0 ? (
            <p className="rounded-3xl border border-night-600 bg-night-900 px-6 py-10 text-center text-sm text-sage">
              Aucune option trouvée avec ces préférences (essayez d&apos;autoriser plus de modes ou un autre trajet).
            </p>
          ) : (
            <>
              {chosenRoute && (
                <p className="mb-4 rounded-2xl border border-brand-500/60 bg-brand-500/12 px-4 py-3 text-[13px] leading-relaxed">
                  ✅ <b>Itinéraire choisi : {chosenRoute.label}</b> — {chosenRoute.totalDurationMin} min,{" "}
                  {chosenRoute.totalCostFcfa.toLocaleString("fr-FR")} FCFA, {chosenRoute.co2Kg} kg de CO₂.
                  {chosenRoute.segments.find((s) => s.departureTime)
                    ? ` Prochain départ : ${chosenRoute.segments.find((s) => s.departureTime)?.departureTime}.`
                    : ""}{" "}
                  Bon voyage !
                </p>
              )}
              <MultimodalRouteSelector
                routes={result.routes}
                selectedId={selectedRouteId}
                onChoose={chooseRoute}
              />
            </>
          )}
        </div>
      </div>

      {/* Parkings + Covoiturage */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div data-reveal className="rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
          <h3 className="flex items-center gap-2 font-display text-lg font-bold">
            <MapPin className="h-5 w-5 text-brand-500" /> Parkings près du départ
          </h3>
          <p className="mt-1 text-[12.5px] text-sage">
            Places libres en direct (capteur) ou estimées par profil horaire — prédiction à 30 min incluse.
          </p>
          <ul className="mt-4 space-y-3">
            {parkings.map((lot) => (
              <li key={lot.id} className="rounded-2xl bg-night-800/70 p-3.5">
                <p className="flex items-baseline justify-between gap-2 text-[13.5px] font-bold">
                  <span className="truncate">{lot.name}</span>
                  <span className={lot.availabilityPct > 25 ? "text-mint-300" : lot.availabilityPct > 8 ? "text-amber-warn" : "text-coral"}>
                    {lot.availableSpots} places
                  </span>
                </p>
                <div className="mt-2 h-2 overflow-hidden rounded-full bg-night-950">
                  <div
                    className={`h-full rounded-full ${lot.availabilityPct > 25 ? "bg-brand-500" : lot.availabilityPct > 8 ? "bg-amber-warn" : "bg-coral"}`}
                    style={{ width: `${lot.availabilityPct}%` }}
                  />
                </div>
                <p className="mt-1.5 flex flex-wrap gap-x-3 text-[11px] text-sage">
                  <span>{lot.distanceM >= 1000 ? `${(lot.distanceM / 1000).toFixed(1)} km` : `${lot.distanceM} m`}</span>
                  <span>{lot.pricePerHourFcfa} F/h</span>
                  <span>dispo {lot.availabilityPct} % → {lot.predictedAvailabilityPct} % dans 30 min</span>
                  <span>occupation : {lot.occupancySource}</span>
                  {lot.nearestTransitStop && (
                    <span>🚉 {lot.nearestTransitStop.name} à {lot.nearestTransitStop.walkingDistanceM} m</span>
                  )}
                </p>
              </li>
            ))}
            {parkings.length === 0 && <li className="text-[13px] text-sage">Chargement des parkings…</li>}
          </ul>
        </div>

        <div data-reveal className="rounded-3xl border border-night-600 bg-night-900 p-5 sm:p-6">
          <h3 className="flex items-center gap-2 font-display text-lg font-bold">
            <Users className="h-5 w-5 text-amber-warn" /> Covoiturage — conducteurs &amp; passagers
          </h3>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <input value={passenger.name} onChange={(e) => setPassenger({ ...passenger, name: e.target.value })} placeholder="Votre nom" className={inputCls} />
            <input value={passenger.phone} onChange={(e) => setPassenger({ ...passenger, phone: e.target.value })} placeholder="Votre téléphone" className={inputCls} />
          </div>
          <button
            onClick={() => void searchMatches()}
            disabled={carpoolBusy}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-night-700 py-2.5 text-[13px] font-bold transition hover:bg-night-600 disabled:opacity-60"
          >
            <Search className="h-4 w-4" /> Trouver un conducteur ({fromZone} → {toZone})
          </button>

          {matches.length > 0 && (
            <ul className="mt-3 space-y-2">
              {matches.map((m) => (
                <li key={m.offer.id} className="flex items-center gap-3 rounded-2xl bg-night-800/70 px-3.5 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-[13px] font-bold">
                      {m.offer.driverName} · {m.offer.vehicleType} — départ{" "}
                      {new Date(m.offer.departureTime).toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })}
                    </p>
                    <p className="text-[11.5px] text-sage">
                      compatibilité {m.compatibilityScore} % · détour +{m.detourMinutes} min · {m.seatsLeft} place(s) ·{" "}
                      {m.offer.pricePerSeatFcfa} F/pers
                      {m.offer.driverRating && m.offer.driverRating.average !== null
                        ? ` · ⭐ ${m.offer.driverRating.average} (${m.offer.driverRating.count} avis)`
                        : " · nouveau conducteur"}
                    </p>
                  </div>
                  <button
                    onClick={() => void book(m.offer.id)}
                    disabled={carpoolBusy || !passenger.name || !passenger.phone}
                    className="shrink-0 rounded-xl bg-amber-warn px-3 py-2 text-[12px] font-bold text-night-950 transition hover:brightness-105 disabled:opacity-50"
                    title={!passenger.name || !passenger.phone ? "Renseignez nom et téléphone ci-dessus" : "Réserver une place"}
                  >
                    Réserver
                  </button>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-5 border-t border-night-600/60 pt-4">
            <p className="flex items-center gap-2 text-[13px] font-bold">
              <CalendarClock className="h-4 w-4 text-brand-500" /> Vous conduisez ? Publiez votre trajet
            </p>
            <div className="mt-3 grid grid-cols-2 gap-2">
              <input value={offerForm.name} onChange={(e) => setOfferForm({ ...offerForm, name: e.target.value })} placeholder="Votre nom" className={inputCls} />
              <input value={offerForm.phone} onChange={(e) => setOfferForm({ ...offerForm, phone: e.target.value })} placeholder="Téléphone" className={inputCls} />
              <input type="datetime-local" value={offerForm.time} onChange={(e) => setOfferForm({ ...offerForm, time: e.target.value })} className={inputCls} />
              <input value={offerForm.vehicle} onChange={(e) => setOfferForm({ ...offerForm, vehicle: e.target.value })} placeholder="Véhicule (ex. Toyota Corolla)" className={inputCls} />
              <label className="flex items-center gap-2 text-[12px] text-sage">
                Places
                <input type="number" min={1} max={8} value={offerForm.seats} onChange={(e) => setOfferForm({ ...offerForm, seats: Number(e.target.value) })} className={inputCls} />
              </label>
              <label className="flex items-center gap-2 text-[12px] text-sage">
                Prix/pers (F)
                <input type="number" min={0} max={10000} step={50} value={offerForm.price} onChange={(e) => setOfferForm({ ...offerForm, price: Number(e.target.value) })} className={inputCls} />
              </label>
            </div>
            <button
              onClick={() => void publishOffer()}
              disabled={carpoolBusy}
              className="mt-3 flex w-full items-center justify-center gap-2 rounded-xl bg-brand-500 py-2.5 text-[13px] font-bold text-night-950 transition hover:bg-mint-400 disabled:opacity-60"
            >
              <Coins className="h-4 w-4" /> Publier l&apos;offre ({fromZone} → {toZone})
            </button>
          </div>
          {carpoolMsg && (
            <p className="mt-3 rounded-xl bg-brand-500/12 px-3 py-2.5 text-[12.5px] font-medium text-mint-300">{carpoolMsg}</p>
          )}
          {lastBookingId !== null && (
            <div className="mt-4 rounded-2xl border border-amber-warn/40 bg-amber-warn/8 px-3.5 py-3">
              <p className="text-[12.5px] font-bold">⭐ Noter ce trajet après l&apos;arrivée (réservation #{lastBookingId})</p>
              <div className="mt-2 flex items-center gap-1.5">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    key={n}
                    onClick={() => setRatingStars(n)}
                    className={`grid h-9 w-9 place-items-center rounded-full text-lg transition ${
                      ratingStars >= n ? "bg-amber-warn text-night-950" : "bg-night-700 text-sage"
                    }`}
                    aria-label={`${n} étoile(s)`}
                  >
                    ★
                  </button>
                ))}
                <button
                  disabled={carpoolBusy}
                  onClick={async () => {
                    setCarpoolBusy(true);
                    setRatingMsg(null);
                    try {
                      const res = await fetch("/api/carpool", {
                        method: "POST",
                        headers: { "Content-Type": "application/json" },
                        body: JSON.stringify({
                          action: "rate",
                          city: cityId,
                          bookingId: lastBookingId,
                          raterPhone: passenger.phone,
                          stars: ratingStars,
                        }),
                      });
                      const json = (await res.json()) as { message?: string; error?: string };
                      if (!res.ok) throw new Error(json.error ?? "Notation impossible");
                      setRatingMsg(`✅ ${json.message}`);
                      void searchMatches();
                    } catch (e) {
                      setRatingMsg(e instanceof Error ? e.message : "Notation impossible");
                    } finally {
                      setCarpoolBusy(false);
                    }
                  }}
                  className="ml-2 rounded-xl bg-amber-warn px-3 py-2 text-[12px] font-bold text-night-950 transition hover:brightness-105 disabled:opacity-60"
                >
                  Envoyer la note
                </button>
              </div>
              <p className="mt-1.5 text-[11px] text-sage">
                Vous pouvez aussi noter simplement en envoyant « {ratingStars} » ou « note {ratingStars} » au bot
                WhatsApp après le trajet.
              </p>
              {ratingMsg && <p className="mt-2 text-[12px] font-medium text-mint-300">{ratingMsg}</p>}
            </div>
          )}
          <p className="mt-3 flex items-start gap-2 text-[11.5px] leading-relaxed text-sage">
            <ArrowRight className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            La réservation est atomique : une place n&apos;est prise que s&apos;il en reste, et le conducteur reçoit
            votre numéro pour fixer le point de rendez-vous.
          </p>
        </div>
      </div>
    </section>
  );
}
