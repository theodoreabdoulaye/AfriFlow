import { and, eq, gte } from "drizzle-orm";
import { cellToBoundary, latLngToCell } from "h3-js";
import { db } from "@/db";
import { telemetryPoints } from "@/db/schema";
import type { CityDef } from "./cities";

/**
 * Indexation spatiale hexagonale Uber H3 (résolution 9, ~0,1 km²) :
 * les points GPS sont agrégés par cellule — densité de téléphones et
 * vitesse moyenne — pour lisser le bruit des mesures par tronçon et
 * révéler les zones chaudes même hors des axes surveillés.
 */

export const H3_RESOLUTION = 9;

export interface H3CellData {
  cell: string;
  count: number;
  avgSpeedKmh: number;
  boundary: [number, number][]; // [lat, lon]
}

export interface H3DensityResult {
  city: string;
  resolution: number;
  windowMinutes: number;
  totalPoints: number;
  cells: H3CellData[];
  generatedAt: string;
}

const cache = new Map<string, { at: number; value: H3DensityResult }>();
const CACHE_MS = 60_000;

export async function h3Density(city: CityDef, windowMinutes = 60): Promise<H3DensityResult> {
  const cacheKey = `${city.id}:${windowMinutes}`;
  const hit = cache.get(cacheKey);
  if (hit && Date.now() - hit.at < CACHE_MS) return hit.value;

  const since = new Date(Date.now() - windowMinutes * 60_000);
  const byCell = new Map<string, { count: number; speedSum: number }>();
  let totalPoints = 0;
  try {
    const rows = await db
      .select({ lat: telemetryPoints.lat, lon: telemetryPoints.lon, speedKmh: telemetryPoints.speedKmh })
      .from(telemetryPoints)
      .where(and(eq(telemetryPoints.city, city.id), gte(telemetryPoints.createdAt, since)))
      .limit(8000);
    totalPoints = rows.length;
    for (const r of rows) {
      const cell = latLngToCell(r.lat, r.lon, H3_RESOLUTION);
      const agg = byCell.get(cell) ?? { count: 0, speedSum: 0 };
      agg.count++;
      agg.speedSum += r.speedKmh;
      byCell.set(cell, agg);
    }
  } catch {
    /* aucune donnée : cellules vides */
  }

  const cells: H3CellData[] = [...byCell.entries()]
    .map(([cell, agg]) => ({
      cell,
      count: agg.count,
      avgSpeedKmh: Math.round((agg.speedSum / agg.count) * 10) / 10,
      boundary: cellToBoundary(cell) as [number, number][],
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 400);

  const value: H3DensityResult = {
    city: city.id,
    resolution: H3_RESOLUTION,
    windowMinutes,
    totalPoints,
    cells,
    generatedAt: new Date().toISOString(),
  };
  cache.set(cacheKey, { at: Date.now(), value });
  return value;
}

