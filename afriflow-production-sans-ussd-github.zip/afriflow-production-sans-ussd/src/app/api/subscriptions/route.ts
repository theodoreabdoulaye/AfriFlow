import { NextRequest, NextResponse } from "next/server";
import { randomBytes } from "node:crypto";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

const PLANS = ["premium", "saas", "api", "urbain"] as const;

/**
 * POST /api/subscriptions — inscription à une offre (Mobile Money).
 * L'offre « API Traffic & Prédiction » délivre immédiatement une clé API
 * utilisable sur POST /api/telemetry (source=partner).
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`subscriptions:${clientIp(req)}`, 20, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;

  const plan = String(body.plan ?? "");
  const name = String(body.name ?? "").trim().slice(0, 80);
  const phone = String(body.phone ?? "").trim().slice(0, 24);
  if (!PLANS.includes(plan as (typeof PLANS)[number])) {
    return NextResponse.json({ error: "Offre inconnue." }, { status: 422 });
  }
  if (name.length < 2) {
    return NextResponse.json({ error: "Nom ou raison sociale requis (2 caractères minimum)." }, { status: 422 });
  }
  const digits = phone.replace(/[^\d]/g, "");
  if (digits.length < 8 || digits.length > 15) {
    return NextResponse.json(
      { error: "Numéro Mobile Money invalide : 8 à 15 chiffres attendus." },
      { status: 422 },
    );
  }

  const apiKey = plan === "api" ? `af_${randomBytes(16).toString("hex")}` : null;
  try {
    const [created] = await db.insert(subscriptions).values({ plan, name, phone, apiKey }).returning();
    return NextResponse.json({ subscription: created }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Inscription indisponible" }, { status: 503 });
  }
}
