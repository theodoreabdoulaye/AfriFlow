import { NextRequest, NextResponse } from "next/server";
import { count, desc } from "drizzle-orm";
import { db } from "@/db";
import { wazeApplications } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";

export const dynamic = "force-dynamic";

/** GET /api/waze/apply — état du partenariat Waze for Cities côté AfriFlow. */
export async function GET() {
  let total = 0;
  let latest: (typeof wazeApplications.$inferSelect)[] = [];
  try {
    const [c] = await db.select({ n: count() }).from(wazeApplications);
    total = c?.n ?? 0;
    latest = await db.select().from(wazeApplications).orderBy(desc(wazeApplications.id)).limit(5);
  } catch {
    /* base indisponible */
  }
  return NextResponse.json({
    program: "Waze for Cities (Connected Citizens Program)",
    applications: total,
    latest: latest.map((a) => ({
      organisation: a.organisation,
      city: a.city,
      status: a.status,
      createdAt: a.createdAt,
    })),
    integration: {
      feedUrl: "/api/waze/feed?city=<ville>",
      webhookUrl: "/api/waze/webhook",
      reportEndpoint: "/api/v1/report (source: waze_webhook)",
    },
    note: "L'adhésion se finalise sur le portail officiel Waze for Cities : le dossier généré ici contient le flux d'incidents au format Waze Traffic View à déclarer. AfriFlow ne peut pas approuver la candidature à la place de Waze/Google.",
  });
}

/**
 * POST /api/waze/apply — génère le dossier de candidature d'une
 * organisation (ville, opérateur, ONG) au programme Waze for Cities :
 * coordonnées + flux AfriFlow à déclarer dans le portail Waze.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`wazeapply:${clientIp(req)}`, 10, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;
  const organisation = String(body.organisation ?? "").trim().slice(0, 90);
  const contactName = String(body.contactName ?? "").trim().slice(0, 70);
  const email = String(body.email ?? "").trim().slice(0, 90);
  const cityId = String(body.city ?? "dakar");
  const message = typeof body.message === "string" ? body.message.slice(0, 400) : null;

  if (organisation.length < 2 || contactName.length < 2) {
    return NextResponse.json({ error: "Organisation et personne de contact requises." }, { status: 422 });
  }
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) {
    return NextResponse.json({ error: "Adresse e-mail professionnelle invalide." }, { status: 422 });
  }
  const city = CITY_MAP[cityId];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 422 });

  try {
    const [created] = await db
      .insert(wazeApplications)
      .values({ organisation, contactName, email, city: city.id, message })
      .returning();
    return NextResponse.json(
      {
        application: created,
        nextSteps: [
          "Créez un compte sur le portail officiel « Waze for Cities » (Connected Citizens Program) avec cette adresse e-mail professionnelle.",
          `Déclarez le flux d'incidents AfriFlow de ${city.name} : /api/waze/feed?city=${city.id} (format Waze Traffic View, mis à jour en continu).`,
          "Indiquez l'endpoint de réception des alertes : POST /api/waze/webhook (ou /api/v1/report avec source « waze_webhook »).",
          "Après approbation par Waze, les alertes des conducteurs Waze alimenteront le consensus AfriFlow et vos alertes validées apparaîtront dans Waze.",
        ],
      },
      { status: 201 },
    );
  } catch {
    return NextResponse.json({ error: "Candidature indisponible" }, { status: 503 });
  }
}
