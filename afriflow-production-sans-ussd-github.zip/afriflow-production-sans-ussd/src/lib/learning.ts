import { and, count, desc, eq, gte, isNotNull, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  axisModelWeights,
  axisProfiles,
  incidents,
  mlObservations,
  modelEvaluations,
  telemetryPoints,
} from "@/db/schema";
import type { AxisDef, CityDef } from "./cities";
import { getAxis } from "./cities";
import {
  clamp,
  hashNoise,
  learnedFactorAt,
  profileFactor,
  type AxisWeights,
  type LearnedAxisProfile,
} from "./engine";

/**
 * Apprentissage des profils de vitesse de l'IA.
 *
 * À partir des points GPS collectés (conducteurs réels + simulateur tracé,
 * 7 derniers jours), on calcule pour chaque axe et chaque heure le facteur
 * de vitesse MÉDIAN réellement mesuré (vitesse / vitesse libre), séparé
 * semaine / week-end. Le moteur fusionne ensuite ce profil appris avec le
 * profil historique générique (poids croissant avec le nombre d'échantillons).
 *
 * Évaluation honnête : découpage temporel 80 % entraînement / 20 % test —
 * on compare, sur des points jamais vus à l'entraînement, l'erreur du
 * profil générique historique vs celle du profil appris.
 */

export interface TrainingResult {
  city: string;
  samplesTotal: number;
  samplesTrain: number;
  samplesTest: number;
  axesTrained: number;
  bucketsLearned: number;
  maeGenericKmh: number | null;
  maeLearnedKmh: number | null;
  improvementPct: number | null;
  /** Modèle de correction ML (intercept/pluie/signalements) entraîné en plus. */
  mlWeights?: { axes: number; avgHoldoutMae: number | null };
  trainedAt: string;
}

interface UsablePoint {
  axisId: string;
  at: Date; // instant local ville (composantes UTC = heure locale)
  speedKmh: number;
  factor: number;
}

function median(values: number[]): number {
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
}

async function collectPoints(city: CityDef): Promise<UsablePoint[]> {
  const since = new Date(Date.now() - 7 * 24 * 3600_000);
  const rows = await db
    .select()
    .from(telemetryPoints)
    .where(
      and(
        eq(telemetryPoints.city, city.id),
        isNotNull(telemetryPoints.axisId),
        gte(telemetryPoints.createdAt, since),
      ),
    )
    .limit(30000);
  const points: UsablePoint[] = [];
  for (const r of rows) {
    if (!r.axisId) continue;
    const axis = getAxis(city, r.axisId);
    if (!axis) continue;
    points.push({
      axisId: r.axisId,
      at: new Date(new Date(r.createdAt).getTime() + (city.tzOffsetMin ?? 0) * 60_000),
      speedKmh: r.speedKmh,
      factor: clamp(r.speedKmh / axis.freeFlowKmh, 0.05, 1.05),
    });
  }
  return points.sort((a, b) => a.at.getTime() - b.at.getTime());
}

type BucketMap = Map<string, number[]>; // "axisId|dayKind|hour" -> facteurs

function bucketize(points: UsablePoint[]): BucketMap {
  const map: BucketMap = new Map();
  for (const p of points) {
    const dow = p.at.getUTCDay();
    const key = `${p.axisId}|${dow}|${p.at.getUTCHours()}`;
    const list = map.get(key) ?? [];
    list.push(p.factor);
    map.set(key, list);
  }
  return map;
}

function learnedFromBuckets(buckets: BucketMap): Map<string, LearnedAxisProfile> {
  const byAxis = new Map<string, LearnedAxisProfile>();
  const kindPools = new Map<string, number[]>(); // "axisId|kind|hour" -> facteurs fusionnés
  for (const [key, values] of buckets) {
    if (values.length < 3) continue;
    const [axisId, dowStr, hourStr] = key.split("|");
    const dow = Number(dowStr);
    const hour = Number(hourStr);
    let profile = byAxis.get(axisId);
    if (!profile) {
      profile = {
        weekday: new Array(24).fill(null),
        weekend: new Array(24).fill(null),
        byDow: Array.from({ length: 7 }, () => new Array(24).fill(null)),
        samples: 0,
      };
      byAxis.set(axisId, profile);
    }
    profile.byDow![dow][hour] = Math.round(median(values) * 1000) / 1000;
    profile.samples += values.length;
    const kind = dow === 0 || dow === 6 ? "weekend" : "weekday";
    const kindKey = `${axisId}|${kind}|${hour}`;
    kindPools.set(kindKey, [...(kindPools.get(kindKey) ?? []), ...values]);
  }
  for (const [key, values] of kindPools) {
    if (values.length < 3) continue;
    const [axisId, kind, hourStr] = key.split("|");
    const profile = byAxis.get(axisId);
    if (!profile) continue;
    const arr = kind === "weekend" ? profile.weekend : profile.weekday;
    arr[Number(hourStr)] = Math.round(median(values) * 1000) / 1000;
  }
  return byAxis;
}



/* ------------------------------------------------------------------ */
/* Modèle de correction ML par axe (porté du MLEngine Rust)            */
/* ------------------------------------------------------------------ */

interface MlObservation {
  observed: number;
  baseline: number;
  rain: number;
  reports: number;
  /** Instant local de la ville (pour le facteur de profil horaire). */
  at: Date;
}

function mlPredict(w: { intercept: number; rainPenalty: number; reportPenalty: number }, o: MlObservation): number {
  return clamp(o.baseline * w.intercept - o.rain * w.rainPenalty - o.reports * w.reportPenalty, 5, o.baseline * 1.2);
}

/**
 * Entraîne les poids de correction par axe sur les observations terrain
 * (points GPS des 7 derniers jours) : séparation aléatoire seedée 80/20,
 * intercept = ratio moyen observé/base, pénalités pluie et signalements
 * = effets moyens mesurés, erreur honnête calculée sur le holdout.
 */
/** Calcule les poids ML depuis une liste d'observations (split seedé 80/20). */
export function computeWeightsFromObservations(
  axis: AxisDef,
  observations: MlObservation[],
): {
  intercept: number;
  rainPenalty: number;
  reportPenalty: number;
  trainProfileFactor: number;
  holdoutMae: number;
} | null {
  if (observations.length < 3) return null;
  const shuffled = [...observations].sort(
    (a, b) =>
      hashNoise(`w:${axis.id}:${a.observed}:${a.rain}:${a.reports}`) -
      hashNoise(`w:${axis.id}:${b.observed}:${b.rain}:${b.reports}`),
  );
  const splitIdx = Math.max(1, Math.floor(shuffled.length * 0.8));
  const train = shuffled.slice(0, splitIdx);
  const test = shuffled.slice(splitIdx);

  const intercept = clamp(
    train.reduce((a, o) => a + o.observed / o.baseline, 0) / train.length,
    0.5,
    1.2,
  );
  const rainy = train.filter((o) => o.rain > 0.1);
  const rainPenalty =
    rainy.length >= 2
      ? clamp(rainy.reduce((a, o) => a + (o.baseline - o.observed) / o.rain, 0) / rainy.length, 0, 8)
      : 0;
  const reported = train.filter((o) => o.reports > 0);
  const reportPenalty =
    reported.length >= 2
      ? clamp(reported.reduce((a, o) => a + (o.baseline - o.observed) / o.reports, 0) / reported.length, 0, 10)
      : 0;

  const w = { intercept, rainPenalty, reportPenalty };
  const evalSet = test.length > 0 ? test : train;
  const holdoutMae =
    evalSet.reduce((a, o) => a + Math.abs(mlPredict(w, o) - o.observed), 0) / evalSet.length;
  // Facteur de profil moyen pendant l'entraînement (correction en ratio).
  const trainProfileFactor =
    train.reduce((a, o) => a + profileFactor(axis, o.at), 0) / Math.max(1, train.length);
  return { intercept, rainPenalty, reportPenalty, trainProfileFactor, holdoutMae };
}

async function upsertAxisWeights(
  city: CityDef,
  axisId: string,
  w: {
    intercept: number;
    rainPenalty: number;
    reportPenalty: number;
    trainProfileFactor: number;
    holdoutMae: number;
  },
  samples: number,
): Promise<void> {
  const values = {
    intercept: Math.round(w.intercept * 1000) / 1000,
    rainPenalty: Math.round(w.rainPenalty * 100) / 100,
    reportPenalty: Math.round(w.reportPenalty * 100) / 100,
    trainProfileFactor: Math.round(w.trainProfileFactor * 1000) / 1000,
    samples,
    holdoutMae: Math.round(w.holdoutMae * 100) / 100,
    updatedAt: new Date(),
  };
  await db
    .insert(axisModelWeights)
    .values({ city: city.id, axisId, ...values })
    .onConflictDoUpdate({
      target: [axisModelWeights.city, axisModelWeights.axisId],
      set: values,
    });
  weightsCache.delete(city.id);
}

/**
 * Backfill unique : si la table d'observations est vide pour la ville,
 * on y projette les points GPS des 7 derniers jours (avec pluie et
 * nombre de signalements actifs au moment de chaque point).
 */
export async function ensureObservationsBackfill(city: CityDef): Promise<void> {
  try {
    const [existing] = await db
      .select({ n: count() })
      .from(mlObservations)
      .where(eq(mlObservations.city, city.id));
    if ((existing?.n ?? 0) > 0) return;

    const since = new Date(Date.now() - 7 * 24 * 3600_000);
    const rows = await db
      .select()
      .from(telemetryPoints)
      .where(
        and(
          eq(telemetryPoints.city, city.id),
          isNotNull(telemetryPoints.axisId),
          gte(telemetryPoints.createdAt, since),
        ),
      )
      .limit(30000);
    if (rows.length === 0) return;
    const broadcast = await db
      .select({ axisId: incidents.axisId, createdAt: incidents.createdAt })
      .from(incidents)
      .where(and(eq(incidents.city, city.id), eq(incidents.status, "broadcast")));

    const values: (typeof mlObservations.$inferInsert)[] = [];
    for (const r of rows) {
      if (!r.axisId) continue;
      const axis = getAxis(city, r.axisId);
      if (!axis) continue;
      const t = new Date(r.createdAt).getTime();
      const reports = broadcast.filter(
        (b) =>
          b.axisId === r.axisId &&
          new Date(b.createdAt).getTime() <= t + 30 * 60_000 &&
          new Date(b.createdAt).getTime() >= t - 2 * 3600_000,
      ).length;
      values.push({
        city: city.id,
        axisId: r.axisId,
        observedSpeedKmh: r.speedKmh,
        baselineSpeedKmh: axis.freeFlowKmh,
        rainMm: r.rainMm ?? 0,
        activeReports: reports,
        source: `backfill-${r.source}`,
        createdAt: new Date(r.createdAt),
      });
    }
    for (let i = 0; i < values.length; i += 500) {
      await db.insert(mlObservations).values(values.slice(i, i + 500));
    }
  } catch {
    /* backfill best-effort */
  }
}

/** Poids éphémères (non persistés) depuis les 50 dernières observations d'un axe. */
export async function ephemeralWeights(
  city: CityDef,
  axisId: string,
): Promise<{ weights: ReturnType<typeof computeWeightsFromObservations>; count: number }> {
  const observations = await observationsForAxis(city, axisId, 50);
  const axis = getAxis(city, axisId);
  return {
    weights: axis ? computeWeightsFromObservations(axis, observations) : null,
    count: observations.length,
  };
}

async function observationsForAxis(city: CityDef, axisId: string, limit = 50): Promise<MlObservation[]> {
  const rows = await db
    .select()
    .from(mlObservations)
    .where(and(eq(mlObservations.city, city.id), eq(mlObservations.axisId, axisId)))
    .orderBy(desc(mlObservations.createdAt))
    .limit(limit);
  return rows.map((r) => ({
    observed: r.observedSpeedKmh,
    baseline: r.baselineSpeedKmh,
    rain: r.rainMm,
    reports: r.activeReports,
    at: new Date(new Date(r.createdAt).getTime() + (city.tzOffsetMin ?? 0) * 60_000),
  }));
}

/**
 * Réentraînement d'UN axe (équivalent du tokio::spawn par edge du design) :
 * relit ses 50 dernières observations et met à jour ses poids persistés.
 * Déclenché en arrière-plan après chaque ingestion sur l'axe.
 */
export async function retrainAxisWeights(city: CityDef, axisId: string): Promise<boolean> {
  try {
    await ensureObservationsBackfill(city);
    const observations = await observationsForAxis(city, axisId, 50);
    const axis = getAxis(city, axisId);
    const w = axis ? computeWeightsFromObservations(axis, observations) : null;
    if (!w) return false;
    await upsertAxisWeights(city, axisId, w, observations.length);
    return true;
  } catch {
    return false;
  }
}

export async function trainAxisWeights(
  city: CityDef,
): Promise<{ axes: number; avgHoldoutMae: number | null }> {
  await ensureObservationsBackfill(city);
  let axes = 0;
  const maes: number[] = [];
  try {
    const since = new Date(Date.now() - 7 * 24 * 3600_000);
    const rows = await db
      .select()
      .from(mlObservations)
      .where(and(eq(mlObservations.city, city.id), gte(mlObservations.createdAt, since)))
      .limit(30000);
    const byAxis = new Map<string, MlObservation[]>();
    for (const r of rows) {
      const list = byAxis.get(r.axisId) ?? [];
      list.push({
        observed: r.observedSpeedKmh,
        baseline: r.baselineSpeedKmh,
        rain: r.rainMm,
        reports: r.activeReports,
        at: new Date(new Date(r.createdAt).getTime() + (city.tzOffsetMin ?? 0) * 60_000),
      });
      byAxis.set(r.axisId, list);
    }
    for (const [axisId, observations] of byAxis) {
      const axisDef = getAxis(city, axisId);
      const w = axisDef ? computeWeightsFromObservations(axisDef, observations) : null;
      if (!w) continue;
      await upsertAxisWeights(city, axisId, w, observations.length);
      axes++;
      maes.push(w.holdoutMae);
    }
  } catch {
    /* entraînement ML best-effort : les profils restent la référence */
  }
  return {
    axes,
    avgHoldoutMae: maes.length ? Math.round((maes.reduce((a, b) => a + b, 0) / maes.length) * 10) / 10 : null,
  };
}

const weightsCache = new Map<string, { at: number; weights: Map<string, AxisWeights> }>();
const WEIGHTS_CACHE_MS = 5 * 60_000;

/** Poids ML appris par axe (cache 5 min), utilisés par le moteur. */
export async function loadWeights(city: CityDef): Promise<Map<string, AxisWeights>> {
  const hit = weightsCache.get(city.id);
  if (hit && Date.now() - hit.at < WEIGHTS_CACHE_MS) return hit.weights;
  const weights = new Map<string, AxisWeights>();
  try {
    const rows = await db.select().from(axisModelWeights).where(eq(axisModelWeights.city, city.id));
    for (const r of rows) {
      weights.set(r.axisId, {
        intercept: r.intercept,
        rainPenalty: r.rainPenalty,
        reportPenalty: r.reportPenalty,
        trainProfileFactor: r.trainProfileFactor,
        samples: r.samples,
        holdoutMae: r.holdoutMae,
      });
    }
  } catch {
    /* poids indisponibles : prédictions historiques seules */
  }
  weightsCache.set(city.id, { at: Date.now(), weights });
  return weights;
}

export async function trainCityProfiles(city: CityDef): Promise<TrainingResult> {
  const points = await collectPoints(city);
  const result: TrainingResult = {
    city: city.id,
    samplesTotal: points.length,
    samplesTrain: 0,
    samplesTest: 0,
    axesTrained: 0,
    bucketsLearned: 0,
    maeGenericKmh: null,
    maeLearnedKmh: null,
    improvementPct: null,
    trainedAt: new Date().toISOString(),
  };

  // Le modèle de correction ML (poids par axe) s'entraîne dans le même job.
  result.mlWeights = await trainAxisWeights(city);

  if (points.length < 10) return result;

  // --- Évaluation holdout : 80 % plus anciens → entraînement, 20 % → test
  const cutoffIdx = Math.floor(points.length * 0.8);
  const trainPoints = points.slice(0, cutoffIdx);
  const testPoints = points.slice(cutoffIdx);
  result.samplesTrain = trainPoints.length;
  result.samplesTest = testPoints.length;

  const trainProfiles = learnedFromBuckets(bucketize(trainPoints));
  if (testPoints.length >= 5) {
    let errGeneric = 0;
    let errLearned = 0;
    let n = 0;
    for (const p of testPoints) {
      const axis = getAxis(city, p.axisId);
      if (!axis) continue;
      const genericKmh = axis.freeFlowKmh * profileFactor(axis, p.at);
      const learned = learnedFactorAt(trainProfiles.get(p.axisId), p.at);
      const prof = trainProfiles.get(p.axisId);
      const w = prof ? clamp(prof.samples / 48, 0, 0.8) : 0;
      const learnedKmh =
        learned !== null
          ? axis.freeFlowKmh * ((1 - w) * profileFactor(axis, p.at) + w * learned)
          : genericKmh;
      errGeneric += Math.abs(genericKmh - p.speedKmh);
      errLearned += Math.abs(learnedKmh - p.speedKmh);
      n++;
    }
    if (n > 0) {
      result.maeGenericKmh = Math.round((errGeneric / n) * 10) / 10;
      result.maeLearnedKmh = Math.round((errLearned / n) * 10) / 10;
      result.improvementPct =
        result.maeGenericKmh > 0
          ? Math.round((1 - result.maeLearnedKmh / result.maeGenericKmh) * 100)
          : 0;
    }
  }

  // --- Modèle final : entraîné sur 100 % des points, persisté en base
  const finalProfiles = learnedFromBuckets(bucketize(points));

  // Tendance récente par axe (dérive 72 h, esprit Prophet) : ratio moyen
  // observé / prédit par le profil générique sur les 3 derniers jours.
  const nowLocal = new Date(Date.now() + (city.tzOffsetMin ?? 0) * 60_000);
  const cutoff72 = nowLocal.getTime() - 72 * 3600_000;
  const trendByAxis = new Map<string, { sum: number; n: number }>();
  for (const p of points) {
    if (p.at.getTime() < cutoff72) continue;
    const axis = getAxis(city, p.axisId);
    if (!axis) continue;
    const predicted = axis.freeFlowKmh * profileFactor(axis, p.at);
    if (predicted <= 0) continue;
    const agg = trendByAxis.get(p.axisId) ?? { sum: 0, n: 0 };
    agg.sum += p.speedKmh / predicted;
    agg.n++;
    trendByAxis.set(p.axisId, agg);
  }
  for (const [axisId, agg] of trendByAxis) {
    if (agg.n < 5) continue;
    const profile = finalProfiles.get(axisId);
    if (profile) profile.trendFactor = Math.round(clamp(agg.sum / agg.n, 0.85, 1.1) * 1000) / 1000;
  }

  const now = new Date();
  let bucketsLearned = 0;
  const persistRow = async (axisId: string, hour: number, dayKind: string, factor: number, samples: number) => {
    bucketsLearned++;
    await db
      .insert(axisProfiles)
      .values({ city: city.id, axisId, hour, dayKind, factor, samples, updatedAt: now })
      .onConflictDoUpdate({
        target: [axisProfiles.city, axisProfiles.axisId, axisProfiles.hour, axisProfiles.dayKind],
        set: { factor, samples, updatedAt: now },
      });
  };
  for (const [axisId, profile] of finalProfiles) {
    for (const dayKind of ["weekday", "weekend"] as const) {
      const arr = dayKind === "weekend" ? profile.weekend : profile.weekday;
      for (let hour = 0; hour < 24; hour++) {
        const factor = arr[hour];
        if (factor === null) continue;
        await persistRow(axisId, hour, dayKind, factor, profile.samples);
      }
    }
    if (profile.byDow) {
      for (let d = 0; d < 7; d++) {
        for (let hour = 0; hour < 24; hour++) {
          const factor = profile.byDow[d][hour];
          if (factor === null) continue;
          await persistRow(axisId, hour, `dow-${d}`, factor, profile.samples);
        }
      }
    }
    if (profile.trendFactor) {
      await persistRow(axisId, 0, "trend", profile.trendFactor, profile.samples);
    }
  }
  result.axesTrained = finalProfiles.size;
  result.bucketsLearned = bucketsLearned;

  // Persiste l'évaluation holdout (preuve hors échantillon, durable).
  try {
    await db.insert(modelEvaluations).values({
      city: city.id,
      samplesTotal: result.samplesTotal,
      samplesTrain: result.samplesTrain,
      samplesTest: result.samplesTest,
      axesTrained: result.axesTrained,
      maeGenericKmh: result.maeGenericKmh,
      maeLearnedKmh: result.maeLearnedKmh,
      improvementPct: result.improvementPct,
    });
    evalCache.delete(city.id);
  } catch {
    /* l'évaluation reste consultable via la réponse d'entraînement */
  }

  profilesCache.delete(city.id);
  lastTrainAt.set(city.id, Date.now());
  // Invalide les caches de métriques/validation qui précèdent l'entraînement.
  (globalThis as { __afriModelVersion?: number }).__afriModelVersion = Date.now();
  return result;
}

/** Horodatage du dernier entraînement (pour invalider les caches aval). */
export function modelVersion(): number {
  return (globalThis as { __afriModelVersion?: number }).__afriModelVersion ?? 0;
}

/* ------------------- Dernière évaluation persistée ------------------- */

export interface HoldoutEvaluation {
  trainedAt: string;
  samplesTotal: number;
  samplesTest: number;
  axesTrained: number;
  maeGenericKmh: number | null;
  maeLearnedKmh: number | null;
  improvementPct: number | null;
}

const evalCache = new Map<string, { at: number; value: HoldoutEvaluation | null }>();
const EVAL_CACHE_MS = 60_000;

/** Dernière évaluation holdout persistée de la ville (preuve durable). */
export async function getLastEvaluation(city: CityDef): Promise<HoldoutEvaluation | null> {
  const hit = evalCache.get(city.id);
  if (hit && Date.now() - hit.at < EVAL_CACHE_MS) return hit.value;
  let value: HoldoutEvaluation | null = null;
  try {
    const rows = await db
      .select()
      .from(modelEvaluations)
      .where(eq(modelEvaluations.city, city.id))
      .orderBy(desc(modelEvaluations.id))
      .limit(1);
    if (rows.length > 0) {
      const r = rows[0];
      value = {
        trainedAt: new Date(r.trainedAt).toISOString(),
        samplesTotal: r.samplesTotal,
        samplesTest: r.samplesTest,
        axesTrained: r.axesTrained,
        maeGenericKmh: r.maeGenericKmh,
        maeLearnedKmh: r.maeLearnedKmh,
        improvementPct: r.improvementPct,
      };
    }
  } catch {
    value = null;
  }
  evalCache.set(city.id, { at: Date.now(), value });
  return value;
}

/* ------------------------- Chargement (cache) ------------------------- */

const profilesCache = new Map<string, { at: number; profiles: Map<string, LearnedAxisProfile> }>();
const PROFILES_CACHE_MS = 5 * 60_000;

export async function loadProfiles(city: CityDef): Promise<Map<string, LearnedAxisProfile>> {
  const hit = profilesCache.get(city.id);
  if (hit && Date.now() - hit.at < PROFILES_CACHE_MS) return hit.profiles;
  const profiles = new Map<string, LearnedAxisProfile>();
  try {
    const rows = await db.select().from(axisProfiles).where(eq(axisProfiles.city, city.id));
    for (const r of rows) {
      let profile = profiles.get(r.axisId);
      if (!profile) {
        profile = {
          weekday: new Array(24).fill(null),
          weekend: new Array(24).fill(null),
          byDow: Array.from({ length: 7 }, () => new Array(24).fill(null)),
          samples: 0,
        };
        profiles.set(r.axisId, profile);
      }
      if (r.dayKind === "trend") {
        profile.trendFactor = r.factor;
        continue;
      }
      if (r.dayKind.startsWith("dow-")) {
        const d = Number(r.dayKind.slice(4));
        if (d >= 0 && d < 7 && r.hour >= 0 && r.hour < 24) {
          profile.byDow![d][r.hour] = r.factor;
        }
        profile.samples = Math.max(profile.samples, r.samples);
        continue;
      }
      const arr = r.dayKind === "weekend" ? profile.weekend : profile.weekday;
      if (r.hour >= 0 && r.hour < 24) arr[r.hour] = r.factor;
      profile.samples = Math.max(profile.samples, r.samples);
    }
  } catch {
    /* profils indisponibles : le moteur reste sur l'historique générique */
  }
  profilesCache.set(city.id, { at: Date.now(), profiles });
  return profiles;
}

/* --------------------- Réentraînement automatique --------------------- */

const lastTrainAt = new Map<string, number>();
const trainInflight = new Map<string, Promise<unknown>>();
const RETRAIN_MS = 6 * 3600_000;

function launchRetrain(city: CityDef): Promise<unknown> {
  const task = trainCityProfiles(city)
    .catch(() => undefined)
    .finally(() => trainInflight.delete(city.id));
  trainInflight.set(city.id, task);
  return task;
}

/**
 * Réentraîne en arrière-plan si les profils ont plus de 6 h (jamais
 * bloquant). La fraîcheur est relue en base (max des updated_at des
 * profils) : le mécanisme survit donc aux redémarrages du serveur.
 */
export async function maybeRetrain(city: CityDef): Promise<unknown> {
  if (trainInflight.has(city.id)) return trainInflight.get(city.id);
  const last = lastTrainAt.get(city.id);
  if (last !== undefined) {
    if (Date.now() - last < RETRAIN_MS) return;
    return launchRetrain(city);
  }
  // Premier appel depuis le démarrage : fraîcheur relue en base.
  trainInflight.set(city.id, Promise.resolve());
  return (async () => {
    let stamp = 0;
    try {
      const [row] = await db
        .select({ m: sql<string | null>`max(${axisProfiles.updatedAt})` })
        .from(axisProfiles)
        .where(eq(axisProfiles.city, city.id));
      if (row?.m) stamp = new Date(row.m).getTime();
    } catch {
      stamp = 0;
    }
    lastTrainAt.set(city.id, stamp);
    trainInflight.delete(city.id);
    if (Date.now() - stamp >= RETRAIN_MS) return launchRetrain(city);
  })();
}
