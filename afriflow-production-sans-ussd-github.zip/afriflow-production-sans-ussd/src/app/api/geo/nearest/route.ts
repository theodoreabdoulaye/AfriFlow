import { NextRequest, NextResponse } from "next/server";
import { CITY_MAP, getAxis } from "@/lib/cities";
import { reversePlace } from "@/lib/geocode";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { nearestAxisFast } from "@/lib/spatial";

export const dynamic = "force-dynamic";

/**
 * GET /api/geo/nearest?city=dakar&lat=..&lon=.. — map matching d'une
 * position (géolocalisation navigateur) : axe surveillé le plus proche
 * via l'index spatial, distance, et adresse approximative (Nominatim).
 * Sert au pré-remplissage intelligent du formulaire de signalement.
 */
export async function GET(req: NextRequest) {
  const rl = rateLimit(`geonearest:${clientIp(req)}`, 60, 60_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  const city = CITY_MAP[req.nextUrl.searchParams.get("city") ?? "dakar"];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });
  const lat = Number(req.nextUrl.searchParams.get("lat"));
  const lon = Number(req.nextUrl.searchParams.get("lon"));
  if (!Number.isFinite(lat) || !Number.isFinite(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    return NextResponse.json({ error: "Coordonnées invalides" }, { status: 422 });
  }

  const found = nearestAxisFast(city, lat, lon, 3000);
  if (!found) {
    return NextResponse.json(
      { error: "Aucun axe surveillé à moins de 3 km de votre position." },
      { status: 422 },
    );
  }
  const place = await reversePlace(city, lat, lon);
  const axis = getAxis(city, found.axis.id);
  return NextResponse.json({
    city: city.id,
    axisId: found.axis.id,
    axisName: axis?.name ?? found.axis.name,
    distanceM: found.distanceM,
    place,
  });
}
