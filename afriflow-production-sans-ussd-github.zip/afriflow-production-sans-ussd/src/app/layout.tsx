import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import { Inter, JetBrains_Mono, Space_Grotesk } from "next/font/google";
import { CITY_COUNT, COUNTRY_COUNT } from "@/lib/cities";
import { headers } from "next/headers";
import { SecurityNonce } from "@/components/SecurityNonce";
import "./globals.css";

// Polices auto-hébergées par Next (fichiers servis en même origine,
// display: swap) : supprime le rendu bloqué par Google Fonts.
const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const grotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-grotesk", display: "swap" });
const jetbrains = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono-jb", display: "swap" });

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "https://afriflow.app"),
  title: "AfriFlow — Trafic en temps réel",
  description: `AfriFlow anticipe les embouteillages 30 à 60 minutes à l'avance dans ${CITY_COUNT} villes et ${COUNTRY_COUNT} pays d'Afrique — tout le continent. Signalements communautaires dans l'application web.`,
  keywords: [
    "trafic temps réel",
    "Afrique de l'Ouest",
    "Dakar",
    "Lagos",
    "Abidjan",
    "embouteillages",
    "itinéraire ventilé",
  ],
  authors: [{ name: "AfriFlow" }],
  icons: {
    icon: "/icons/icon-512.png",
    apple: "/icons/icon-512.png",
  },
  openGraph: {
    type: "website",
    locale: "fr_FR",
    title: "AfriFlow — Les bouchons se prévoient. La ville respire.",
    description:
      `Trafic temps réel et prédictif pour ${CITY_COUNT} villes (${COUNTRY_COUNT} pays), sans aucun capteur coûteux. Signalements communautaires dans l'application web.`,
    siteName: "AfriFlow",
    images: [{ url: "/icons/icon-512.png", width: 512, height: 512, alt: "AfriFlow" }],
  },
  twitter: {
    card: "summary",
    title: "AfriFlow — Trafic en temps réel",
    description: `Bouchons prévus 30 à 60 min à l'avance dans ${CITY_COUNT} villes (${COUNTRY_COUNT} pays). Signalements communautaires.`,
    images: ["/icons/icon-512.png"],
  },
};

export const viewport: Viewport = {
  themeColor: "#060f0a",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const nonce = (await headers()).get("x-nonce") ?? undefined;
  return (
    <html lang="fr" className={`${inter.variable} ${grotesk.variable} ${jetbrains.variable}`}>
      <body className="bg-night-950 font-sans text-paper antialiased"><SecurityNonce nonce={nonce}>{children}</SecurityNonce></body>
    </html>
  );
}
