import type { CityDef } from "./cities";
import { getZone } from "./cities";
import {
  findRoutes,
  haversineKm,
  type AxisLiveState,
  type RoutePriorities,
  type VehicleProfile,
} from "./engine";
import {
  nearestStop,
  nextDeparture,
  terDurationMinutes,
  transitStopsFor,
  zoneLatLon,
  type TransitStop,
} from "./transit";

/**
 * Routage MULTIMODAL (porté du design Rust) : combine le moteur de
 * routage ventilé existant (voiture) avec le réseau de transport
 * collectif (TER, BRT, Car Rapide) et la marche — options Voiture directe,
 * Park & Ride (voiture → TER → marche) et Transit seul, notées en durée,
 * coût FCFA, CO₂, confort et fiabilité.
 */

export type MultimodalMode = "car" | "ter" | "brt" | "carrapide" | "walking" | "bike";

export interface RouteSegment {
  mode: MultimodalMode;
  fromName: string;
  toName: string;
  durationMin: number;
  distanceKm: number;
  costFcfa: number;
  departureTime: string | null;
  walkingDistanceM: number;
}

export interface MultimodalRoute {
  id: string;
  kind: "voiture" | "park-and-ride" | "transit" | "marche";
  label: string;
  segments: RouteSegment[];
  totalDurationMin: number;
  totalCostFcfa: number;
  co2Kg: number;
  comfortScore: number;
  reliabilityScore: number;
}

export interface RoutingPreferences {
  allowCar: boolean;
  allowTransit: boolean;
  allowParkAndRide: boolean;
  maxWalkingDistanceM: number;
  prioritize: "time" | "cost" | "comfort" | "eco";
}

export const DEFAULT_PREFS: RoutingPreferences = {
  allowCar: true,
  allowTransit: true,
  allowParkAndRide: true,
  maxWalkingDistanceM: 1200,
  prioritize: "time",
};

const WALK_M_PER_MIN = 80;

function nearestZoneId(city: CityDef, lat: number, lon: number): string | null {
  let best: string | null = null;
  let bestDist = Infinity;
  for (const zone of city.zones) {
    const coords = zoneLatLon(city, zone.id);
    if (!coords) continue;
    const d = haversineKm([lat, lon], coords);
    if (d < bestDist) {
      bestDist = d;
      best = zone.id;
    }
  }
  return best;
}

function carRouteBetween(
  city: CityDef,
  states: AxisLiveState[],
  fromCoords: [number, number],
  toCoords: [number, number],
  weather: Parameters<typeof findRoutes>[5],
  profile: VehicleProfile,
): { minutes: number; distanceKm: number; fuelFcfa: number; fluidityAvg: number } | null {
  const fromZone = nearestZoneId(city, fromCoords[0], fromCoords[1]);
  const toZone = nearestZoneId(city, toCoords[0], toCoords[1]);
  if (!fromZone || !toZone || fromZone === toZone) {
    // Même zone : estimation routière directe à vol d'oiseau.
    const km = haversineKm(fromCoords, toCoords) * 1.3;
    return { minutes: Math.max(3, Math.round((km / 22) * 60)), distanceKm: Math.round(km * 10) / 10, fuelFcfa: Math.round(km * 95), fluidityAvg: 65 };
  }
  const prio: RoutePriorities = { time: true, fuel: true, safety: false, practicability: true };
  const routes = findRoutes(city, states, fromZone, toZone, prio, weather, { grantedByAxis: new Map() }, new Date(), profile);
  const best = routes.find((r) => r.status === "recommande") ?? routes[0];
  if (!best) return null;
  return {
    minutes: best.minutes,
    distanceKm: best.distanceKm,
    fuelFcfa: best.fuelFcfa,
    fluidityAvg: best.fluidityAvg,
  };
}

function walkSegment(fromName: string, toName: string, distanceKm: number): RouteSegment {
  return {
    mode: "walking",
    fromName,
    toName,
    durationMin: Math.max(1, Math.round((distanceKm * 1000) / WALK_M_PER_MIN)),
    distanceKm: Math.round(distanceKm * 100) / 100,
    costFcfa: 0,
    departureTime: null,
    walkingDistanceM: Math.round(distanceKm * 1000),
  };
}

function railRide(
  board: TransitStop,
  alight: TransitStop,
): { durationMin: number; distanceKm: number; costFcfa: number } | null {
  const railKm = haversineKm([board.lat, board.lon], [alight.lat, alight.lon]) * 1.15;
  if (board.mode === "ter") {
    const duration = terDurationMinutes(board.id, alight.id);
    if (duration === null) return null;
    return { durationMin: duration, distanceKm: Math.round(railKm * 10) / 10, costFcfa: 1500 };
  }
  if (board.mode === "brt") {
    // Tronçons BRT ≈ 8 min entre stations de la ligne.
    const stops = transitStopsFor({ id: "dakar" } as CityDef).filter((s) => s.mode === "brt");
    const i = stops.findIndex((s) => s.id === board.id);
    const j = stops.findIndex((s) => s.id === alight.id);
    if (i < 0 || j < 0 || i === j) return null;
    return { durationMin: Math.abs(i - j) * 8, distanceKm: Math.round(railKm * 10) / 10, costFcfa: 500 };
  }
  return null;
}

export interface MultimodalInput {
  city: CityDef;
  states: AxisLiveState[];
  weather: Parameters<typeof findRoutes>[5];
  from: { lat: number; lon: number; label: string };
  to: { lat: number; lon: number; label: string };
  prefs: RoutingPreferences;
  atLocal: Date;
  profile?: VehicleProfile;
}

export function findMultimodalRoutes(input: MultimodalInput): MultimodalRoute[] {
  const { city, states, weather, from, to, prefs, atLocal } = input;
  const profile = input.profile ?? "standard";
  const stops = transitStopsFor(city);
  const routes: MultimodalRoute[] = [];
  const totalDirectKm = haversineKm([from.lat, from.lon], [to.lat, to.lon]);

  // --- Option Voiture directe (moteur ventilé) ---
  if (prefs.allowCar) {
    const car = carRouteBetween(city, states, [from.lat, from.lon], [to.lat, to.lon], weather, profile);
    if (car) {
      routes.push({
        id: "voiture",
        kind: "voiture",
        label: "Voiture directe (itinéraire ventilé)",
        segments: [
          {
            mode: "car",
            fromName: from.label,
            toName: to.label,
            durationMin: car.minutes,
            distanceKm: car.distanceKm,
            costFcfa: car.fuelFcfa,
            departureTime: null,
            walkingDistanceM: 0,
          },
        ],
        totalDurationMin: car.minutes,
        totalCostFcfa: car.fuelFcfa,
        co2Kg: Math.round(car.distanceKm * 0.192 * 100) / 100,
        comfortScore: Math.round(45 + car.fluidityAvg * 0.35),
        reliabilityScore: Math.round(car.fluidityAvg),
      });
    }
  }

  // --- Marche intégrale (courtes distances) ---
  if (totalDirectKm <= 2.5) {
    const walk = walkSegment(from.label, to.label, totalDirectKm);
    routes.push({
      id: "marche",
      kind: "marche",
      label: "À pied",
      segments: [walk],
      totalDurationMin: walk.durationMin,
      totalCostFcfa: 0,
      co2Kg: 0,
      comfortScore: 40,
      reliabilityScore: 95,
    });
  }

  // --- Journeys rail (TER / BRT) : transit seul et Park & Ride ---
  const railModes: ("ter" | "brt")[] = ["ter", "brt"];
  for (const mode of railModes) {
    const boardNear = nearestStop(stops, from.lat, from.lon, mode);
    const alightNear = nearestStop(stops, to.lat, to.lon, mode);
    if (!boardNear || !alightNear || boardNear.stop.id === alightNear.stop.id) continue;
    const ride = railRide(boardNear.stop, alightNear.stop);
    if (!ride) continue;
    const departure = nextDeparture(boardNear.stop, atLocal);
    const modeLabel = mode === "ter" ? "TER" : "BRT";
    const comfort = mode === "ter" ? 80 : 74;
    const reliability = mode === "ter" ? 90 : 80;

    // Transit seul : marche + rail + marche.
    if (
      prefs.allowTransit &&
      boardNear.distanceKm * 1000 <= prefs.maxWalkingDistanceM &&
      alightNear.distanceKm * 1000 <= prefs.maxWalkingDistanceM
    ) {
      const w1 = walkSegment(from.label, boardNear.stop.name, boardNear.distanceKm);
      const w2 = walkSegment(alightNear.stop.name, to.label, alightNear.distanceKm);
      const total = w1.durationMin + departure.waitMinutes + ride.durationMin + w2.durationMin;
      routes.push({
        id: `transit-${mode}`,
        kind: "transit",
        label: `${modeLabel} direct (marche + ${modeLabel})`,
        segments: [
          w1,
          {
            mode,
            fromName: boardNear.stop.name,
            toName: alightNear.stop.name,
            durationMin: ride.durationMin,
            distanceKm: ride.distanceKm,
            costFcfa: ride.costFcfa,
            departureTime: departure.inService ? departure.time : `${departure.time} (hors service)`,
            walkingDistanceM: 0,
          },
          w2,
        ],
        totalDurationMin: total,
        totalCostFcfa: ride.costFcfa,
        co2Kg: Math.round(ride.distanceKm * 0.03 * 100) / 100,
        comfortScore: comfort,
        reliabilityScore: reliability,
      });
    }

    // Park & Ride : voiture jusqu'à la gare (avec parking), rail, marche.
    if (prefs.allowParkAndRide && boardNear.stop.parkingSpots > 0) {
      const drive = carRouteBetween(
        city,
        states,
        [from.lat, from.lon],
        [boardNear.stop.lat, boardNear.stop.lon],
        weather,
        profile,
      );
      if (drive && alightNear.distanceKm * 1000 <= Math.max(prefs.maxWalkingDistanceM, 1500)) {
        const w2 = walkSegment(alightNear.stop.name, to.label, alightNear.distanceKm);
        const total = drive.minutes + departure.waitMinutes + ride.durationMin + w2.durationMin;
        routes.push({
          id: `pr-${mode}`,
          kind: "park-and-ride",
          label: `Park & Ride (voiture → ${modeLabel} → marche)`,
          segments: [
            {
              mode: "car",
              fromName: from.label,
              toName: `${boardNear.stop.name} (parking ${boardNear.stop.parkingSpots} places)`,
              durationMin: drive.minutes,
              distanceKm: drive.distanceKm,
              costFcfa: drive.fuelFcfa + 500,
              departureTime: null,
              walkingDistanceM: 0,
            },
            {
              mode,
              fromName: boardNear.stop.name,
              toName: alightNear.stop.name,
              durationMin: ride.durationMin,
              distanceKm: ride.distanceKm,
              costFcfa: ride.costFcfa,
              departureTime: departure.inService ? departure.time : `${departure.time} (hors service)`,
              walkingDistanceM: 0,
            },
            w2,
          ],
          totalDurationMin: total,
          totalCostFcfa: drive.fuelFcfa + 500 + ride.costFcfa,
          co2Kg: Math.round((drive.distanceKm * 0.192 + ride.distanceKm * 0.03) * 100) / 100,
          comfortScore: comfort,
          reliabilityScore: reliability,
        });
      }
    }
  }

  // --- Car Rapide / Gbaka (transport informel, toutes villes) ---
  if (prefs.allowTransit) {
    const hubFrom = nearestStop(stops, from.lat, from.lon, "carrapide");
    const hubTo = nearestStop(stops, to.lat, to.lon, "carrapide");
    if (hubFrom && hubTo) {
      const rideKm = Math.max(1.2, haversineKm([hubFrom.stop.lat, hubFrom.stop.lon], [hubTo.stop.lat, hubTo.stop.lon]) * 1.25);
      const rideMin = Math.round((rideKm / 20) * 60) + 3;
      const fare = Math.min(900, 250 + Math.round(rideKm * 30));
      const w1 = walkSegment(from.label, hubFrom.stop.name, hubFrom.distanceKm);
      const w2 = walkSegment(hubTo.stop.name, to.label, hubTo.distanceKm);
      if (
        hubFrom.distanceKm * 1000 <= prefs.maxWalkingDistanceM + 600 &&
        hubTo.distanceKm * 1000 <= prefs.maxWalkingDistanceM + 600
      ) {
        routes.push({
          id: "carrapide",
          kind: "transit",
          label: "Car Rapide / Gbaka (transport informel)",
          segments: [
            w1,
            {
              mode: "carrapide",
              fromName: hubFrom.stop.name,
              toName: hubTo.stop.name,
              durationMin: rideMin,
              distanceKm: Math.round(rideKm * 10) / 10,
              costFcfa: fare,
              departureTime: null,
              walkingDistanceM: 0,
            },
            w2,
          ],
          totalDurationMin: w1.durationMin + rideMin + w2.durationMin,
          totalCostFcfa: fare,
          co2Kg: Math.round(rideKm * 0.09 * 100) / 100,
          comfortScore: 45,
          reliabilityScore: 55,
        });
      }
    }
  }

  // Tri selon la priorité choisie.
  const score = (r: MultimodalRoute): number => {
    switch (prefs.prioritize) {
      case "cost":
        return r.totalCostFcfa + r.totalDurationMin * 5;
      case "comfort":
        return r.totalDurationMin - r.comfortScore * 1.5;
      case "eco":
        return r.co2Kg * 20 + r.totalDurationMin * 0.3;
      default:
        return r.totalDurationMin + r.totalCostFcfa * 0.01;
    }
  };
  return routes.sort((a, b) => score(a) - score(b)).slice(0, 4);
}

/* ------------------------------------------------------------------ */
/* Parkings : occupation modélisée + prédiction à 30 min               */
/* ------------------------------------------------------------------ */

export interface ParkingLotLike {
  id: number;
  totalSpots: number;
  currentOccupancy: number | null;
  occupancyUpdatedAt: Date | string | null;
  parkingType: string;
}

function hashUnit(seed: string): number {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return ((h >>> 0) % 1000) / 1000;
}

/** Profil d'occupation par heure (0..1) selon le type de parking. */
function occupancyProfile(type: string, hourFloat: number): number {
  const peak = (mu: number, sigma: number) =>
    Math.exp(-((hourFloat - mu) ** 2) / (2 * sigma * sigma));
  let ratio: number;
  switch (type) {
    case "ParkAndRide":
      ratio = 0.3 + 0.55 * peak(8.5, 1.6) + 0.4 * peak(18, 2);
      break;
    case "ShoppingMall":
      ratio = 0.25 + 0.5 * peak(13, 3.2) + 0.35 * peak(19.5, 2.2);
      break;
    case "Street":
      ratio = 0.45 + 0.35 * peak(10, 3.5);
      break;
    default:
      ratio = 0.35 + 0.45 * peak(9, 2.6) + 0.3 * peak(18.5, 2.4);
  }
  return Math.min(0.97, Math.max(0.06, ratio));
}

/** Occupation effective : réelle si fraîche (< 2 h), modélisée sinon. */
export function effectiveOccupancy(
  lot: ParkingLotLike,
  atLocal: Date,
): { occupancy: number; ratio: number; source: "réelle" | "modèle" } {
  if (
    lot.currentOccupancy !== null &&
    lot.occupancyUpdatedAt &&
    Date.now() - new Date(lot.occupancyUpdatedAt).getTime() < 2 * 3600_000
  ) {
    return {
      occupancy: lot.currentOccupancy,
      ratio: Math.min(1, lot.currentOccupancy / Math.max(1, lot.totalSpots)),
      source: "réelle",
    };
  }
  const hourFloat = atLocal.getUTCHours() + atLocal.getUTCMinutes() / 60;
  const ratio =
    occupancyProfile(lot.parkingType, hourFloat) * (0.88 + hashUnit(`lot:${lot.id}`) * 0.2);
  return {
    occupancy: Math.round(lot.totalSpots * Math.min(0.97, ratio)),
    ratio: Math.min(0.97, ratio),
    source: "modèle",
  };
}

/** Disponibilité (%) actuelle et prédite dans 30 minutes. */
export function parkingAvailability(lot: ParkingLotLike, atLocal: Date): {
  availableSpots: number;
  availabilityPct: number;
  predictedAvailabilityPct: number;
  source: "réelle" | "modèle";
} {
  const now = effectiveOccupancy(lot, atLocal);
  const in30 = new Date(atLocal.getTime() + 30 * 60_000);
  const next =
    now.source === "réelle"
      ? {
          ratio:
            occupancyProfile(lot.parkingType, in30.getUTCHours() + in30.getUTCMinutes() / 60) *
            (lot.currentOccupancy! / Math.max(1, lot.totalSpots) > 0.85 ? 1.02 : 0.92),
        }
      : effectiveOccupancy({ ...lot, currentOccupancy: null, occupancyUpdatedAt: null }, in30);
  return {
    availableSpots: Math.max(0, lot.totalSpots - now.occupancy),
    availabilityPct: Math.round((1 - now.ratio) * 100),
    predictedAvailabilityPct: Math.round((1 - Math.min(0.98, next.ratio)) * 100),
    source: now.source,
  };
}

/* ------------------------------------------------------------------ */
/* Covoiturage : appariement offres / demandes                         */
/* ------------------------------------------------------------------ */

export interface CarpoolOfferLike {
  id: number;
  driverName: string;
  fromLat: number;
  fromLon: number;
  toLat: number;
  toLon: number;
  fromLabel: string;
  toLabel: string;
  departureTime: Date | string;
  seatsTotal: number;
  seatsTaken: number;
  pricePerSeatFcfa: number;
  vehicleType: string;
}

export function matchCarpoolOffers(
  offers: CarpoolOfferLike[],
  request: {
    fromLat: number;
    fromLon: number;
    toLat: number;
    toLon: number;
    desiredDeparture: Date;
    maxPriceFcfa: number;
  },
): {
  offer: CarpoolOfferLike;
  compatibilityScore: number;
  detourMinutes: number;
  pickupPoint: { lat: number; lon: number };
  seatsLeft: number;
}[] {
  const distKm = (aLat: number, aLon: number, bLat: number, bLon: number) =>
    haversineKm([aLat, aLon], [bLat, bLon]);

  return offers
    .filter((o) => o.pricePerSeatFcfa <= request.maxPriceFcfa && o.seatsTaken < o.seatsTotal)
    .map((offer) => {
      const startKm = distKm(offer.fromLat, offer.fromLon, request.fromLat, request.fromLon);
      const endKm = distKm(offer.toLat, offer.toLon, request.toLat, request.toLon);
      const routeCompat =
        startKm < 1 && endKm < 1 ? 100 : startKm < 2 && endKm < 2 ? 80 : startKm < 4 && endKm < 4 ? 62 : 40;
      const diffMin = Math.abs(
        (new Date(offer.departureTime).getTime() - request.desiredDeparture.getTime()) / 60_000,
      );
      const timeCompat = diffMin <= 15 ? 100 : diffMin <= 30 ? 80 : diffMin <= 60 ? 60 : 30;
      const compatibilityScore = Math.round((routeCompat + timeCompat) / 2);
      return {
        offer,
        compatibilityScore,
        detourMinutes: Math.round((startKm + endKm) * 1.4) + 3,
        pickupPoint: {
          lat: Math.round(((offer.fromLat + request.fromLat) / 2) * 1e6) / 1e6,
          lon: Math.round(((offer.fromLon + request.fromLon) / 2) * 1e6) / 1e6,
        },
        seatsLeft: offer.seatsTotal - offer.seatsTaken,
      };
    })
    .filter((m) => m.compatibilityScore >= 45)
    .sort((a, b) => b.compatibilityScore - a.compatibilityScore)
    .slice(0, 5);
}
