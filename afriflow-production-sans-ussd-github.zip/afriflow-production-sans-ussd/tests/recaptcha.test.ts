import { test } from "node:test";
import assert from "node:assert/strict";
import { verifyRecaptcha } from "../src/lib/recaptcha";

test("reCAPTCHA rejects missing configuration, bad action, hostname and low score", async () => {
  const originalFetch = globalThis.fetch;
  const secret = process.env.RECAPTCHA_SECRET_KEY;
  try {
    delete process.env.RECAPTCHA_SECRET_KEY;
    assert.equal(await verifyRecaptcha("token", "login", "https://example.com"), false);
    process.env.RECAPTCHA_SECRET_KEY = "test-secret";
    assert.equal(await verifyRecaptcha(null, "login", "https://example.com"), false);
    for (const [action, hostname, score, expected] of [
      ["login", "example.com", 0.9, true],
      ["register", "example.com", 0.9, false],
      ["login", "attacker.com", 0.9, false],
      ["login", "example.com", 0.1, false],
    ] as const) {
      globalThis.fetch = async () => Response.json({ success: true, action, hostname, score });
      assert.equal(await verifyRecaptcha("token", "login", "https://example.com"), expected);
    }
  } finally {
    globalThis.fetch = originalFetch;
    if (secret === undefined) delete process.env.RECAPTCHA_SECRET_KEY;
    else process.env.RECAPTCHA_SECRET_KEY = secret;
  }
});
