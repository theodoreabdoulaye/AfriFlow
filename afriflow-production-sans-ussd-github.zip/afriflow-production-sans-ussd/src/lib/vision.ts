/**
 * Vision par ordinateur (YOLOv8 via Roboflow) : détection automatique
 * des dégradations routières sur les photos envoyées par les usagers
 * (nid-de-poule, inondation, fissures) pour valider un signalement sans
 * intervention humaine.
 *
 * Activation par variables d'environnement (ROBOFLOW_API_KEY +
 * ROBOFLOW_MODEL_ID, ex. "road-damage-detection/2"). Sans clé, le module
 * le dit honnêtement et le bot retombe sur la description texte.
 */

export interface VisionDetection {
  className: string;
  confidence: number; // 0..1
  incidentType: string | null; // type AfriFlow déduit
}

export interface VisionResult {
  configured: boolean;
  detections: VisionDetection[];
  topType: string | null;
  topConfidence: number;
}

export function visionConfigured(): boolean {
  return !!(process.env.ROBOFLOW_API_KEY && process.env.ROBOFLOW_MODEL_ID);
}

function classToIncidentType(className: string): string | null {
  const c = className.toLowerCase();
  if (c.includes("pothole") || c.includes("pot_hole")) return "nid_de_poule";
  if (c.includes("flood") || c.includes("water") || c.includes("inond")) return "inondation";
  if (c.includes("crack") || c.includes("damage") || c.includes("degrad")) return "danger";
  return null;
}

/** Envoie une image au modèle hébergé Roboflow et mappe les détections. */
export async function detectRoadDamage(imageBytes: ArrayBuffer): Promise<VisionResult> {
  if (!visionConfigured()) {
    return { configured: false, detections: [], topType: null, topConfidence: 0 };
  }
  const apiKey = process.env.ROBOFLOW_API_KEY!;
  const modelId = process.env.ROBOFLOW_MODEL_ID!;
  try {
    const base64 = Buffer.from(imageBytes).toString("base64");
    const res = await fetch(
      `https://detect.roboflow.com/${modelId}?api_key=${encodeURIComponent(apiKey)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: base64,
        signal: AbortSignal.timeout(20000),
      },
    );
    if (!res.ok) return { configured: true, detections: [], topType: null, topConfidence: 0 };
    const json = (await res.json()) as {
      predictions?: { class?: string; confidence?: number }[];
    };
    const detections: VisionDetection[] = (json.predictions ?? [])
      .map((p) => ({
        className: String(p.class ?? ""),
        confidence: typeof p.confidence === "number" ? p.confidence : 0,
        incidentType: classToIncidentType(String(p.class ?? "")),
      }))
      .filter((d) => d.className.length > 0)
      .sort((a, b) => b.confidence - a.confidence);
    const top = detections.find((d) => d.incidentType !== null) ?? null;
    return {
      configured: true,
      detections,
      topType: top?.incidentType ?? null,
      topConfidence: top?.confidence ?? 0,
    };
  } catch {
    return { configured: true, detections: [], topType: null, topConfidence: 0 };
  }
}
