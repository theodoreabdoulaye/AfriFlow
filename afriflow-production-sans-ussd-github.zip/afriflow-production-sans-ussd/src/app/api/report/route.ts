import { NextRequest, NextResponse } from "next/server";
import { createHash } from "node:crypto";
import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import { incidentConfirmations, incidents } from "@/db/schema";
import { CITY_MAP, getAxis, type AxisDef } from "@/lib/cities";
import { alreadyCounted } from "@/lib/consensus";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { emitValidatedAlert } from "@/lib/alert-hub";
import { ensureCitySeed } from "@/lib/seed";
import { nearestAxisFast } from "@/lib/spatial";

export const dynamic = "force-dynamic";

const TYPE_KEYWORDS: { type: string; words: string[] }[] = [
  { type: "accident", words: ["accident", "collision", "carambolage", "accidente", "crash"] },
  { type: "inondation", words: ["inond", "eau sur", "pluie", "flood", "alagamento", "enchente"] },
  { type: "travaux", words: ["travaux", "chantier", "construction", "obras", "roadwork"] },
  { type: "police", words: ["police", "contrôle", "controle", "radar", "checkpoint"] },
  { type: "panne", words: ["panne", "en panne", "camion arrêté", "obstacle", "avaria"] },
  { type: "danger", words: ["danger", "nid-de-poule", "nid de poule", "pothole", "buraco", "trou"] },
  { type: "bouchon", words: ["bouchon", "embouteillage", "circulation bloquée", "engarrafamento", "traffic jam", "bloqué"] },
];

function parseType(text: string): string {
  const t = text.toLowerCase();
  for (const { type, words } of TYPE_KEYWORDS) {
    if (words.some((w) => t.includes(w))) return type;
  }
  return "bouchon";
}

function parseSeverity(text: string): number {
  const t = text.toLowerCase();
  if (t.includes("bloquant") || t.includes("bloqué") || t.includes("total")) return 5;
  if (t.includes("fort") || t.includes("grave")) return 4;
  if (t.includes("faible") || t.includes("leger") || t.includes("léger")) return 2;
  return 3;
}

/**
 * POST /api/report — réception des signalements du bot WhatsApp Business.
 * Deux formes acceptées (webhook WhatsApp) :
 *  1) localisation partagée : { from, city, location: { latitude, longitude } }
 *     → le lieu est map-matché sur l'axe le plus proche (index spatial) ;
 *  2) texte libre : { from, city, text: "Accident sur la VDN bloquant", axisId? }
 *     → type et gravité extraits des mots-clés FR/EN/PT.
 * L'incident entre dans le même consensus communautaire (canal whatsapp).
 * Réponse : { incident, reply } — reply = message de retour du bot.
 */
export async function POST(req: NextRequest) {
  const rl = rateLimit(`report:${clientIp(req)}`, 60, 600_000);
  if (!rl.ok) return tooManyRequests(rl.retryAfterSec);

  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    return NextResponse.json({ error: "JSON invalide" }, { status: 400 });
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) {
    return NextResponse.json({ error: "Corps JSON invalide (objet attendu)" }, { status: 400 });
  }
  const body = raw as Record<string, unknown>;

  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404 });

  const from = typeof body.from === "string" ? body.from.slice(0, 32) : "whatsapp-inconnu";
  const deviceHash = `wa-${createHash("sha1").update(from).digest("hex").slice(0, 16)}`;
  const text = typeof body.text === "string" ? body.text.slice(0, 400) : "";

  // Résolution de l'axe : localisation partagée > axisId explicite.
  let axis: AxisDef | null = null;
  const loc = body.location as { latitude?: unknown; longitude?: unknown } | undefined;
  if (loc && Number.isFinite(Number(loc.latitude)) && Number.isFinite(Number(loc.longitude))) {
    const found = nearestAxisFast(city, Number(loc.latitude), Number(loc.longitude), 2500);
    axis = found?.axis ?? null;
  }
  if (!axis && typeof body.axisId === "string") {
    axis = getAxis(city, body.axisId) ?? null;
  }
  if (!axis) {
    return NextResponse.json(
      {
        error: "Aucun axe identifié : partagez votre localisation WhatsApp ou précisez l'axe.",
        reply: "📍 Je n'ai pas pu situer l'incident. Touchez 📎 → Localisation dans WhatsApp et partagez votre position, ou précisez le nom de la route.",
      },
      { status: 422 },
    );
  }

  const type = parseType(text || String(body.type ?? ""));
  const severity = parseSeverity(text);
  const network = ["orange", "mtn", "moov", "airtel"].includes(String(body.network))
    ? String(body.network)
    : "orange";

  await ensureCitySeed(city);
  // Contact remerciable : numéro WhatsApp au format international.
  const reporterContact = /^\+?\d{8,15}$/.test(from.replace(/[\s-]/g, "")) ? from : null;
  try {
    // Même logique de fusion que l'API communautaire : incident du même
    // type sur l'axe < 45 min → confirmation de ce conducteur.
    const windowStart = new Date(Date.now() - 45 * 60_000);
    const similar = await db
      .select()
      .from(incidents)
      .where(
        and(
          eq(incidents.city, city.id),
          eq(incidents.axisId, axis.id),
          eq(incidents.type, type),
          gte(incidents.createdAt, windowStart),
        ),
      )
      .orderBy(desc(incidents.createdAt))
      .limit(1);

    if (similar.length > 0) {
      const target = similar[0];
      const prior = await db
        .select()
        .from(incidentConfirmations)
        .where(eq(incidentConfirmations.incidentId, target.id));
      if (!alreadyCounted(prior, network, deviceHash)) {
        await db.insert(incidentConfirmations).values({
          incidentId: target.id,
          network,
          channel: "whatsapp",
          deviceHash,
          reporterContact,
        });
        const [updated] = await db
          .update(incidents)
          .set({
            confirmations: sql`${incidents.confirmations} + 1`,
            confidence: sql`CASE WHEN ${incidents.confirmations} + 1 >= 3 THEN 98 WHEN ${incidents.confirmations} + 1 = 2 THEN 71 ELSE 38 END`,
            status: sql`CASE WHEN ${incidents.confirmations} + 1 >= 3 THEN 'broadcast' WHEN ${incidents.confirmations} + 1 = 2 THEN 'confirmed' ELSE 'pending' END`,
            updatedAt: new Date(),
          })
          .where(eq(incidents.id, target.id))
          .returning();
        if (updated.status === "broadcast" && target.status !== "broadcast") {
          emitValidatedAlert(city, updated);
        }
        return NextResponse.json({
          incident: updated,
          reply: `✅ Merci ! Votre message confirme l'incident sur ${axis.name}. Confiance portée à ${updated.confidence} % (${updated.confirmations}/3 confirmations).${updated.status === "broadcast" ? " 📣 Alerte diffusée à toute la ville !" : ""}`,
        });
      }
      return NextResponse.json({
        incident: target,
        reply: `Vous avez déjà contribué à ce signalement sur ${axis.name} — une seule voix par conducteur. Merci !`,
      });
    }

    const [created] = await db
      .insert(incidents)
      .values({
        city: city.id,
        axisId: axis.id,
        type,
        severity,
        channel: "whatsapp",
        network,
        description: text ? text.slice(0, 280) : `Signalement WhatsApp (localisation partagée) — ${axis.name}.`,
        confirmations: 1,
        confidence: 38,
        status: "pending",
      })
      .returning();
    await db.insert(incidentConfirmations).values({
      incidentId: created.id,
      network,
      channel: "whatsapp",
      deviceHash,
      reporterContact,
    });
    return NextResponse.json(
      {
        incident: created,
        reply: `🚨 Incident enregistré sur ${axis.name} (gravité ${severity}/5, confiance 38 %). Deux autres conducteurs doivent confirmer pour diffuser l'alerte à toute la ville. Merci pour votre signalement !`,
      },
      { status: 201 },
    );
  } catch {
    return NextResponse.json({ error: "Signalement WhatsApp indisponible" }, { status: 503 });
  }
}
