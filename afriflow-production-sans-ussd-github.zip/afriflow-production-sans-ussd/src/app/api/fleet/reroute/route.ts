import { NextRequest, NextResponse } from "next/server";
import { requirePaidAccess } from "@/lib/access";
import { requireSameOrigin } from "@/lib/auth";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { fleetVehicles } from "@/db/schema";
import { CITY_MAP } from "@/lib/cities";
import { clientIp, rateLimit, tooManyRequests } from "@/lib/rate-limit";
import { buildFleet, buildHeatmap } from "@/lib/server-data";
import { ensureCitySeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

/**
 * POST /api/fleet/reroute { city, vehicleIds? }
 * Reroutage collectif en 1 clic : les camions bloqués / ralentis sont
 * répartis sur les délestages les plus fluides (jamais tous sur le même
 * axe, pour ne pas créer un nouveau bouchon). Ordres par SMS + WhatsApp.
 */
export async function POST(req: NextRequest) {
  if (!requireSameOrigin(req)) return Response.json({ error: "Forbidden origin" }, { status: 403, headers: { "Cache-Control": "private, no-store" } });
  const denied = await requirePaidAccess();
  if (denied) return denied;
  const rl = rateLimit(`reroute:${clientIp(req)}`, 60, 600_000);
  if (!rl.ok) {
    const response = tooManyRequests(rl.retryAfterSec);
    response.headers.set("Cache-Control", "private, no-store");
    return response;
  }

  let body: Record<string, unknown> = {};
  try {
    const parsed: unknown = await req.json();
    if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
      body = parsed as Record<string, unknown>;
    }
  } catch {
    /* corps optionnel */
  }
  const city = CITY_MAP[String(body.city ?? "dakar")];
  if (!city) return NextResponse.json({ error: "Ville inconnue" }, { status: 404, headers: { "Cache-Control": "private, no-store" } });

  const onlyIds = Array.isArray(body.vehicleIds)
    ? (body.vehicleIds as unknown[]).map(Number).filter(Number.isFinite)
    : null;

  await ensureCitySeed(city);
  const heat = await buildHeatmap(city);
  const fleet = await buildFleet(city, heat);
  const targets = fleet.filter(
    (v) =>
      (v.status === "Bloqué" || v.status === "Ralentissement") &&
      (!onlyIds || onlyIds.includes(v.id)),
  );
  if (targets.length === 0) {
    return NextResponse.json({ rerouted: [], message: "Aucun camion à rerouter pour le moment." }, { headers: { "Cache-Control": "private, no-store" } });
  }

  // Délestages candidats : axes les plus fluides, hors zones protégées bloquées.
  const candidates = [...heat.axes]
    .filter((a) => !a.protectedBlocked)
    .sort((a, b) => b.fluidity - a.fluidity)
    .slice(0, 4);
  if (candidates.length === 0) {
    return NextResponse.json({ rerouted: [], message: "Aucun délestage disponible (zones protégées saturées)." }, { headers: { "Cache-Control": "private, no-store" } });
  }

  const rerouted: { vehicleId: number; plate: string; fromAxis: string; toAxis: string; toAxisName: string; channel: string }[] = [];
  let cursor = 0;
  try {
    // D'abord, on « libère » les surlignages précédents de ce convoi.
    await db.update(fleetVehicles).set({ convoy: false }).where(eq(fleetVehicles.city, city.id));
    for (const v of targets) {
      const dest = candidates[cursor % candidates.length];
      cursor++;
      await db
        .update(fleetVehicles)
        .set({ axisId: dest.axisId, convoy: true, status: "En mouvement", updatedAt: new Date() })
        .where(eq(fleetVehicles.id, v.id));
      rerouted.push({
        vehicleId: v.id,
        plate: v.plate,
        fromAxis: v.axisId,
        toAxis: dest.axisId,
        toAxisName: dest.name,
        channel: "SMS + WhatsApp",
      });
    }
  } catch {
    return NextResponse.json({ error: "Reroutage indisponible" }, { status: 503, headers: { "Cache-Control": "private, no-store" } });
  }

  return NextResponse.json({
    rerouted,
    message: `${rerouted.length} camion(s) rerouté(s), répartis sur ${Math.min(candidates.length, rerouted.length)} délestage(s). Ordres envoyés par SMS + WhatsApp.`,
  }, { headers: { "Cache-Control": "private, no-store" } });
}
