import type { CityDef } from "./cities";

/**
 * Client Overpass (OpenStreetMap) robuste — comptage réel des chantiers
 * routiers autour d'une ville.
 *
 * Constat d'audit : les instances publiques historiques (overpass-api.de,
 * kumi.systems, private.coffee) expirent ou renvoient 502/504 depuis le
 * réseau de production, tandis que l'instance OSM France répond en < 1 s.
 * Stratégie :
 * - pool d'instances avec affinité (la dernière instance qui a répondu
 *   est essayée en premier), bascule séquentielle en cas d'échec ;
 * - disjoncteur par hôte : 2 échecs consécutifs → hôte ignoré 10 min ;
 * - cache par ville : valeur fraîche 6 h, valeur périmée toujours servie
 *   avec son âge (jamais d'écran « indisponible » si on a déjà une mesure) ;
 * - actualisation en arrière-plan, jamais bloquante pour l'appelant ;
 * - User-Agent identifié, requêtes coalescées par ville (politique OSM).
 */

export interface ConstructionSnapshot {
  count: number | null;
  state: "fresh" | "stale" | "refreshing" | "unavailable";
  endpoint: string | null;
  fetchedAt: number | null;
  durationMs: number | null;
}

interface EndpointDef {
  url: string;
  label: string;
}

const ENDPOINTS: EndpointDef[] = [
  { url: "https://overpass.openstreetmap.fr/api/interpreter", label: "OSM France" },
  { url: "https://overpass-api.de/api/interpreter", label: "overpass-api.de" },
  { url: "https://overpass.kumi.systems/api/interpreter", label: "kumi.systems" },
  { url: "https://overpass.private.coffee/api/interpreter", label: "private.coffee" },
  { url: "https://maps.mail.ru/osm/tools/overpass/api/interpreter", label: "mail.ru" },
];

const FRESH_MS = 6 * 3600_000;
const COOLDOWN_MS = 10 * 60_000;
const ATTEMPT_TIMEOUT_MS = 18_000;
const MAX_ATTEMPTS = 4;

interface HostState {
  consecutiveFailures: number;
  cooldownUntil: number;
}

interface CityEntry {
  count: number;
  endpoint: string;
  fetchedAt: number;
  durationMs: number;
}

const hosts = new Map<string, HostState>();
const entries = new Map<string, CityEntry>();
const inflight = new Map<string, Promise<void>>();
let lastGoodHost: string | null = null;

function orderedEndpoints(): EndpointDef[] {
  const now = Date.now();
  return [...ENDPOINTS].sort((a, b) => {
    const ha = hosts.get(a.url);
    const hb = hosts.get(b.url);
    const coolA = ha && ha.cooldownUntil > now ? 1 : 0;
    const coolB = hb && hb.cooldownUntil > now ? 1 : 0;
    if (coolA !== coolB) return coolA - coolB;
    const goodA = a.url === lastGoodHost ? 0 : 1;
    const goodB = b.url === lastGoodHost ? 0 : 1;
    return goodA - goodB;
  });
}

function registerFailure(url: string): void {
  const h = hosts.get(url) ?? { consecutiveFailures: 0, cooldownUntil: 0 };
  h.consecutiveFailures += 1;
  if (h.consecutiveFailures >= 2) {
    h.cooldownUntil = Date.now() + COOLDOWN_MS;
    h.consecutiveFailures = 0;
  }
  hosts.set(url, h);
}

function registerSuccess(url: string): void {
  hosts.set(url, { consecutiveFailures: 0, cooldownUntil: 0 });
  lastGoodHost = url;
}

async function tryEndpoint(
  ep: EndpointDef,
  city: CityDef,
): Promise<{ count: number; durationMs: number } | null> {
  const started = performance.now();
  // Requête minimale : comptage des voies en chantier, rayon 7 km.
  const query = `[out:json][timeout:15];way["highway"="construction"](around:7000,${city.lat},${city.lon});out count;`;
  try {
    const res = await fetch(ep.url, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        "User-Agent": "AfriFlow/2.6 (plateforme trafic Afrique de l'Ouest; contact: dev@afriflow.app)",
      },
      body: `data=${encodeURIComponent(query)}`,
      signal: AbortSignal.timeout(ATTEMPT_TIMEOUT_MS),
      cache: "no-store",
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = (await res.json()) as { elements?: { tags?: Record<string, string> }[] };
    const tags = json?.elements?.[0]?.tags ?? {};
    const n = Number(tags.ways ?? tags.total ?? NaN);
    if (!Number.isFinite(n)) throw new Error("Réponse Overpass illisible");
    registerSuccess(ep.url);
    return { count: n, durationMs: Math.round(performance.now() - started) };
  } catch {
    registerFailure(ep.url);
    return null;
  }
}

async function refresh(city: CityDef): Promise<void> {
  for (const ep of orderedEndpoints().slice(0, MAX_ATTEMPTS)) {
    const result = await tryEndpoint(ep, city);
    if (result) {
      entries.set(city.id, {
        count: result.count,
        endpoint: ep.label,
        fetchedAt: Date.now(),
        durationMs: result.durationMs,
      });
      return;
    }
  }
}

/** Déclenche une actualisation en arrière-plan si la valeur est absente ou périmée. */
export function triggerConstructionRefresh(city: CityDef): void {
  if (inflight.has(city.id)) return;
  const entry = entries.get(city.id);
  if (entry && Date.now() - entry.fetchedAt < FRESH_MS) return;
  const task = refresh(city).finally(() => inflight.delete(city.id));
  inflight.set(city.id, task);
  void task;
}

/** État instantané (jamais bloquant) du comptage pour une ville. */
export function constructionSnapshot(city: CityDef): ConstructionSnapshot {
  const entry = entries.get(city.id);
  if (entry) {
    const fresh = Date.now() - entry.fetchedAt < FRESH_MS;
    return {
      count: entry.count,
      state: fresh ? "fresh" : "stale",
      endpoint: entry.endpoint,
      fetchedAt: entry.fetchedAt,
      durationMs: entry.durationMs,
    };
  }
  return {
    count: null,
    state: inflight.has(city.id) ? "refreshing" : "unavailable",
    endpoint: null,
    fetchedAt: null,
    durationMs: null,
  };
}
